# Foraggio.py

# https://www.lazoovet.it/wp-content/uploads/2021/04/FIENO-DI-MEDICA-3-Tg-NIR-Ed2.pdf
# https://www.lazoovet.it/wp-content/uploads/2021/04/FIENO-DI-LOIETTO-NIR-CNCPS-Ed2.pdf
# https://www.lazoovet.it/wp-content/uploads/2021/04/INSILATO-DI-LOIETTO-NIR-CNCPS-Ed2.pdf

# https://www.lazoovet.it/documenti/

erba_loietto = [17, 1.7, 1.3, 0.4, 4.4, 9.7, 5.2, 0.5, 0.001, 0.001, 1.7, 0.06, 0.05, 0.02, 0.39, 0.03, 0.003, 0.15, 0.15, 259.5, 1.09] 
erba_medica_II_taglio = [20, 4.5, 3.4, 1.1, 7, 9.7, 5.2, 0.5, 0.001, 0.001, 1.7, 0.06, 0.05, 0.02, 0.39, 0.03, 0.003, 0.21, 0.15, 259.5, 1.09] 

# alfalfa meal
# Dell'Orto - Savoini (2005)
erba_medica_disidratata_15x100 = [91, 14.8, 6.07, 8.73, 27.9, 43.6, 34.5, 2.5, 0.001, 3, 8.7, 1.32, 0.21, 0.23, 1.8, 0.2, 0.08, 0.54, 0.57, 986.1, 4.13]
# NUTRIENT REQUIREMENT OF DAIRY CATTLE - Eighth Revised Edition
erba_medica_disidratata_17x100 = [92, 16.8, 6.89, 9.91, 26.5, 43.2, 32.1, 2.8, 1.63, 7.53, 9.5, 1.32, 0.26, 0.26, 2.15, 0.23, 0.09, 0.56, 0.59, 1020.7, 4.27]    

erba_prato_stabile = [17, 2.2, 1.8, 0.4, 4.8, 9.1, 5.7, 0.7, 0.001, 0.001, 1.6, 0.11, 0.06, 0.05, 0.25, 0.03, 0.002, 0.15, 0.15, 259.5, 1.09] 

# Golder, H. M., Celi, P., Rabiee, A. R., Heuer, C., Bramley, E., Miller, D. W., ... & Lean, I. J. (2012). Effects of grain, fructose, and histidine on ruminal pH and fermentation products during an induced subacute acidosis protocol. Journal of dairy science, 95(4), 1971-1982.
insilato_loietto = [35, 3.05, 2.45, 0.6, 10.8, 22.4, 12.25, 1.12, 0.59, 2.62, 2.52, 0.11, 0.09, 0.03, 0.7, 0.06, 0.005, 0.31, 0.26, 449.8, 1.88] 

insilato_mais = [33, 2.54, 1.85, 0.69, 6.7, 14.9, 8.5, 1.0, 10, 0.99, 1.56, 0.07, 0.08, 0.04, 0.31, 0.04, 0.003, 0.28, 0.28, 484.4, 2.03]
pastone_mais_granella = [68.8, 6.88, 4.34, 2.54, 1.7, 6.9, 2.3, 2.9, 49.5, 1.2, 1.0, 0.01, 0.21, 0.08, 0.3, 0.07, 0.01, 0.8, 0.84, 1453.2, 6.08]
pastone_mais_integrale = [57.2, 4.9, 3.1, 1.8, 3.6, 11.4, 4.5, 2.34, 34.8, 1.1, 0.97, 0.03, 0.19, 0.08, 0.29, 0.07, 0.02, 0.55, 0.58, 1003.4, 4.2]
fieno_loietto = [87, 8.08, 5.0, 3.0, 27.0, 48.0, 31.3, 2.6, 2.26, 15.14, 9.4, 0.31, 0.25, 0.08, 2.0, 1.7, 0.02, 0.57, 0.63, 1089.9, 4.56]   
fieno_medica_I_taglio = [87, 15.3, 11.0, 4.3, 26.3, 45.0, 39.5, 2.2, 2.47, 3.83, 8.5, 1.4, 0.26, 0.17, 1.8, 0.42, 0.18, 0.43, 0.57, 986.1, 4.13]   
fieno_medica_II_taglio = [87, 16.6, 12.0, 4.6, 27.2, 47.0, 40.9, 2.5, 2.47, 3.83, 8.5, 1.4, 0.26, 0.17, 1.8, 0.42, 0.18, 0.63, 0.58, 1003.4, 4.2]    
fieno_silos_medica = [40, 8.8, 7.0, 1.8, 13.6, 21.6, 16.5, 1.28, 0.001, 0.001, 4.0, 0.7, 0.14, 0.13, 1.0, 0.11, 0.55, 0.27, 0.28, 484.4, 2.03]    

# https://www.crpa.it/media/documents/crpa_www/Pubblicazi/Opuscoli-C/Archivio_2009/CRPA_5_2009.pdf
fieno_prato_stabile_I_taglio = [87, 9.5, 6.0, 3.5, 30.0, 46.5, 34.8, 2.6, 1.78, 7.34, 7.7, 0.42, 0.23, 0.25, 1.3, 0.15, 0.009, 0.41, 0.61, 1055.3, 4.42]   
fieno_prato_stabile_II_taglio = [87, 10.0, 6.3, 3.7, 26.0, 45.0, 29.7, 3.2, 1.78, 7.34, 7.0, 0.6, 0.3, 0.25, 1.3, 0.15, 0.009, 0.54, 0.65, 1124.5, 4.71]

paglia_frumento = [88, 3.2, 0.64, 2.56, 40.0, 70.0, 50.0, 2.0, 0.001, 0.001, 8.0, 3.2, 0.9, 0.1, 1.24, 0.17, 0.12, 0.3, 0.37, 640.1, 2.68]
