# importa_MySQLdb_cruschello_frumento_tenero.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    cruschello_frumento_tenero = []

    for i in parametri:
        i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'cruschello_frumento_tenero'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        cruschello_frumento_tenero.append(float(i[0]))
#   print(CRUSCHFRUTE)

    CRUSCHFRUTE = list(np.float_(cruschello_frumento_tenero))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <cruschello_frumento_tenero> dal modulo <Fonte_di_fibra>') 
    from Fonte_di_fibra import cruschello_frumento_tenero
    print('<cruschello_frumento_tenero> importato con successo dal modulo <Fonte_di_fibra>!')

    CRUSCHFRUTE = list(np.float_(cruschello_frumento_tenero))

    del CRUSCHFRUTE[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del CRUSCHFRUTE[10]
# elimino 'ceneri'

    del CRUSCHFRUTE[13:15]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <CRUSCHFRUTE> => %d' % len(CRUSCHFRUTE))

    for i in range(len(CRUSCHFRUTE)):
        CRUSCHFRUTE[i] = CRUSCHFRUTE[i]*10

    CRUSCHFRUTE[0] = CRUSCHFRUTE[0]/1000
    CRUSCHFRUTE[12] = CRUSCHFRUTE[12]/10

    CRUSCHFRUTE_arr = np.array(CRUSCHFRUTE)

    for i in range(len(CRUSCHFRUTE)):
        CRUSCHFRUTE[i] = float(CRUSCHFRUTE[i])

print("COMPOSIZIONE CHIMICA dell'alimento <CRUSCHELLO DI FRUMENTO TENERO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % CRUSCHFRUTE_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % CRUSCHFRUTE_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % CRUSCHFRUTE_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % CRUSCHFRUTE_arr[3])
print("Fibra Grezza (FG) => %f g" % CRUSCHFRUTE_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % CRUSCHFRUTE_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % CRUSCHFRUTE_arr[6])
print("FAT (Grasso) => %f g" % CRUSCHFRUTE_arr[7])
print("AM (Amido) => %f g" % CRUSCHFRUTE_arr[8])
print("ZUC (Zuccheri) => %f g" % CRUSCHFRUTE_arr[9])
print("Ca (Calcio) => %f g" % CRUSCHFRUTE_arr[10])
print("P (Fosforo) => %f g" % CRUSCHFRUTE_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % CRUSCHFRUTE_arr[12])
print('')

# sio.sCRUSCHFRUTEemat('CRUSCHFRUTE.mat', {'vect':CRUSCHFRUTE})
