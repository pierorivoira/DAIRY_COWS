# importa_MySQLdb_fieno_loietto_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
    fieno_loietto = []

    for i in parametri:
        i = "SELECT %s FROM Foraggio_Lys_Met WHERE nome = 'fieno_loietto'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        fieno_loietto.append(float(i[0]))
#   print(fieno_loietto)

    FIELO = list(np.float_(fieno_loietto))

except mysql.connector.Error as err:
  print("Server non raggiungibile: {}".format(err))
  print('Provo ad importare <fieno_loietto> dal modulo <foraggio_LYS_MET>') 
  from foraggio_LYS_MET import fieno_loietto
  print('<fieno_loietto> importato con successo dal modulo <foraggio_LYS_MET>!')

FIELO = list(np.float_(fieno_loietto))

del FIELO[10]
del FIELO[12:16]
del FIELO[12]
del FIELO[13]

FIELO[0] = FIELO[0]/100

for i in list(range(1, 12)):
	FIELO[i] = FIELO[i]*10

FIELO[16] = FIELO[16]*FIELO[15]/100
FIELO[17] = FIELO[17]*FIELO[15]/100

del FIELO[13]
# elimina Mj

del FIELO[2:4]
# elimina RDP e RUP

PDIE_FIELO = FIELO[12]
LysDI_FIELO = FIELO[13]
MetDI_FIELO = FIELO[14]

LysDI_MetDI_ratio = LysDI_FIELO/MetDI_FIELO

FIELO_mod = FIELO[0:12]
FIELO_arr = np.array(FIELO_mod)

for i in range(len(FIELO_mod)):
    FIELO_mod[i] = float(FIELO_mod[i])

print('')
print("COMPOSIZIONE CHIMICA dell'alimento <FIENO DI LOIETTO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % FIELO_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % FIELO_arr[1])
print("Fibra Grezza (FG) => %f g" % FIELO_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % FIELO_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % FIELO_arr[4])
print("FAT (Grasso) => %f g" % FIELO_arr[5])
print("AM (Amido) => %f g" % FIELO_arr[6])
print("ZUC (Zuccheri) => %f g" % FIELO_arr[7])
print("Ca (Calcio) => %f g" % FIELO_arr[8])
print("P (Fosforo) => %f g" % FIELO_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % FIELO_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % FIELO_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.savemat('FIELO.mat', {'vect':FIELO})
