# importa_MySQLdb_insilato_loietto_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
    insilato_loietto = []

    for i in parametri:
        i = "SELECT %s FROM Foraggio_Lys_Met WHERE nome = 'insilato_loietto'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        insilato_loietto.append(float(i[0]))
#   print(insilato_loietto)

    INSILO = list(np.float_(insilato_loietto))

except mysql.connector.Error as err:
  print("Server non raggiungibile: {}".format(err))
  print('Provo ad importare <insilato_loietto> dal modulo <foraggio_LYS_MET>') 
  from foraggio_LYS_MET import insilato_loietto
  print('<insilato_loietto> importato con successo dal modulo <foraggio_LYS_MET>!')

INSILO = list(np.float_(insilato_loietto))

del INSILO[10]
del INSILO[12:16]
del INSILO[12]
del INSILO[13]

INSILO[0] = INSILO[0]/100

for i in list(range(1, 12)):
	INSILO[i] = INSILO[i]*10

INSILO[16] = INSILO[16]*INSILO[15]/100
INSILO[17] = INSILO[17]*INSILO[15]/100

del INSILO[13]
# elimina Mj

del INSILO[2:4]
# elimina RDP e RUP

PDIE_INSILO = INSILO[12]
LysDI_INSILO = INSILO[13]
MetDI_INSILO = INSILO[14]

LysDI_MetDI_ratio = LysDI_INSILO/MetDI_INSILO

INSILO_mod = INSILO[0:12]
INSILO_arr = np.array(INSILO_mod)

for i in range(len(INSILO_mod)):
    INSILO_mod[i] = float(INSILO_mod[i])

print('')
print("COMPOSIZIONE CHIMICA dell'alimento <INSILATO DI LOIETTO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % INSILO_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % INSILO_arr[1])
print("Fibra Grezza (FG) => %f g" % INSILO_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % INSILO_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % INSILO_arr[4])
print("FAT (Grasso) => %f g" % INSILO_arr[5])
print("AM (Amido) => %f g" % INSILO_arr[6])
print("ZUC (Zuccheri) => %f g" % INSILO_arr[7])
print("Ca (Calcio) => %f g" % INSILO_arr[8])
print("P (Fosforo) => %f g" % INSILO_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % INSILO_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % INSILO_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.savemat('INSILO.mat', {'vect':INSILO})
