# importa_MySQLdb_mais_residui_distilleria_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
    mais_residui_distilleria = []

    for i in parametri:
        i = "SELECT %s FROM Fonte_di_fibra_Lys_Met WHERE nome = 'mais_residui_distilleria'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        mais_residui_distilleria.append(float(i[0]))
#   print(mais_residui_distilleria)

    MAISDIST = list(np.float_(mais_residui_distilleria))

except mysql.connector.Error as err:
  print("Server non raggiungibile: {}".format(err))
  print('Provo ad importare <mais_residui_distilleria> dal modulo <fonte_di_fibra_LYS_MET>') 
  from fonte_di_fibra_LYS_MET import mais_residui_distilleria
  print('<mais_residui_distilleria> importato con successo dal modulo <fonte_di_fibra_LYS_MET>!')

MAISDIST = list(np.float_(mais_residui_distilleria))

del MAISDIST[10]
del MAISDIST[12:16]
del MAISDIST[12]
del MAISDIST[13]

MAISDIST[0] = MAISDIST[0]/100

for i in list(range(1, 12)):
	MAISDIST[i] = MAISDIST[i]*10

MAISDIST[16] = MAISDIST[16]*MAISDIST[15]/100
MAISDIST[17] = MAISDIST[17]*MAISDIST[15]/100

del MAISDIST[13]
# elimina Mj

del MAISDIST[2:4]
# elimina RDP e RUP

PDIE_MAISDIST = MAISDIST[12]
LysDI_MAISDIST = MAISDIST[13]
MetDI_MAISDIST = MAISDIST[14]

LysDI_MetDI_ratio = LysDI_MAISDIST/MetDI_MAISDIST

MAISDIST_mod = MAISDIST[0:12]
MAISDIST_arr = np.array(MAISDIST_mod)

for i in range(len(MAISDIST_mod)):
    MAISDIST_mod[i] = float(MAISDIST_mod[i])

print('')
print("COMPOSIZIONE CHIMICA dell'alimento <MAIS RESIDUI DI DISTILLERIA>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % MAISDIST_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % MAISDIST_arr[1])
print("Fibra Grezza (FG) => %f g" % MAISDIST_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % MAISDIST_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % MAISDIST_arr[4])
print("FAT (Grasso) => %f g" % MAISDIST_arr[5])
print("AM (Amido) => %f g" % MAISDIST_arr[6])
print("ZUC (Zuccheri) => %f g" % MAISDIST_arr[7])
print("Ca (Calcio) => %f g" % MAISDIST_arr[8])
print("P (Fosforo) => %f g" % MAISDIST_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % MAISDIST_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % MAISDIST_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.sMAISDISTemat('MAISDIST.mat', {'vect':MAISDIST})
