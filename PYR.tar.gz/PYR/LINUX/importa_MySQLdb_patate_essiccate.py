# importa_MySQLdb_patate_essiccate.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    patate_essiccate = []

    for i in parametri:
        i = "SELECT %s FROM Sottoprodotto WHERE nome = 'patate_essiccate'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        patate_essiccate.append(float(i[0]))
#   print(PAESSI)

    PAESSI = list(np.float_(patate_essiccate))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <patate_essiccate> dal modulo <Sottoprodotto>') 
    from Sottoprodotto import  patate_essiccate
    print('<patate_essiccate> importato con successo dal modulo <Sottoprodotto>!')

    PAESSI = list(np.float_(patate_essiccate))

    del PAESSI[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del PAESSI[10]
# elimino 'ceneri'

    del PAESSI[13:17]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <PAESSI> => %d' % len(PAESSI))

    for i in range(len(PAESSI)):
        PAESSI[i] = PAESSI[i]*10

    PAESSI[0] = PAESSI[0]/1000
    PAESSI[12] = PAESSI[12]/10

    PAESSI_arr = np.array(PAESSI)

    for i in range(len(PAESSI)):
        PAESSI[i] = float(PAESSI[i])

print("COMPOSIZIONE CHIMICA dell'alimento <PATATE ESSICCATE>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % PAESSI_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % PAESSI_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % PAESSI_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % PAESSI_arr[3])
print("Fibra Grezza (FG) => %f g" % PAESSI_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % PAESSI_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % PAESSI_arr[6])
print("FAT (Grasso) => %f g" % PAESSI_arr[7])
print("AM (Amido) => %f g" % PAESSI_arr[8])
print("ZUC (Zuccheri) => %f g" % PAESSI_arr[9])
print("Ca (Calcio) => %f g" % PAESSI_arr[10])
print("P (Fosforo) => %f g" % PAESSI_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % PAESSI_arr[12])
print('')

# sio.sPAESSIemat('PAESSI.mat', {'vect':PAESSI})
