# stampa_composizione_alimenti.py

# https://medium.com/analytics-vidhya/importing-data-from-a-mysql-database-into-pandas-data-frame-a06e392d27d7
# https://towardsdatascience.com/how-to-export-pandas-dataframe-to-csv-2038e43d9c03


import mysql.connector, os
import pandas as pd
import numpy as np
HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"
DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
query = "Select * from Foraggio;"
pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', None)
Foraggio = pd.read_sql(query,DB)
Foraggio.to_csv('Foraggio.csv')

# in R:
# foraggio = read.csv('/home/piero/PYTHON/LINUX/Foraggio.csv')
