# importa_MySQLdb_agrumi_pastazzo_secco.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
AGRPASE = []

for i in parametri:
	i = "SELECT %s FROM Sottoprodotto WHERE nome = 'agrumi_pastazzo_secco'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	AGRPASE.append(float(i[0]))
#   print(AGRPASE)

AGRPASE = list(np.float_(AGRPASE))

del AGRPASE[13:18]
del AGRPASE[10]
del AGRPASE[13:15]

AGRPASE[0] = AGRPASE[0]/100
AGRPASE[1] = AGRPASE[1]*10
AGRPASE[2] = AGRPASE[2]*10
AGRPASE[3] = AGRPASE[3]*10
AGRPASE[4] = AGRPASE[4]*10
AGRPASE[5] = AGRPASE[5]*10
AGRPASE[6] = AGRPASE[6]*10
AGRPASE[7] = AGRPASE[7]*10
AGRPASE[8] = AGRPASE[8]*10
AGRPASE[9] = AGRPASE[9]*10
AGRPASE[10] = AGRPASE[10]*10
AGRPASE[11] = AGRPASE[11]*10

AGRPASE_arr = np.array(AGRPASE)

for i in range(len(AGRPASE)):
    AGRPASE[i] = float(AGRPASE[i])

print("COMPOSIZIONE CHIMICA dell'alimento <PASTAZZO SECCO DI AGRUMI>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % AGRPASE_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % AGRPASE_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % AGRPASE_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % AGRPASE_arr[3])
print("Fibra Grezza (FG) => %f g" % AGRPASE_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % AGRPASE_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % AGRPASE_arr[6])
print("FAT (Grasso) => %f g" % AGRPASE_arr[7])
print("AM (Amido) => %f g" % AGRPASE_arr[8])
print("ZUC (Zuccheri) => %f g" % AGRPASE_arr[9])
print("Ca (Calcio) => %f g" % AGRPASE_arr[10])
print("P (Fosforo) => %f g" % AGRPASE_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % AGRPASE_arr[12])
print('')

# sio.sAGRPASEemat('AGRPASE.mat', {'vect':AGRPASE})
