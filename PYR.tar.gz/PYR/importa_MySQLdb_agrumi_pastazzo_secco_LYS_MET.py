# importa_MySQLdb_agrumi_pastazzo_secco_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
agrumi_pastazzo_secco = []

for i in parametri:
	i = "SELECT %s FROM Sottoprodotto_Lys_Met WHERE nome = 'agrumi_pastazzo_secco'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	agrumi_pastazzo_secco.append(float(i[0]))

AGRPASE = list(np.float_(agrumi_pastazzo_secco))

del AGRPASE[10]
del AGRPASE[12:16]
del AGRPASE[12]
del AGRPASE[13]


AGRPASE[0] = AGRPASE[0]/100

for i in list(range(1, 12)):
	AGRPASE[i] = AGRPASE[i]*10

AGRPASE[16] = AGRPASE[16]*AGRPASE[15]/100
AGRPASE[17] = AGRPASE[17]*AGRPASE[15]/100

del AGRPASE[13]
# elimina i Mj

del AGRPASE[2:4]
# elimina RDP ed RUP

PDIE_AGRPASE = AGRPASE[12]
LysDI_AGRPASE = AGRPASE[13]
MetDI_AGRPASE = AGRPASE[14]

LysDI_MetDI_ratio = LysDI_AGRPASE/MetDI_AGRPASE

AGRPASE_mod = AGRPASE[0:12]
AGRPASE_arr = np.array(AGRPASE_mod)

for i in range(len(AGRPASE_mod)):
    AGRPASE_mod[i] = float(AGRPASE_mod[i])

print("COMPOSIZIONE CHIMICA dell'alimento <PASTAZZO SECCO DI AGRUMI>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % AGRPASE_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % AGRPASE_arr[1])
print("Fibra Grezza (FG) => %f g" % AGRPASE_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % AGRPASE_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % AGRPASE_arr[4])
print("FAT (Grasso) => %f g" % AGRPASE_arr[5])
print("AM (Amido) => %f g" % AGRPASE_arr[6])
print("ZUC (Zuccheri) => %f g" % AGRPASE_arr[7])
print("Ca (Calcio) => %f g" % AGRPASE_arr[8])
print("P (Fosforo) => %f g" % AGRPASE_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % AGRPASE_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % AGRPASE_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.sAGRPASEemat('AGRPASE.mat', {'vect':AGRPASE})
