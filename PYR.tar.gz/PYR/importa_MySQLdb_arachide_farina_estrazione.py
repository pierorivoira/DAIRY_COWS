# importa_MySQLdb_arachide_farina_estrazione.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
ARAFAESTR = []

for i in parametri:
	i = "SELECT %s FROM Farina_di_estrazione WHERE nome = 'arachide_farina_estrazione'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	ARAFAESTR.append(float(i[0]))
#   print(ARAFAESTR)

ARAFAESTR = list(np.float_(ARAFAESTR))

del ARAFAESTR[13:18]
del ARAFAESTR[10]
del ARAFAESTR[13:15]

ARAFAESTR[0] = ARAFAESTR[0]/100
ARAFAESTR[1] = ARAFAESTR[1]*10
ARAFAESTR[2] = ARAFAESTR[2]*10
ARAFAESTR[3] = ARAFAESTR[3]*10
ARAFAESTR[4] = ARAFAESTR[4]*10
ARAFAESTR[5] = ARAFAESTR[5]*10
ARAFAESTR[6] = ARAFAESTR[6]*10
ARAFAESTR[7] = ARAFAESTR[7]*10
ARAFAESTR[8] = ARAFAESTR[8]*10
ARAFAESTR[9] = ARAFAESTR[9]*10
ARAFAESTR[10] = ARAFAESTR[10]*10
ARAFAESTR[11] = ARAFAESTR[11]*10

ARAFAESTR_arr = np.array(ARAFAESTR)

print("COMPOSIZIONE CHIMICA dell'alimento <FARINA DI ESTRAZIONE DI ARACHIDE>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % ARAFAESTR_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % ARAFAESTR_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % ARAFAESTR_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % ARAFAESTR_arr[3])
print("Fibra Grezza (FG) => %f g" % ARAFAESTR_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % ARAFAESTR_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % ARAFAESTR_arr[6])
print("FAT (Grasso) => %f g" % ARAFAESTR_arr[7])
print("AM (Amido) => %f g" % ARAFAESTR_arr[8])
print("ZUC (Zuccheri) => %f g" % ARAFAESTR_arr[9])
print("Ca (Calcio) => %f g" % ARAFAESTR_arr[10])
print("P (Fosforo) => %f g" % ARAFAESTR_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % ARAFAESTR_arr[12])
print('')
# sio.sARAFAESTRemat('ARAFAESTR.mat', {'vect':ARAFAESTR})
