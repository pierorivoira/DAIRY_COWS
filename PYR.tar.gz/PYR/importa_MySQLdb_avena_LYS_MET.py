# importa_MySQLdb_avena_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
avena = []

for i in parametri:
	i = "SELECT %s FROM Cereale_Lys_Met WHERE nome = 'avena'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	avena.append(float(i[0]))
#   print(avena)

AV = list(np.float_(avena))

del AV[10]
del AV[12:16]
del AV[12]
del AV[13]

AV[0] = AV[0]/100

for i in list(range(1, 12)):
	AV[i] = AV[i]*10

AV[16] = AV[16]*AV[15]/100
AV[17] = AV[17]*AV[15]/100

del AV[13]
# elimina i Mj

del AV[2:4]
# elimina RDP ed RUP

PDIE_AV = AV[12]
LysDI_AV = AV[13]
MetDI_AV = AV[14]

LysDI_MetDI_ratio = LysDI_AV/MetDI_AV

AV_mod = AV[0:12]
AV_arr = np.array(AV_mod)

for i in range(len(AV_mod)):
    AV_mod[i] = float(AV_mod[i])

print("COMPOSIZIONE CHIMICA dell'alimento <AVENA>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % AV_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % AV_arr[1])
print("Fibra Grezza (FG) => %f g" % AV_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % AV_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % AV_arr[4])
print("FAT (Grasso) => %f g" % AV_arr[5])
print("AM (Amido) => %f g" % AV_arr[6])
print("ZUC (Zuccheri) => %f g" % AV_arr[7])
print("Ca (Calcio) => %f g" % AV_arr[8])
print("P (Fosforo) => %f g" % AV_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % AV_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % AV_arr[11])
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')   
print('')
# sio.savemat('AV.mat', {'vect':AV})
