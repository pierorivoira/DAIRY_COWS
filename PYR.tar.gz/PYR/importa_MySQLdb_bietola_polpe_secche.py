# importa_MySQLdb_bietola_polpe_secche.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
BIEPOLPSE = []

for i in parametri:
	i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'bietola_polpe_secche'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	BIEPOLPSE.append(float(i[0]))
#   print(BIEPOLPSE)

BIEPOLPSE = list(np.float_(BIEPOLPSE))

del BIEPOLPSE[13:18]
del BIEPOLPSE[10]
del BIEPOLPSE[13:15]

BIEPOLPSE[0] = BIEPOLPSE[0]/100
BIEPOLPSE[1] = BIEPOLPSE[1]*10
BIEPOLPSE[2] = BIEPOLPSE[2]*10
BIEPOLPSE[3] = BIEPOLPSE[3]*10
BIEPOLPSE[4] = BIEPOLPSE[4]*10
BIEPOLPSE[5] = BIEPOLPSE[5]*10
BIEPOLPSE[6] = BIEPOLPSE[6]*10
BIEPOLPSE[7] = BIEPOLPSE[7]*10
BIEPOLPSE[8] = BIEPOLPSE[8]*10
BIEPOLPSE[9] = BIEPOLPSE[9]*10
BIEPOLPSE[10] = BIEPOLPSE[10]*10
BIEPOLPSE[11] = BIEPOLPSE[11]*10

BIEPOLPSE_arr = np.array(BIEPOLPSE)

print("COMPOSIZIONE CHIMICA dell'alimento <BIETOLA POLPE SECCHE>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % BIEPOLPSE_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % BIEPOLPSE_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % BIEPOLPSE_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % BIEPOLPSE_arr[3])
print("Fibra Grezza (FG) => %f g" % BIEPOLPSE_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % BIEPOLPSE_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % BIEPOLPSE_arr[6])
print("FAT (Grasso) => %f g" % BIEPOLPSE_arr[7])
print("AM (Amido) => %f g" % BIEPOLPSE_arr[8])
print("ZUC (Zuccheri) => %f g" % BIEPOLPSE_arr[9])
print("Ca (Calcio) => %f g" % BIEPOLPSE_arr[10])
print("P (Fosforo) => %f g" % BIEPOLPSE_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % BIEPOLPSE_arr[12])
print('')
# sio.sBIEPOLPSEemat('BIEPOLPSE.mat', {'vect':BIEPOLPSE})
