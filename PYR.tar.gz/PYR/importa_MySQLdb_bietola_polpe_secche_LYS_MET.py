# importa_MySQLdb_bietola_polpe_secche_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
bietola_polpe_secche = []

for i in parametri:
	i = "SELECT %s FROM Fonte_di_fibra_Lys_Met WHERE nome = 'bietola_polpe_secche'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	bietola_polpe_secche.append(float(i[0]))
#   print(bietola_polpe_secche)

BIEPOLPSE = list(np.float_(bietola_polpe_secche))

del BIEPOLPSE[10]
del BIEPOLPSE[12:16]
del BIEPOLPSE[12]
del BIEPOLPSE[13]

BIEPOLPSE[0] = BIEPOLPSE[0]/100

for i in list(range(1, 12)):
	BIEPOLPSE[i] = BIEPOLPSE[i]*10

BIEPOLPSE[16] = BIEPOLPSE[16]*BIEPOLPSE[15]/100
BIEPOLPSE[17] = BIEPOLPSE[17]*BIEPOLPSE[15]/100

del BIEPOLPSE[13]
# elimina i Mj

del BIEPOLPSE[2:4]
# elimina RDP ed RUP

PDIE_BIEPOLPSE = BIEPOLPSE[12]
LysDI_BIEPOLPSE = BIEPOLPSE[13]
MetDI_BIEPOLPSE = BIEPOLPSE[14]

LysDI_MetDI_ratio = LysDI_BIEPOLPSE/MetDI_BIEPOLPSE

BIEPOLPSE_mod = BIEPOLPSE[0:12]
BIEPOLPSE_arr = np.array(BIEPOLPSE_mod)

for i in range(len(BIEPOLPSE_mod)):
    BIEPOLPSE_mod[i] = float(BIEPOLPSE_mod[i])

print("COMPOSIZIONE CHIMICA dell'alimento <POLPE SECCHE DI BIETOLA>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % BIEPOLPSE_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % BIEPOLPSE_arr[1])
print("Fibra Grezza (FG) => %f g" % BIEPOLPSE_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % BIEPOLPSE_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % BIEPOLPSE_arr[4])
print("FAT (Grasso) => %f g" % BIEPOLPSE_arr[5])
print("AM (Amido) => %f g" % BIEPOLPSE_arr[6])
print("ZUC (Zuccheri) => %f g" % BIEPOLPSE_arr[7])
print("Ca (Calcio) => %f g" % BIEPOLPSE_arr[8])
print("P (Fosforo) => %f g" % BIEPOLPSE_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % BIEPOLPSE_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % BIEPOLPSE_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.sBIEPOLPSEemat('BIEPOLPSE.mat', {'vect':BIEPOLPSE})
