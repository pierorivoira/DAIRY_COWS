# importa_MySQLdb_bietola_polpe_surpressate.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
BIEPOLSURPR = []

for i in parametri:
	i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'bietola_polpe_surpressate'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	BIEPOLSURPR.append(float(i[0]))
#   print(BIEPOLSURPR)

BIEPOLSURPR = list(np.float_(BIEPOLSURPR))

del BIEPOLSURPR[13:18]
del BIEPOLSURPR[10]
del BIEPOLSURPR[13:15]

BIEPOLSURPR[0] = BIEPOLSURPR[0]/100
BIEPOLSURPR[1] = BIEPOLSURPR[1]*10
BIEPOLSURPR[2] = BIEPOLSURPR[2]*10
BIEPOLSURPR[3] = BIEPOLSURPR[3]*10
BIEPOLSURPR[4] = BIEPOLSURPR[4]*10
BIEPOLSURPR[5] = BIEPOLSURPR[5]*10
BIEPOLSURPR[6] = BIEPOLSURPR[6]*10
BIEPOLSURPR[7] = BIEPOLSURPR[7]*10
BIEPOLSURPR[8] = BIEPOLSURPR[8]*10
BIEPOLSURPR[9] = BIEPOLSURPR[9]*10
BIEPOLSURPR[10] = BIEPOLSURPR[10]*10
BIEPOLSURPR[11] = BIEPOLSURPR[11]*10

BIEPOLSURPR_arr = np.array(BIEPOLSURPR)

print("COMPOSIZIONE CHIMICA dell'alimento <BIETOLA POLPE SURPRESSATE>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % BIEPOLSURPR_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % BIEPOLSURPR_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % BIEPOLSURPR_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % BIEPOLSURPR_arr[3])
print("Fibra Grezza (FG) => %f g" % BIEPOLSURPR_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % BIEPOLSURPR_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % BIEPOLSURPR_arr[6])
print("FAT (Grasso) => %f g" % BIEPOLSURPR_arr[7])
print("AM (Amido) => %f g" % BIEPOLSURPR_arr[8])
print("ZUC (Zuccheri) => %f g" % BIEPOLSURPR_arr[9])
print("Ca (Calcio) => %f g" % BIEPOLSURPR_arr[10])
print("P (Fosforo) => %f g" % BIEPOLSURPR_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % BIEPOLSURPR_arr[12])
print('')
# sio.sBIEPOLSURPRemat('BIEPOLSURPR.mat', {'vect':BIEPOLSURPR})
