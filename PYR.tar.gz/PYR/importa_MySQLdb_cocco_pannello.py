# importa_MySQLdb_cocco_pannello.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
COCPANN = []

for i in parametri:
	i = "SELECT %s FROM Sottoprodotto WHERE nome = 'cocco_pannello'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	COCPANN.append(float(i[0]))
#   print(COCPANN)

COCPANN = list(np.float_(COCPANN))

del COCPANN[13:18]
del COCPANN[10]
del COCPANN[13:15]

COCPANN[0] = COCPANN[0]/100
COCPANN[1] = COCPANN[1]*10
COCPANN[2] = COCPANN[2]*10
COCPANN[3] = COCPANN[3]*10
COCPANN[4] = COCPANN[4]*10
COCPANN[5] = COCPANN[5]*10
COCPANN[6] = COCPANN[6]*10
COCPANN[7] = COCPANN[7]*10
COCPANN[8] = COCPANN[8]*10
COCPANN[9] = COCPANN[9]*10
COCPANN[10] = COCPANN[10]*10
COCPANN[11] = COCPANN[11]*10

COCPANN_arr = np.array(COCPANN)

print("COMPOSIZIONE CHIMICA dell'alimento <PANNELLO DI COCCO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % COCPANN_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % COCPANN_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % COCPANN_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % COCPANN_arr[3])
print("Fibra Grezza (FG) => %f g" % COCPANN_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % COCPANN_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % COCPANN_arr[6])
print("FAT (Grasso) => %f g" % COCPANN_arr[7])
print("AM (Amido) => %f g" % COCPANN_arr[8])
print("ZUC (Zuccheri) => %f g" % COCPANN_arr[9])
print("Ca (Calcio) => %f g" % COCPANN_arr[10])
print("P (Fosforo) => %f g" % COCPANN_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % COCPANN_arr[12])
print('')
# sio.sCOCPANNemat('COCPANN.mat', {'vect':COCPANN})
