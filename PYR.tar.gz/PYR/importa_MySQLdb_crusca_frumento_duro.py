# importa_MySQLdb_crusca_frumento_duro.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
CRUFRUDU = []

for i in parametri:
	i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'crusca_frumento_duro'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	CRUFRUDU.append(float(i[0]))
#   print(CRUFRUDU)

CRUFRUDU = list(np.float_(CRUFRUDU))

del CRUFRUDU[13:18]
del CRUFRUDU[10]
del CRUFRUDU[13:15]

CRUFRUDU[0] = CRUFRUDU[0]/100
CRUFRUDU[1] = CRUFRUDU[1]*10
CRUFRUDU[2] = CRUFRUDU[2]*10
CRUFRUDU[3] = CRUFRUDU[3]*10
CRUFRUDU[4] = CRUFRUDU[4]*10
CRUFRUDU[5] = CRUFRUDU[5]*10
CRUFRUDU[6] = CRUFRUDU[6]*10
CRUFRUDU[7] = CRUFRUDU[7]*10
CRUFRUDU[8] = CRUFRUDU[8]*10
CRUFRUDU[9] = CRUFRUDU[9]*10
CRUFRUDU[10] = CRUFRUDU[10]*10
CRUFRUDU[11] = CRUFRUDU[11]*10

CRUFRUDU_arr = np.array(CRUFRUDU)

print("COMPOSIZIONE CHIMICA dell'alimento <CRUSCA DI FRUMENTO DURO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % CRUFRUDU_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % CRUFRUDU_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % CRUFRUDU_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % CRUFRUDU_arr[3])
print("Fibra Grezza (FG) => %f g" % CRUFRUDU_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % CRUFRUDU_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % CRUFRUDU_arr[6])
print("FAT (Grasso) => %f g" % CRUFRUDU_arr[7])
print("AM (Amido) => %f g" % CRUFRUDU_arr[8])
print("ZUC (Zuccheri) => %f g" % CRUFRUDU_arr[9])
print("Ca (Calcio) => %f g" % CRUFRUDU_arr[10])
print("P (Fosforo) => %f g" % CRUFRUDU_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % CRUFRUDU_arr[12])
print('')
# sio.sCRUFRUDUemat('CRUFRUDU.mat', {'vect':CRUFRUDU})
