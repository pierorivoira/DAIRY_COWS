# importa_MySQLdb_crusca_frumento_tenero.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
CRUFRUTE = []

for i in parametri:
	i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'crusca_frumento_tenero'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	CRUFRUTE.append(float(i[0]))
#   print(CRUFRUTE)

CRUFRUTE = list(np.float_(CRUFRUTE))

del CRUFRUTE[13:18]
del CRUFRUTE[10]
del CRUFRUTE[13:15]

CRUFRUTE[0] = CRUFRUTE[0]/100
CRUFRUTE[1] = CRUFRUTE[1]*10
CRUFRUTE[2] = CRUFRUTE[2]*10
CRUFRUTE[3] = CRUFRUTE[3]*10
CRUFRUTE[4] = CRUFRUTE[4]*10
CRUFRUTE[5] = CRUFRUTE[5]*10
CRUFRUTE[6] = CRUFRUTE[6]*10
CRUFRUTE[7] = CRUFRUTE[7]*10
CRUFRUTE[8] = CRUFRUTE[8]*10
CRUFRUTE[9] = CRUFRUTE[9]*10
CRUFRUTE[10] = CRUFRUTE[10]*10
CRUFRUTE[11] = CRUFRUTE[11]*10

CRUFRUTE_arr = np.array(CRUFRUTE)

print("COMPOSIZIONE CHIMICA dell'alimento <CRUSCA DI FRUMENTO TENERO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % CRUFRUTE_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % CRUFRUTE_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % CRUFRUTE_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % CRUFRUTE_arr[3])
print("Fibra Grezza (FG) => %f g" % CRUFRUTE_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % CRUFRUTE_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % CRUFRUTE_arr[6])
print("FAT (Grasso) => %f g" % CRUFRUTE_arr[7])
print("AM (Amido) => %f g" % CRUFRUTE_arr[8])
print("ZUC (Zuccheri) => %f g" % CRUFRUTE_arr[9])
print("Ca (Calcio) => %f g" % CRUFRUTE_arr[10])
print("P (Fosforo) => %f g" % CRUFRUTE_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % CRUFRUTE_arr[12])
print('')
# sio.sCRUFRUTEemat('CRUFRUTE.mat', {'vect':CRUFRUTE})
