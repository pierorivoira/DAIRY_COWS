# importa_MySQLdb_cruschello_frumento_tenero.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
CRUSCHFRUTE = []

for i in parametri:
	i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'cruschello_frumento_tenero'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	CRUSCHFRUTE.append(float(i[0]))
#   print(CRUSCHFRUTE)

CRUSCHFRUTE = list(np.float_(CRUSCHFRUTE))

del CRUSCHFRUTE[13:18]
del CRUSCHFRUTE[10]
del CRUSCHFRUTE[13:15]

CRUSCHFRUTE[0] = CRUSCHFRUTE[0]/100
CRUSCHFRUTE[1] = CRUSCHFRUTE[1]*10
CRUSCHFRUTE[2] = CRUSCHFRUTE[2]*10
CRUSCHFRUTE[3] = CRUSCHFRUTE[3]*10
CRUSCHFRUTE[4] = CRUSCHFRUTE[4]*10
CRUSCHFRUTE[5] = CRUSCHFRUTE[5]*10
CRUSCHFRUTE[6] = CRUSCHFRUTE[6]*10
CRUSCHFRUTE[7] = CRUSCHFRUTE[7]*10
CRUSCHFRUTE[8] = CRUSCHFRUTE[8]*10
CRUSCHFRUTE[9] = CRUSCHFRUTE[9]*10
CRUSCHFRUTE[10] = CRUSCHFRUTE[10]*10
CRUSCHFRUTE[11] = CRUSCHFRUTE[11]*10

CRUSCHFRUTE_arr = np.array(CRUSCHFRUTE)

print("COMPOSIZIONE CHIMICA dell'alimento <CRUSCHELLO DI FRUMENTO TENERO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % CRUSCHFRUTE_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % CRUSCHFRUTE_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % CRUSCHFRUTE_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % CRUSCHFRUTE_arr[3])
print("Fibra Grezza (FG) => %f g" % CRUSCHFRUTE_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % CRUSCHFRUTE_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % CRUSCHFRUTE_arr[6])
print("FAT (Grasso) => %f g" % CRUSCHFRUTE_arr[7])
print("AM (Amido) => %f g" % CRUSCHFRUTE_arr[8])
print("ZUC (Zuccheri) => %f g" % CRUSCHFRUTE_arr[9])
print("Ca (Calcio) => %f g" % CRUSCHFRUTE_arr[10])
print("P (Fosforo) => %f g" % CRUSCHFRUTE_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % CRUSCHFRUTE_arr[12])
print('')
# sio.sCRUSCHFRUTEemat('CRUSCHFRUTE.mat', {'vect':CRUSCHFRUTE})
