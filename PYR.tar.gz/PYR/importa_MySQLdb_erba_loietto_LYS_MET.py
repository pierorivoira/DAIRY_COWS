# importa_MySQLdb_erba_loietto_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
    erba_loietto = []

    for i in parametri:
        i = "SELECT %s FROM Foraggio_Lys_Met WHERE nome = 'erba_loietto'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        erba_loietto.append(float(i[0]))
#   print(erba_loietto)

    ERLO = list(np.float_(erba_loietto))

except mysql.connector.Error as err:
  print("Server non raggiungibile: {}".format(err))
  print('Provo ad importare <erba_loietto> dal modulo <foraggio_LYS_MET>') 
  from foraggio_LYS_MET import erba_loietto
  print('<erba_loietto> importato con successo dal modulo <foraggio_LYS_MET>!')

ERLO = list(np.float_(erba_loietto))

del ERLO[10]
del ERLO[12:16]
del ERLO[12]
del ERLO[13]

ERLO[0] = ERLO[0]/100

for i in list(range(1, 12)):
	ERLO[i] = ERLO[i]*10

ERLO[16] = ERLO[16]*ERLO[15]/100
ERLO[17] = ERLO[17]*ERLO[15]/100

del ERLO[13]
# elimina Mj

del ERLO[2:4]
# elimina RDP e RUP

PDIE_ERLO = ERLO[12]
LysDI_ERLO = ERLO[13]
MetDI_ERLO = ERLO[14]

LysDI_MetDI_ratio = LysDI_ERLO/MetDI_ERLO

ERLO_mod = ERLO[0:12]
ERLO_arr = np.array(ERLO_mod)

for i in range(len(ERLO_mod)):
    ERLO_mod[i] = float(ERLO_mod[i])

print('')
print("COMPOSIZIONE CHIMICA dell'alimento <ERBA DI LOIETTO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter Intake (DMI, Sostanza Secca) => %f kg" % ERLO_arr[0])
print("Crude Protein Intake (CPI, Proteina Grezza) => %f g" % ERLO_arr[1])
print("Fibra Grezza (FG) => %f g" % ERLO_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % ERLO_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % ERLO_arr[4])
print("FAT (Grasso) => %f g" % ERLO_arr[5])
print("AM (Amido) => %f g" % ERLO_arr[6])
print("ZUC (Zuccheri) => %f g" % ERLO_arr[7])
print("Ca (Calcio) => %f g" % ERLO_arr[8])
print("P (Fosforo) => %f g" % ERLO_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % ERLO_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % ERLO_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.savemat('ERLO.mat', {'vect':ERLO})
