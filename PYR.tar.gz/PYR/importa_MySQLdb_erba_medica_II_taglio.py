# importa_MySQLdb_erba_medica_II_taglio.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
erba_medica_II_taglio = []

for i in parametri:
	i = "SELECT %s FROM Foraggio WHERE nome = 'erba_medica_II_taglio'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	erba_medica_II_taglio.append(float(i[0]))
#   print(erba_medica_II_taglio)

ERME2TA = list(np.float_(erba_medica_II_taglio))

del ERME2TA[13:18]
del ERME2TA[10]
del ERME2TA[13:15]

ERME2TA[0] = ERME2TA[0]/100
ERME2TA[1] = ERME2TA[1]*10
ERME2TA[2] = ERME2TA[2]*10
ERME2TA[3] = ERME2TA[3]*10
ERME2TA[4] = ERME2TA[4]*10
ERME2TA[5] = ERME2TA[5]*10
ERME2TA[6] = ERME2TA[6]*10
ERME2TA[7] = ERME2TA[7]*10
ERME2TA[8] = ERME2TA[8]*10
ERME2TA[9] = ERME2TA[9]*10
ERME2TA[10] = ERME2TA[10]*10
ERME2TA[11] = ERME2TA[11]*10

ERME2TA_arr = np.array(ERME2TA)

print("COMPOSIZIONE CHIMICA dell'alimento <ERBA MEDICA DI II TAGLIO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % ERME2TA_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % ERME2TA_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % ERME2TA_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % ERME2TA_arr[3])
print("Fibra Grezza (FG) => %f g" % ERME2TA_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % ERME2TA_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % ERME2TA_arr[6])
print("FAT (Grasso) => %f g" % ERME2TA_arr[7])
print("AM (Amido) => %f g" % ERME2TA_arr[8])
print("ZUC (Zuccheri) => %f g" % ERME2TA_arr[9])
print("Ca (Calcio) => %f g" % ERME2TA_arr[10])
print("P (Fosforo) => %f g" % ERME2TA_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % ERME2TA_arr[12])
print('')
# sio.savemat('ERME2TA.mat', {'vect':ERME2TA})
