# importa_MySQLdb_erba_medica_disidratata_15x100_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
erba_medica_disidratata_15x100 = []

for i in parametri:
	i = "SELECT %s FROM Foraggio_Lys_Met WHERE nome = 'erba_medica_disidratata_15x100'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	erba_medica_disidratata_15x100.append(float(i[0]))
#   print(erba_medica_disidratata_15x100)

ERMEDIS15 = list(np.float_(erba_medica_disidratata_15x100))

del ERMEDIS15[10]
del ERMEDIS15[12:16]
del ERMEDIS15[12]
del ERMEDIS15[13]

ERMEDIS15[0] = ERMEDIS15[0]/100

for i in list(range(1, 12)):
	ERMEDIS15[i] = ERMEDIS15[i]*10

ERMEDIS15[16] = ERMEDIS15[16]*ERMEDIS15[15]/100
ERMEDIS15[17] = ERMEDIS15[17]*ERMEDIS15[15]/100

del ERMEDIS15[13]
# elimina Mj

del ERMEDIS15[2:4]
# elimina RDP e RUP

PDIE_ERMEDIS15 = ERMEDIS15[12]
LysDI_ERMEDIS15 = ERMEDIS15[13]
MetDI_ERMEDIS15 = ERMEDIS15[14]

LysDI_MetDI_ratio = LysDI_ERMEDIS15/MetDI_ERMEDIS15

ERMEDIS15_mod = ERMEDIS15[0:12]
ERMEDIS15_arr = np.array(ERMEDIS15_mod)

for i in range(len(ERMEDIS15_mod)):
    ERMEDIS15_mod[i] = float(ERMEDIS15_mod[i])

print("COMPOSIZIONE CHIMICA dell'alimento <ERBA MEDICA DISIDRATATA 15x100>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % ERMEDIS15_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % ERMEDIS15_arr[1])
print("Fibra Grezza (FG) => %f g" % ERMEDIS15_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % ERMEDIS15_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % ERMEDIS15_arr[4])
print("FAT (Grasso) => %f g" % ERMEDIS15_arr[5])
print("AM (Amido) => %f g" % ERMEDIS15_arr[6])
print("ZUC (Zuccheri) => %f g" % ERMEDIS15_arr[7])
print("Ca (Calcio) => %f g" % ERMEDIS15_arr[8])
print("P (Fosforo) => %f g" % ERMEDIS15_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % ERMEDIS15_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % ERMEDIS15_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.savemat('ERMEDIS15.mat', {'vect':ERMEDIS15})
