# importa_MySQLdb_erba_medica_disidratata_17x100.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
erba_medica_disidratata_17x100 = []

for i in parametri:
	i = "SELECT %s FROM Foraggio WHERE nome = 'erba_medica_disidratata_17x100'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	erba_medica_disidratata_17x100.append(float(i[0]))
#   print(erba_medica_disidratata_17x100)

ERMEDIS17 = list(np.float_(erba_medica_disidratata_17x100))

del ERMEDIS17[13:18]
del ERMEDIS17[10]
del ERMEDIS17[13:15]

ERMEDIS17[0] = ERMEDIS17[0]/100
ERMEDIS17[1] = ERMEDIS17[1]*10
ERMEDIS17[2] = ERMEDIS17[2]*10
ERMEDIS17[3] = ERMEDIS17[3]*10
ERMEDIS17[4] = ERMEDIS17[4]*10
ERMEDIS17[5] = ERMEDIS17[5]*10
ERMEDIS17[6] = ERMEDIS17[6]*10
ERMEDIS17[7] = ERMEDIS17[7]*10
ERMEDIS17[8] = ERMEDIS17[8]*10
ERMEDIS17[9] = ERMEDIS17[9]*10
ERMEDIS17[10] = ERMEDIS17[10]*10
ERMEDIS17[11] = ERMEDIS17[11]*10

ERMEDIS17_arr = np.array(ERMEDIS17)

print("COMPOSIZIONE CHIMICA dell'alimento <ERBA MEDICA DISIDRATATA 17x100>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % ERMEDIS17_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % ERMEDIS17_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % ERMEDIS17_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % ERMEDIS17_arr[3])
print("Fibra Grezza (FG) => %f g" % ERMEDIS17_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % ERMEDIS17_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % ERMEDIS17_arr[6])
print("FAT (Grasso) => %f g" % ERMEDIS17_arr[7])
print("AM (Amido) => %f g" % ERMEDIS17_arr[8])
print("ZUC (Zuccheri) => %f g" % ERMEDIS17_arr[9])
print("Ca (Calcio) => %f g" % ERMEDIS17_arr[10])
print("P (Fosforo) => %f g" % ERMEDIS17_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % ERMEDIS17_arr[12])
print('')
# sio.savemat('ERMEDIS17.mat', {'vect':ERMEDIS17})
