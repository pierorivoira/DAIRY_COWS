# importa_MySQLdb_fieno_loietto.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
fieno_loietto = []

for i in parametri:
	i = "SELECT %s FROM Foraggio WHERE nome = 'fieno_loietto'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	fieno_loietto.append(float(i[0]))
#   print(fieno_loietto)

FIELO = list(np.float_(fieno_loietto))

del FIELO[13:18]
del FIELO[10]
del FIELO[13:15]

FIELO[0] = FIELO[0]/100
FIELO[1] = FIELO[1]*10
FIELO[2] = FIELO[2]*10
FIELO[3] = FIELO[3]*10
FIELO[4] = FIELO[4]*10
FIELO[5] = FIELO[5]*10
FIELO[6] = FIELO[6]*10
FIELO[7] = FIELO[7]*10
FIELO[8] = FIELO[8]*10
FIELO[9] = FIELO[9]*10
FIELO[10] = FIELO[10]*10
FIELO[11] = FIELO[11]*10

FIELO_arr = np.array(FIELO)

print("COMPOSIZIONE CHIMICA dell'alimento <FIENO DI LOIETTO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % FIELO_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % FIELO_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % FIELO_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % FIELO_arr[3])
print("Fibra Grezza (FG) => %f g" % FIELO_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % FIELO_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % FIELO_arr[6])
print("FAT (Grasso) => %f g" % FIELO_arr[7])
print("AM (Amido) => %f g" % FIELO_arr[8])
print("ZUC (Zuccheri) => %f g" % FIELO_arr[9])
print("Ca (Calcio) => %f g" % FIELO_arr[10])
print("P (Fosforo) => %f g" % FIELO_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % FIELO_arr[12])
print('')
# sio.savemat('FIELO.mat', {'vect':FIELO})
