# importa_MySQLdb_fieno_medica_II_taglio.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
fieno_medica_II_taglio = []

for i in parametri:
	i = "SELECT %s FROM Foraggio WHERE nome = 'fieno_medica_II_taglio'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	fieno_medica_II_taglio.append(float(i[0]))
#   print(fieno_medica_II_taglio)

FIEME2TA = list(np.float_(fieno_medica_II_taglio))

del FIEME2TA[13:18]
del FIEME2TA[10]
del FIEME2TA[13:15]

FIEME2TA[0] = FIEME2TA[0]/100
FIEME2TA[1] = FIEME2TA[1]*10
FIEME2TA[2] = FIEME2TA[2]*10
FIEME2TA[3] = FIEME2TA[3]*10
FIEME2TA[4] = FIEME2TA[4]*10
FIEME2TA[5] = FIEME2TA[5]*10
FIEME2TA[6] = FIEME2TA[6]*10
FIEME2TA[7] = FIEME2TA[7]*10
FIEME2TA[8] = FIEME2TA[8]*10
FIEME2TA[9] = FIEME2TA[9]*10
FIEME2TA[10] = FIEME2TA[10]*10
FIEME2TA[11] = FIEME2TA[11]*10

FIEME2TA_arr = np.array(FIEME2TA)

print("COMPOSIZIONE CHIMICA dell'alimento <FIENO DI MEDICA DI II TAGLIO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % FIEME2TA_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % FIEME2TA_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % FIEME2TA_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % FIEME2TA_arr[3])
print("Fibra Grezza (FG) => %f g" % FIEME2TA_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % FIEME2TA_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % FIEME2TA_arr[6])
print("FAT (Grasso) => %f g" % FIEME2TA_arr[7])
print("AM (Amido) => %f g" % FIEME2TA_arr[8])
print("ZUC (Zuccheri) => %f g" % FIEME2TA_arr[9])
print("Ca (Calcio) => %f g" % FIEME2TA_arr[10])
print("P (Fosforo) => %f g" % FIEME2TA_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % FIEME2TA_arr[12])
print('')
# sio.savemat('FIEME2TA.mat', {'vect':FIEME2TA})
