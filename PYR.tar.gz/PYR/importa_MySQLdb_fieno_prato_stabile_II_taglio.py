# importa_MySQLdb_fieno_prato_stabile_II_taglio.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
fieno_prato_stabile_II_taglio = []

for i in parametri:
	i = "SELECT %s FROM Foraggio WHERE nome = 'fieno_prato_stabile_II_taglio'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	fieno_prato_stabile_II_taglio.append(float(i[0]))
#   print(fieno_prato_stabile_II_taglio)

FIEPRASTA2TA = list(np.float_(fieno_prato_stabile_II_taglio))

del FIEPRASTA2TA[13:18]
del FIEPRASTA2TA[10]
del FIEPRASTA2TA[13:15]

FIEPRASTA2TA[0] = FIEPRASTA2TA[0]/100
FIEPRASTA2TA[1] = FIEPRASTA2TA[1]*10
FIEPRASTA2TA[2] = FIEPRASTA2TA[2]*10
FIEPRASTA2TA[3] = FIEPRASTA2TA[3]*10
FIEPRASTA2TA[4] = FIEPRASTA2TA[4]*10
FIEPRASTA2TA[5] = FIEPRASTA2TA[5]*10
FIEPRASTA2TA[6] = FIEPRASTA2TA[6]*10
FIEPRASTA2TA[7] = FIEPRASTA2TA[7]*10
FIEPRASTA2TA[8] = FIEPRASTA2TA[8]*10
FIEPRASTA2TA[9] = FIEPRASTA2TA[9]*10
FIEPRASTA2TA[10] = FIEPRASTA2TA[10]*10
FIEPRASTA2TA[11] = FIEPRASTA2TA[11]*10

FIEPRASTA2TA_arr = np.array(FIEPRASTA2TA)

print("COMPOSIZIONE CHIMICA dell'alimento <FIENO DI PRATO STABILE DI II TAGLIO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % FIEPRASTA2TA_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % FIEPRASTA2TA_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % FIEPRASTA2TA_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % FIEPRASTA2TA_arr[3])
print("Fibra Grezza (FG) => %f g" % FIEPRASTA2TA_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % FIEPRASTA2TA_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % FIEPRASTA2TA_arr[6])
print("FAT (Grasso) => %f g" % FIEPRASTA2TA_arr[7])
print("AM (Amido) => %f g" % FIEPRASTA2TA_arr[8])
print("ZUC (Zuccheri) => %f g" % FIEPRASTA2TA_arr[9])
print("Ca (Calcio) => %f g" % FIEPRASTA2TA_arr[10])
print("P (Fosforo) => %f g" % FIEPRASTA2TA_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % FIEPRASTA2TA_arr[12])
print('')
# sio.savemat('FIEPRASTA2TA.mat', {'vect':FIEPRASTA2TA})
