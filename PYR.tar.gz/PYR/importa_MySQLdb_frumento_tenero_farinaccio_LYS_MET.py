# importa_MySQLdb_frumento_tenero_farinaccio_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
    frumento_tenero_farinaccio = []

    for i in parametri:
        i = "SELECT %s FROM Fonte_di_fibra_Lys_Met WHERE nome = 'frumento_tenero_farinaccio'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        frumento_tenero_farinaccio.append(float(i[0]))
#   print(frumento_tenero_farinaccio)

    FRUTEFA = list(np.float_(frumento_tenero_farinaccio))

except mysql.connector.Error as err:
  print("Server non raggiungibile: {}".format(err))
  print('Provo ad importare <frumento_tenero_farinaccio> dal modulo <fonte_di_fibra_LYS_MET>') 
  from fonte_di_fibra_LYS_MET import frumento_tenero_farinaccio
  print('<frumento_tenero_farinaccio> importato con successo dal modulo <fonte_di_fibra_LYS_MET>!')

FRUTEFA = list(np.float_(frumento_tenero_farinaccio))

del FRUTEFA[10]
del FRUTEFA[12:16]
del FRUTEFA[12]
del FRUTEFA[13]


FRUTEFA[0] = FRUTEFA[0]/100

for i in list(range(1, 12)):
	FRUTEFA[i] = FRUTEFA[i]*10

FRUTEFA[16] = FRUTEFA[16]*FRUTEFA[15]/100
FRUTEFA[17] = FRUTEFA[17]*FRUTEFA[15]/100

del FRUTEFA[13]
# elimina Mj

del FRUTEFA[2:4]
# elimina RDP e RUP

PDIE_FRUTEFA = FRUTEFA[12]
LysDI_FRUTEFA = FRUTEFA[13]
MetDI_FRUTEFA = FRUTEFA[14]

LysDI_MetDI_ratio = LysDI_FRUTEFA/MetDI_FRUTEFA

FRUTEFA_mod = FRUTEFA[0:12]
FRUTEFA_arr = np.array(FRUTEFA_mod)

for i in range(len(FRUTEFA_mod)):
    FRUTEFA_mod[i] = float(FRUTEFA_mod[i])

print('')
print("COMPOSIZIONE CHIMICA dell'alimento <FARINACCIO DI FRUMENTO TENERO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % FRUTEFA_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % FRUTEFA_arr[1])
print("Fibra Grezza (FG) => %f g" % FRUTEFA_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % FRUTEFA_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % FRUTEFA_arr[4])
print("FAT (Grasso) => %f g" % FRUTEFA_arr[5])
print("AM (Amido) => %f g" % FRUTEFA_arr[6])
print("ZUC (Zuccheri) => %f g" % FRUTEFA_arr[7])
print("Ca (Calcio) => %f g" % FRUTEFA_arr[8])
print("P (Fosforo) => %f g" % FRUTEFA_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % FRUTEFA_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % FRUTEFA_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.sFRUTEFAemat('FRUTEFA.mat', {'vect':FRUTEFA})
