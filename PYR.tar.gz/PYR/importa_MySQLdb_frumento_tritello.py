# importa_MySQLdb_frumento_tritello.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
FRUTRI = []

for i in parametri:
	i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'frumento_tritello'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	FRUTRI.append(float(i[0]))
#   print(FRUTRI)

FRUTRI = list(np.float_(FRUTRI))

del FRUTRI[13:18]
del FRUTRI[10]
del FRUTRI[13:15]

FRUTRI[0] = FRUTRI[0]/100
FRUTRI[1] = FRUTRI[1]*10
FRUTRI[2] = FRUTRI[2]*10
FRUTRI[3] = FRUTRI[3]*10
FRUTRI[4] = FRUTRI[4]*10
FRUTRI[5] = FRUTRI[5]*10
FRUTRI[6] = FRUTRI[6]*10
FRUTRI[7] = FRUTRI[7]*10
FRUTRI[8] = FRUTRI[8]*10
FRUTRI[9] = FRUTRI[9]*10
FRUTRI[10] = FRUTRI[10]*10
FRUTRI[11] = FRUTRI[11]*10

FRUTRI_arr = np.array(FRUTRI)

print("COMPOSIZIONE CHIMICA dell'alimento <TRITELLO DI FRUMENTO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % FRUTRI_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % FRUTRI_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % FRUTRI_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % FRUTRI_arr[3])
print("Fibra Grezza (FG) => %f g" % FRUTRI_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % FRUTRI_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % FRUTRI_arr[6])
print("FAT (Grasso) => %f g" % FRUTRI_arr[7])
print("AM (Amido) => %f g" % FRUTRI_arr[8])
print("ZUC (Zuccheri) => %f g" % FRUTRI_arr[9])
print("Ca (Calcio) => %f g" % FRUTRI_arr[10])
print("P (Fosforo) => %f g" % FRUTRI_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % FRUTRI_arr[12])
print('')
# sio.sFRUTRIemat('FRUTRI.mat', {'vect':FRUTRI})
