# importa_MySQLdb_insilato_mais.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
insilato_mais = []

for i in parametri:
	i = "SELECT %s FROM Foraggio WHERE nome = 'insilato_mais'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	insilato_mais.append(float(i[0]))
#   print(insilato_mais)

INSIMA = list(np.float_(insilato_mais))

del INSIMA[13:18]
del INSIMA[10]
del INSIMA[13:15]

INSIMA[0] = INSIMA[0]/100
INSIMA[1] = INSIMA[1]*10
INSIMA[2] = INSIMA[2]*10
INSIMA[3] = INSIMA[3]*10
INSIMA[4] = INSIMA[4]*10
INSIMA[5] = INSIMA[5]*10
INSIMA[6] = INSIMA[6]*10
INSIMA[7] = INSIMA[7]*10
INSIMA[8] = INSIMA[8]*10
INSIMA[9] = INSIMA[9]*10
INSIMA[10] = INSIMA[10]*10
INSIMA[11] = INSIMA[11]*10

INSIMA_arr = np.array(INSIMA)

print("COMPOSIZIONE CHIMICA dell'alimento <INSILATO DI MAIS>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % INSIMA_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % INSIMA_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % INSIMA_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % INSIMA_arr[3])
print("Fibra Grezza (FG) => %f g" % INSIMA_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % INSIMA_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % INSIMA_arr[6])
print("FAT (Grasso) => %f g" % INSIMA_arr[7])
print("AM (Amido) => %f g" % INSIMA_arr[8])
print("ZUC (Zuccheri) => %f g" % INSIMA_arr[9])
print("Ca (Calcio) => %f g" % INSIMA_arr[10])
print("P (Fosforo) => %f g" % INSIMA_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % INSIMA_arr[12])
print('')
# sio.savemat('INSIMA.mat', {'vect':INSIMA})
