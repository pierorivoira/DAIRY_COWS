# importa_MySQLdb_latte_magro_polvere.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
LATMAPOL = []

for i in parametri:
	i = "SELECT %s FROM Sottoprodotto WHERE nome = 'latte_magro_polvere'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	LATMAPOL.append(float(i[0]))
#   print(LATMAPOL)

LATMAPOL = list(np.float_(LATMAPOL))

del LATMAPOL[13:18]
del LATMAPOL[10]
del LATMAPOL[13:15]

LATMAPOL[0] = LATMAPOL[0]/100
LATMAPOL[1] = LATMAPOL[1]*10
LATMAPOL[2] = LATMAPOL[2]*10
LATMAPOL[3] = LATMAPOL[3]*10
LATMAPOL[4] = LATMAPOL[4]*10
LATMAPOL[5] = LATMAPOL[5]*10
LATMAPOL[6] = LATMAPOL[6]*10
LATMAPOL[7] = LATMAPOL[7]*10
LATMAPOL[8] = LATMAPOL[8]*10
LATMAPOL[9] = LATMAPOL[9]*10
LATMAPOL[10] = LATMAPOL[10]*10
LATMAPOL[11] = LATMAPOL[11]*10

LATMAPOL_arr = np.array(LATMAPOL)

print("COMPOSIZIONE CHIMICA dell'alimento <LATTE MAGRO IN POLVERE>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % LATMAPOL_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % LATMAPOL_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % LATMAPOL_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % LATMAPOL_arr[3])
print("Fibra Grezza (FG) => %f g" % LATMAPOL_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % LATMAPOL_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % LATMAPOL_arr[6])
print("FAT (Grasso) => %f g" % LATMAPOL_arr[7])
print("AM (Amido) => %f g" % LATMAPOL_arr[8])
print("ZUC (Zuccheri) => %f g" % LATMAPOL_arr[9])
print("Ca (Calcio) => %f g" % LATMAPOL_arr[10])
print("P (Fosforo) => %f g" % LATMAPOL_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % LATMAPOL_arr[12])
print('')
# sio.sLATMAPOLemat('LATMAPOL.mat', {'vect':LATMAPOL})
