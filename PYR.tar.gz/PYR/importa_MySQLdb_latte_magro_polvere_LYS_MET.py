# importa_MySQLdb_latte_magro_polvere_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
    latte_magro_polvere = []

    for i in parametri:
        i = "SELECT %s FROM Sottoprodotto_Lys_Met WHERE nome = 'latte_magro_polvere'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        latte_magro_polvere.append(float(i[0]))
#   print(latte_magro_polvere)

    LATMAPOL = list(np.float_(latte_magro_polvere))

except mysql.connector.Error as err:
  print("Server non raggiungibile: {}".format(err))
  print('Provo ad importare <latte_magro_polvere> dal modulo <sottoprodotto_LYS_MET>') 
  from sottoprodotto_LYS_MET import latte_magro_polvere
  print('<latte_magro_polvere> importato con successo dal modulo <sottoprodotto_LYS_MET>!')

LATMAPOL = list(np.float_(latte_magro_polvere))

del LATMAPOL[10]
del LATMAPOL[12:16]
del LATMAPOL[12]
del LATMAPOL[13]

LATMAPOL[0] = LATMAPOL[0]/100

for i in list(range(1, 12)):
	LATMAPOL[i] = LATMAPOL[i]*10

LATMAPOL[16] = LATMAPOL[16]*LATMAPOL[15]/100
LATMAPOL[17] = LATMAPOL[17]*LATMAPOL[15]/100

del LATMAPOL[13]
# elimina Mj

del LATMAPOL[2:4]
# elimina RDP e RUP

PDIE_LATMAPOL = LATMAPOL[12]
LysDI_LATMAPOL = LATMAPOL[13]
MetDI_LATMAPOL = LATMAPOL[14]

LysDI_MetDI_ratio = LysDI_LATMAPOL/MetDI_LATMAPOL

LATMAPOL_mod = LATMAPOL[0:12]
LATMAPOL_arr = np.array(LATMAPOL_mod)

for i in range(len(LATMAPOL_mod)):
    LATMAPOL_mod[i] = float(LATMAPOL_mod[i])

print('')
print("COMPOSIZIONE CHIMICA dell'alimento <LATTE MAGRO IN POLVERE>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % LATMAPOL_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % LATMAPOL_arr[1])
print("Fibra Grezza (FG) => %f g" % LATMAPOL_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % LATMAPOL_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % LATMAPOL_arr[4])
print("FAT (Grasso) => %f g" % LATMAPOL_arr[5])
print("AM (Amido) => %f g" % LATMAPOL_arr[6])
print("ZUC (Zuccheri) => %f g" % LATMAPOL_arr[7])
print("Ca (Calcio) => %f g" % LATMAPOL_arr[8])
print("P (Fosforo) => %f g" % LATMAPOL_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % LATMAPOL_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % LATMAPOL_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.sLATMAPOLemat('LATMAPOL.mat', {'vect':LATMAPOL})
