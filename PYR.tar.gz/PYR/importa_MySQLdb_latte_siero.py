# importa_MySQLdb_latte_siero.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
LATSIE = []

for i in parametri:
	i = "SELECT %s FROM Sottoprodotto WHERE nome = 'latte_siero'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	LATSIE.append(float(i[0]))
#   print(LATSIE)

LATSIE = list(np.float_(LATSIE))

del LATSIE[13:18]
del LATSIE[10]
del LATSIE[13:15]

LATSIE[0] = LATSIE[0]/100
LATSIE[1] = LATSIE[1]*10
LATSIE[2] = LATSIE[2]*10
LATSIE[3] = LATSIE[3]*10
LATSIE[4] = LATSIE[4]*10
LATSIE[5] = LATSIE[5]*10
LATSIE[6] = LATSIE[6]*10
LATSIE[7] = LATSIE[7]*10
LATSIE[8] = LATSIE[8]*10
LATSIE[9] = LATSIE[9]*10
LATSIE[10] = LATSIE[10]*10
LATSIE[11] = LATSIE[11]*10

LATSIE_arr = np.array(LATSIE)

print("COMPOSIZIONE CHIMICA dell'alimento <LATTE SIERO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % LATSIE_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % LATSIE_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % LATSIE_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % LATSIE_arr[3])
print("Fibra Grezza (FG) => %f g" % LATSIE_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % LATSIE_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % LATSIE_arr[6])
print("FAT (Grasso) => %f g" % LATSIE_arr[7])
print("AM (Amido) => %f g" % LATSIE_arr[8])
print("ZUC (Zuccheri) => %f g" % LATSIE_arr[9])
print("Ca (Calcio) => %f g" % LATSIE_arr[10])
print("P (Fosforo) => %f g" % LATSIE_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % LATSIE_arr[12])
print('')
# sio.sLATSIEemat('LATSIE.mat', {'vect':LATSIE})
