# importa_MySQLdb_lino_farina_estrazione.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
LIFAESTR = []

for i in parametri:
	i = "SELECT %s FROM Farina_di_estrazione WHERE nome = 'lino_farina_estrazione'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	LIFAESTR.append(float(i[0]))
#   print(LIFAESTR)

LIFAESTR = list(np.float_(LIFAESTR))

del LIFAESTR[13:18]
del LIFAESTR[10]
del LIFAESTR[13:15]

LIFAESTR[0] = LIFAESTR[0]/100
LIFAESTR[1] = LIFAESTR[1]*10
LIFAESTR[2] = LIFAESTR[2]*10
LIFAESTR[3] = LIFAESTR[3]*10
LIFAESTR[4] = LIFAESTR[4]*10
LIFAESTR[5] = LIFAESTR[5]*10
LIFAESTR[6] = LIFAESTR[6]*10
LIFAESTR[7] = LIFAESTR[7]*10
LIFAESTR[8] = LIFAESTR[8]*10
LIFAESTR[9] = LIFAESTR[9]*10
LIFAESTR[10] = LIFAESTR[10]*10
LIFAESTR[11] = LIFAESTR[11]*10

LIFAESTR_arr = np.array(LIFAESTR)

print("COMPOSIZIONE CHIMICA dell'alimento <LINO FARINA DI ESTRAZIONE>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % LIFAESTR_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % LIFAESTR_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % LIFAESTR_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % LIFAESTR_arr[3])
print("Fibra Grezza (FG) => %f g" % LIFAESTR_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % LIFAESTR_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % LIFAESTR_arr[6])
print("FAT (Grasso) => %f g" % LIFAESTR_arr[7])
print("AM (Amido) => %f g" % LIFAESTR_arr[8])
print("ZUC (Zuccheri) => %f g" % LIFAESTR_arr[9])
print("Ca (Calcio) => %f g" % LIFAESTR_arr[10])
print("P (Fosforo) => %f g" % LIFAESTR_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % LIFAESTR_arr[12])
print('')
# sio.sLIFAESTRemat('LIFAESTR.mat', {'vect':LIFAESTR})
