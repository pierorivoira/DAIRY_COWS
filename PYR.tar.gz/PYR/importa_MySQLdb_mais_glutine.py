# importa_MySQLdb_mais_glutine.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
MAISGLU = []

for i in parametri:
	i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'mais_glutine'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	MAISGLU.append(float(i[0]))
#   print(MAISGLU)

MAISGLU = list(np.float_(MAISGLU))

del MAISGLU[13:18]
del MAISGLU[10]
del MAISGLU[13:15]

MAISGLU[0] = MAISGLU[0]/100
MAISGLU[1] = MAISGLU[1]*10
MAISGLU[2] = MAISGLU[2]*10
MAISGLU[3] = MAISGLU[3]*10
MAISGLU[4] = MAISGLU[4]*10
MAISGLU[5] = MAISGLU[5]*10
MAISGLU[6] = MAISGLU[6]*10
MAISGLU[7] = MAISGLU[7]*10
MAISGLU[8] = MAISGLU[8]*10
MAISGLU[9] = MAISGLU[9]*10
MAISGLU[10] = MAISGLU[10]*10
MAISGLU[11] = MAISGLU[11]*10

MAISGLU_arr = np.array(MAISGLU)

print("COMPOSIZIONE CHIMICA dell'alimento <MAIS GLUTINE>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % MAISGLU_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % MAISGLU_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % MAISGLU_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % MAISGLU_arr[3])
print("Fibra Grezza (FG) => %f g" % MAISGLU_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % MAISGLU_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % MAISGLU_arr[6])
print("FAT (Grasso) => %f g" % MAISGLU_arr[7])
print("AM (Amido) => %f g" % MAISGLU_arr[8])
print("ZUC (Zuccheri) => %f g" % MAISGLU_arr[9])
print("Ca (Calcio) => %f g" % MAISGLU_arr[10])
print("P (Fosforo) => %f g" % MAISGLU_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % MAISGLU_arr[12])
print('')
# sio.sMAISGLUemat('MAISGLU.mat', {'vect':MAISGLU})
