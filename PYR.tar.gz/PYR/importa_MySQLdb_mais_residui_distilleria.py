# importa_MySQLdb_mais_residui_distilleria.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
MAISDIST = []

for i in parametri:
	i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'mais_residui_distilleria'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	MAISDIST.append(float(i[0]))
#   print(MAISDIST)

MAISDIST = list(np.float_(MAISDIST))

del MAISDIST[13:18]
del MAISDIST[10]
del MAISDIST[13:15]

MAISDIST[0] = MAISDIST[0]/100
MAISDIST[1] = MAISDIST[1]*10
MAISDIST[2] = MAISDIST[2]*10
MAISDIST[3] = MAISDIST[3]*10
MAISDIST[4] = MAISDIST[4]*10
MAISDIST[5] = MAISDIST[5]*10
MAISDIST[6] = MAISDIST[6]*10
MAISDIST[7] = MAISDIST[7]*10
MAISDIST[8] = MAISDIST[8]*10
MAISDIST[9] = MAISDIST[9]*10
MAISDIST[10] = MAISDIST[10]*10
MAISDIST[11] = MAISDIST[11]*10

MAISDIST_arr = np.array(MAISDIST)

print("COMPOSIZIONE CHIMICA dell'alimento <MAIS RESIDUI DI DISTILLERIA>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % MAISDIST_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % MAISDIST_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % MAISDIST_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % MAISDIST_arr[3])
print("Fibra Grezza (FG) => %f g" % MAISDIST_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % MAISDIST_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % MAISDIST_arr[6])
print("FAT (Grasso) => %f g" % MAISDIST_arr[7])
print("AM (Amido) => %f g" % MAISDIST_arr[8])
print("ZUC (Zuccheri) => %f g" % MAISDIST_arr[9])
print("Ca (Calcio) => %f g" % MAISDIST_arr[10])
print("P (Fosforo) => %f g" % MAISDIST_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % MAISDIST_arr[12])
print('')
# sio.sMAISDISTemat('MAISDIST.mat', {'vect':MAISDIST})
