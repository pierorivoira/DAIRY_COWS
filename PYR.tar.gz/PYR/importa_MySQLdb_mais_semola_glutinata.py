# importa_MySQLdb_mais_semola_glutinata.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
MAISSEGLU = []

for i in parametri:
	i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'mais_semola_glutinata'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	MAISSEGLU.append(float(i[0]))
#   print(MAISSEGLU)

MAISSEGLU = list(np.float_(MAISSEGLU))

del MAISSEGLU[13:18]
del MAISSEGLU[10]
del MAISSEGLU[13:15]

MAISSEGLU[0] = MAISSEGLU[0]/100
MAISSEGLU[1] = MAISSEGLU[1]*10
MAISSEGLU[2] = MAISSEGLU[2]*10
MAISSEGLU[3] = MAISSEGLU[3]*10
MAISSEGLU[4] = MAISSEGLU[4]*10
MAISSEGLU[5] = MAISSEGLU[5]*10
MAISSEGLU[6] = MAISSEGLU[6]*10
MAISSEGLU[7] = MAISSEGLU[7]*10
MAISSEGLU[8] = MAISSEGLU[8]*10
MAISSEGLU[9] = MAISSEGLU[9]*10
MAISSEGLU[10] = MAISSEGLU[10]*10
MAISSEGLU[11] = MAISSEGLU[11]*10

MAISSEGLU_arr = np.array(MAISSEGLU)

print("COMPOSIZIONE CHIMICA dell'alimento <MAIS SEMOLA GLUTINATA>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % MAISSEGLU_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % MAISSEGLU_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % MAISSEGLU_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % MAISSEGLU_arr[3])
print("Fibra Grezza (FG) => %f g" % MAISSEGLU_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % MAISSEGLU_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % MAISSEGLU_arr[6])
print("FAT (Grasso) => %f g" % MAISSEGLU_arr[7])
print("AM (Amido) => %f g" % MAISSEGLU_arr[8])
print("ZUC (Zuccheri) => %f g" % MAISSEGLU_arr[9])
print("Ca (Calcio) => %f g" % MAISSEGLU_arr[10])
print("P (Fosforo) => %f g" % MAISSEGLU_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % MAISSEGLU_arr[12])
print('')
# sio.sMAISSEGLUemat('MAISSEGLU.mat', {'vect':MAISSEGLU})
