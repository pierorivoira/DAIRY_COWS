# importa_MySQLdb_melasso_barbabietola.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
MEBARBA = []

for i in parametri:
	i = "SELECT %s FROM Sottoprodotto WHERE nome = 'melasso_barbabietola'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	MEBARBA.append(float(i[0]))
#   print(MEBARBA)

MEBARBA = list(np.float_(MEBARBA))

del MEBARBA[13:18]
del MEBARBA[10]
del MEBARBA[13:15]

MEBARBA[0] = MEBARBA[0]/100
MEBARBA[1] = MEBARBA[1]*10
MEBARBA[2] = MEBARBA[2]*10
MEBARBA[3] = MEBARBA[3]*10
MEBARBA[4] = MEBARBA[4]*10
MEBARBA[5] = MEBARBA[5]*10
MEBARBA[6] = MEBARBA[6]*10
MEBARBA[7] = MEBARBA[7]*10
MEBARBA[8] = MEBARBA[8]*10
MEBARBA[9] = MEBARBA[9]*10
MEBARBA[10] = MEBARBA[10]*10
MEBARBA[11] = MEBARBA[11]*10

MEBARBA_arr = np.array(MEBARBA)

print("COMPOSIZIONE CHIMICA dell'alimento <MELASSO DI BARBABIETOLA>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % MEBARBA_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % MEBARBA_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % MEBARBA_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % MEBARBA_arr[3])
print("Fibra Grezza (FG) => %f g" % MEBARBA_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % MEBARBA_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % MEBARBA_arr[6])
print("FAT (Grasso) => %f g" % MEBARBA_arr[7])
print("AM (Amido) => %f g" % MEBARBA_arr[8])
print("ZUC (Zuccheri) => %f g" % MEBARBA_arr[9])
print("Ca (Calcio) => %f g" % MEBARBA_arr[10])
print("P (Fosforo) => %f g" % MEBARBA_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % MEBARBA_arr[12])
print('')
# sio.sMEBARBAemat('MEBARBA.mat', {'vect':MEBARBA})
