# importa_MySQLdb_melasso_barbabietola_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
melasso_barbabietola = []

for i in parametri:
	i = "SELECT %s FROM Sottoprodotto_Lys_Met WHERE nome = 'melasso_barbabietola'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	melasso_barbabietola.append(float(i[0]))
#   print(melasso_barbabietola)

MEBARBA = list(np.float_(melasso_barbabietola))

del MEBARBA[10]
del MEBARBA[12:16]
del MEBARBA[12]
del MEBARBA[13]

MEBARBA[0] = MEBARBA[0]/100

for i in list(range(1, 12)):
	MEBARBA[i] = MEBARBA[i]*10

MEBARBA[16] = MEBARBA[16]*MEBARBA[15]/100
MEBARBA[17] = MEBARBA[17]*MEBARBA[15]/100

del MEBARBA[13]
# elimina Mj

del MEBARBA[2:4]
# elimina RDP e RUP

PDIE_MEBARBA = MEBARBA[12]
LysDI_MEBARBA = MEBARBA[13]
MetDI_MEBARBA = MEBARBA[14]

LysDI_MetDI_ratio = LysDI_MEBARBA/MetDI_MEBARBA

MEBARBA_mod = MEBARBA[0:12]
MEBARBA_arr = np.array(MEBARBA_mod)

for i in range(len(MEBARBA_mod)):
    MEBARBA_mod[i] = float(MEBARBA_mod[i])

print("COMPOSIZIONE CHIMICA dell'alimento <MELASSO DI BARBABIETOLA>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % MEBARBA_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % MEBARBA_arr[1])
print("Fibra Grezza (FG) => %f g" % MEBARBA_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % MEBARBA_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % MEBARBA_arr[4])
print("FAT (Grasso) => %f g" % MEBARBA_arr[5])
print("AM (Amido) => %f g" % MEBARBA_arr[6])
print("ZUC (Zuccheri) => %f g" % MEBARBA_arr[7])
print("Ca (Calcio) => %f g" % MEBARBA_arr[8])
print("P (Fosforo) => %f g" % MEBARBA_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % MEBARBA_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % MEBARBA_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.sMEBARBAemat('MEBARBA.mat', {'vect':MEBARBA})
