# importa_MySQLdb_orzo_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
orzo = []

for i in parametri:
	i = "SELECT %s FROM Cereale_Lys_Met WHERE nome = 'orzo'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	orzo.append(float(i[0]))
#   print(orzo)

ORZO = list(np.float_(orzo))

del ORZO[10]
del ORZO[12:16]
del ORZO[12]
del ORZO[13]

ORZO[0] = ORZO[0]/100

for i in list(range(1, 12)):
	ORZO[i] = ORZO[i]*10

ORZO[16] = ORZO[16]*ORZO[15]/100
ORZO[17] = ORZO[17]*ORZO[15]/100

del ORZO[13]
# elimina Mj

del ORZO[2:4]
# elimina RDP e RUP

PDIE_ORZO = ORZO[12]
LysDI_ORZO = ORZO[13]
MetDI_ORZO = ORZO[14]

LysDI_MetDI_ratio = LysDI_ORZO/MetDI_ORZO

ORZO_mod = ORZO[0:12]
ORZO_arr = np.array(ORZO_mod)

for i in range(len(ORZO_mod)):
    ORZO_mod[i] = float(ORZO_mod[i])

print("COMPOSIZIONE CHIMICA dell'alimento <ORZO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % ORZO_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % ORZO_arr[1])
print("Fibra Grezza (FG) => %f g" % ORZO_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % ORZO_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % ORZO_arr[4])
print("FAT (Grasso) => %f g" % ORZO_arr[5])
print("AM (Amido) => %f g" % ORZO_arr[6])
print("ZUC (Zuccheri) => %f g" % ORZO_arr[7])
print("Ca (Calcio) => %f g" % ORZO_arr[8])
print("P (Fosforo) => %f g" % ORZO_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % ORZO_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % ORZO_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.sORZOemat('ORZO.mat', {'vect':ORZO})
