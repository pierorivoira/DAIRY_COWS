# importa_MySQLdb_orzo_trebbie_birra.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
ORTREBIR = []

for i in parametri:
	i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'orzo_trebbie_birra'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	ORTREBIR.append(float(i[0]))
#   print(ORTREBIR)

ORTREBIR = list(np.float_(ORTREBIR))

del ORTREBIR[13:18]
del ORTREBIR[10]
del ORTREBIR[13:15]

ORTREBIR[0] = ORTREBIR[0]/100
ORTREBIR[1] = ORTREBIR[1]*10
ORTREBIR[2] = ORTREBIR[2]*10
ORTREBIR[3] = ORTREBIR[3]*10
ORTREBIR[4] = ORTREBIR[4]*10
ORTREBIR[5] = ORTREBIR[5]*10
ORTREBIR[6] = ORTREBIR[6]*10
ORTREBIR[7] = ORTREBIR[7]*10
ORTREBIR[8] = ORTREBIR[8]*10
ORTREBIR[9] = ORTREBIR[9]*10
ORTREBIR[10] = ORTREBIR[10]*10
ORTREBIR[11] = ORTREBIR[11]*10

ORTREBIR_arr = np.array(ORTREBIR)

print("COMPOSIZIONE CHIMICA dell'alimento <ORZO TREBBIE DI BIRRA>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % ORTREBIR_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % ORTREBIR_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % ORTREBIR_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % ORTREBIR_arr[3])
print("Fibra Grezza (FG) => %f g" % ORTREBIR_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % ORTREBIR_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % ORTREBIR_arr[6])
print("FAT (Grasso) => %f g" % ORTREBIR_arr[7])
print("AM (Amido) => %f g" % ORTREBIR_arr[8])
print("ZUC (Zuccheri) => %f g" % ORTREBIR_arr[9])
print("Ca (Calcio) => %f g" % ORTREBIR_arr[10])
print("P (Fosforo) => %f g" % ORTREBIR_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % ORTREBIR_arr[12])
print('')
# sio.sORTREBIRemat('ORTREBIR.mat', {'vect':ORTREBIR})
