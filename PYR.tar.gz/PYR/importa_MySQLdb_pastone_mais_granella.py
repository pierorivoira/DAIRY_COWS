# importa_MySQLdb_pastone_mais_granella.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
pastone_mais_granella = []

for i in parametri:
	i = "SELECT %s FROM Foraggio WHERE nome = 'pastone_mais_granella'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	pastone_mais_granella.append(float(i[0]))
#   print(pastone_mais_granella)

PASTOMAISGRA = list(np.float_(pastone_mais_granella))

del PASTOMAISGRA[13:18]
del PASTOMAISGRA[10]
del PASTOMAISGRA[13:15]

PASTOMAISGRA[0] = PASTOMAISGRA[0]/100
PASTOMAISGRA[1] = PASTOMAISGRA[1]*10
PASTOMAISGRA[2] = PASTOMAISGRA[2]*10
PASTOMAISGRA[3] = PASTOMAISGRA[3]*10
PASTOMAISGRA[4] = PASTOMAISGRA[4]*10
PASTOMAISGRA[5] = PASTOMAISGRA[5]*10
PASTOMAISGRA[6] = PASTOMAISGRA[6]*10
PASTOMAISGRA[7] = PASTOMAISGRA[7]*10
PASTOMAISGRA[8] = PASTOMAISGRA[8]*10
PASTOMAISGRA[9] = PASTOMAISGRA[9]*10
PASTOMAISGRA[10] = PASTOMAISGRA[10]*10
PASTOMAISGRA[11] = PASTOMAISGRA[11]*10

PASTOMAISGRA_arr = np.array(PASTOMAISGRA)

print("COMPOSIZIONE CHIMICA dell'alimento <PASTONE DI MAIS GRANELLA>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % PASTOMAISGRA_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % PASTOMAISGRA_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % PASTOMAISGRA_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % PASTOMAISGRA_arr[3])
print("Fibra Grezza (FG) => %f g" % PASTOMAISGRA_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % PASTOMAISGRA_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % PASTOMAISGRA_arr[6])
print("FAT (Grasso) => %f g" % PASTOMAISGRA_arr[7])
print("AM (Amido) => %f g" % PASTOMAISGRA_arr[8])
print("ZUC (Zuccheri) => %f g" % PASTOMAISGRA_arr[9])
print("Ca (Calcio) => %f g" % PASTOMAISGRA_arr[10])
print("P (Fosforo) => %f g" % PASTOMAISGRA_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % PASTOMAISGRA_arr[12])
print('')
# sio.savemat('PASTOMAISGRA.mat', {'vect':PASTOMAISGRA})
