# importa_MySQLdb_pisello_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
pisello = []

for i in parametri:
	i = "SELECT %s FROM Leguminosa_Lys_Met WHERE nome = 'pisello'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	pisello.append(float(i[0]))
#   print(pisello)

PISELLO = list(np.float_(pisello))

del PISELLO[10]
del PISELLO[12:16]
del PISELLO[12]
del PISELLO[13]

PISELLO[0] = PISELLO[0]/100

for i in list(range(1, 12)):
	PISELLO[i] = PISELLO[i]*10

PISELLO[16] = PISELLO[16]*PISELLO[15]/100
PISELLO[17] = PISELLO[17]*PISELLO[15]/100

del PISELLO[13]
# elimina Mj

del PISELLO[2:4]
# elimina RDP e RUP

PDIE_PISELLO = PISELLO[12]
LysDI_PISELLO = PISELLO[13]
MetDI_PISELLO = PISELLO[14]

LysDI_MetDI_ratio = LysDI_PISELLO/MetDI_PISELLO

PISELLO_mod = PISELLO[0:12]
PISELLO_arr = np.array(PISELLO_mod)

for i in range(len(PISELLO_mod)):
    PISELLO_mod[i] = float(PISELLO_mod[i])

print("COMPOSIZIONE CHIMICA dell'alimento <PISELLO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % PISELLO_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % PISELLO_arr[1])
print("Fibra Grezza (FG) => %f g" % PISELLO_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % PISELLO_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % PISELLO_arr[4])
print("FAT (Grasso) => %f g" % PISELLO_arr[5])
print("AM (Amido) => %f g" % PISELLO_arr[6])
print("ZUC (Zuccheri) => %f g" % PISELLO_arr[7])
print("Ca (Calcio) => %f g" % PISELLO_arr[8])
print("P (Fosforo) => %f g" % PISELLO_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % PISELLO_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % PISELLO_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.sPISELLOemat('PISELLO.mat', {'vect':PISELLO})
