# importa_MySQLdb_proteina_patata_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
proteina_patata = []

for i in parametri:
	i = "SELECT %s FROM Sottoprodotto_Lys_Met WHERE nome = 'proteina_patata'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	proteina_patata.append(float(i[0]))
#   print(proteina_patata)

PROPA = list(np.float_(proteina_patata))

del PROPA[10]
del PROPA[12:16]
del PROPA[12]
del PROPA[13]


PROPA[0] = PROPA[0]/100

for i in list(range(1, 12)):
	PROPA[i] = PROPA[i]*10

PROPA[16] = PROPA[16]*PROPA[15]/100
PROPA[17] = PROPA[17]*PROPA[15]/100

del PROPA[13]
# elimina Mj

del PROPA[2:4]
# elimina RDP e RUP

PDIE_PROPA = PROPA[12]
LysDI_PROPA = PROPA[13]
MetDI_PROPA = PROPA[14]

LysDI_MetDI_ratio = LysDI_PROPA/MetDI_PROPA

PROPA_mod = PROPA[0:12]
PROPA_arr = np.array(PROPA_mod)

for i in range(len(PROPA_mod)):
    PROPA_mod[i] = float(PROPA_mod[i])

print("COMPOSIZIONE CHIMICA dell'alimento <PROTEINA DI PATATA>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % PROPA_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % PROPA_arr[1])
print("Fibra Grezza (FG) => %f g" % PROPA_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % PROPA_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % PROPA_arr[4])
print("FAT (Grasso) => %f g" % PROPA_arr[5])
print("AM (Amido) => %f g" % PROPA_arr[6])
print("ZUC (Zuccheri) => %f g" % PROPA_arr[7])
print("Ca (Calcio) => %f g" % PROPA_arr[8])
print("P (Fosforo) => %f g" % PROPA_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % PROPA_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % PROPA_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.sPROPAemat('PROPA.mat', {'vect':PROPA})
