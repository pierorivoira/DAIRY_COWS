# importa_MySQLdb_riso_pula_vergine.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
RISPUVER = []

for i in parametri:
	i = "SELECT %s FROM Sottoprodotto WHERE nome = 'riso_pula_vergine'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	RISPUVER.append(float(i[0]))
#   print(RISPUVER)

RISPUVER = list(np.float_(RISPUVER))

del RISPUVER[13:18]
del RISPUVER[10]
del RISPUVER[13:15]

RISPUVER[0] = RISPUVER[0]/100
RISPUVER[1] = RISPUVER[1]*10
RISPUVER[2] = RISPUVER[2]*10
RISPUVER[3] = RISPUVER[3]*10
RISPUVER[4] = RISPUVER[4]*10
RISPUVER[5] = RISPUVER[5]*10
RISPUVER[6] = RISPUVER[6]*10
RISPUVER[7] = RISPUVER[7]*10
RISPUVER[8] = RISPUVER[8]*10
RISPUVER[9] = RISPUVER[9]*10
RISPUVER[10] = RISPUVER[10]*10
RISPUVER[11] = RISPUVER[11]*10

RISPUVER_arr = np.array(RISPUVER)

print("COMPOSIZIONE CHIMICA dell'alimento <RISO PULA VERGINE>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % RISPUVER_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % RISPUVER_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % RISPUVER_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % RISPUVER_arr[3])
print("Fibra Grezza (FG) => %f g" % RISPUVER_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % RISPUVER_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % RISPUVER_arr[6])
print("FAT (Grasso) => %f g" % RISPUVER_arr[7])
print("AM (Amido) => %f g" % RISPUVER_arr[8])
print("ZUC (Zuccheri) => %f g" % RISPUVER_arr[9])
print("Ca (Calcio) => %f g" % RISPUVER_arr[10])
print("P (Fosforo) => %f g" % RISPUVER_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % RISPUVER_arr[12])
print('')
# sio.sRISPUVERemat('RISPUVER.mat', {'vect':RISPUVER})
