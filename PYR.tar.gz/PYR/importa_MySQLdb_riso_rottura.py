# importa_MySQLdb_riso_rottura.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
RIROTTU = []

for i in parametri:
	i = "SELECT %s FROM Sottoprodotto WHERE nome = 'riso_rottura'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	RIROTTU.append(float(i[0]))
#   print(RIROTTU)

RIROTTU = list(np.float_(RIROTTU))

del RIROTTU[13:18]
del RIROTTU[10]
del RIROTTU[13:15]

RIROTTU[0] = RIROTTU[0]/100
RIROTTU[1] = RIROTTU[1]*10
RIROTTU[2] = RIROTTU[2]*10
RIROTTU[3] = RIROTTU[3]*10
RIROTTU[4] = RIROTTU[4]*10
RIROTTU[5] = RIROTTU[5]*10
RIROTTU[6] = RIROTTU[6]*10
RIROTTU[7] = RIROTTU[7]*10
RIROTTU[8] = RIROTTU[8]*10
RIROTTU[9] = RIROTTU[9]*10
RIROTTU[10] = RIROTTU[10]*10
RIROTTU[11] = RIROTTU[11]*10

RIROTTU_arr = np.array(RIROTTU)

print("COMPOSIZIONE CHIMICA dell'alimento <RISO ROTTURA>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % RIROTTU_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % RIROTTU_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % RIROTTU_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % RIROTTU_arr[3])
print("Fibra Grezza (FG) => %f g" % RIROTTU_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % RIROTTU_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % RIROTTU_arr[6])
print("FAT (Grasso) => %f g" % RIROTTU_arr[7])
print("AM (Amido) => %f g" % RIROTTU_arr[8])
print("ZUC (Zuccheri) => %f g" % RIROTTU_arr[9])
print("Ca (Calcio) => %f g" % RIROTTU_arr[10])
print("P (Fosforo) => %f g" % RIROTTU_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % RIROTTU_arr[12])
print('')
# sio.sRIROTTUemat('RIROTTU.mat', {'vect':RIROTTU})
