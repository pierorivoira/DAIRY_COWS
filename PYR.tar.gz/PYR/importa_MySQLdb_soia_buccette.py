# importa_MySQLdb_soia_buccette.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
SOIABUCC = []

for i in parametri:
	i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'soia_buccette'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	SOIABUCC.append(float(i[0]))
#   print(SOIABUCC)

SOIABUCC = list(np.float_(SOIABUCC))

del SOIABUCC[13:18]
del SOIABUCC[10]
del SOIABUCC[13:15]

SOIABUCC[0] = SOIABUCC[0]/100
SOIABUCC[1] = SOIABUCC[1]*10
SOIABUCC[2] = SOIABUCC[2]*10
SOIABUCC[3] = SOIABUCC[3]*10
SOIABUCC[4] = SOIABUCC[4]*10
SOIABUCC[5] = SOIABUCC[5]*10
SOIABUCC[6] = SOIABUCC[6]*10
SOIABUCC[7] = SOIABUCC[7]*10
SOIABUCC[8] = SOIABUCC[8]*10
SOIABUCC[9] = SOIABUCC[9]*10
SOIABUCC[10] = SOIABUCC[10]*10
SOIABUCC[11] = SOIABUCC[11]*10

SOIABUCC_arr = np.array(SOIABUCC)

print("COMPOSIZIONE CHIMICA dell'alimento <SOIA BUCCETTE>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % SOIABUCC_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % SOIABUCC_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % SOIABUCC_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % SOIABUCC_arr[3])
print("Fibra Grezza (FG) => %f g" % SOIABUCC_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % SOIABUCC_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % SOIABUCC_arr[6])
print("FAT (Grasso) => %f g" % SOIABUCC_arr[7])
print("AM (Amido) => %f g" % SOIABUCC_arr[8])
print("ZUC (Zuccheri) => %f g" % SOIABUCC_arr[9])
print("Ca (Calcio) => %f g" % SOIABUCC_arr[10])
print("P (Fosforo) => %f g" % SOIABUCC_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % SOIABUCC_arr[12])
print('')
# sio.sSOIABUCCemat('SOIABUCC.mat', {'vect':SOIABUCC})
