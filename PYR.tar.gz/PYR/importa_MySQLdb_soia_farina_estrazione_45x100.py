# importa_MySQLdb_soia_farina_estrazione_45x100.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
SOFAESTR45 = []

for i in parametri:
	i = "SELECT %s FROM Farina_di_estrazione WHERE nome = 'soia_farina_estrazione_45x100'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	SOFAESTR45.append(float(i[0]))
#   print(SOFAESTR45)

SOFAESTR45 = list(np.float_(SOFAESTR45))

del SOFAESTR45[13:18]
del SOFAESTR45[10]
del SOFAESTR45[13:15]

SOFAESTR45[0] = SOFAESTR45[0]/100
SOFAESTR45[1] = SOFAESTR45[1]*10
SOFAESTR45[2] = SOFAESTR45[2]*10
SOFAESTR45[3] = SOFAESTR45[3]*10
SOFAESTR45[4] = SOFAESTR45[4]*10
SOFAESTR45[5] = SOFAESTR45[5]*10
SOFAESTR45[6] = SOFAESTR45[6]*10
SOFAESTR45[7] = SOFAESTR45[7]*10
SOFAESTR45[8] = SOFAESTR45[8]*10
SOFAESTR45[9] = SOFAESTR45[9]*10
SOFAESTR45[10] = SOFAESTR45[10]*10
SOFAESTR45[11] = SOFAESTR45[11]*10

SOFAESTR45_arr = np.array(SOFAESTR45)

print("COMPOSIZIONE CHIMICA dell'alimento <SOIA FARINA DI ESTRAZIONE 45x100>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % SOFAESTR45_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % SOFAESTR45_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % SOFAESTR45_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % SOFAESTR45_arr[3])
print("Fibra Grezza (FG) => %f g" % SOFAESTR45_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % SOFAESTR45_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % SOFAESTR45_arr[6])
print("FAT (Grasso) => %f g" % SOFAESTR45_arr[7])
print("AM (Amido) => %f g" % SOFAESTR45_arr[8])
print("ZUC (Zuccheri) => %f g" % SOFAESTR45_arr[9])
print("Ca (Calcio) => %f g" % SOFAESTR45_arr[10])
print("P (Fosforo) => %f g" % SOFAESTR45_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % SOFAESTR45_arr[12])
print('')
# sio.sSOFAESTR45emat('SOFAESTR45.mat', {'vect':SOFAESTR45})
