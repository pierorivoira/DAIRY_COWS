# importa_MySQLdb_soia_farina_estrazione_45x100.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    soia_farina_estrazione_45x100 = []

    for i in parametri:
        i = "SELECT %s FROM Farina_di_estrazione WHERE nome = 'soia_farina_estrazione_45x100'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        soia_farina_estrazione_45x100.append(float(i[0]))
#   print(SOFAESTR45)

    SOFAESTR45 = list(np.float_(soia_farina_estrazione_45x100))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <soia_farina_estrazione_45x100> dal modulo <Farina_di_estrazione>') 
    from Farina_di_estrazione import  soia_farina_estrazione_45x100
    print('<soia_farina_estrazione_45x100> importato con successo dal modulo <Farina_di_estrazione>!')

    SOFAESTR45 = list(np.float_(soia_farina_estrazione_45x100))

    del SOFAESTR45[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del SOFAESTR45[10]
# elimino 'ceneri'

    del SOFAESTR45[13:17]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <SOFAESTR45> => %d' % len(SOFAESTR45))

    for i in range(len(SOFAESTR45)):
        SOFAESTR45[i] = SOFAESTR45[i]*10

    SOFAESTR45[0] = SOFAESTR45[0]/1000
    SOFAESTR45[12] = SOFAESTR45[12]/10

    SOFAESTR45_arr = np.array(SOFAESTR45)

    for i in range(len(SOFAESTR45)):
        SOFAESTR45[i] = float(SOFAESTR45[i])

print("COMPOSIZIONE CHIMICA dell'alimento <FARINA DI ESTRAZIONE DI SOIA 45%>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % SOFAESTR45_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % SOFAESTR45_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % SOFAESTR45_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % SOFAESTR45_arr[3])
print("Fibra Grezza (FG) => %f g" % SOFAESTR45_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % SOFAESTR45_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % SOFAESTR45_arr[6])
print("FAT (Grasso) => %f g" % SOFAESTR45_arr[7])
print("AM (Amido) => %f g" % SOFAESTR45_arr[8])
print("ZUC (Zuccheri) => %f g" % SOFAESTR45_arr[9])
print("Ca (Calcio) => %f g" % SOFAESTR45_arr[10])
print("P (Fosforo) => %f g" % SOFAESTR45_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % SOFAESTR45_arr[12])
print('')

# sio.sSOFAESTR45emat('SOFAESTR45.mat', {'vect':SOFAESTR45})
