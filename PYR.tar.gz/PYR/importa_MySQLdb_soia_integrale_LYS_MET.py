# importa_MySQLdb_soia_integrale_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
soia_integrale = []

for i in parametri:
	i = "SELECT %s FROM Leguminosa_Lys_Met WHERE nome = 'soia_integrale'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	soia_integrale.append(float(i[0]))

SOIAIN = list(np.float_(soia_integrale))

del SOIAIN[10]
del SOIAIN[12:16]
del SOIAIN[12]
del SOIAIN[13]


SOIAIN[0] = SOIAIN[0]/100

for i in list(range(1, 12)):
	SOIAIN[i] = SOIAIN[i]*10

SOIAIN[16] = SOIAIN[16]*SOIAIN[15]/100
SOIAIN[17] = SOIAIN[17]*SOIAIN[15]/100

del SOIAIN[13]
# elimina i Mj

del SOIAIN[2:4]
# elimina RDP ed RUP

PDIE_SOIAIN = SOIAIN[12]
LysDI_SOIAIN = SOIAIN[13]
MetDI_SOIAIN = SOIAIN[14]

LysDI_MetDI_ratio = LysDI_SOIAIN/MetDI_SOIAIN

SOIAIN_mod = SOIAIN[0:12]
SOIAIN_arr = np.array(SOIAIN_mod)

for i in range(len(SOIAIN_mod)):
    SOIAIN_mod[i] = float(SOIAIN_mod[i])

print("COMPOSIZIONE CHIMICA dell'alimento <SOIA INTEGRALE>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % SOIAIN_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % SOIAIN_arr[1])
print("Fibra Grezza (FG) => %f g" % SOIAIN_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % SOIAIN_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % SOIAIN_arr[4])
print("FAT (Grasso) => %f g" % SOIAIN_arr[5])
print("AM (Amido) => %f g" % SOIAIN_arr[6])
print("ZUC (Zuccheri) => %f g" % SOIAIN_arr[7])
print("Ca (Calcio) => %f g" % SOIAIN_arr[8])
print("P (Fosforo) => %f g" % SOIAIN_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % SOIAIN_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % SOIAIN_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.sSOIAINemat('SOIAIN.mat', {'vect':SOIAIN})
