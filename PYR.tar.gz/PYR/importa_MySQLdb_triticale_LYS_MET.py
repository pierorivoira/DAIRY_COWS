# importa_MySQLdb_triticale_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
triticale = []

for i in parametri:
	i = "SELECT %s FROM Cereale_Lys_Met WHERE nome = 'triticale'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	triticale.append(float(i[0]))
#   print(triticale)

TRIT = list(np.float_(triticale))

del TRIT[10]
del TRIT[12:16]
del TRIT[12]
del TRIT[13]
TRIT[0] = TRIT[0]/100

for i in list(range(1, 12)):
	TRIT[i] = TRIT[i]*10

TRIT[16] = TRIT[16]*TRIT[15]/100
TRIT[17] = TRIT[17]*TRIT[15]/100

del TRIT[13]
# elimina Mj

del TRIT[2:4]
# elimina RDP e RUP

PDIE_TRIT = TRIT[12]
LysDI_TRIT = TRIT[13]
MetDI_TRIT = TRIT[14]

LysDI_MetDI_ratio = LysDI_TRIT/MetDI_TRIT

TRIT_mod = TRIT[0:12]
TRIT_arr = np.array(TRIT_mod)

for i in range(len(TRIT_mod)):
    TRIT_mod[i] = float(TRIT_mod[i])

print("COMPOSIZIONE CHIMICA dell'alimento <TRITICALE>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % TRIT_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % TRIT_arr[1])
print("Fibra Grezza (FG) => %f g" % TRIT_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % TRIT_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % TRIT_arr[4])
print("FAT (Grasso) => %f g" % TRIT_arr[5])
print("AM (Amido) => %f g" % TRIT_arr[6])
print("ZUC (Zuccheri) => %f g" % TRIT_arr[7])
print("Ca (Calcio) => %f g" % TRIT_arr[8])
print("P (Fosforo) => %f g" % TRIT_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % TRIT_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % TRIT_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.sTRITemat('TRIT.mat', {'vect':TRIT})
