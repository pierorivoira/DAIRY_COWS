# scrape_tables_Verona_powershell_bozza.py
# https://www.phillipsj.net/posts/executing-powershell-from-python/



### LINUX ###



import pandas as pd
import fileinput, io, numpy, os, re, subprocess, sys, tabula
from datetime import date, datetime, timedelta


user = os.getlogin()
os.chdir('/home/%s/PYTHON/LINUX' % user)



today = date.today()
offset = (today.weekday() - 0) % 7

import datetime

if datetime.datetime.today().weekday() == 0:
	last_Monday = today - timedelta(days=7)
	Monday = last_Monday
else:
	Monday = today - timedelta(days=offset)
	
data_aggiornamento_V = Monday.strftime('%d.%m.%Y')
giorno_di_pubblicazione_V = Monday.strftime('%d_%m_%Y')


url = 'https://www.portaleprezziverona.it/camcom-verona/it/borsa-merci/rilevazione_borsa-merci_%s_%s.xml' % (giorno_di_pubblicazione_V,giorno_di_pubblicazione_V)

os.system('wget %s' % url)





# print('Prezzi della Borsa di Verona aggiornati al %s' % data_aggiornamento_V)
print('Prezzi della Borsa di Verona aggiornati al 14.02.2022')
print(prezzo_COTONE_V)

# df22 => prezzo dei semi di cotone


  
