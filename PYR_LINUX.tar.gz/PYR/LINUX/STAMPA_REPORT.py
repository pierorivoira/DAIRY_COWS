# STAMPA_REPORT.py

import time
from reportlab.lib.enums import TA_JUSTIFY
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from datetime import date, datetime
import os, datetime


user = os.getlogin()
os.chdir('/home/%s/PYTHON/LINUX' % user)


today = date.today()
now = datetime.datetime.now()
day = datetime.datetime.now().strftime("%A")
data = today.strftime('%d/%m/%Y')
current_time = now.strftime("%H:%M:%S")



def form_letter():
    doc = SimpleDocTemplate("REPORT.pdf",
                            pagesize=letter,
                            rightMargin=72,
                            leftMargin=72,
                            topMargin=72,
                            bottomMargin=18)
    flowables = []
    logo = "carro_sfondo.png"
    magName = "Pythonista"
    issueNum = 12
    subPrice = "99.00"
    limitedDate = "03/05/2010"
    freeGift = "tin foil hat"

    formatted_time = time.ctime()
    name = user
    address_parts = ["411 State St.", "Waterloo, IA 50158"]

    im = Image(logo, 3*inch, 1.5*inch)
    flowables.append(im)

    styles = getSampleStyleSheet()
    # Modify the Normal Style
    styles["Normal"].fontSize = 12
    styles["Normal"].leading = 14
    
    # Create a Justify style
    styles.add(ParagraphStyle(name='Justify', alignment=TA_JUSTIFY))    

    flowables.append(Paragraph(formatted_time, styles["Normal"]))
    flowables.append(Spacer(1, 12))

    # Create return address
    flowables.append(Paragraph(name, styles["Normal"]))
    for part in address_parts:
        flowables.append(Paragraph(part.strip(), styles["Normal"]))

    flowables.append(Spacer(1, 12))
    ptext = 'Dear {}:'.format(name.split()[0].strip())
    flowables.append(Paragraph(ptext, styles["Normal"]))
    flowables.append(Spacer(1, 12))
    
    TESTO = open('/home/piero/PYTHON/LINUX/RAZIONE_PyR_0013.txt').read()

    ptext = TESTO.format(magName=magName,
               issueNum=issueNum,
               subPrice=subPrice,
               limitedDate=limitedDate,
               freeGift=freeGift)
    flowables.append(Paragraph(ptext, styles["Justify"]))
    flowables.append(Spacer(1, 12))

    ptext = '''Per ulteriori informazioni si prega di rivolgersi a Piero Rivoira (piero.rivoira@pyr.com)'''

    flowables.append(Paragraph(ptext, styles["Justify"]))
    flowables.append(Spacer(1, 12))
    ptext = 'Sincerely,'
    flowables.append(Paragraph(ptext, styles["Normal"]))
    flowables.append(Spacer(1, 48))
    ptext = 'Ima Sucker'
    flowables.append(Paragraph(ptext, styles["Normal"]))
    flowables.append(Spacer(1, 12))
    doc.build(flowables)

if __name__ == '__main__':
    form_letter()


