# barplot_CNCPS_.py
# https://matplotlib.org/3.5.0/gallery/lines_bars_and_markers/barchart.html#sphx-glr-gallery-lines-bars-and-markers-barchart-py



import matplotlib.pyplot as plt
import numpy as np
import os, re
os.chdir('/home/piero/PYTHON/LINUX')

F = re.findall(r"[+-]?\d+(?:\.\d+)?", open('FABBISOGNI.txt').read())

for i in range(len(F)):
    F[i] = float(F[i])
    
F_SS = F[0]
F_UFL = F[12]
for i in range(len(F)):
    F[i] = F[i]/1000
    
F[0] = F_SS
F[12] = F_UFL

for i in range(len(F)):
    F[i] = round(F[i], 1)

A = re.findall(r"[+-]?\d+(?:\.\d+)?", open('APPORTI.txt').read())
for i in range(len(A)):
    A[i] = float(A[i])

A_SS = A[0]
A_UFL = A[12]
for i in range(len(A)):
    A[i] = A[i]/1000
   
A[0] = A_SS
A[12] = A_UFL

for i in range(len(A)):
    A[i] = round(A[i], 1)

labels = ['DM', 'CP', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'AM', 'ZUC', 'Ca', 'P', 'UFL']

# for i in [F, A, labels]:
#    print(len(i))

	
x = np.arange(len(labels))

width = 0.35
fig, ax = plt.subplots()
rects1 = ax.bar(x - width/2, F, width, label='Fabbisogni')
rects2 = ax.bar(x + width/2, A, width, label='Apporti')

ax.set_ylabel('kg (o UFL)')

ax.set_title('FABBISOGNI vs APPORTI')

ax.set_xticks(x, labels)

ax.legend()

ax.bar_label(rects1, padding=3)
ax.bar_label(rects2, padding=3)

fig.tight_layout()

plt.show()
