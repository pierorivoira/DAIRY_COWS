# crea_db_FABBISOGNI_L.py

### LINUX ###


import os, re
import numpy as np
import scipy.io as sio
from pathlib import Path

user = os.getlogin()
os.chdir('/home/%s/PYTHON/LINUX' % user)

if Path("FABBISOGNI.txt").exists():
    fabbisogni = re.findall('[\d]*[.][\d]+', open('FABBISOGNI.txt').read())
    F = list(np.float_(fabbisogni))
    F_arr = np.array(F)
else:
    print('Impossibile creare il database <FABBISOGNI>!')
    print('Per favore, dopo aver scelto un METODO DI CALCOLO DELLA RAZIONE, inserisci i PARAMETRI richiesti e calcola i FABBISOGNI')
    print('Per calcolare i FABBISOGNI, seleziona la voce <Calcola i fabbisogni metodo> nel menù del METODO che hai scelto!') 

