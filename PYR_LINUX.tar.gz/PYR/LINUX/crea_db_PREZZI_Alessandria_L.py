# crea_db_PREZZI_Alessandria_L.py

### LINUX ###


import os, re
from pathlib import Path
# import numpy as np
# import scipy.io as sio

user = os.getlogin()
os.chdir('/home/%s/PYR/LINUX' % user)
cartella = os.getcwd()

# os.system('python3 scrape_tables_Alessandria_w.py > listino_prezzi_Alessandria.txt')
# os.system('python3 crea_db_PREZZI_Alessandria_w.py)
# COMANDI DA INSERIRE NELLA FUNZIONE "crea_listino_prezzi()"

# TESTO = open('listino_prezzi_Alessandria.txt').read()
# prezzi_interi = re.findall('\d+', open('listino_prezzi_Alessandria.txt').read())

if Path("listino_prezzi_Alessandria.txt").exists():
    prezzi_decimali = re.findall('[\d]*[.][\d]+', open('listino_prezzi_Alessandria.txt').read())
    prezzo_LUPINO = float(prezzi_decimali[0])
    prezzo_MAIS_INSILATO = float(prezzi_decimali[1])
    prezzo_LOIETTO_INSILATO = float(prezzi_decimali[2])
else:
    print('Non ho trovato il LISTINO PREZZI <BORSA MERCI di Alessandria> nella CARTELLA <%s>!' % cartella)
    print('')
    print("Devi prima crearlo, selezionando l'opzione <Crea il listino della Borsa di Alessandria> nel menù <Prezzi>")
    print('')
