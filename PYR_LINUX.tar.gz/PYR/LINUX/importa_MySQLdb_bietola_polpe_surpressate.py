# importa_MySQLdb_bietola_polpe_surpressate.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    bietola_polpe_surpressate = []

    for i in parametri:
        i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'bietola_polpe_surpressate'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        bietola_polpe_surpressate.append(float(i[0]))
#   print(BIEPOLSURPR)

    BIEPOLSURPR = list(np.float_(bietola_polpe_surpressate))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <bietola_polpe_surpressate> dal modulo <Fonte_di_fibra>') 
    from Fonte_di_fibra import bietola_polpe_surpressate
    print('<bietola_polpe_surpressate> importato con successo dal modulo <Fonte_di_fibra>!')

    BIEPOLSURPR = list(np.float_(bietola_polpe_surpressate))

    del BIEPOLSURPR[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del BIEPOLSURPR[10]
# elimino 'ceneri'

    del BIEPOLSURPR[13:15]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <BIEPOLSURPR> => %d' % len(BIEPOLSURPR))

    for i in range(len(BIEPOLSURPR)):
        BIEPOLSURPR[i] = BIEPOLSURPR[i]*10

    BIEPOLSURPR[0] = BIEPOLSURPR[0]/1000
    BIEPOLSURPR[12] = BIEPOLSURPR[12]/10

    BIEPOLSURPR_arr = np.array(BIEPOLSURPR)

    for i in range(len(BIEPOLSURPR)):
        BIEPOLSURPR[i] = float(BIEPOLSURPR[i])

print("COMPOSIZIONE CHIMICA dell'alimento <POLPE SURPRESSATE DI BIETOLA>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % BIEPOLSURPR_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % BIEPOLSURPR_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % BIEPOLSURPR_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % BIEPOLSURPR_arr[3])
print("Fibra Grezza (FG) => %f g" % BIEPOLSURPR_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % BIEPOLSURPR_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % BIEPOLSURPR_arr[6])
print("FAT (Grasso) => %f g" % BIEPOLSURPR_arr[7])
print("AM (Amido) => %f g" % BIEPOLSURPR_arr[8])
print("ZUC (Zuccheri) => %f g" % BIEPOLSURPR_arr[9])
print("Ca (Calcio) => %f g" % BIEPOLSURPR_arr[10])
print("P (Fosforo) => %f g" % BIEPOLSURPR_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % BIEPOLSURPR_arr[12])
print('')

# sio.sBIEPOLSURPRemat('BIEPOLSURPR.mat', {'vect':BIEPOLSURPR})
