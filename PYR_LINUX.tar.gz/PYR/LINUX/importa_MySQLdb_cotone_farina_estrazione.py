# importa_MySQLdb_cotone_farina_estrazione.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    cotone_farina_estrazione = []

    for i in parametri:
        i = "SELECT %s FROM Farina_di_estrazione WHERE nome = 'cotone_farina_estrazione'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        cotone_farina_estrazione.append(float(i[0]))
#   print(COTFAESTR)

    COTFAESTR = list(np.float_(cotone_farina_estrazione))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <cotone_farina_estrazione> dal modulo <Farina_di_estrazione>') 
    from Farina_di_estrazione import cotone_farina_estrazione
    print('<cotone_farina_estrazione> importato con successo dal modulo <Farina_di_estrazione>!')

    COTFAESTR = list(np.float_(cotone_farina_estrazione))

    del COTFAESTR[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del COTFAESTR[10]
# elimino 'ceneri'

    del COTFAESTR[13:15]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <COTFAESTR> => %d' % len(COTFAESTR))

    for i in range(len(COTFAESTR)):
        COTFAESTR[i] = COTFAESTR[i]*10

    COTFAESTR[0] = COTFAESTR[0]/1000
    COTFAESTR[12] = COTFAESTR[12]/10

    COTFAESTR_arr = np.array(COTFAESTR)

    for i in range(len(COTFAESTR)):
        COTFAESTR[i] = float(COTFAESTR[i])

print("COMPOSIZIONE CHIMICA dell'alimento <FARINA DI ESTRAZIONE DI COTONE>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % COTFAESTR_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % COTFAESTR_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % COTFAESTR_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % COTFAESTR_arr[3])
print("Fibra Grezza (FG) => %f g" % COTFAESTR_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % COTFAESTR_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % COTFAESTR_arr[6])
print("FAT (Grasso) => %f g" % COTFAESTR_arr[7])
print("AM (Amido) => %f g" % COTFAESTR_arr[8])
print("ZUC (Zuccheri) => %f g" % COTFAESTR_arr[9])
print("Ca (Calcio) => %f g" % COTFAESTR_arr[10])
print("P (Fosforo) => %f g" % COTFAESTR_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % COTFAESTR_arr[12])
print('')

# sio.sCOTFAESTRemat('COTFAESTR.mat', {'vect':COTFAESTR})
