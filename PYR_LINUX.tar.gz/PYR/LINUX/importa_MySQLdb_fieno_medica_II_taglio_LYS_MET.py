# importa_MySQLdb_fieno_medica_II_taglio_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
    fieno_medica_II_taglio = []

    for i in parametri:
        i = "SELECT %s FROM Foraggio_Lys_Met WHERE nome = 'fieno_medica_II_taglio'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        fieno_medica_II_taglio.append(float(i[0]))
#   print(fieno_medica_II_taglio)

    FIEME2TA = list(np.float_(fieno_medica_II_taglio))

except mysql.connector.Error as err:
  print("Server non raggiungibile: {}".format(err))
  print('Provo ad importare <fieno_medica_II_taglio> dal modulo <foraggio_LYS_MET>') 
  from foraggio_LYS_MET import fieno_medica_II_taglio
  print('<fieno_medica_II_taglio> importato con successo dal modulo <foraggio_LYS_MET>!')

FIEME2TA = list(np.float_(fieno_medica_II_taglio))

del FIEME2TA[10]
del FIEME2TA[12:16]
del FIEME2TA[12]
del FIEME2TA[13]

FIEME2TA[0] = FIEME2TA[0]/100

for i in list(range(1, 12)):
	FIEME2TA[i] = FIEME2TA[i]*10

FIEME2TA[16] = FIEME2TA[16]*FIEME2TA[15]/100
FIEME2TA[17] = FIEME2TA[17]*FIEME2TA[15]/100

del FIEME2TA[13]
# elimina Mj

del FIEME2TA[2:4]
# elimina RDP e RUP

PDIE_FIEME2TA = FIEME2TA[12]
LysDI_FIEME2TA = FIEME2TA[13]
MetDI_FIEME2TA = FIEME2TA[14]

LysDI_MetDI_ratio = LysDI_FIEME2TA/MetDI_FIEME2TA

FIEME2TA_mod = FIEME2TA[0:12]
FIEME2TA_arr = np.array(FIEME2TA_mod)

for i in range(len(FIEME2TA_mod)):
    FIEME2TA_mod[i] = float(FIEME2TA_mod[i])

print('')
print("COMPOSIZIONE CHIMICA dell'alimento <FIENO DI MEDICA DI II TAGLIO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % FIEME2TA_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % FIEME2TA_arr[1])
print("Fibra Grezza (FG) => %f g" % FIEME2TA_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % FIEME2TA_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % FIEME2TA_arr[4])
print("FAT (Grasso) => %f g" % FIEME2TA_arr[5])
print("AM (Amido) => %f g" % FIEME2TA_arr[6])
print("ZUC (Zuccheri) => %f g" % FIEME2TA_arr[7])
print("Ca (Calcio) => %f g" % FIEME2TA_arr[8])
print("P (Fosforo) => %f g" % FIEME2TA_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % FIEME2TA_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % FIEME2TA_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.savemat('FIEME2TA.mat', {'vect':FIEME2TA})
