# importa_MySQLdb_insilato_mais_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
    insilato_mais = []

    for i in parametri:
        i = "SELECT %s FROM Foraggio_Lys_Met WHERE nome = 'insilato_mais'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        insilato_mais.append(float(i[0]))
#   print(insilato_mais)

    INSIMA = list(np.float_(insilato_mais))

except mysql.connector.Error as err:
  print("Server non raggiungibile: {}".format(err))
  print('Provo ad importare <insilato_mais> dal modulo <foraggio_LYS_MET>') 
  from foraggio_LYS_MET import insilato_mais
  print('<insilato_mais> importato con successo dal modulo <foraggio_LYS_MET>!')

INSIMA = list(np.float_(insilato_mais))

del INSIMA[10]
del INSIMA[12:16]
del INSIMA[12]
del INSIMA[13]

INSIMA[0] = INSIMA[0]/100

for i in list(range(1, 12)):
	INSIMA[i] = INSIMA[i]*10

INSIMA[16] = INSIMA[16]*INSIMA[15]/100
INSIMA[17] = INSIMA[17]*INSIMA[15]/100

del INSIMA[13]
# elimina Mj

del INSIMA[2:4]
# elimina RDP e RUP

PDIE_INSIMA = INSIMA[12]
LysDI_INSIMA = INSIMA[13]
MetDI_INSIMA = INSIMA[14]

LysDI_MetDI_ratio = LysDI_INSIMA/MetDI_INSIMA

INSIMA_mod = INSIMA[0:12]
INSIMA_arr = np.array(INSIMA_mod)

for i in range(len(INSIMA_mod)):
    INSIMA_mod[i] = float(INSIMA_mod[i])

print('')
print("COMPOSIZIONE CHIMICA dell'alimento <INSILATO DI MAIS>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % INSIMA_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % INSIMA_arr[1])
print("Fibra Grezza (FG) => %f g" % INSIMA_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % INSIMA_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % INSIMA_arr[4])
print("FAT (Grasso) => %f g" % INSIMA_arr[5])
print("AM (Amido) => %f g" % INSIMA_arr[6])
print("ZUC (Zuccheri) => %f g" % INSIMA_arr[7])
print("Ca (Calcio) => %f g" % INSIMA_arr[8])
print("P (Fosforo) => %f g" % INSIMA_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % INSIMA_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % INSIMA_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.savemat('INSIMA.mat', {'vect':INSIMA})
