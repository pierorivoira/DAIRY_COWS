# importa_MySQLdb_mais_semola_glutinata.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    mais_semola_glutinata = []

    for i in parametri:
        i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'mais_semola_glutinata'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        mais_semola_glutinata.append(float(i[0]))
#   print(MAISSEGLU)

    MAISSEGLU = list(np.float_(mais_semola_glutinata))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <mais_semola_glutinata> dal modulo <Fonte_di_fibra>') 
    from Fonte_di_fibra import mais_semola_glutinata
    print('<mais_semola_glutinata> importato con successo dal modulo <Fonte_di_fibra>!')

    MAISSEGLU = list(np.float_(mais_semola_glutinata))

    del MAISSEGLU[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del MAISSEGLU[10]
# elimino 'ceneri'

    del MAISSEGLU[13:17]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <MAISSEGLU> => %d' % len(MAISSEGLU))

    for i in range(len(MAISSEGLU)):
        MAISSEGLU[i] = MAISSEGLU[i]*10

    MAISSEGLU[0] = MAISSEGLU[0]/1000
    MAISSEGLU[12] = MAISSEGLU[12]/10

    MAISSEGLU_arr = np.array(MAISSEGLU)

    for i in range(len(MAISSEGLU)):
        MAISSEGLU[i] = float(MAISSEGLU[i])

print("COMPOSIZIONE CHIMICA dell'alimento <MAIS SEMOLA GLUTINATA>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % MAISSEGLU_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % MAISSEGLU_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % MAISSEGLU_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % MAISSEGLU_arr[3])
print("Fibra Grezza (FG) => %f g" % MAISSEGLU_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % MAISSEGLU_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % MAISSEGLU_arr[6])
print("FAT (Grasso) => %f g" % MAISSEGLU_arr[7])
print("AM (Amido) => %f g" % MAISSEGLU_arr[8])
print("ZUC (Zuccheri) => %f g" % MAISSEGLU_arr[9])
print("Ca (Calcio) => %f g" % MAISSEGLU_arr[10])
print("P (Fosforo) => %f g" % MAISSEGLU_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % MAISSEGLU_arr[12])
print('')

# sio.sMAISSEGLUemat('MAISSEGLU.mat', {'vect':MAISSEGLU})
