# importa_MySQLdb_melasso_barbabietola.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    melasso_barbabietola = []

    for i in parametri:
        i = "SELECT %s FROM Sottoprodotto WHERE nome = 'melasso_barbabietola'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        melasso_barbabietola.append(float(i[0]))
#   print(MEBARBA)

    MEBARBA = list(np.float_(melasso_barbabietola))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <melasso_barbabietola> dal modulo <Sottoprodotto>') 
    from Sottoprodotto import melasso_barbabietola
    print('<melasso_barbabietola> importato con successo dal modulo <Sottoprodotto>!')

    MEBARBA = list(np.float_(melasso_barbabietola))

    del MEBARBA[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del MEBARBA[10]
# elimino 'ceneri'

    del MEBARBA[13:17]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <MEBARBA> => %d' % len(MEBARBA))

    for i in range(len(MEBARBA)):
        MEBARBA[i] = MEBARBA[i]*10

    MEBARBA[0] = MEBARBA[0]/1000
    MEBARBA[12] = MEBARBA[12]/10

    MEBARBA_arr = np.array(MEBARBA)

    for i in range(len(MEBARBA)):
        MEBARBA[i] = float(MEBARBA[i])

print("COMPOSIZIONE CHIMICA dell'alimento <MELASSO DI BIETOLA>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % MEBARBA_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % MEBARBA_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % MEBARBA_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % MEBARBA_arr[3])
print("Fibra Grezza (FG) => %f g" % MEBARBA_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % MEBARBA_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % MEBARBA_arr[6])
print("FAT (Grasso) => %f g" % MEBARBA_arr[7])
print("AM (Amido) => %f g" % MEBARBA_arr[8])
print("ZUC (Zuccheri) => %f g" % MEBARBA_arr[9])
print("Ca (Calcio) => %f g" % MEBARBA_arr[10])
print("P (Fosforo) => %f g" % MEBARBA_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % MEBARBA_arr[12])
print('')

# sio.sMEBARBAemat('MEBARBA.mat', {'vect':MEBARBA})
