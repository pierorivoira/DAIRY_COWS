# importa_MySQLdb_paglia_frumento.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    paglia_frumento = []

    for i in parametri:
        i = "SELECT %s FROM Foraggio WHERE nome = 'paglia_frumento'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        paglia_frumento.append(float(i[0]))
#   print(PAFRU)

    PAFRU = list(np.float_(paglia_frumento))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <paglia_frumento> dal modulo <Foraggio>') 
    from Foraggio import  paglia_frumento
    print('<paglia_frumento> importato con successo dal modulo <Foraggio>!')

    PAFRU = list(np.float_(paglia_frumento))

    del PAFRU[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del PAFRU[10]
# elimino 'ceneri'

    del PAFRU[13:17]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <PAFRU> => %d' % len(PAFRU))

    for i in range(len(PAFRU)):
        PAFRU[i] = PAFRU[i]*10

    PAFRU[0] = PAFRU[0]/1000
    PAFRU[12] = PAFRU[12]/10

    PAFRU_arr = np.array(PAFRU)

    for i in range(len(PAFRU)):
        PAFRU[i] = float(PAFRU[i])

print("COMPOSIZIONE CHIMICA dell'alimento <PAGLIA DI FRUMENTO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % PAFRU_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % PAFRU_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % PAFRU_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % PAFRU_arr[3])
print("Fibra Grezza (FG) => %f g" % PAFRU_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % PAFRU_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % PAFRU_arr[6])
print("FAT (Grasso) => %f g" % PAFRU_arr[7])
print("AM (Amido) => %f g" % PAFRU_arr[8])
print("ZUC (Zuccheri) => %f g" % PAFRU_arr[9])
print("Ca (Calcio) => %f g" % PAFRU_arr[10])
print("P (Fosforo) => %f g" % PAFRU_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % PAFRU_arr[12])
print('')

# sio.sPAFRUemat('PAFRU.mat', {'vect':PAFRU})
