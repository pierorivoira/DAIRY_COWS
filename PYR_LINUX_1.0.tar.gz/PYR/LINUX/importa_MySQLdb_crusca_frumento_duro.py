# importa_MySQLdb_crusca_frumento_duro.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    crusca_frumento_duro = []

    for i in parametri:
        i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'crusca_frumento_duro'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        crusca_frumento_duro.append(float(i[0]))
#   print(CRUFRUDU)

    CRUFRUDU = list(np.float_(crusca_frumento_duro))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <crusca_frumento_duro> dal modulo <Fonte_di_fibra>') 
    from Fonte_di_fibra import crusca_frumento_duro
    print('<crusca_frumento_duro> importato con successo dal modulo <Fonte_di_fibra>!')

    CRUFRUDU = list(np.float_(crusca_frumento_duro))

    del CRUFRUDU[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del CRUFRUDU[10]
# elimino 'ceneri'

    del CRUFRUDU[13:15]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <CRUFRUDU> => %d' % len(CRUFRUDU))

    for i in range(len(CRUFRUDU)):
        CRUFRUDU[i] = CRUFRUDU[i]*10

    CRUFRUDU[0] = CRUFRUDU[0]/1000
    CRUFRUDU[12] = CRUFRUDU[12]/10

    CRUFRUDU_arr = np.array(CRUFRUDU)

    for i in range(len(CRUFRUDU)):
        CRUFRUDU[i] = float(CRUFRUDU[i])

print("COMPOSIZIONE CHIMICA dell'alimento <CRUSCA DI FRUMENTO DURO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % CRUFRUDU_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % CRUFRUDU_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % CRUFRUDU_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % CRUFRUDU_arr[3])
print("Fibra Grezza (FG) => %f g" % CRUFRUDU_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % CRUFRUDU_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % CRUFRUDU_arr[6])
print("FAT (Grasso) => %f g" % CRUFRUDU_arr[7])
print("AM (Amido) => %f g" % CRUFRUDU_arr[8])
print("ZUC (Zuccheri) => %f g" % CRUFRUDU_arr[9])
print("Ca (Calcio) => %f g" % CRUFRUDU_arr[10])
print("P (Fosforo) => %f g" % CRUFRUDU_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % CRUFRUDU_arr[12])
print('')

# sio.sCRUFRUDUemat('CRUFRUDU.mat', {'vect':CRUFRUDU})
