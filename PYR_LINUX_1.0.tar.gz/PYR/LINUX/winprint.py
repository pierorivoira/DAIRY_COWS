def quit(root):
    if askyesno('Verify quit', 'Sei sicuro di voler uscire dal programma?'):
        Frame.quit(root)


Button(toolbar, text='Quit', command=root.quit).pack(side=RIGHT, fill=Y)