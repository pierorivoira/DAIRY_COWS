# crea_db_PREZZI_Bologna_L.py


### LINUX ###


import os
from pathlib import Path

user = os.getlogin()
os.chdir('/Users/%s/PYTHON' % user)
cartella = os.getcwd()

if Path("listino_prezzi_Bologna.txt").exists():
    with open('listino_prezzi_Bologna.txt', 'r') as file:
        righe = file.readlines()
    for i in range(len(righe)):
	    righe[i] = righe[i].replace('\n', '')
	    if righe[i] != '-':
                righe[i] = float(righe[i])
	    else:
                righe[i] = 'ALIMENTO NON QUOTATO'
    prezzo_SORGO_B = righe[0]
    prezzo_SOIA_B = righe[1]
    prezzo_MAIS_B = righe[2]
    prezzo_ORZO_B = righe[3]
    prezzo_FRUMENTO_B = righe[4]
    prezzo_PISELLO_B = righe[5]
    prezzo_FAVINO_B = righe[6]
    prezzo_FRUMENTO_TENERO_CRUSCA_B = righe[7]
    prezzo_FRUMENTO_TENERO_CRUSCHELLO_B = righe[8]
    prezzo_FRUMENTO_TENERO_TRITELLO_B = righe[9]
    prezzo_FRUMENTO_TENERO_FARINACCIO_B = righe[10]
    prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B = righe[11]
    prezzo_FRUMENTO_DURO_FARINACCIO_B = righe[12]
    prezzo_FRUMENTO_DURO_FARINETTA_B = righe[13]
    prezzo_SOIA_FE_B = righe[14]
    prezzo_GIRASOLE_INTEGRALE_FE_B = righe[15]
    prezzo_COLZA_FE_B = righe[16]
    prezzo_ERBA_MED_DIS_17_B = righe[17]
    prezzo_ERBA_MED_DIS_16_B = righe[18]
    prezzo_ERBA_MED_DIS_14_B = righe[19]
    prezzo_FIENO_1_TAGLIO_B = righe[20]
    prezzo_FIENO_1_TAGLIO_FIBRA_LUNGA_B = righe[21]
    prezzo_MAIS_FARINA_B = righe[22]
    prezzo_MAIS_SEMOLA_GLUTINATA_B = righe[23]
    prezzo_MELASSO_CANNA_B = righe[24]
    prezzo_MELASSO_BIETOLA_B = righe[25]
    prezzo_SOIA_BUCCETTE_B = righe[26]
    prezzo_BIETOLA_POLPE_B = righe[27]
    prezzo_COTONE_B = righe[28]
    prezzo_RISO_GRANA_VERDE_B = righe[29]
    prezzo_RISO_FARINACCIO_B = righe[30]
    prezzo_RISO_PULA_VERGINE_B = righe[31]
    prezzo_FIENO_MEDICA_17_1_TAGLIO_ROTBAL_B = righe[32]
    prezzo_FIENO_MEDICA_17_1_TAGLIO_BALQUA_B = righe[33]
    prezzo_FIENO_MEDICA_17_2_TAGLIO_ROTBAL_B = righe[34]
    prezzo_FIENO_MEDICA_17_2_TAGLIO_BALQUA_B = righe[35]
    prezzo_FIENO_MEDICA_17_3_TAGLIO_ROTBAL_B = righe[36]
    prezzo_FIENO_MEDICA_17_3_TAGLIO_BALQUA_B = righe[37]
    prezzo_FIENO_MEDICA_17_4_TAGLIO_ROTBAL_B = righe[38]
    prezzo_FIENO_MEDICA_17_4_TAGLIO_BALQUA_B = righe[39]
    prezzo_PAGLIA_ROTBAL_B = righe[40]


else:
    print('Non ho trovato il LISTINO PREZZI <BORSA MERCI di Bologna> nella CARTELLA <%s>!' % cartella)
    print('')
    print("Devi prima crearlo, selezionando l'opzione <Crea il listino della Borsa di Bologna> nel menù <Prezzi>")
    print('')

