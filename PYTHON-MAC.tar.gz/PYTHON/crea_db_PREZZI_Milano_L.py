# crea_db_PREZZI_Milano_L.py

### LINUX ### 

import os
from pathlib import Path
# from datetime import datetime

user = os.getlogin()
os.chdir('/Users/%s/PYTHON' % user)
cartella = os.getcwd()

# global data
# data = datetime.today().strftime('%d-%m-%Y')

# os.system('python3 scrape_tables_Milano.py > listino_prezzi_Milano.txt')
# os.system('python3 crea_db_PREZZI_Milano.py)
# COMANDI DA INSERIRE NELLA FUNZIONE "crea_elenco_prezzi()"


# TESTO = open('listino_prezzi_Milano.txt').read()
# prezzi_interi = re.findall('\d+', open('listino_prezzi_Milano.txt').read())

if Path("listino_prezzi_clal.txt").exists(): 

    file = open('listino_prezzi_Milano.txt', 'r')
    list_of_lists = []
    list_of_lists = [(line.strip()).split() for line in file]
    FRUMENTO_TENERO_FARINACCIO = list_of_lists[33]
    FRUMENTO_TENERO_TRITELLO = list_of_lists[35]
    FRUMENTO_TENERO_CRUSCA = list_of_lists[37]
    FRUMENTO_TENERO_CRUSCHELLO = list_of_lists[37]
    FRUMENTO_TENERO_GERME = list_of_lists[41]
    FRUMENTO_DURO_FARINACCIO = list_of_lists[43]
    MAIS = list_of_lists[48]
    MAIS_GLUTINE = list_of_lists[55]
    MAIS_FARINA_GLUTINATA = list_of_lists[56]
    MAIS_SEMOLA_GLUTINATA = list_of_lists[58]							# Corn Gluten Feed
    SEGALE = list_of_lists[61]
    ORZO = list_of_lists[63]
    AVENA = list_of_lists[65]
    TRITICALE = list_of_lists[67]
    SORGO = list_of_lists[68]
    MANIOCA = list_of_lists[69]
    PISELLO = list_of_lists[70]
    SOIA = list_of_lists[81]
    COLZA_FE = list_of_lists[107]
    GIRASOLE_DECORTICATO_FE = list_of_lists[110]	
    SOIA_FE = list_of_lists[112]
    ERBA_MEDICA_DIS_EXTRA = list_of_lists[123]
    ERBA_MEDICA_DIS_1_QUAL = list_of_lists[124]
    MELASSO = list_of_lists[127]
    BIETOLA_POLPE_SECCHE = list_of_lists[128]
    CARRUBE_FRANTUMATE = list_of_lists[130]
    FIENO_MAGGENGO = list_of_lists[132]
    FIENO_AGOSTANO = list_of_lists[133]
    FIENO_MEDICA = list_of_lists[134]
    PAGLIA = list_of_lists[135]
    SOIA_BUCCETTE = list_of_lists[136]
    # SOIA_FE = list_of_lists[148]
    RISO_GRANA_VERDE = list_of_lists[155]
    RISO_FARINACCIO = list_of_lists[156]
    RISO_PULA_VERGINE = list_of_lists[158]
						       

    if FRUMENTO_TENERO_FARINACCIO[len(FRUMENTO_TENERO_FARINACCIO)-3] != 'nq':
        prezzo_FRUMENTO_TENERO_FARINACCIO = float(FRUMENTO_TENERO_FARINACCIO[len(FRUMENTO_TENERO_FARINACCIO)-3])
    else:
        prezzo_FRUMENTO_TENERO_FARINACCIO  = 'ALIMENTO NON QUOTATO'
    # print(FRUMENTO_TENERO_FARINACCIO)


    if FRUMENTO_TENERO_TRITELLO[len(FRUMENTO_TENERO_TRITELLO)-3] != 'nq':
        prezzo_FRUMENTO_TENERO_TRITELLO = float(FRUMENTO_TENERO_TRITELLO[len(FRUMENTO_TENERO_TRITELLO)-3])
    else:
        prezzo_FRUMENTO_TENERO_TRITELLO = 'ALIMENTO NON QUOTATO'
    # print(FRUMENTO_TENERO_TRITELLO)


    if FRUMENTO_TENERO_CRUSCA[len(FRUMENTO_TENERO_CRUSCA)-3] != 'nq':
        prezzo_FRUMENTO_TENERO_CRUSCA = float(FRUMENTO_TENERO_CRUSCA[len(FRUMENTO_TENERO_CRUSCA)-3])
    else:
        prezzo_FRUMENTO_TENERO_CRUSCA = 'ALIMENTO NON QUOTATO'
    # print(FRUMENTO_TENERO_CRUSCA)


    if FRUMENTO_TENERO_CRUSCHELLO[len(FRUMENTO_TENERO_CRUSCHELLO)-3] != 'nq':
        prezzo_FRUMENTO_TENERO_CRUSCHELLO = float(FRUMENTO_TENERO_CRUSCHELLO[len(FRUMENTO_TENERO_CRUSCHELLO)-3])
    else:
        prezzo_FRUMENTO_TENERO_CRUSCHELLO = 'ALIMENTO NON QUOTATO'
    # print(FRUMENTO_TENERO_CRUSCHELLO)


    if FRUMENTO_TENERO_GERME[len(FRUMENTO_TENERO_GERME)-3] != 'nq':
        prezzo_FRUMENTO_TENERO_GERME = float(FRUMENTO_TENERO_GERME[len(FRUMENTO_TENERO_GERME)-3])
    else:
        prezzo_FRUMENTO_TENERO_GERME = 'ALIMENTO NON QUOTATO'
    # print(FRUMENTO_TENERO_GERME)


    if FRUMENTO_DURO_FARINACCIO[len(FRUMENTO_DURO_FARINACCIO)-3] != 'nq':
        prezzo_FRUMENTO_DURO_FARINACCIO = float(FRUMENTO_DURO_FARINACCIO[len(FRUMENTO_DURO_FARINACCIO)-3])
    else:
        prezzo_FRUMENTO_DURO_FARINACCIO = 'ALIMENTO NON QUOTATO'
    # print(FRUMENTO_DURO_FARINACCIO)


    if MAIS[len(MAIS)-3] != 'nq':
        prezzo_MAIS = float(MAIS[len(MAIS)-3])
    else:
        prezzo_MAIS = 'ALIMENTO NON QUOTATO'
    # print(MAIS)

   
    if MAIS_GLUTINE[len(MAIS_GLUTINE)-3] != 'nq':
        prezzo_MAIS_GLUTINE = float(MAIS_GLUTINE[len(MAIS_GLUTINE)-3])
    else:
        prezzo_MAIS_GLUTINE = 'ALIMENTO NON QUOTATO'
    # print(MAIS_GLUTINE)
    

    if MAIS_FARINA_GLUTINATA[len(MAIS_FARINA_GLUTINATA)-3] != 'nq':
        prezzo_MAIS_FARINA_GLUTINATA = float(MAIS_FARINA_GLUTINATA[len(MAIS_FARINA_GLUTINATA)-3])
    else:
        prezzo_MAIS_FARINA_GLUTINATA = 'ALIMENTO NON QUOTATO'
    # print(MAIS_FARINA_GLUTINATA)    
    # NON SI TROVA LA COMPOSIZIONE


    if MAIS_SEMOLA_GLUTINATA[len(MAIS_SEMOLA_GLUTINATA)-3] != 'nq':
        prezzo_MAIS_SEMOLA_GLUTINATA = float(MAIS_SEMOLA_GLUTINATA[len(MAIS_SEMOLA_GLUTINATA)-3])
    else:
        prezzo_MAIS_SEMOLA_GLUTINATA = 'ALIMENTO NON QUOTATO'
    # print(MAIS_SEMOLA_GLUTINATA)


    if SEGALE[len(SEGALE)-3] != 'nq':
        prezzo_SEGALE = float(SEGALE[len(SEGALE)-3])
    else:
        prezzo_SEGALE = 'ALIMENTO NON QUOTATO'
    # print(SEGALE)


    if ORZO[len(ORZO)-3] != 'nq':
        prezzo_ORZO = float(ORZO[len(ORZO)-3])
    else:
        prezzo_ORZO = 'ALIMENTO NON QUOTATO'
    # print(ORZO)


    if AVENA[len(AVENA)-3] != 'nq':
        prezzo_AVENA = float(AVENA[len(AVENA)-3])
    else:
        prezzo_AVENA = 'ALIMENTO NON QUOTATO'
    # print(AVENA)


    if TRITICALE[len(TRITICALE)-3] != 'nq':
        prezzo_TRITICALE = float(TRITICALE[len(TRITICALE)-3])
    else:
        prezzo_TRITICALE = 'ALIMENTO NON QUOTATO'
    # print(TRITICALE)


    if SORGO[len(SORGO)-3] != 'nq':
        prezzo_SORGO = float(SORGO[len(SORGO)-3])
    else:
        prezzo_SORGO = 'ALIMENTO NON QUOTATO'
    # print(SORGO)


    if MANIOCA[len(MANIOCA)-3] != 'nq':
        prezzo_MANIOCA = float(MANIOCA[len(MANIOCA)-3])
    else:
        prezzo_MANIOCA = 'ALIMENTO NON QUOTATO'
    # print(MANIOCA)


    if PISELLO[len(PISELLO)-3] != 'nq':
        prezzo_PISELLO = float(PISELLO[len(PISELLO)-3])
    else:
        prezzo_PISELLO = 'ALIMENTO NON QUOTATO'
    # print(PISELLO)


    if SOIA[len(SOIA)-3] != 'nq':
        prezzo_SOIA = float(SOIA[len(SOIA)-3])
    else:
        prezzo_SOIA = 'ALIMENTO NON QUOTATO'
    # print(SOIA)


    if COLZA_FE[len(COLZA_FE)-3] != 'nq':
        prezzo_COLZA_FE = float(COLZA_FE[len(COLZA_FE)-3])
    else:
        prezzo_COLZA_FE = 'ALIMENTO NON QUOTATO'
    # print(COLZA_FE)


    if GIRASOLE_DECORTICATO_FE[len(GIRASOLE_DECORTICATO_FE)-3] != 'nq':
        prezzo_GIRASOLE_DECORTICATO_FE = float(GIRASOLE_DECORTICATO_FE[len(GIRASOLE_DECORTICATO_FE)-3])
    else:
        prezzo_GIRASOLE_DECORTICATO_FE = 'ALIMENTO NON QUOTATO'
    # print(GIRASOLE_DECORTICATO_FE)


    if SOIA_FE[len(SOIA_FE)-3] != 'nq':
        prezzo_SOIA_FE = float(SOIA_FE[len(SOIA_FE)-3])
    else:
        prezzo_SOIA_FE = 'ALIMENTO NON QUOTATO'
    # print(SOIA_FE)


    if ERBA_MEDICA_DIS_EXTRA[len(ERBA_MEDICA_DIS_EXTRA)-3] != 'nq':
        prezzo_ERBA_MEDICA_DIS_EXTRA = float(ERBA_MEDICA_DIS_EXTRA[len(ERBA_MEDICA_DIS_EXTRA)-3])
    else:
        prezzo_ERBA_MEDICA_DIS_EXTRA = 'ALIMENTO NON QUOTATO'
    # print(ERBA_MEDICA_DIS_EXTRA)


    if ERBA_MEDICA_DIS_1_QUAL[len(ERBA_MEDICA_DIS_1_QUAL)-3] != 'nq':
        prezzo_ERBA_MEDICA_DIS_1_QUAL = float(ERBA_MEDICA_DIS_1_QUAL[len(ERBA_MEDICA_DIS_1_QUAL)-3])
    else:
        prezzo_ERBA_MEDICA_DIS_1_QUAL = 'ALIMENTO NON QUOTATO'
    # print(ERBA_MEDICA_DIS_1_QUAL)


    if MELASSO[len(MELASSO)-3] != 'nq':
        prezzo_MELASSO = float(MELASSO[len(MELASSO)-3])
    else:
        prezzo_MELASSO = 'ALIMENTO NON QUOTATO'
    # print(MELASSO)


    if BIETOLA_POLPE_SECCHE[len(BIETOLA_POLPE_SECCHE)-3] != 'nq':
        prezzo_BIETOLA_POLPE_SECCHE = float(BIETOLA_POLPE_SECCHE[len(BIETOLA_POLPE_SECCHE)-3])
    else:
        prezzo_BIETOLA_POLPE_SECCHE = 'ALIMENTO NON QUOTATO'
    # print(BIETOLA_POLPE_SECCHE)


    if CARRUBE_FRANTUMATE[len(CARRUBE_FRANTUMATE)-3] != 'nq':
        prezzo_CARRUBE_FRANTUMATE = float(CARRUBE_FRANTUMATE[len(CARRUBE_FRANTUMATE)-3])
    else:
        prezzo_CARRUBE_FRANTUMATE = 'ALIMENTO NON QUOTATO'
    # print(CARRUBE_FRANTUMATE)


    if FIENO_MAGGENGO[len(FIENO_MAGGENGO)-3] != 'nq':
        prezzo_FIENO_MAGGENGO = float(FIENO_MAGGENGO[len(FIENO_MAGGENGO)-3])
    else:
        prezzo_FIENO_MAGGENGO = 'ALIMENTO NON QUOTATO'
    # print(FIENO_MAGGENGO)


    if FIENO_AGOSTANO[len(FIENO_AGOSTANO)-3] != 'nq':
        prezzo_FIENO_AGOSTANO = float(FIENO_AGOSTANO[len(FIENO_AGOSTANO)-3])
    else:
        prezzo_FIENO_AGOSTANO = 'ALIMENTO NON QUOTATO'
    # print(FIENO_AGOSTANO)


    if FIENO_MEDICA[len(FIENO_MEDICA)-3] != 'nq':
        prezzo_FIENO_MEDICA = float(FIENO_MEDICA[len(FIENO_MEDICA)-3])
    else:
        prezzo_FIENO_MEDICA = 'ALIMENTO NON QUOTATO'
    # print(FIENO_MEDICA)


    if PAGLIA[len(PAGLIA)-3] != 'nq':
        prezzo_PAGLIA = float(PAGLIA[len(PAGLIA)-3])
    else:
        prezzo_PAGLIA = 'ALIMENTO NON QUOTATO'
    # print(PAGLIA)


    if SOIA_BUCCETTE[len(SOIA_BUCCETTE)-3] != 'nq':
        prezzo_SOIA_BUCCETTE = float(SOIA_BUCCETTE[len(SOIA_BUCCETTE)-3])
    else:
        prezzo_SOIA_BUCCETTE = 'ALIMENTO NON QUOTATO'
    # print(SOIA_BUCCETTE)


    if RISO_GRANA_VERDE[len(RISO_GRANA_VERDE)-3] != 'nq':
        prezzo_RISO_GRANA_VERDE = float(RISO_GRANA_VERDE[len(RISO_GRANA_VERDE)-3])
    else:
        prezzo_RISO_GRANA_VERDE = 'ALIMENTO NON QUOTATO'
    # print(RISO_GRANA_VERDE)


    if RISO_FARINACCIO[len(RISO_FARINACCIO)-3] != 'nq':
        prezzo_RISO_FARINACCIO = float(RISO_FARINACCIO[len(RISO_FARINACCIO)-3])
    else:
        prezzo_RISO_FARINACCIO = 'ALIMENTO NON QUOTATO'
    # print(RISO_FARINACCIO)


    if RISO_PULA_VERGINE[len(RISO_PULA_VERGINE)-3] != 'nq':
        prezzo_RISO_PULA_VERGINE = float(RISO_PULA_VERGINE[len(RISO_PULA_VERGINE)-3])
    else:
        prezzo_RISO_PULA_VERGINE = 'ALIMENTO NON QUOTATO'
    # print(RISO_PULA_VERGINE)
    
else:
    print('Non ho trovato il LISTINO PREZZI <BORSA MERCI di Milano> nella CARTELLA <%s>!' % cartella)
    print('')
    print("Devi prima crearlo, selezionando l'opzione <Crea il listino della Borsa di Milano> nel menù <Prezzi>")
    print('')
