# crea_db_PREZZI_Alessandria_w.py

### WINDOWS ###

import os, re
# import numpy as np
# import scipy.io as sio

user = os.getlogin()
os.chdir('C:/Users/%s/PYTHON_WIN' % user)

# os.system('python3 scrape_tables_Alessandria_w.py > listino_prezzi_Alessandria.txt')
# os.system('python3 crea_db_PREZZI_Alessandria_w.py)
# COMANDI DA INSERIRE NELLA FUNZIONE "crea_listino_prezzi()"

# TESTO = open('listino_prezzi_Alessandria.txt').read()
# prezzi_interi = re.findall('\d+', open('listino_prezzi_Alessandria.txt').read())

prezzi_decimali = re.findall('[\d]*[.][\d]+', open('listino_prezzi_Alessandria.txt').read())


prezzo_LUPINO = float(prezzi_decimali[0])
prezzo_MAIS_INSILATO = float(prezzi_decimali[1])
prezzo_LOIETTO_INSILATO = float(prezzi_decimali[2])
