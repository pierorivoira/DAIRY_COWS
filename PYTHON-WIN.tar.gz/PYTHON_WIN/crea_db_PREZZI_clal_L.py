# crea_db_PREZZI_clal_L.py

### LINUX ### 

import os
from pathlib import Path


user = os.getlogin()
os.chdir('/home/%s/PYR/LINUX' % user)
cartella = os.getcwd()

# os.system('python scrape_tables_clal_w.py > listino_prezzi_clal.txt')
# os.system('python crea_db_PREZZI_clal_w.py)
# COMANDI DA INSERIRE NELLA FUNZIONE "crea_listino_prezzi()"

if Path("listino_prezzi_clal.txt").exists():
    file = open('listino_prezzi_clal.txt', 'r')
    list_of_lists = []
    list_of_lists = [(line.strip()).split() for line in file]

    MAIS_PASTONE_INTEGRALE_COSTO_PR = list_of_lists[13]
    FIENO_MEDICA_1_TG_COSTO_PR = list_of_lists[15]
    FIENO_MEDICA_2_TG_COSTO_PR = list_of_lists[17]
    FIENO_PRATO_POLIFITA_COSTO_PR = list_of_lists[21]
    INSILATO_PRATO_POLIFITA_COSTO_PR = list_of_lists[24]
    INSILATO_MAIS_COSTO_PR = list_of_lists[25]

    prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR = MAIS_PASTONE_INTEGRALE_COSTO_PR[10]
    prezzo_FIENO_MEDICA_1_TG_COSTO_PR = FIENO_MEDICA_1_TG_COSTO_PR[10]
    prezzo_FIENO_MEDICA_2_TG_COSTO_PR = FIENO_MEDICA_2_TG_COSTO_PR[10]
    prezzo_FIENO_PRATO_POLIFITA_COSTO_PR = FIENO_PRATO_POLIFITA_COSTO_PR[10]
    prezzo_INSILATO_PRATO_POLIFITA_COSTO_PR = INSILATO_PRATO_POLIFITA_COSTO_PR[9]
    prezzo_INSILATO_MAIS_COSTO_PR = INSILATO_MAIS_COSTO_PR[8]



else:
    print('Non ho trovato il LISTINO PREZZI <CLAL> nella CARTELLA <%s>!' % cartella)
    print('')
    print("Devi prima crearlo, selezionando l'opzione <Crea il listino CLAL> nel menù <Prezzi>")
    print('')

