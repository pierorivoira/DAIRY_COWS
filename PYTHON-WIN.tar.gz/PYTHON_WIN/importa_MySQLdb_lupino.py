# importa_MySQLdb_lupino.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    lupino = []

    for i in parametri:
        i = "SELECT %s FROM Leguminosa WHERE nome = 'lupino'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        lupino.append(float(i[0]))
#   print(LU)

    LU = list(np.float_(lupino))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <lupino> dal modulo <Leguminosa>') 
    from Leguminosa import lupino
    print('<lupino> importato con successo dal modulo <Leguminosa>!')

    LU = list(np.float_(lupino))

    del LU[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del LU[10]
# elimino 'ceneri'

    del LU[13:17]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <LU> => %d' % len(LU))

    for i in range(len(LU)):
        LU[i] = LU[i]*10

    LU[0] = LU[0]/1000
    LU[12] = LU[12]/10

    LU_arr = np.array(LU)

    for i in range(len(LU)):
        LU[i] = float(LU[i])

print("COMPOSIZIONE CHIMICA dell'alimento <LUPINO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % LU_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % LU_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % LU_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % LU_arr[3])
print("Fibra Grezza (FG) => %f g" % LU_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % LU_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % LU_arr[6])
print("FAT (Grasso) => %f g" % LU_arr[7])
print("AM (Amido) => %f g" % LU_arr[8])
print("ZUC (Zuccheri) => %f g" % LU_arr[9])
print("Ca (Calcio) => %f g" % LU_arr[10])
print("P (Fosforo) => %f g" % LU_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % LU_arr[12])
print('')

# sio.sLUemat('LU.mat', {'vect':LU})
