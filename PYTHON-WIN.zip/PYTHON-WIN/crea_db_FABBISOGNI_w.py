# crea_db_FABBISOGNI_w.py

import os, re
import numpy as np
import scipy.io as sio

user = os.getlogin()
os.chdir('C:/Users/%s/PYTHON' % user)

fabbisogni = re.findall('[\d]*[.][\d]+', open('FABBISOGNI.txt').read())
F = list(np.float_(fabbisogni))
F_arr = np.array(F)

