# importa_MySQLdb_agrumi_pastazzo_secco.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
AGRPASE = []

for i in parametri:
	i = "SELECT %s FROM Sottoprodotto WHERE nome = 'agrumi_pastazzo_secco'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	AGRPASE.append(float(i[0]))
#   print(AGRPASE)

AGRPASE = list(np.float_(AGRPASE))

del AGRPASE[13:18]
del AGRPASE[10]
del AGRPASE[13:15]

AGRPASE[0] = AGRPASE[0]/100
AGRPASE[1] = AGRPASE[1]*10
AGRPASE[2] = AGRPASE[2]*10
AGRPASE[3] = AGRPASE[3]*10
AGRPASE[4] = AGRPASE[4]*10
AGRPASE[5] = AGRPASE[5]*10
AGRPASE[6] = AGRPASE[6]*10
AGRPASE[7] = AGRPASE[7]*10
AGRPASE[8] = AGRPASE[8]*10
AGRPASE[9] = AGRPASE[9]*10
AGRPASE[10] = AGRPASE[10]*10
AGRPASE[11] = AGRPASE[11]*10

AGRPASE_arr = np.array(AGRPASE)
print(AGRPASE_arr)

# sio.sAGRPASEemat('AGRPASE.mat', {'vect':AGRPASE})
