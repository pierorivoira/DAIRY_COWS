# importa_MySQLdb_avena.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
avena = []

for i in parametri:
	i = "SELECT %s FROM Cereale WHERE nome = 'avena'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	avena.append(float(i[0]))
#   print(avena)

AV = list(np.float_(avena))

del AV[13:18]
del AV[10]
del AV[13:15]

AV[0] = AV[0]/100
AV[1] = AV[1]*10
AV[2] = AV[2]*10
AV[3] = AV[3]*10
AV[4] = AV[4]*10
AV[5] = AV[5]*10
AV[6] = AV[6]*10
AV[7] = AV[7]*10
AV[8] = AV[8]*10
AV[9] = AV[9]*10
AV[10] = AV[10]*10
AV[11] = AV[11]*10

AV_arr = np.array(AV)
print(AV_arr)
# sio.savemat('AV.mat', {'vect':AV})
