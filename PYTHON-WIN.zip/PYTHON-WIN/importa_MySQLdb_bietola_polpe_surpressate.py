# importa_MySQLdb_bietola_polpe_surpressate.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
BIEPOLSURPR = []

for i in parametri:
	i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'bietola_polpe_surpressate'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	BIEPOLSURPR.append(float(i[0]))
#   print(BIEPOLSURPR)

BIEPOLSURPR = list(np.float_(BIEPOLSURPR))

del BIEPOLSURPR[13:18]
del BIEPOLSURPR[10]
del BIEPOLSURPR[13:15]

BIEPOLSURPR[0] = BIEPOLSURPR[0]/100
BIEPOLSURPR[1] = BIEPOLSURPR[1]*10
BIEPOLSURPR[2] = BIEPOLSURPR[2]*10
BIEPOLSURPR[3] = BIEPOLSURPR[3]*10
BIEPOLSURPR[4] = BIEPOLSURPR[4]*10
BIEPOLSURPR[5] = BIEPOLSURPR[5]*10
BIEPOLSURPR[6] = BIEPOLSURPR[6]*10
BIEPOLSURPR[7] = BIEPOLSURPR[7]*10
BIEPOLSURPR[8] = BIEPOLSURPR[8]*10
BIEPOLSURPR[9] = BIEPOLSURPR[9]*10
BIEPOLSURPR[10] = BIEPOLSURPR[10]*10
BIEPOLSURPR[11] = BIEPOLSURPR[11]*10

BIEPOLSURPR_arr = np.array(BIEPOLSURPR)
print(BIEPOLSURPR_arr)
# sio.sBIEPOLSURPRemat('BIEPOLSURPR.mat', {'vect':BIEPOLSURPR})
