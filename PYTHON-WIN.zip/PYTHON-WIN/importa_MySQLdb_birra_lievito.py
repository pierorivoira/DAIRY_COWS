# importa_MySQLdb_birra_lievito.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
BILIE = []

for i in parametri:
	i = "SELECT %s FROM Sottoprodotto WHERE nome = 'birra_lievito'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	BILIE.append(float(i[0]))
#   print(BILIE)

BILIE = list(np.float_(BILIE))

del BILIE[13:18]
del BILIE[10]
del BILIE[13:15]

BILIE[0] = BILIE[0]/100
BILIE[1] = BILIE[1]*10
BILIE[2] = BILIE[2]*10
BILIE[3] = BILIE[3]*10
BILIE[4] = BILIE[4]*10
BILIE[5] = BILIE[5]*10
BILIE[6] = BILIE[6]*10
BILIE[7] = BILIE[7]*10
BILIE[8] = BILIE[8]*10
BILIE[9] = BILIE[9]*10
BILIE[10] = BILIE[10]*10
BILIE[11] = BILIE[11]*10

BILIE_arr = np.array(BILIE)
print(BILIE_arr)
# sio.sBILIEemat('BILIE.mat', {'vect':BILIE})
