# importa_MySQLdb_calcio_saponi.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
CASAP = []

for i in parametri:
	i = "SELECT %s FROM Sottoprodotto WHERE nome = 'calcio_saponi'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	CASAP.append(float(i[0]))
#   print(CASAP)

CASAP = list(np.float_(CASAP))

del CASAP[13:18]
del CASAP[10]
del CASAP[13:15]

CASAP[0] = CASAP[0]/100
CASAP[1] = CASAP[1]*10
CASAP[2] = CASAP[2]*10
CASAP[3] = CASAP[3]*10
CASAP[4] = CASAP[4]*10
CASAP[5] = CASAP[5]*10
CASAP[6] = CASAP[6]*10
CASAP[7] = CASAP[7]*10
CASAP[8] = CASAP[8]*10
CASAP[9] = CASAP[9]*10
CASAP[10] = CASAP[10]*10
CASAP[11] = CASAP[11]*10

CASAP_arr = np.array(CASAP)
print(CASAP_arr)
# sio.sCASAPemat('CASAP.mat', {'vect':CASAP})
