# importa_MySQLdb_carruba_polpa_denocciolata.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
CARRPOLDEN = []

for i in parametri:
	i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'carruba_polpa_denocciolata'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	CARRPOLDEN.append(float(i[0]))
#   print(CARRPOLDEN)

CARRPOLDEN = list(np.float_(CARRPOLDEN))

del CARRPOLDEN[13:18]
del CARRPOLDEN[10]
del CARRPOLDEN[13:15]

CARRPOLDEN[0] = CARRPOLDEN[0]/100
CARRPOLDEN[1] = CARRPOLDEN[1]*10
CARRPOLDEN[2] = CARRPOLDEN[2]*10
CARRPOLDEN[3] = CARRPOLDEN[3]*10
CARRPOLDEN[4] = CARRPOLDEN[4]*10
CARRPOLDEN[5] = CARRPOLDEN[5]*10
CARRPOLDEN[6] = CARRPOLDEN[6]*10
CARRPOLDEN[7] = CARRPOLDEN[7]*10
CARRPOLDEN[8] = CARRPOLDEN[8]*10
CARRPOLDEN[9] = CARRPOLDEN[9]*10
CARRPOLDEN[10] = CARRPOLDEN[10]*10
CARRPOLDEN[11] = CARRPOLDEN[11]*10

CARRPOLDEN_arr = np.array(CARRPOLDEN)
print(CARRPOLDEN_arr)
# sio.sCARRPOLDENemat('CARRPOLDEN.mat', {'vect':CARRPOLDEN})
