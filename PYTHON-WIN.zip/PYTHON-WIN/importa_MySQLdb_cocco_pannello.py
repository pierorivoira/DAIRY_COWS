# importa_MySQLdb_cocco_pannello.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
COCPANN = []

for i in parametri:
	i = "SELECT %s FROM Sottoprodotto WHERE nome = 'cocco_pannello'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	COCPANN.append(float(i[0]))
#   print(COCPANN)

COCPANN = list(np.float_(COCPANN))

del COCPANN[13:18]
del COCPANN[10]
del COCPANN[13:15]

COCPANN[0] = COCPANN[0]/100
COCPANN[1] = COCPANN[1]*10
COCPANN[2] = COCPANN[2]*10
COCPANN[3] = COCPANN[3]*10
COCPANN[4] = COCPANN[4]*10
COCPANN[5] = COCPANN[5]*10
COCPANN[6] = COCPANN[6]*10
COCPANN[7] = COCPANN[7]*10
COCPANN[8] = COCPANN[8]*10
COCPANN[9] = COCPANN[9]*10
COCPANN[10] = COCPANN[10]*10
COCPANN[11] = COCPANN[11]*10

COCPANN_arr = np.array(COCPANN)
print(COCPANN_arr)
# sio.sCOCPANNemat('COCPANN.mat', {'vect':COCPANN})
