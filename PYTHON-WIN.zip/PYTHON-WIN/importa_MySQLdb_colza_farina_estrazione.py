# importa_MySQLdb_colza_farina_estrazione.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
COLFAESTR = []

for i in parametri:
	i = "SELECT %s FROM Farina_di_estrazione WHERE nome = 'colza_farina_estrazione'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	COLFAESTR.append(float(i[0]))
#   print(COLFAESTR)

COLFAESTR = list(np.float_(COLFAESTR))

del COLFAESTR[13:18]
del COLFAESTR[10]
del COLFAESTR[13:15]

COLFAESTR[0] = COLFAESTR[0]/100
COLFAESTR[1] = COLFAESTR[1]*10
COLFAESTR[2] = COLFAESTR[2]*10
COLFAESTR[3] = COLFAESTR[3]*10
COLFAESTR[4] = COLFAESTR[4]*10
COLFAESTR[5] = COLFAESTR[5]*10
COLFAESTR[6] = COLFAESTR[6]*10
COLFAESTR[7] = COLFAESTR[7]*10
COLFAESTR[8] = COLFAESTR[8]*10
COLFAESTR[9] = COLFAESTR[9]*10
COLFAESTR[10] = COLFAESTR[10]*10
COLFAESTR[11] = COLFAESTR[11]*10

COLFAESTR_arr = np.array(COLFAESTR)
print(COLFAESTR_arr)
# sio.sCOLFAESTRemat('COLFAESTR.mat', {'vect':COLFAESTR})
