# importa_MySQLdb_cotone_farina_estrazione.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
COTFAESTR = []

for i in parametri:
	i = "SELECT %s FROM Farina_di_estrazione WHERE nome = 'cotone_farina_estrazione'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	COTFAESTR.append(float(i[0]))
#   print(COTFAESTR)

COTFAESTR = list(np.float_(COTFAESTR))

del COTFAESTR[13:18]
del COTFAESTR[10]
del COTFAESTR[13:15]

COTFAESTR[0] = COTFAESTR[0]/100
COTFAESTR[1] = COTFAESTR[1]*10
COTFAESTR[2] = COTFAESTR[2]*10
COTFAESTR[3] = COTFAESTR[3]*10
COTFAESTR[4] = COTFAESTR[4]*10
COTFAESTR[5] = COTFAESTR[5]*10
COTFAESTR[6] = COTFAESTR[6]*10
COTFAESTR[7] = COTFAESTR[7]*10
COTFAESTR[8] = COTFAESTR[8]*10
COTFAESTR[9] = COTFAESTR[9]*10
COTFAESTR[10] = COTFAESTR[10]*10
COTFAESTR[11] = COTFAESTR[11]*10

COTFAESTR_arr = np.array(COTFAESTR)
print(COTFAESTR_arr)
# sio.sCOTFAESTRemat('COTFAESTR.mat', {'vect':COTFAESTR})
