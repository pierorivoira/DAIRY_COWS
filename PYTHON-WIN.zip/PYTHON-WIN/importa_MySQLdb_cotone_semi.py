# importa_MySQLdb_cotone_semi.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
COTSEMI = []

for i in parametri:
	i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'cotone_semi'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	COTSEMI.append(float(i[0]))
#   print(COTSEMI)

COTSEMI = list(np.float_(COTSEMI))

del COTSEMI[13:18]
del COTSEMI[10]
del COTSEMI[13:15]

COTSEMI[0] = COTSEMI[0]/100
COTSEMI[1] = COTSEMI[1]*10
COTSEMI[2] = COTSEMI[2]*10
COTSEMI[3] = COTSEMI[3]*10
COTSEMI[4] = COTSEMI[4]*10
COTSEMI[5] = COTSEMI[5]*10
COTSEMI[6] = COTSEMI[6]*10
COTSEMI[7] = COTSEMI[7]*10
COTSEMI[8] = COTSEMI[8]*10
COTSEMI[9] = COTSEMI[9]*10
COTSEMI[10] = COTSEMI[10]*10
COTSEMI[11] = COTSEMI[11]*10

COTSEMI_arr = np.array(COTSEMI)
print(COTSEMI_arr)
# sio.sCOTSEMIemat('COTSEMI.mat', {'vect':COTSEMI})
