# importa_MySQLdb_crusca_frumento_tenero.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
CRUFRUTE = []

for i in parametri:
	i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'crusca_frumento_tenero'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	CRUFRUTE.append(float(i[0]))
#   print(CRUFRUTE)

CRUFRUTE = list(np.float_(CRUFRUTE))

del CRUFRUTE[13:18]
del CRUFRUTE[10]
del CRUFRUTE[13:15]

CRUFRUTE[0] = CRUFRUTE[0]/100
CRUFRUTE[1] = CRUFRUTE[1]*10
CRUFRUTE[2] = CRUFRUTE[2]*10
CRUFRUTE[3] = CRUFRUTE[3]*10
CRUFRUTE[4] = CRUFRUTE[4]*10
CRUFRUTE[5] = CRUFRUTE[5]*10
CRUFRUTE[6] = CRUFRUTE[6]*10
CRUFRUTE[7] = CRUFRUTE[7]*10
CRUFRUTE[8] = CRUFRUTE[8]*10
CRUFRUTE[9] = CRUFRUTE[9]*10
CRUFRUTE[10] = CRUFRUTE[10]*10
CRUFRUTE[11] = CRUFRUTE[11]*10

CRUFRUTE_arr = np.array(CRUFRUTE)
print(CRUFRUTE_arr)
# sio.sCRUFRUTEemat('CRUFRUTE.mat', {'vect':CRUFRUTE})
