# importa_MySQLdb_cruschello_frumento_duro.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
CRUSCHFRUDU = []

for i in parametri:
	i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'cruschello_frumento_duro'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	CRUSCHFRUDU.append(float(i[0]))
#   print(CRUSCHFRUDU)

CRUSCHFRUDU = list(np.float_(CRUSCHFRUDU))

del CRUSCHFRUDU[13:18]
del CRUSCHFRUDU[10]
del CRUSCHFRUDU[13:15]

CRUSCHFRUDU[0] = CRUSCHFRUDU[0]/100
CRUSCHFRUDU[1] = CRUSCHFRUDU[1]*10
CRUSCHFRUDU[2] = CRUSCHFRUDU[2]*10
CRUSCHFRUDU[3] = CRUSCHFRUDU[3]*10
CRUSCHFRUDU[4] = CRUSCHFRUDU[4]*10
CRUSCHFRUDU[5] = CRUSCHFRUDU[5]*10
CRUSCHFRUDU[6] = CRUSCHFRUDU[6]*10
CRUSCHFRUDU[7] = CRUSCHFRUDU[7]*10
CRUSCHFRUDU[8] = CRUSCHFRUDU[8]*10
CRUSCHFRUDU[9] = CRUSCHFRUDU[9]*10
CRUSCHFRUDU[10] = CRUSCHFRUDU[10]*10
CRUSCHFRUDU[11] = CRUSCHFRUDU[11]*10

CRUSCHFRUDU_arr = np.array(CRUSCHFRUDU)
print(CRUSCHFRUDU_arr)
# sio.sCRUSCHFRUDUemat('CRUSCHFRUDU.mat', {'vect':CRUSCHFRUDU})
