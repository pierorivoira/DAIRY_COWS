# importa_MySQLdb_cruschello_frumento_tenero.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
CRUSCHFRUTE = []

for i in parametri:
	i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'cruschello_frumento_tenero'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	CRUSCHFRUTE.append(float(i[0]))
#   print(CRUSCHFRUTE)

CRUSCHFRUTE = list(np.float_(CRUSCHFRUTE))

del CRUSCHFRUTE[13:18]
del CRUSCHFRUTE[10]
del CRUSCHFRUTE[13:15]

CRUSCHFRUTE[0] = CRUSCHFRUTE[0]/100
CRUSCHFRUTE[1] = CRUSCHFRUTE[1]*10
CRUSCHFRUTE[2] = CRUSCHFRUTE[2]*10
CRUSCHFRUTE[3] = CRUSCHFRUTE[3]*10
CRUSCHFRUTE[4] = CRUSCHFRUTE[4]*10
CRUSCHFRUTE[5] = CRUSCHFRUTE[5]*10
CRUSCHFRUTE[6] = CRUSCHFRUTE[6]*10
CRUSCHFRUTE[7] = CRUSCHFRUTE[7]*10
CRUSCHFRUTE[8] = CRUSCHFRUTE[8]*10
CRUSCHFRUTE[9] = CRUSCHFRUTE[9]*10
CRUSCHFRUTE[10] = CRUSCHFRUTE[10]*10
CRUSCHFRUTE[11] = CRUSCHFRUTE[11]*10

CRUSCHFRUTE_arr = np.array(CRUSCHFRUTE)
print(CRUSCHFRUTE_arr)
# sio.sCRUSCHFRUTEemat('CRUSCHFRUTE.mat', {'vect':CRUSCHFRUTE})
