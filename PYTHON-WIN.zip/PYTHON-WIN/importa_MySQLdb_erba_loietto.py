# importa_MySQLdb_erba_loietto.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
erba_loietto = []

for i in parametri:
	i = "SELECT %s FROM Foraggio WHERE nome = 'erba_loietto'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	erba_loietto.append(float(i[0]))
#   print(erba_loietto)

ERLO = list(np.float_(erba_loietto))

del ERLO[13:18]
del ERLO[10]
del ERLO[13:15]

ERLO[0] = ERLO[0]/100
ERLO[1] = ERLO[1]*10
ERLO[2] = ERLO[2]*10
ERLO[3] = ERLO[3]*10
ERLO[4] = ERLO[4]*10
ERLO[5] = ERLO[5]*10
ERLO[6] = ERLO[6]*10
ERLO[7] = ERLO[7]*10
ERLO[8] = ERLO[8]*10
ERLO[9] = ERLO[9]*10
ERLO[10] = ERLO[10]*10
ERLO[11] = ERLO[11]*10

ERLO_arr = np.array(ERLO)
print(ERLO_arr)
# sio.savemat('ERLO.mat', {'vect':ERLO})
