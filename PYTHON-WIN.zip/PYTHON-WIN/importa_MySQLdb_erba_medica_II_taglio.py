# importa_MySQLdb_erba_medica_II_taglio.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
erba_medica_II_taglio = []

for i in parametri:
	i = "SELECT %s FROM Foraggio WHERE nome = 'erba_medica_II_taglio'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	erba_medica_II_taglio.append(float(i[0]))
#   print(erba_medica_II_taglio)

ERME2TA = list(np.float_(erba_medica_II_taglio))

del ERME2TA[13:18]
del ERME2TA[10]
del ERME2TA[13:15]

ERME2TA[0] = ERME2TA[0]/100
ERME2TA[1] = ERME2TA[1]*10
ERME2TA[2] = ERME2TA[2]*10
ERME2TA[3] = ERME2TA[3]*10
ERME2TA[4] = ERME2TA[4]*10
ERME2TA[5] = ERME2TA[5]*10
ERME2TA[6] = ERME2TA[6]*10
ERME2TA[7] = ERME2TA[7]*10
ERME2TA[8] = ERME2TA[8]*10
ERME2TA[9] = ERME2TA[9]*10
ERME2TA[10] = ERME2TA[10]*10
ERME2TA[11] = ERME2TA[11]*10

ERME2TA_arr = np.array(ERME2TA)
print(ERME2TA_arr)
# sio.savemat('ERME2TA.mat', {'vect':ERME2TA})
