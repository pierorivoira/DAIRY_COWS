# importa_MySQLdb_erba_medica_disidratata_15_per_100.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
erba_medica_disidratata_15_per_100 = []

for i in parametri:
	i = "SELECT %s FROM Foraggio WHERE nome = 'erba_medica_disidratata_15_per_100'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	erba_medica_disidratata_15_per_100.append(float(i[0]))
#   print(erba_medica_disidratata_15_per_100)

ERMEDIS15 = list(np.float_(erba_medica_disidratata_15_per_100))

del ERMEDIS15[13:18]
del ERMEDIS15[10]
del ERMEDIS15[13:15]

ERMEDIS15[0] = ERMEDIS15[0]/100
ERMEDIS15[1] = ERMEDIS15[1]*10
ERMEDIS15[2] = ERMEDIS15[2]*10
ERMEDIS15[3] = ERMEDIS15[3]*10
ERMEDIS15[4] = ERMEDIS15[4]*10
ERMEDIS15[5] = ERMEDIS15[5]*10
ERMEDIS15[6] = ERMEDIS15[6]*10
ERMEDIS15[7] = ERMEDIS15[7]*10
ERMEDIS15[8] = ERMEDIS15[8]*10
ERMEDIS15[9] = ERMEDIS15[9]*10
ERMEDIS15[10] = ERMEDIS15[10]*10
ERMEDIS15[11] = ERMEDIS15[11]*10

ERMEDIS15_arr = np.array(ERMEDIS15)
print(ERMEDIS15_arr)
# sio.savemat('ERMEDIS15.mat', {'vect':ERMEDIS15})
