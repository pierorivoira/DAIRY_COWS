# importa_MySQLdb_erba_medica_disidratata_17_per_100.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
erba_medica_disidratata_17_per_100 = []

for i in parametri:
	i = "SELECT %s FROM Foraggio WHERE nome = 'erba_medica_disidratata_17_per_100'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	erba_medica_disidratata_17_per_100.append(float(i[0]))
#   print(erba_medica_disidratata_17_per_100)

ERMEDIS17 = list(np.float_(erba_medica_disidratata_17_per_100))

del ERMEDIS17[13:18]
del ERMEDIS17[10]
del ERMEDIS17[13:15]

ERMEDIS17[0] = ERMEDIS17[0]/100
ERMEDIS17[1] = ERMEDIS17[1]*10
ERMEDIS17[2] = ERMEDIS17[2]*10
ERMEDIS17[3] = ERMEDIS17[3]*10
ERMEDIS17[4] = ERMEDIS17[4]*10
ERMEDIS17[5] = ERMEDIS17[5]*10
ERMEDIS17[6] = ERMEDIS17[6]*10
ERMEDIS17[7] = ERMEDIS17[7]*10
ERMEDIS17[8] = ERMEDIS17[8]*10
ERMEDIS17[9] = ERMEDIS17[9]*10
ERMEDIS17[10] = ERMEDIS17[10]*10
ERMEDIS17[11] = ERMEDIS17[11]*10

ERMEDIS17_arr = np.array(ERMEDIS17)
print(ERMEDIS17_arr)
# sio.savemat('ERMEDIS17.mat', {'vect':ERMEDIS17})
