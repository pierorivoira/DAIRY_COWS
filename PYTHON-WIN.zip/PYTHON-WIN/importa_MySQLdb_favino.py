# importa_MySQLdb_favino.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
FAVINO = []

for i in parametri:
	i = "SELECT %s FROM Leguminosa WHERE nome = 'favino'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	FAVINO.append(float(i[0]))
#   print(FAVINO)

FAVINO = list(np.float_(FAVINO))

del FAVINO[13:18]
del FAVINO[10]
del FAVINO[13:15]

FAVINO[0] = FAVINO[0]/100
FAVINO[1] = FAVINO[1]*10
FAVINO[2] = FAVINO[2]*10
FAVINO[3] = FAVINO[3]*10
FAVINO[4] = FAVINO[4]*10
FAVINO[5] = FAVINO[5]*10
FAVINO[6] = FAVINO[6]*10
FAVINO[7] = FAVINO[7]*10
FAVINO[8] = FAVINO[8]*10
FAVINO[9] = FAVINO[9]*10
FAVINO[10] = FAVINO[10]*10
FAVINO[11] = FAVINO[11]*10

FAVINO_arr = np.array(FAVINO)
print(FAVINO_arr)

# sio.savemat('FAVINO.mat', {'vect':FAVINO})
