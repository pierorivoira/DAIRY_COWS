# importa_MySQLdb_fieno_loietto.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
fieno_loietto = []

for i in parametri:
	i = "SELECT %s FROM Foraggio WHERE nome = 'fieno_loietto'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	fieno_loietto.append(float(i[0]))
#   print(fieno_loietto)

FIELO = list(np.float_(fieno_loietto))

del FIELO[13:18]
del FIELO[10]
del FIELO[13:15]

FIELO[0] = FIELO[0]/100
FIELO[1] = FIELO[1]*10
FIELO[2] = FIELO[2]*10
FIELO[3] = FIELO[3]*10
FIELO[4] = FIELO[4]*10
FIELO[5] = FIELO[5]*10
FIELO[6] = FIELO[6]*10
FIELO[7] = FIELO[7]*10
FIELO[8] = FIELO[8]*10
FIELO[9] = FIELO[9]*10
FIELO[10] = FIELO[10]*10
FIELO[11] = FIELO[11]*10

FIELO_arr = np.array(FIELO)
print(FIELO_arr)
# sio.savemat('FIELO.mat', {'vect':FIELO})
