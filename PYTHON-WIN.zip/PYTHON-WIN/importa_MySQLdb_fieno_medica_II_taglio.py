# importa_MySQLdb_fieno_medica_II_taglio.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
fieno_medica_II_taglio = []

for i in parametri:
	i = "SELECT %s FROM Foraggio WHERE nome = 'fieno_medica_II_taglio'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	fieno_medica_II_taglio.append(float(i[0]))
#   print(fieno_medica_II_taglio)

FIEME2TA = list(np.float_(fieno_medica_II_taglio))

del FIEME2TA[13:18]
del FIEME2TA[10]
del FIEME2TA[13:15]

FIEME2TA[0] = FIEME2TA[0]/100
FIEME2TA[1] = FIEME2TA[1]*10
FIEME2TA[2] = FIEME2TA[2]*10
FIEME2TA[3] = FIEME2TA[3]*10
FIEME2TA[4] = FIEME2TA[4]*10
FIEME2TA[5] = FIEME2TA[5]*10
FIEME2TA[6] = FIEME2TA[6]*10
FIEME2TA[7] = FIEME2TA[7]*10
FIEME2TA[8] = FIEME2TA[8]*10
FIEME2TA[9] = FIEME2TA[9]*10
FIEME2TA[10] = FIEME2TA[10]*10
FIEME2TA[11] = FIEME2TA[11]*10

FIEME2TA_arr = np.array(FIEME2TA)
print(FIEME2TA_arr)
# sio.savemat('FIEME2TA.mat', {'vect':FIEME2TA})
