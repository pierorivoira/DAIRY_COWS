# importa_MySQLdb_fieno_medica_I_taglio.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
fieno_medica_I_taglio = []

for i in parametri:
	i = "SELECT %s FROM Foraggio WHERE nome = 'fieno_medica_I_taglio'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	fieno_medica_I_taglio.append(float(i[0]))
#   print(fieno_medica_I_taglio)

FIEME1TA = list(np.float_(fieno_medica_I_taglio))

del FIEME1TA[13:18]
del FIEME1TA[10]
del FIEME1TA[13:15]

FIEME1TA[0] = FIEME1TA[0]/100
FIEME1TA[1] = FIEME1TA[1]*10
FIEME1TA[2] = FIEME1TA[2]*10
FIEME1TA[3] = FIEME1TA[3]*10
FIEME1TA[4] = FIEME1TA[4]*10
FIEME1TA[5] = FIEME1TA[5]*10
FIEME1TA[6] = FIEME1TA[6]*10
FIEME1TA[7] = FIEME1TA[7]*10
FIEME1TA[8] = FIEME1TA[8]*10
FIEME1TA[9] = FIEME1TA[9]*10
FIEME1TA[10] = FIEME1TA[10]*10
FIEME1TA[11] = FIEME1TA[11]*10

FIEME1TA_arr = np.array(FIEME1TA)
print(FIEME1TA_arr)
# sio.savemat('FIEME1TA.mat', {'vect':FIEME1TA})
