# importa_MySQLdb_fieno_prato_stabile_II_taglio.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
fieno_prato_stabile_II_taglio = []

for i in parametri:
	i = "SELECT %s FROM Foraggio WHERE nome = 'fieno_prato_stabile_II_taglio'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	fieno_prato_stabile_II_taglio.append(float(i[0]))
#   print(fieno_prato_stabile_II_taglio)

FIEPRASTA2TA = list(np.float_(fieno_prato_stabile_II_taglio))

del FIEPRASTA2TA[13:18]
del FIEPRASTA2TA[10]
del FIEPRASTA2TA[13:15]

FIEPRASTA2TA[0] = FIEPRASTA2TA[0]/100
FIEPRASTA2TA[1] = FIEPRASTA2TA[1]*10
FIEPRASTA2TA[2] = FIEPRASTA2TA[2]*10
FIEPRASTA2TA[3] = FIEPRASTA2TA[3]*10
FIEPRASTA2TA[4] = FIEPRASTA2TA[4]*10
FIEPRASTA2TA[5] = FIEPRASTA2TA[5]*10
FIEPRASTA2TA[6] = FIEPRASTA2TA[6]*10
FIEPRASTA2TA[7] = FIEPRASTA2TA[7]*10
FIEPRASTA2TA[8] = FIEPRASTA2TA[8]*10
FIEPRASTA2TA[9] = FIEPRASTA2TA[9]*10
FIEPRASTA2TA[10] = FIEPRASTA2TA[10]*10
FIEPRASTA2TA[11] = FIEPRASTA2TA[11]*10

FIEPRASTA2TA_arr = np.array(FIEPRASTA2TA)
print(FIEPRASTA2TA_arr)
# sio.savemat('FIEPRASTA2TA.mat', {'vect':FIEPRASTA2TA})
