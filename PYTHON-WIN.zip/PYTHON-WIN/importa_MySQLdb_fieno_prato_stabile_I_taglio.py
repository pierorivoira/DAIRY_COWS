# importa_MySQLdb_fieno_prato_stabile_I_taglio.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
fieno_prato_stabile_I_taglio = []

for i in parametri:
	i = "SELECT %s FROM Foraggio WHERE nome = 'fieno_prato_stabile_I_taglio'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	fieno_prato_stabile_I_taglio.append(float(i[0]))
#   print(fieno_prato_stabile_I_taglio)

FIEPRASTA1TA = list(np.float_(fieno_prato_stabile_I_taglio))

del FIEPRASTA1TA[13:18]
del FIEPRASTA1TA[10]
del FIEPRASTA1TA[13:15]

FIEPRASTA1TA[0] = FIEPRASTA1TA[0]/100
FIEPRASTA1TA[1] = FIEPRASTA1TA[1]*10
FIEPRASTA1TA[2] = FIEPRASTA1TA[2]*10
FIEPRASTA1TA[3] = FIEPRASTA1TA[3]*10
FIEPRASTA1TA[4] = FIEPRASTA1TA[4]*10
FIEPRASTA1TA[5] = FIEPRASTA1TA[5]*10
FIEPRASTA1TA[6] = FIEPRASTA1TA[6]*10
FIEPRASTA1TA[7] = FIEPRASTA1TA[7]*10
FIEPRASTA1TA[8] = FIEPRASTA1TA[8]*10
FIEPRASTA1TA[9] = FIEPRASTA1TA[9]*10
FIEPRASTA1TA[10] = FIEPRASTA1TA[10]*10
FIEPRASTA1TA[11] = FIEPRASTA1TA[11]*10

FIEPRASTA1TA_arr = np.array(FIEPRASTA1TA)
print(FIEPRASTA1TA_arr)
# sio.savemat('FIEPRASTA1TA.mat', {'vect':FIEPRASTA1TA})
