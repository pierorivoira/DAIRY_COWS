# importa_MySQLdb_fieno_silos_medica.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
fieno_silos_medica = []

for i in parametri:
	i = "SELECT %s FROM Foraggio WHERE nome = 'fieno_silos_medica'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	fieno_silos_medica.append(float(i[0]))
#   print(fieno_silos_medica)

FIESIME = list(np.float_(fieno_silos_medica))

del FIESIME[13:18]
del FIESIME[10]
del FIESIME[13:15]

FIESIME[0] = FIESIME[0]/100
FIESIME[1] = FIESIME[1]*10
FIESIME[2] = FIESIME[2]*10
FIESIME[3] = FIESIME[3]*10
FIESIME[4] = FIESIME[4]*10
FIESIME[5] = FIESIME[5]*10
FIESIME[6] = FIESIME[6]*10
FIESIME[7] = FIESIME[7]*10
FIESIME[8] = FIESIME[8]*10
FIESIME[9] = FIESIME[9]*10
FIESIME[10] = FIESIME[10]*10
FIESIME[11] = FIESIME[11]*10

FIESIME_arr = np.array(FIESIME)
print(FIESIME_arr)
# sio.savemat('FIESIME.mat', {'vect':FIESIME})
