# importa_MySQLdb_frumento_duro_farinaccio.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
FRUDUFA = []

for i in parametri:
	i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'frumento_duro_farinaccio'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	FRUDUFA.append(float(i[0]))
#   print(FRUDUFA)

FRUDUFA = list(np.float_(FRUDUFA))

del FRUDUFA[13:18]
del FRUDUFA[10]
del FRUDUFA[13:15]

FRUDUFA[0] = FRUDUFA[0]/100
FRUDUFA[1] = FRUDUFA[1]*10
FRUDUFA[2] = FRUDUFA[2]*10
FRUDUFA[3] = FRUDUFA[3]*10
FRUDUFA[4] = FRUDUFA[4]*10
FRUDUFA[5] = FRUDUFA[5]*10
FRUDUFA[6] = FRUDUFA[6]*10
FRUDUFA[7] = FRUDUFA[7]*10
FRUDUFA[8] = FRUDUFA[8]*10
FRUDUFA[9] = FRUDUFA[9]*10
FRUDUFA[10] = FRUDUFA[10]*10
FRUDUFA[11] = FRUDUFA[11]*10

FRUDUFA_arr = np.array(FRUDUFA)
print(FRUDUFA_arr)
# sio.sFRUDUFAemat('FRUDUFA.mat', {'vect':FRUDUFA})
