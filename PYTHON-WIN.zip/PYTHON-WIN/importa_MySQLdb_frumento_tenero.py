# importa_MySQLdb_frumento_tenero.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
frumento_tenero = []

for i in parametri:
	i = "SELECT %s FROM Cereale WHERE nome = 'frumento_tenero'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	frumento_tenero.append(float(i[0]))
#   print(frumento_tenero)

FRUTE = list(np.float_(frumento_tenero))

del FRUTE[13:18]
del FRUTE[10]
del FRUTE[13:15]

FRUTE[0] = FRUTE[0]/100
FRUTE[1] = FRUTE[1]*10
FRUTE[2] = FRUTE[2]*10
FRUTE[3] = FRUTE[3]*10
FRUTE[4] = FRUTE[4]*10
FRUTE[5] = FRUTE[5]*10
FRUTE[6] = FRUTE[6]*10
FRUTE[7] = FRUTE[7]*10
FRUTE[8] = FRUTE[8]*10
FRUTE[9] = FRUTE[9]*10
FRUTE[10] = FRUTE[10]*10
FRUTE[11] = FRUTE[11]*10

FRUTE_arr = np.array(FRUTE)
print(FRUTE_arr)
# sio.sFRUTEemat('FRUTE.mat', {'vect':FRUTE})
