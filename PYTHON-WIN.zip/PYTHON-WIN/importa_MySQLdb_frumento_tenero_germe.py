# importa_MySQLdb_frumento_tenero_germe.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
FRUTEGE = []

for i in parametri:
	i = "SELECT %s FROM Sottoprodotto WHERE nome = 'frumento_tenero_germe'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	FRUTEGE.append(float(i[0]))
#   print(FRUTEGE)

FRUTEGE = list(np.float_(FRUTEGE))

del FRUTEGE[13:18]
del FRUTEGE[10]
del FRUTEGE[13:15]

FRUTEGE[0] = FRUTEGE[0]/100
FRUTEGE[1] = FRUTEGE[1]*10
FRUTEGE[2] = FRUTEGE[2]*10
FRUTEGE[3] = FRUTEGE[3]*10
FRUTEGE[4] = FRUTEGE[4]*10
FRUTEGE[5] = FRUTEGE[5]*10
FRUTEGE[6] = FRUTEGE[6]*10
FRUTEGE[7] = FRUTEGE[7]*10
FRUTEGE[8] = FRUTEGE[8]*10
FRUTEGE[9] = FRUTEGE[9]*10
FRUTEGE[10] = FRUTEGE[10]*10
FRUTEGE[11] = FRUTEGE[11]*10

FRUTEGE_arr = np.array(FRUTEGE)
print(FRUTEGE_arr)
# sio.sFRUTEGEemat('FRUTEGE.mat', {'vect':FRUTEGE})
