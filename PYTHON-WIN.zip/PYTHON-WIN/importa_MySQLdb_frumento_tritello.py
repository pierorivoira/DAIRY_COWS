# importa_MySQLdb_frumento_tritello.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
FRUTRI = []

for i in parametri:
	i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'frumento_tritello'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	FRUTRI.append(float(i[0]))
#   print(FRUTRI)

FRUTRI = list(np.float_(FRUTRI))

del FRUTRI[13:18]
del FRUTRI[10]
del FRUTRI[13:15]

FRUTRI[0] = FRUTRI[0]/100
FRUTRI[1] = FRUTRI[1]*10
FRUTRI[2] = FRUTRI[2]*10
FRUTRI[3] = FRUTRI[3]*10
FRUTRI[4] = FRUTRI[4]*10
FRUTRI[5] = FRUTRI[5]*10
FRUTRI[6] = FRUTRI[6]*10
FRUTRI[7] = FRUTRI[7]*10
FRUTRI[8] = FRUTRI[8]*10
FRUTRI[9] = FRUTRI[9]*10
FRUTRI[10] = FRUTRI[10]*10
FRUTRI[11] = FRUTRI[11]*10

FRUTRI_arr = np.array(FRUTRI)
print(FRUTRI_arr)
# sio.sFRUTRIemat('FRUTRI.mat', {'vect':FRUTRI})
