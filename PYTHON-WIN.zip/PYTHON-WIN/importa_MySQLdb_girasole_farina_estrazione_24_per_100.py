# importa_MySQLdb_girasole_farina_estrazione_24_per_100.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
GIRFAESTR24 = []

for i in parametri:
	i = "SELECT %s FROM Farina_di_estrazione WHERE nome = 'girasole_farina_estrazione_24_per_100'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	GIRFAESTR24.append(float(i[0]))
#   print(GIRFAESTR24)

GIRFAESTR24 = list(np.float_(GIRFAESTR24))

del GIRFAESTR24[13:18]
del GIRFAESTR24[10]
del GIRFAESTR24[13:15]

GIRFAESTR24[0] = GIRFAESTR24[0]/100
GIRFAESTR24[1] = GIRFAESTR24[1]*10
GIRFAESTR24[2] = GIRFAESTR24[2]*10
GIRFAESTR24[3] = GIRFAESTR24[3]*10
GIRFAESTR24[4] = GIRFAESTR24[4]*10
GIRFAESTR24[5] = GIRFAESTR24[5]*10
GIRFAESTR24[6] = GIRFAESTR24[6]*10
GIRFAESTR24[7] = GIRFAESTR24[7]*10
GIRFAESTR24[8] = GIRFAESTR24[8]*10
GIRFAESTR24[9] = GIRFAESTR24[9]*10
GIRFAESTR24[10] = GIRFAESTR24[10]*10
GIRFAESTR24[11] = GIRFAESTR24[11]*10

GIRFAESTR24_arr = np.array(GIRFAESTR24)
print(GIRFAESTR24_arr)
# sio.sGIRFAESTR24emat('GIRFAESTR24.mat', {'vect':GIRFAESTR24})
