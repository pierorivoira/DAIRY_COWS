# importa_MySQLdb_girasole_farina_estrazione_34_per_100.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
GIRFAESTR34 = []

for i in parametri:
	i = "SELECT %s FROM Farina_di_estrazione WHERE nome = 'girasole_farina_estrazione_34_per_100'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	GIRFAESTR34.append(float(i[0]))
#   print(GIRFAESTR34)

GIRFAESTR34 = list(np.float_(GIRFAESTR34))

del GIRFAESTR34[13:18]
del GIRFAESTR34[10]
del GIRFAESTR34[13:15]

GIRFAESTR34[0] = GIRFAESTR34[0]/100
GIRFAESTR34[1] = GIRFAESTR34[1]*10
GIRFAESTR34[2] = GIRFAESTR34[2]*10
GIRFAESTR34[3] = GIRFAESTR34[3]*10
GIRFAESTR34[4] = GIRFAESTR34[4]*10
GIRFAESTR34[5] = GIRFAESTR34[5]*10
GIRFAESTR34[6] = GIRFAESTR34[6]*10
GIRFAESTR34[7] = GIRFAESTR34[7]*10
GIRFAESTR34[8] = GIRFAESTR34[8]*10
GIRFAESTR34[9] = GIRFAESTR34[9]*10
GIRFAESTR34[10] = GIRFAESTR34[10]*10
GIRFAESTR34[11] = GIRFAESTR34[11]*10

GIRFAESTR34_arr = np.array(GIRFAESTR34)
print(GIRFAESTR34_arr)
# sio.sGIRFAESTR34emat('GIRFAESTR34.mat', {'vect':GIRFAESTR34})
