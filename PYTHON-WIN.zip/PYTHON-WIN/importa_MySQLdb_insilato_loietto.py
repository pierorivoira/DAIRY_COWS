# importa_MySQLdb_insilato_loietto.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
insilato_loietto = []

for i in parametri:
	i = "SELECT %s FROM Foraggio WHERE nome = 'insilato_loietto'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	insilato_loietto.append(float(i[0]))
#   print(insilato_loietto)

INSILO = list(np.float_(insilato_loietto))

del INSILO[13:18]
del INSILO[10]
del INSILO[13:15]

INSILO[0] = INSILO[0]/100
INSILO[1] = INSILO[1]*10
INSILO[2] = INSILO[2]*10
INSILO[3] = INSILO[3]*10
INSILO[4] = INSILO[4]*10
INSILO[5] = INSILO[5]*10
INSILO[6] = INSILO[6]*10
INSILO[7] = INSILO[7]*10
INSILO[8] = INSILO[8]*10
INSILO[9] = INSILO[9]*10
INSILO[10] = INSILO[10]*10
INSILO[11] = INSILO[11]*10

INSILO_arr = np.array(INSILO)
print(INSILO_arr)
# sio.savemat('INSILO.mat', {'vect':INSILO})
