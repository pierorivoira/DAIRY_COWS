# importa_MySQLdb_latte_magro_polvere.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
LATMAPOL = []

for i in parametri:
	i = "SELECT %s FROM Sottoprodotto WHERE nome = 'latte_magro_polvere'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	LATMAPOL.append(float(i[0]))
#   print(LATMAPOL)

LATMAPOL = list(np.float_(LATMAPOL))

del LATMAPOL[13:18]
del LATMAPOL[10]
del LATMAPOL[13:15]

LATMAPOL[0] = LATMAPOL[0]/100
LATMAPOL[1] = LATMAPOL[1]*10
LATMAPOL[2] = LATMAPOL[2]*10
LATMAPOL[3] = LATMAPOL[3]*10
LATMAPOL[4] = LATMAPOL[4]*10
LATMAPOL[5] = LATMAPOL[5]*10
LATMAPOL[6] = LATMAPOL[6]*10
LATMAPOL[7] = LATMAPOL[7]*10
LATMAPOL[8] = LATMAPOL[8]*10
LATMAPOL[9] = LATMAPOL[9]*10
LATMAPOL[10] = LATMAPOL[10]*10
LATMAPOL[11] = LATMAPOL[11]*10

LATMAPOL_arr = np.array(LATMAPOL)
print(LATMAPOL_arr)
# sio.sLATMAPOLemat('LATMAPOL.mat', {'vect':LATMAPOL})
