# importa_MySQLdb_latte_siero.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
LATSIE = []

for i in parametri:
	i = "SELECT %s FROM Sottoprodotto WHERE nome = 'latte_siero'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	LATSIE.append(float(i[0]))
#   print(LATSIE)

LATSIE = list(np.float_(LATSIE))

del LATSIE[13:18]
del LATSIE[10]
del LATSIE[13:15]

LATSIE[0] = LATSIE[0]/100
LATSIE[1] = LATSIE[1]*10
LATSIE[2] = LATSIE[2]*10
LATSIE[3] = LATSIE[3]*10
LATSIE[4] = LATSIE[4]*10
LATSIE[5] = LATSIE[5]*10
LATSIE[6] = LATSIE[6]*10
LATSIE[7] = LATSIE[7]*10
LATSIE[8] = LATSIE[8]*10
LATSIE[9] = LATSIE[9]*10
LATSIE[10] = LATSIE[10]*10
LATSIE[11] = LATSIE[11]*10

LATSIE_arr = np.array(LATSIE)
print(LATSIE_arr)
# sio.sLATSIEemat('LATSIE.mat', {'vect':LATSIE})
