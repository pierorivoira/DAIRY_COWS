# importa_MySQLdb_lupino.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
LU = []

for i in parametri:
	i = "SELECT %s FROM Leguminosa WHERE nome = 'lupino'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	LU.append(float(i[0]))
#   print(LU)

LU = list(np.float_(LU))

del LU[13:18]
del LU[10]
del LU[13:15]

LU[0] = LU[0]/100
LU[1] = LU[1]*10
LU[2] = LU[2]*10
LU[3] = LU[3]*10
LU[4] = LU[4]*10
LU[5] = LU[5]*10
LU[6] = LU[6]*10
LU[7] = LU[7]*10
LU[8] = LU[8]*10
LU[9] = LU[9]*10
LU[10] = LU[10]*10
LU[11] = LU[11]*10

LU_arr = np.array(LU)
print(LU_arr)

# sio.savemat('LU.mat', {'vect':LU})
