# importa_MySQLdb_mais_glutine.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
MAISGLU = []

for i in parametri:
	i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'mais_glutine'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	MAISGLU.append(float(i[0]))
#   print(MAISGLU)

MAISGLU = list(np.float_(MAISGLU))

del MAISGLU[13:18]
del MAISGLU[10]
del MAISGLU[13:15]

MAISGLU[0] = MAISGLU[0]/100
MAISGLU[1] = MAISGLU[1]*10
MAISGLU[2] = MAISGLU[2]*10
MAISGLU[3] = MAISGLU[3]*10
MAISGLU[4] = MAISGLU[4]*10
MAISGLU[5] = MAISGLU[5]*10
MAISGLU[6] = MAISGLU[6]*10
MAISGLU[7] = MAISGLU[7]*10
MAISGLU[8] = MAISGLU[8]*10
MAISGLU[9] = MAISGLU[9]*10
MAISGLU[10] = MAISGLU[10]*10
MAISGLU[11] = MAISGLU[11]*10

MAISGLU_arr = np.array(MAISGLU)
print(MAISGLU_arr)
# sio.sMAISGLUemat('MAISGLU.mat', {'vect':MAISGLU})
