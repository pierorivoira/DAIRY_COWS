# importa_MySQLdb_mais_granella.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
mais_granella = []

for i in parametri:
	i = "SELECT %s FROM Cereale WHERE nome = 'mais_granella'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	mais_granella.append(float(i[0]))
#   print(mais_granella)

MAISGRA = list(np.float_(mais_granella))

del MAISGRA[13:18]
del MAISGRA[10]
del MAISGRA[13:15]

MAISGRA[0] = MAISGRA[0]/100
MAISGRA[1] = MAISGRA[1]*10
MAISGRA[2] = MAISGRA[2]*10
MAISGRA[3] = MAISGRA[3]*10
MAISGRA[4] = MAISGRA[4]*10
MAISGRA[5] = MAISGRA[5]*10
MAISGRA[6] = MAISGRA[6]*10
MAISGRA[7] = MAISGRA[7]*10
MAISGRA[8] = MAISGRA[8]*10
MAISGRA[9] = MAISGRA[9]*10
MAISGRA[10] = MAISGRA[10]*10
MAISGRA[11] = MAISGRA[11]*10

MAISGRA_arr = np.array(MAISGRA)
print(MAISGRA_arr)
# sio.sMAISGRAemat('MAISGRA.mat', {'vect':MAISGRA})
