# importa_MySQLdb_mais_residui_distilleria.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
MAISDIST = []

for i in parametri:
	i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'mais_residui_distilleria'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	MAISDIST.append(float(i[0]))
#   print(MAISDIST)

MAISDIST = list(np.float_(MAISDIST))

del MAISDIST[13:18]
del MAISDIST[10]
del MAISDIST[13:15]

MAISDIST[0] = MAISDIST[0]/100
MAISDIST[1] = MAISDIST[1]*10
MAISDIST[2] = MAISDIST[2]*10
MAISDIST[3] = MAISDIST[3]*10
MAISDIST[4] = MAISDIST[4]*10
MAISDIST[5] = MAISDIST[5]*10
MAISDIST[6] = MAISDIST[6]*10
MAISDIST[7] = MAISDIST[7]*10
MAISDIST[8] = MAISDIST[8]*10
MAISDIST[9] = MAISDIST[9]*10
MAISDIST[10] = MAISDIST[10]*10
MAISDIST[11] = MAISDIST[11]*10

MAISDIST_arr = np.array(MAISDIST)
print(MAISDIST_arr)
# sio.sMAISDISTemat('MAISDIST.mat', {'vect':MAISDIST})
