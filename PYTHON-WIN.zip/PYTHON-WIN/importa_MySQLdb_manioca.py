# importa_MySQLdb_manioca.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
MANIO = []

for i in parametri:
	i = "SELECT %s FROM Sottoprodotto WHERE nome = 'manioca'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	MANIO.append(float(i[0]))
#   print(MANIO)

MANIO = list(np.float_(MANIO))

del MANIO[13:18]
del MANIO[10]
del MANIO[13:15]

MANIO[0] = MANIO[0]/100
MANIO[1] = MANIO[1]*10
MANIO[2] = MANIO[2]*10
MANIO[3] = MANIO[3]*10
MANIO[4] = MANIO[4]*10
MANIO[5] = MANIO[5]*10
MANIO[6] = MANIO[6]*10
MANIO[7] = MANIO[7]*10
MANIO[8] = MANIO[8]*10
MANIO[9] = MANIO[9]*10
MANIO[10] = MANIO[10]*10
MANIO[11] = MANIO[11]*10

MANIO_arr = np.array(MANIO)
print(MANIO_arr)
# sio.sMANIOemat('MANIO.mat', {'vect':MANIO})
