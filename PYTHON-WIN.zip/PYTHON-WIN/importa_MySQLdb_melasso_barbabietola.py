# importa_MySQLdb_melasso_barbabietola.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
MEBARBA = []

for i in parametri:
	i = "SELECT %s FROM Sottoprodotto WHERE nome = 'melasso_barbabietola'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	MEBARBA.append(float(i[0]))
#   print(MEBARBA)

MEBARBA = list(np.float_(MEBARBA))

del MEBARBA[13:18]
del MEBARBA[10]
del MEBARBA[13:15]

MEBARBA[0] = MEBARBA[0]/100
MEBARBA[1] = MEBARBA[1]*10
MEBARBA[2] = MEBARBA[2]*10
MEBARBA[3] = MEBARBA[3]*10
MEBARBA[4] = MEBARBA[4]*10
MEBARBA[5] = MEBARBA[5]*10
MEBARBA[6] = MEBARBA[6]*10
MEBARBA[7] = MEBARBA[7]*10
MEBARBA[8] = MEBARBA[8]*10
MEBARBA[9] = MEBARBA[9]*10
MEBARBA[10] = MEBARBA[10]*10
MEBARBA[11] = MEBARBA[11]*10

MEBARBA_arr = np.array(MEBARBA)
print(MEBARBA_arr)
# sio.sMEBARBAemat('MEBARBA.mat', {'vect':MEBARBA})
