# importa_MySQLdb_melasso_canna.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
MECANNA = []

for i in parametri:
	i = "SELECT %s FROM Sottoprodotto WHERE nome = 'melasso_canna'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	MECANNA.append(float(i[0]))
#   print(MECANNA)

MECANNA = list(np.float_(MECANNA))

del MECANNA[13:18]
del MECANNA[10]
del MECANNA[13:15]

MECANNA[0] = MECANNA[0]/100
MECANNA[1] = MECANNA[1]*10
MECANNA[2] = MECANNA[2]*10
MECANNA[3] = MECANNA[3]*10
MECANNA[4] = MECANNA[4]*10
MECANNA[5] = MECANNA[5]*10
MECANNA[6] = MECANNA[6]*10
MECANNA[7] = MECANNA[7]*10
MECANNA[8] = MECANNA[8]*10
MECANNA[9] = MECANNA[9]*10
MECANNA[10] = MECANNA[10]*10
MECANNA[11] = MECANNA[11]*10

MECANNA_arr = np.array(MECANNA)
print(MECANNA_arr)
# sio.sMECANNAemat('MECANNA.mat', {'vect':MECANNA})
