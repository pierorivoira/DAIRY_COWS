# importa_MySQLdb_orzo_radichette_malto.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
ORRADMAL = []

for i in parametri:
	i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'orzo_radichette_malto'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	ORRADMAL.append(float(i[0]))
#   print(ORRADMAL)

ORRADMAL = list(np.float_(ORRADMAL))

del ORRADMAL[13:18]
del ORRADMAL[10]
del ORRADMAL[13:15]

ORRADMAL[0] = ORRADMAL[0]/100
ORRADMAL[1] = ORRADMAL[1]*10
ORRADMAL[2] = ORRADMAL[2]*10
ORRADMAL[3] = ORRADMAL[3]*10
ORRADMAL[4] = ORRADMAL[4]*10
ORRADMAL[5] = ORRADMAL[5]*10
ORRADMAL[6] = ORRADMAL[6]*10
ORRADMAL[7] = ORRADMAL[7]*10
ORRADMAL[8] = ORRADMAL[8]*10
ORRADMAL[9] = ORRADMAL[9]*10
ORRADMAL[10] = ORRADMAL[10]*10
ORRADMAL[11] = ORRADMAL[11]*10

ORRADMAL_arr = np.array(ORRADMAL)
print(ORRADMAL_arr)
# sio.sORRADMALemat('ORRADMAL.mat', {'vect':ORRADMAL})
