# importa_MySQLdb_paglia_frumento.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
paglia_frumento = []

for i in parametri:
	i = "SELECT %s FROM Foraggio WHERE nome = 'paglia_frumento'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	paglia_frumento.append(float(i[0]))
#   print(paglia_frumento)

PAFRU = list(np.float_(paglia_frumento))

del PAFRU[13:18]
del PAFRU[10]
del PAFRU[13:15]

PAFRU[0] = PAFRU[0]/100
PAFRU[1] = PAFRU[1]*10
PAFRU[2] = PAFRU[2]*10
PAFRU[3] = PAFRU[3]*10
PAFRU[4] = PAFRU[4]*10
PAFRU[5] = PAFRU[5]*10
PAFRU[6] = PAFRU[6]*10
PAFRU[7] = PAFRU[7]*10
PAFRU[8] = PAFRU[8]*10
PAFRU[9] = PAFRU[9]*10
PAFRU[10] = PAFRU[10]*10
PAFRU[11] = PAFRU[11]*10

PAFRU_arr = np.array(PAFRU)
print(PAFRU_arr)
# sio.savemat('PAFRU.mat', {'vect':PAFRU})
