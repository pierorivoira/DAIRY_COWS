# importa_MySQLdb_pastone_mais_integrale.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
pastone_mais_integrale = []

for i in parametri:
	i = "SELECT %s FROM Foraggio WHERE nome = 'pastone_mais_integrale'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	pastone_mais_integrale.append(float(i[0]))
#   print(pastone_mais_integrale)

PASTOMAISINT = list(np.float_(pastone_mais_integrale))

del PASTOMAISINT[13:18]
del PASTOMAISINT[10]
del PASTOMAISINT[13:15]

PASTOMAISINT[0] = PASTOMAISINT[0]/100
PASTOMAISINT[1] = PASTOMAISINT[1]*10
PASTOMAISINT[2] = PASTOMAISINT[2]*10
PASTOMAISINT[3] = PASTOMAISINT[3]*10
PASTOMAISINT[4] = PASTOMAISINT[4]*10
PASTOMAISINT[5] = PASTOMAISINT[5]*10
PASTOMAISINT[6] = PASTOMAISINT[6]*10
PASTOMAISINT[7] = PASTOMAISINT[7]*10
PASTOMAISINT[8] = PASTOMAISINT[8]*10
PASTOMAISINT[9] = PASTOMAISINT[9]*10
PASTOMAISINT[10] = PASTOMAISINT[10]*10
PASTOMAISINT[11] = PASTOMAISINT[11]*10

PASTOMAISINT_arr = np.array(PASTOMAISINT)
print(PASTOMAISINT_arr)
# sio.savemat('PASTOMAISINT.mat', {'vect':PASTOMAISINT})
