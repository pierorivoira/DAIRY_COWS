# importa_MySQLdb_pisello.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
PISELLO = []

for i in parametri:
	i = "SELECT %s FROM Leguminosa WHERE nome = 'pisello'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	PISELLO.append(float(i[0]))
#   print(PISELLO)

PISELLO = list(np.float_(PISELLO))

del PISELLO[13:18]
del PISELLO[10]
del PISELLO[13:15]

PISELLO[0] = PISELLO[0]/100
PISELLO[1] = PISELLO[1]*10
PISELLO[2] = PISELLO[2]*10
PISELLO[3] = PISELLO[3]*10
PISELLO[4] = PISELLO[4]*10
PISELLO[5] = PISELLO[5]*10
PISELLO[6] = PISELLO[6]*10
PISELLO[7] = PISELLO[7]*10
PISELLO[8] = PISELLO[8]*10
PISELLO[9] = PISELLO[9]*10
PISELLO[10] = PISELLO[10]*10
PISELLO[11] = PISELLO[11]*10

PISELLO_arr = np.array(PISELLO)
print(PISELLO_arr)

# sio.savemat('PISELLO.mat', {'vect':PISELLO})
