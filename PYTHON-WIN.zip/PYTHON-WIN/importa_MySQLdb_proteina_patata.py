# importa_MySQLdb_proteina_patata.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
PROPA = []

for i in parametri:
	i = "SELECT %s FROM Sottoprodotto WHERE nome = 'proteina_patata'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	PROPA.append(float(i[0]))
#   print(PROPA)

PROPA = list(np.float_(PROPA))

del PROPA[13:18]
del PROPA[10]
del PROPA[13:15]

PROPA[0] = PROPA[0]/100
PROPA[1] = PROPA[1]*10
PROPA[2] = PROPA[2]*10
PROPA[3] = PROPA[3]*10
PROPA[4] = PROPA[4]*10
PROPA[5] = PROPA[5]*10
PROPA[6] = PROPA[6]*10
PROPA[7] = PROPA[7]*10
PROPA[8] = PROPA[8]*10
PROPA[9] = PROPA[9]*10
PROPA[10] = PROPA[10]*10
PROPA[11] = PROPA[11]*10

PROPA_arr = np.array(PROPA)
print(PROPA_arr)
# sio.sPROPAemat('PROPA.mat', {'vect':PROPA})
