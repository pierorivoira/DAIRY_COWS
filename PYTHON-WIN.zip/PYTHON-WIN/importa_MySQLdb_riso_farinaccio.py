# importa_MySQLdb_riso_farinaccio.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
RIFARINACCIO = []

for i in parametri:
	i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'riso_farinaccio'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	RIFARINACCIO.append(float(i[0]))
#   print(RIFARINACCIO)

RIFARINACCIO = list(np.float_(RIFARINACCIO))

del RIFARINACCIO[13:18]
del RIFARINACCIO[10]
del RIFARINACCIO[13:15]

RIFARINACCIO[0] = RIFARINACCIO[0]/100
RIFARINACCIO[1] = RIFARINACCIO[1]*10
RIFARINACCIO[2] = RIFARINACCIO[2]*10
RIFARINACCIO[3] = RIFARINACCIO[3]*10
RIFARINACCIO[4] = RIFARINACCIO[4]*10
RIFARINACCIO[5] = RIFARINACCIO[5]*10
RIFARINACCIO[6] = RIFARINACCIO[6]*10
RIFARINACCIO[7] = RIFARINACCIO[7]*10
RIFARINACCIO[8] = RIFARINACCIO[8]*10
RIFARINACCIO[9] = RIFARINACCIO[9]*10
RIFARINACCIO[10] = RIFARINACCIO[10]*10
RIFARINACCIO[11] = RIFARINACCIO[11]*10

RIFARINACCIO_arr = np.array(RIFARINACCIO)
print(RIFARINACCIO_arr)
# sio.sRIFARINACCIOemat('RIFARINACCIO.mat', {'vect':RIFARINACCIO})
