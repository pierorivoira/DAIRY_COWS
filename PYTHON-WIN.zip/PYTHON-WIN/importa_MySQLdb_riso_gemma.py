# importa_MySQLdb_riso_gemma.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
RIGEMMA = []

for i in parametri:
	i = "SELECT %s FROM Sottoprodotto WHERE nome = 'riso_gemma'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	RIGEMMA.append(float(i[0]))
#   print(RIGEMMA)

RIGEMMA = list(np.float_(RIGEMMA))

del RIGEMMA[13:18]
del RIGEMMA[10]
del RIGEMMA[13:15]

RIGEMMA[0] = RIGEMMA[0]/100
RIGEMMA[1] = RIGEMMA[1]*10
RIGEMMA[2] = RIGEMMA[2]*10
RIGEMMA[3] = RIGEMMA[3]*10
RIGEMMA[4] = RIGEMMA[4]*10
RIGEMMA[5] = RIGEMMA[5]*10
RIGEMMA[6] = RIGEMMA[6]*10
RIGEMMA[7] = RIGEMMA[7]*10
RIGEMMA[8] = RIGEMMA[8]*10
RIGEMMA[9] = RIGEMMA[9]*10
RIGEMMA[10] = RIGEMMA[10]*10
RIGEMMA[11] = RIGEMMA[11]*10

RIGEMMA_arr = np.array(RIGEMMA)
print(RIGEMMA_arr)
# sio.sRIGEMMAemat('RIGEMMA.mat', {'vect':RIGEMMA})
