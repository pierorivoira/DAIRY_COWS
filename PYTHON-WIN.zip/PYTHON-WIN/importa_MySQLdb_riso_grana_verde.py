# importa_MySQLdb_riso_grana_verde.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
RIGRVER = []

for i in parametri:
	i = "SELECT %s FROM Sottoprodotto WHERE nome = 'riso_grana_verde'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	RIGRVER.append(float(i[0]))
#   print(RIGRVER)

RIGRVER = list(np.float_(RIGRVER))

del RIGRVER[13:18]
del RIGRVER[10]
del RIGRVER[13:15]

RIGRVER[0] = RIGRVER[0]/100
RIGRVER[1] = RIGRVER[1]*10
RIGRVER[2] = RIGRVER[2]*10
RIGRVER[3] = RIGRVER[3]*10
RIGRVER[4] = RIGRVER[4]*10
RIGRVER[5] = RIGRVER[5]*10
RIGRVER[6] = RIGRVER[6]*10
RIGRVER[7] = RIGRVER[7]*10
RIGRVER[8] = RIGRVER[8]*10
RIGRVER[9] = RIGRVER[9]*10
RIGRVER[10] = RIGRVER[10]*10
RIGRVER[11] = RIGRVER[11]*10

RIGRVER_arr = np.array(RIGRVER)
print(RIGRVER_arr)
# sio.sRIGRVERemat('RIGRVER.mat', {'vect':RIGRVER})
