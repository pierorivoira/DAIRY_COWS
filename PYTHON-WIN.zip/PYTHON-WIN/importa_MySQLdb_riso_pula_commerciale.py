# importa_MySQLdb_riso_pula_commerciale.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
RISPUCOM = []

for i in parametri:
	i = "SELECT %s FROM Sottoprodotto WHERE nome = 'riso_pula_commerciale'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	RISPUCOM.append(float(i[0]))
#   print(RISPUCOM)

RISPUCOM = list(np.float_(RISPUCOM))

del RISPUCOM[13:18]
del RISPUCOM[10]
del RISPUCOM[13:15]

RISPUCOM[0] = RISPUCOM[0]/100
RISPUCOM[1] = RISPUCOM[1]*10
RISPUCOM[2] = RISPUCOM[2]*10
RISPUCOM[3] = RISPUCOM[3]*10
RISPUCOM[4] = RISPUCOM[4]*10
RISPUCOM[5] = RISPUCOM[5]*10
RISPUCOM[6] = RISPUCOM[6]*10
RISPUCOM[7] = RISPUCOM[7]*10
RISPUCOM[8] = RISPUCOM[8]*10
RISPUCOM[9] = RISPUCOM[9]*10
RISPUCOM[10] = RISPUCOM[10]*10
RISPUCOM[11] = RISPUCOM[11]*10

RISPUCOM_arr = np.array(RISPUCOM)
print(RISPUCOM_arr)
# sio.sRISPUCOMemat('RISPUCOM.mat', {'vect':RISPUCOM})
