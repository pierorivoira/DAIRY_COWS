# importa_MySQLdb_riso_pula_vergine.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
RISPUVER = []

for i in parametri:
	i = "SELECT %s FROM Sottoprodotto WHERE nome = 'riso_pula_vergine'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	RISPUVER.append(float(i[0]))
#   print(RISPUVER)

RISPUVER = list(np.float_(RISPUVER))

del RISPUVER[13:18]
del RISPUVER[10]
del RISPUVER[13:15]

RISPUVER[0] = RISPUVER[0]/100
RISPUVER[1] = RISPUVER[1]*10
RISPUVER[2] = RISPUVER[2]*10
RISPUVER[3] = RISPUVER[3]*10
RISPUVER[4] = RISPUVER[4]*10
RISPUVER[5] = RISPUVER[5]*10
RISPUVER[6] = RISPUVER[6]*10
RISPUVER[7] = RISPUVER[7]*10
RISPUVER[8] = RISPUVER[8]*10
RISPUVER[9] = RISPUVER[9]*10
RISPUVER[10] = RISPUVER[10]*10
RISPUVER[11] = RISPUVER[11]*10

RISPUVER_arr = np.array(RISPUVER)
print(RISPUVER_arr)
# sio.sRISPUVERemat('RISPUVER.mat', {'vect':RISPUVER})
