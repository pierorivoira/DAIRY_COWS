# importa_MySQLdb_soia_buccette.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
SOIABUCC = []

for i in parametri:
	i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'soia_buccette'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	SOIABUCC.append(float(i[0]))
#   print(SOIABUCC)

SOIABUCC = list(np.float_(SOIABUCC))

del SOIABUCC[13:18]
del SOIABUCC[10]
del SOIABUCC[13:15]

SOIABUCC[0] = SOIABUCC[0]/100
SOIABUCC[1] = SOIABUCC[1]*10
SOIABUCC[2] = SOIABUCC[2]*10
SOIABUCC[3] = SOIABUCC[3]*10
SOIABUCC[4] = SOIABUCC[4]*10
SOIABUCC[5] = SOIABUCC[5]*10
SOIABUCC[6] = SOIABUCC[6]*10
SOIABUCC[7] = SOIABUCC[7]*10
SOIABUCC[8] = SOIABUCC[8]*10
SOIABUCC[9] = SOIABUCC[9]*10
SOIABUCC[10] = SOIABUCC[10]*10
SOIABUCC[11] = SOIABUCC[11]*10

SOIABUCC_arr = np.array(SOIABUCC)
print(SOIABUCC_arr)
# sio.sSOIABUCCemat('SOIABUCC.mat', {'vect':SOIABUCC})
