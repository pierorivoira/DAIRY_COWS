# importa_MySQLdb_soia_farina_estrazione_45_per_100.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
SOFAESTR45 = []

for i in parametri:
	i = "SELECT %s FROM Farina_di_estrazione WHERE nome = 'soia_farina_estrazione_45_per_100'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	SOFAESTR45.append(float(i[0]))
#   print(SOFAESTR45)

SOFAESTR45 = list(np.float_(SOFAESTR45))

del SOFAESTR45[13:18]
del SOFAESTR45[10]
del SOFAESTR45[13:15]

SOFAESTR45[0] = SOFAESTR45[0]/100
SOFAESTR45[1] = SOFAESTR45[1]*10
SOFAESTR45[2] = SOFAESTR45[2]*10
SOFAESTR45[3] = SOFAESTR45[3]*10
SOFAESTR45[4] = SOFAESTR45[4]*10
SOFAESTR45[5] = SOFAESTR45[5]*10
SOFAESTR45[6] = SOFAESTR45[6]*10
SOFAESTR45[7] = SOFAESTR45[7]*10
SOFAESTR45[8] = SOFAESTR45[8]*10
SOFAESTR45[9] = SOFAESTR45[9]*10
SOFAESTR45[10] = SOFAESTR45[10]*10
SOFAESTR45[11] = SOFAESTR45[11]*10

SOFAESTR45_arr = np.array(SOFAESTR45)
print(SOFAESTR45_arr)
# sio.sSOFAESTR45emat('SOFAESTR45.mat', {'vect':SOFAESTR45})
