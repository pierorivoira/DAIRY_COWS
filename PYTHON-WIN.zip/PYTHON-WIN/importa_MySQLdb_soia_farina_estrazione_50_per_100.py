# importa_MySQLdb_soia_farina_estrazione_50_per_100.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
SOFAESTR50 = []

for i in parametri:
	i = "SELECT %s FROM Farina_di_estrazione WHERE nome = 'soia_farina_estrazione_50_per_100'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	SOFAESTR50.append(float(i[0]))
#   print(SOFAESTR50)

SOFAESTR50 = list(np.float_(SOFAESTR50))

del SOFAESTR50[13:18]
del SOFAESTR50[10]
del SOFAESTR50[13:15]

SOFAESTR50[0] = SOFAESTR50[0]/100
SOFAESTR50[1] = SOFAESTR50[1]*10
SOFAESTR50[2] = SOFAESTR50[2]*10
SOFAESTR50[3] = SOFAESTR50[3]*10
SOFAESTR50[4] = SOFAESTR50[4]*10
SOFAESTR50[5] = SOFAESTR50[5]*10
SOFAESTR50[6] = SOFAESTR50[6]*10
SOFAESTR50[7] = SOFAESTR50[7]*10
SOFAESTR50[8] = SOFAESTR50[8]*10
SOFAESTR50[9] = SOFAESTR50[9]*10
SOFAESTR50[10] = SOFAESTR50[10]*10
SOFAESTR50[11] = SOFAESTR50[11]*10

SOFAESTR50_arr = np.array(SOFAESTR50)
print(SOFAESTR50_arr)
# sio.sSOFAESTR50emat('SOFAESTR50.mat', {'vect':SOFAESTR50})
