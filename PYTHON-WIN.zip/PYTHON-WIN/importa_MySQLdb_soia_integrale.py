# importa_MySQLdb_soia_integrale.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
SOIAIN = []

for i in parametri:
	i = "SELECT %s FROM Leguminosa WHERE nome = 'soia_integrale'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	SOIAIN.append(float(i[0]))
#   print(SOIAIN)

SOIAIN = list(np.float_(SOIAIN))

del SOIAIN[13:18]
del SOIAIN[10]
del SOIAIN[13:15]

SOIAIN[0] = SOIAIN[0]/100
SOIAIN[1] = SOIAIN[1]*10
SOIAIN[2] = SOIAIN[2]*10
SOIAIN[3] = SOIAIN[3]*10
SOIAIN[4] = SOIAIN[4]*10
SOIAIN[5] = SOIAIN[5]*10
SOIAIN[6] = SOIAIN[6]*10
SOIAIN[7] = SOIAIN[7]*10
SOIAIN[8] = SOIAIN[8]*10
SOIAIN[9] = SOIAIN[9]*10
SOIAIN[10] = SOIAIN[10]*10
SOIAIN[11] = SOIAIN[11]*10

SOIAIN_arr = np.array(SOIAIN)
print(SOIAIN_arr)

# sio.savemat('SOIAIN.mat', {'vect':SOIAIN})
