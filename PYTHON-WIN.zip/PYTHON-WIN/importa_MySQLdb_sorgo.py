# importa_MySQLdb_sorgo.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
sorgo = []

for i in parametri:
	i = "SELECT %s FROM Cereale WHERE nome = 'sorgo'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	sorgo.append(float(i[0]))
#   print(sorgo)

SORGO = list(np.float_(sorgo))

del SORGO[13:18]
del SORGO[10]
del SORGO[13:15]

SORGO[0] = SORGO[0]/100
SORGO[1] = SORGO[1]*10
SORGO[2] = SORGO[2]*10
SORGO[3] = SORGO[3]*10
SORGO[4] = SORGO[4]*10
SORGO[5] = SORGO[5]*10
SORGO[6] = SORGO[6]*10
SORGO[7] = SORGO[7]*10
SORGO[8] = SORGO[8]*10
SORGO[9] = SORGO[9]*10
SORGO[10] = SORGO[10]*10
SORGO[11] = SORGO[11]*10

SORGO_arr = np.array(SORGO)
print(SORGO_arr)
# sio.sSORGOemat('SORGO.mat', {'vect':SORGO})
