# importa_MySQLdb_triticale.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
cursor = DB.cursor()		   
parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
TRIT = []

for i in parametri:
	i = "SELECT %s FROM Cereale WHERE nome = 'triticale'" % i
	cursor.execute(i)
	i = cursor.fetchall()
	i = i[0]
	TRIT.append(float(i[0]))
#   print(TRIT)

TRIT = list(np.float_(TRIT))

del TRIT[13:18]
del TRIT[10]
del TRIT[13:15]

TRIT[0] = TRIT[0]/100
TRIT[1] = TRIT[1]*10
TRIT[2] = TRIT[2]*10
TRIT[3] = TRIT[3]*10
TRIT[4] = TRIT[4]*10
TRIT[5] = TRIT[5]*10
TRIT[6] = TRIT[6]*10
TRIT[7] = TRIT[7]*10
TRIT[8] = TRIT[8]*10
TRIT[9] = TRIT[9]*10
TRIT[10] = TRIT[10]*10
TRIT[11] = TRIT[11]*10

TRIT_arr = np.array(TRIT)
print(TRIT_arr)
# sio.sTRITemat('TRIT.mat', {'vect':TRIT})
