# parallel_bologna.py




from tabula import *
# from threading import Thread
# from time import perf_counter
from tabula.io import read_pdf
from datetime import date, datetime, timedelta
import fileinput, io, math, numpy, os, re, subprocess, sys, tabula
import numpy as np
import pandas as pd
import _thread as thread

user = os.getlogin()
os.chdir('C:/Users/%s/PYTHON' % user)

stdoutmutex = thread.allocate_lock()
exitmutexes = [thread.allocate_lock() for i in range(8)]

today = date.today()
offset_b = (today.weekday() - 3) % 7

import datetime

if datetime.datetime.today().weekday() == 3:
    last_Thursday = today - timedelta(days=7)
    Thursday = last_Thursday
else:
    Thursday = today - timedelta(days=offset_b)

data_aggiornamento_B = Thursday.strftime('%d.%m.%Y')
day = Thursday.strftime('%d')
if ((day != '10') and (day != '20') and (day != '30')): 
    day = day.replace("0","",1)
else:
    day = day

month = Thursday.strftime('%m')
if month != '10':
    month = month.replace("0","",1)
else:
    month = month

year = Thursday.strftime('%Y')
giorno_di_pubblicazione_B = '%s_%s_%s' % (day, month, year)
week = Thursday.isocalendar()[1] - 1
os.system('curl -o n.%d-%s.pdf https://www.bo.camcom.gov.it/sites/default/files/borsa-merci-e-rilevazione-prezzi/listino-dei-prezzi-settimanali/anno-%s/n.%d-%s.pdf' % (week, giorno_di_pubblicazione_B, year, week, giorno_di_pubblicazione_B))

def bologna_parallel(i, count):
    global dataframe_bologna
    dataframe_bologna = []
    for i in range(count):
        dati = tabula.io.read_pdf('n.%d-%s.pdf' % (week_B, giorno_di_pubblicazione_B), pages='all')[i]
        dataframe_bologna.append(dati)
        return(dataframe_bologna)
        stdoutmutex.release()
    exitmutexes[myId].acquire()    # signal main thread
    
for i in range(8):
	thread.start_new_thread(bologna_parallel, (i, 8))

for mutex in exitmutexes:
    while not mutex.locked(): pass
print('Main thread exiting.')