# scrape_tables_Foggia_w.py
# https://stackoverflow.com/questions/60377106/python3-module-tabula-has-no-attribute-read-pdf
# https://www.tutorialspoint.com/convert-pdf-to-csv-using-python
# https://www.codegrepper.com/code-examples/python/remove+first+instance+of+character+from+string+python
# https://towardsdatascience.com/how-to-show-all-columns-rows-of-a-pandas-dataframe-c49d4507fcf


### WINDOWS ### 


import pandas as pd
import fileinput, io, numpy, os, re, subprocess, sys, tabula
from tabula.io import read_pdf
from tabula import *
from datetime import date, datetime, timedelta
from contextlib import redirect_stdout


user = os.getlogin()
os.chdir('C:/Users/%s/PYTHON' % user)

# today = date.today()
# offset_F = (today.weekday() - 2) % 7
# Wednesday = today - timedelta(days=offset_F)
# week = Wednesday.isocalendar()[1] - 1


# if datetime.datetime.today().weekday() == 2:

# data_aggiornamento_F = Wednesday.strftime('%d.%m.%Y')


today = date.today()
offset_F = (today.weekday() - 2) % 7

import datetime

if datetime.datetime.today().weekday() == 2:
	last_Wednesday = today - timedelta(days=7)
	Wednesday = last_Wednesday
else:
	Wednesday = today - timedelta(days=offset_F)

data_aggiornamento_F = Wednesday.strftime('%d.%m.%Y')

week = Wednesday.isocalendar()[1] - 1

if week <= 9:
	week = '0%d' % week
else:
	week = week

year = Wednesday.strftime('%Y')

os.system('curl -o %s_%s.pdf https://www.fg.camcom.gov.it/sites/default/files/upload/mercato_e_tutela/borsa_merci/listini/%s/%s_%s.pdf' % (year, week, year, year, week))

# http://www.fg.camcom.gov.it/sites/default/files/upload/mercato_e_tutela/borsa_merci/listini/2022/2022_08.pdf

# df2 = tabula.io.read_pdf('%s_%s.pdf' % (year, week), pages='all')[2]
df3 = tabula.io.read_pdf('%s_%s.pdf' % (year, week), pages='all')[3]
# df4 = tabula.io.read_pdf('%s_%s.pdf' % (year, week), pages='all')[4]
# df5 = tabula.io.read_pdf('%s_%s.pdf' % (year, week), pages='all')[5]
# df6 = tabula.io.read_pdf('%s_%s.pdf' % (year, week), pages='all')[6]



# prezzi_2 = df2.to_numpy()
prezzi_3 = df3.to_numpy()
# prezzi_4 = df4.to_numpy()
# prezzi_5 = df5.to_numpy()
# prezzi_6 = df6.to_numpy()

FAVINO_FORAGGIO = prezzi_3[5]
prezzo_FAVINO_FORAGGIO_F = FAVINO_FORAGGIO[0][47:].replace(',','.')

if prezzo_FAVINO_FORAGGIO_F != '':
	print('Listino prezzi BORSA MERCI Foggia creato con successo!')
else:
	print('prezzo non disponibile')



with open('listino_prezzi_Foggia.txt', 'w', encoding = "utf-8") as f:
    with redirect_stdout(f):
        print(prezzo_FAVINO_FORAGGIO_F)


# pd.set_option('display.max_rows', None)
# pd.set_option('display.max_columns', None)
# pd.set_option('display.width', None)
# pd.set_option('display.max_colwidth', None)
# print(data)
