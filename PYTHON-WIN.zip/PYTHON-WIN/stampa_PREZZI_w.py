# stampa_PREZZI_w.py


#####################################
########## WINDOWS VERSION ##########
#####################################

import os

user = os.getlogin()
os.chdir('C:/Users/%s/PYTHON' % user)


from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
import datetime

last_year = (datetime.datetime.now()-relativedelta(years=1)).strftime('%Y')

today = date.today()
offset_B = (today.weekday() - 3) % 7

if datetime.datetime.today().weekday() == 3:
    last_Thursday = today - timedelta(days=7)
    Thursday = last_Thursday
else:
    Thursday = today - timedelta(days=offset_B)
        
data_aggiornamento_B = Thursday.strftime('%d.%m.%Y')

today = date.today()
offset_F = (today.weekday() - 2) % 7

import datetime

if datetime.datetime.today().weekday() == 2:
	last_Wednesday = today - timedelta(days=7)
	Wednesday = last_Wednesday
else:
	Wednesday = today - timedelta(days=offset_F)

data_aggiornamento_F = Wednesday.strftime('%d.%m.%Y')


with open('listino_prezzi_Milano.txt', 'r') as file:
	intestazione_Milano = file.readlines()[0]


from crea_db_PREZZI_clal_w import prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR
from crea_db_PREZZI_clal_w import prezzo_FIENO_MEDICA_1_TG_COSTO_PR
from crea_db_PREZZI_clal_w import prezzo_FIENO_MEDICA_2_TG_COSTO_PR
from crea_db_PREZZI_clal_w import prezzo_FIENO_PRATO_POLIFITA_COSTO_PR
from crea_db_PREZZI_Alessandria_w import prezzo_LOIETTO_INSILATO
from crea_db_PREZZI_Alessandria_w import prezzo_MAIS_INSILATO
from crea_db_PREZZI_Milano_w import prezzo_FRUMENTO_TENERO_FARINACCIO
from crea_db_PREZZI_Bologna_w import prezzo_FRUMENTO_TENERO_FARINACCIO_B
from crea_db_PREZZI_Milano_w import prezzo_FRUMENTO_TENERO_TRITELLO
from crea_db_PREZZI_Bologna_w import prezzo_FRUMENTO_TENERO_TRITELLO_B
from crea_db_PREZZI_Milano_w import prezzo_FRUMENTO_TENERO_CRUSCA
from crea_db_PREZZI_Bologna_w import prezzo_FRUMENTO_TENERO_CRUSCA_B
from crea_db_PREZZI_Milano_w import prezzo_FRUMENTO_TENERO_CRUSCHELLO
from crea_db_PREZZI_Bologna_w import prezzo_FRUMENTO_TENERO_CRUSCHELLO_B
from crea_db_PREZZI_Milano_w import prezzo_FRUMENTO_TENERO_GERME
from crea_db_PREZZI_Bologna_w import prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B
from crea_db_PREZZI_Milano_w import prezzo_FRUMENTO_DURO_FARINACCIO
from crea_db_PREZZI_Bologna_w import prezzo_FRUMENTO_DURO_FARINACCIO_B
from crea_db_PREZZI_Bologna_w import prezzo_FRUMENTO_DURO_FARINETTA_B
from crea_db_PREZZI_Milano_w import prezzo_MAIS
from crea_db_PREZZI_Bologna_w import prezzo_MAIS_B
from crea_db_PREZZI_Bologna_w import prezzo_MAIS_FARINA_B
from crea_db_PREZZI_Milano_w import prezzo_MAIS_GLUTINE
from crea_db_PREZZI_Milano_w import prezzo_MAIS_FARINA_GLUTINATA
from crea_db_PREZZI_Milano_w import prezzo_MAIS_SEMOLA_GLUTINATA
from crea_db_PREZZI_Bologna_w import prezzo_MAIS_SEMOLA_GLUTINATA_B
from crea_db_PREZZI_Milano_w import prezzo_SEGALE
from crea_db_PREZZI_Bologna_w import prezzo_FRUMENTO_B
from crea_db_PREZZI_Milano_w import prezzo_ORZO
from crea_db_PREZZI_Bologna_w import prezzo_ORZO_B
from crea_db_PREZZI_Milano_w import prezzo_AVENA
from crea_db_PREZZI_Milano_w import prezzo_TRITICALE
from crea_db_PREZZI_Milano_w import prezzo_SORGO
from crea_db_PREZZI_Bologna_w import prezzo_SORGO_B
from crea_db_PREZZI_Milano_w import prezzo_MANIOCA
from crea_db_PREZZI_Milano_w import prezzo_PISELLO
from crea_db_PREZZI_Bologna_w import prezzo_PISELLO_B
from crea_db_PREZZI_Bologna_w import prezzo_FAVINO_B
# from scrape_tables_Foggia_w import prezzo_FAVINO_FORAGGIO_F
from crea_db_PREZZI_Alessandria_w import prezzo_LUPINO
from crea_db_PREZZI_Milano_w import prezzo_SOIA
from crea_db_PREZZI_Bologna_w import prezzo_SOIA_B
from crea_db_PREZZI_Milano_w import prezzo_COLZA_FE
from crea_db_PREZZI_Bologna_w import prezzo_COLZA_FE_B
from crea_db_PREZZI_Milano_w import prezzo_GIRASOLE_DECORTICATO_FE
from crea_db_PREZZI_Bologna_w import prezzo_GIRASOLE_INTEGRALE_FE_B
from crea_db_PREZZI_Milano_w import prezzo_SOIA_FE
from crea_db_PREZZI_Bologna_w import prezzo_SOIA_FE_B
from crea_db_PREZZI_Milano_w import prezzo_ERBA_MEDICA_DIS_EXTRA
from crea_db_PREZZI_Milano_w import prezzo_ERBA_MEDICA_DIS_1_QUAL
from crea_db_PREZZI_Bologna_w import prezzo_ERBA_MED_DIS_17_B
from crea_db_PREZZI_Bologna_w import prezzo_ERBA_MED_DIS_16_B
from crea_db_PREZZI_Bologna_w import prezzo_ERBA_MED_DIS_14_B
from crea_db_PREZZI_Milano_w import prezzo_MELASSO
from crea_db_PREZZI_Bologna_w import prezzo_MELASSO_CANNA_B
from crea_db_PREZZI_Bologna_w import prezzo_MELASSO_BIETOLA_B
from crea_db_PREZZI_Milano_w import prezzo_BIETOLA_POLPE_SECCHE
from crea_db_PREZZI_Milano_w import prezzo_CARRUBE_FRANTUMATE
from crea_db_PREZZI_Milano_w import prezzo_FIENO_MAGGENGO
from crea_db_PREZZI_Bologna_w import prezzo_FIENO_1_TAGLIO_B
from crea_db_PREZZI_Bologna_w import prezzo_FIENO_1_TAGLIO_FIBRA_LUNGA_B
from crea_db_PREZZI_Milano_w import prezzo_FIENO_AGOSTANO
from crea_db_PREZZI_Milano_w import prezzo_FIENO_MEDICA
from crea_db_PREZZI_Bologna_w import prezzo_FIENO_MEDICA_17_1_TAGLIO_ROTBAL_B
from crea_db_PREZZI_Bologna_w import prezzo_FIENO_MEDICA_17_1_TAGLIO_BALQUA_B
from crea_db_PREZZI_Bologna_w import prezzo_FIENO_MEDICA_17_2_TAGLIO_ROTBAL_B
from crea_db_PREZZI_Bologna_w import prezzo_FIENO_MEDICA_17_2_TAGLIO_BALQUA_B
from crea_db_PREZZI_Bologna_w import prezzo_FIENO_MEDICA_17_3_TAGLIO_ROTBAL_B
from crea_db_PREZZI_Bologna_w import prezzo_FIENO_MEDICA_17_3_TAGLIO_BALQUA_B
from crea_db_PREZZI_Bologna_w import prezzo_FIENO_MEDICA_17_4_TAGLIO_ROTBAL_B
from crea_db_PREZZI_Bologna_w import prezzo_FIENO_MEDICA_17_4_TAGLIO_BALQUA_B
from crea_db_PREZZI_Milano_w import prezzo_PAGLIA
from crea_db_PREZZI_Bologna_w import prezzo_PAGLIA_ROTBAL_B
from crea_db_PREZZI_Milano_w import prezzo_SOIA_BUCCETTE
from crea_db_PREZZI_Bologna_w import prezzo_SOIA_BUCCETTE_B
from crea_db_PREZZI_Bologna_w import prezzo_BIETOLA_POLPE_B
from crea_db_PREZZI_Milano_w import prezzo_RISO_GRANA_VERDE
from crea_db_PREZZI_Bologna_w import prezzo_RISO_GRANA_VERDE_B
from crea_db_PREZZI_Milano_w import prezzo_RISO_FARINACCIO
from crea_db_PREZZI_Bologna_w import prezzo_RISO_FARINACCIO_B
from crea_db_PREZZI_Milano_w import prezzo_RISO_PULA_VERGINE
from crea_db_PREZZI_Bologna_w import prezzo_RISO_PULA_VERGINE_B
# from scrape_tables_Verona_w import prezzo_COTONE_V
from crea_db_PREZZI_Bologna_w import prezzo_COTONE_B

prezzi = []



# prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR = str(prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR)
# prezzo_FIENO_MEDICA_1_TG_COSTO_PR = str(prezzo_FIENO_MEDICA_1_TG_COSTO_PR)
# prezzo_FIENO_MEDICA_2_TG_COSTO_PR = str(prezzo_FIENO_MEDICA_2_TG_COSTO_PR)
# FIENO_PRATO_POLIFITA_COSTO_PR = str(FIENO_PRATO_POLIFITA_COSTO_PR)
# prezzo_LOIETTO_INSILATO = str(prezzo_LOIETTO_INSILATO)
# prezzo_MAIS_INSILATO = str(prezzo_MAIS_INSILATO)
prezzo_FRUMENTO_TENERO_FARINACCIO = str(prezzo_FRUMENTO_TENERO_FARINACCIO)
# prezzo_FRUMENTO_TENERO_FARINACCIO_B = str(prezzo_FRUMENTO_TENERO_FARINACCIO_B)
prezzo_FRUMENTO_TENERO_TRITELLO = str(prezzo_FRUMENTO_TENERO_TRITELLO)
# prezzo_FRUMENTO_TENERO_TRITELLO_B = str(prezzo_FRUMENTO_TENERO_TRITELLO_B)
prezzo_FRUMENTO_TENERO_CRUSCA = str(prezzo_FRUMENTO_TENERO_CRUSCA)
# prezzo_FRUMENTO_TENERO_CRUSCA_B = str(prezzo_FRUMENTO_TENERO_CRUSCA_B)
prezzo_FRUMENTO_TENERO_CRUSCHELLO = str(prezzo_FRUMENTO_TENERO_CRUSCHELLO)
# prezzo_FRUMENTO_TENERO_CRUSCHELLO_B = str(prezzo_FRUMENTO_TENERO_CRUSCHELLO_B)
prezzo_FRUMENTO_TENERO_GERME = str(prezzo_FRUMENTO_TENERO_GERME)
# prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B = str(prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B)
prezzo_FRUMENTO_DURO_FARINACCIO = str(prezzo_FRUMENTO_DURO_FARINACCIO)
# prezzo_FRUMENTO_DURO_FARINACCIO_B = str(prezzo_FRUMENTO_DURO_FARINACCIO_B)
# prezzo_FRUMENTO_DURO_FARINETTA_B = str(prezzo_FRUMENTO_DURO_FARINETTA_B)
prezzo_MAIS = str(prezzo_MAIS)
# prezzo_MAIS_B = str(prezzo_MAIS_B)
# prezzo_MAIS_FARINA_B = str(prezzo_MAIS_FARINA_B)
prezzo_MAIS_GLUTINE = str(prezzo_MAIS_GLUTINE) 
prezzo_MAIS_FARINA_GLUTINATA = str(prezzo_MAIS_FARINA_GLUTINATA)
prezzo_MAIS_SEMOLA_GLUTINATA = str(prezzo_MAIS_SEMOLA_GLUTINATA)
# prezzo_MAIS_SEMOLA_GLUTINATA_B = str(prezzo_MAIS_SEMOLA_GLUTINATA_B)
prezzo_SEGALE = str(prezzo_SEGALE)
# prezzo_FRUMENTO_B = str(prezzo_FRUMENTO_B)
prezzo_ORZO = str(prezzo_ORZO)
# prezzo_ORZO_B = str(prezzo_ORZO_B)
prezzo_AVENA = str(prezzo_AVENA)
prezzo_TRITICALE = str(prezzo_TRITICALE)
prezzo_SORGO = str(prezzo_SORGO)
# prezzo_SORGO_B = str(prezzo_SORGO_B)
prezzo_MANIOCA = str(prezzo_MANIOCA)
prezzo_PISELLO = str(prezzo_PISELLO)
# prezzo_PISELLO_B = str(prezzo_PISELLO_B)
# prezzo_FAVINO_B = str(prezzo_FAVINO_B)
# prezzo_FAVINO_FORAGGIO_F = str(prezzo_FAVINO_FORAGGIO_F)
# prezzo_LUPINO = str(prezzo_LUPINO)
prezzo_SOIA = str(prezzo_SOIA)
# prezzo_SOIA_B = str(prezzo_SOIA_B)
prezzo_COLZA_FE = str(prezzo_COLZA_FE)
# prezzo_COLZA_FE_B = str(prezzo_COLZA_FE_B)
prezzo_GIRASOLE_DECORTICATO_FE_B = str(prezzo_GIRASOLE_DECORTICATO_FE)
# prezzo_GIRASOLE_INTEGRALE_FE_B = str(prezzo_GIRASOLE_INTEGRALE_FE_B)
prezzo_SOIA_FE = str(prezzo_SOIA_FE)
# prezzo_SOIA_FE_B = str(prezzo_SOIA_FE_B)
prezzo_ERBA_MEDICA_DIS_EXTRA = str(prezzo_ERBA_MEDICA_DIS_EXTRA)
# prezzo_ERBA_MED_DIS_17_B = str(prezzo_ERBA_MED_DIS_17_B)
# prezzo_ERBA_MED_DIS_16_B = str(prezzo_ERBA_MED_DIS_16_B)
# prezzo_ERBA_MED_DIS_14_B = str(prezzo_ERBA_MED_DIS_14_B)
prezzo_ERBA_MEDICA_DIS_1_QUAL = str(prezzo_ERBA_MEDICA_DIS_1_QUAL)
prezzo_MELASSO = str(prezzo_MELASSO)
# prezzo_MELASSO_CANNA_B = str(prezzo_MELASSO_CANNA_B)
# prezzo_MELASSO_BIETOLA_B = str(prezzo_MELASSO_BIETOLA_B)
prezzo_BIETOLA_POLPE_SECCHE = str(prezzo_BIETOLA_POLPE_SECCHE)
prezzo_CARRUBE_FRANTUMATE = str(prezzo_CARRUBE_FRANTUMATE)
prezzo_FIENO_MAGGENGO = str(prezzo_FIENO_MAGGENGO)
prezzo_FIENO_AGOSTANO = str(prezzo_FIENO_AGOSTANO)
# prezzo_FIENO_1_TAGLIO_B = str(prezzo_FIENO_1_TAGLIO_B)
# prezzo_FIENO_1_TAGLIO_FIBRA_LUNGA_B = str(prezzo_FIENO_1_TAGLIO_FIBRA_LUNGA_B)
prezzo_FIENO_MEDICA = str(prezzo_FIENO_MEDICA)
# prezzo_FIENO_MEDICA_17_1_TAGLIO_ROTBAL_B = str(prezzo_FIENO_MEDICA_17_1_TAGLIO_ROTBAL_B)
# prezzo_FIENO_MEDICA_17_1_TAGLIO_BALQUA_B = str(prezzo_FIENO_MEDICA_17_1_TAGLIO_BALQUA_B)
# prezzo_FIENO_MEDICA_17_2_TAGLIO_ROTBAL_B = str(prezzo_FIENO_MEDICA_17_2_TAGLIO_ROTBAL_B)
# prezzo_FIENO_MEDICA_17_2_TAGLIO_BALQUA_B = str(prezzo_FIENO_MEDICA_17_2_TAGLIO_BALQUA_B)
# prezzo_FIENO_MEDICA_17_3_TAGLIO_ROTBAL_B = str(prezzo_FIENO_MEDICA_17_3_TAGLIO_ROTBAL_B)
# prezzo_FIENO_MEDICA_17_3_TAGLIO_BALQUA_B = str(prezzo_FIENO_MEDICA_17_3_TAGLIO_BALQUA_B)
# prezzo_FIENO_MEDICA_17_4_TAGLIO_ROTBAL_B = str(prezzo_FIENO_MEDICA_17_4_TAGLIO_ROTBAL_B)
# prezzo_FIENO_MEDICA_17_4_TAGLIO_BALQUA_B = str(prezzo_FIENO_MEDICA_17_4_TAGLIO_BALQUA_B)
prezzo_PAGLIA = str(prezzo_PAGLIA)
# prezzo_PAGLIA_ROTBAL_B = str(prezzo_PAGLIA_ROTBAL_B)
prezzo_SOIA_BUCCETTE = str(prezzo_SOIA_BUCCETTE)
# prezzo_SOIA_BUCCETTE_B = str(prezzo_SOIA_BUCCETTE_B)
# prezzo_BIETOLA_POLPE_B = str(prezzo_BIETOLA_POLPE_B)
prezzo_RISO_GRANA_VERDE = str(prezzo_RISO_GRANA_VERDE)
# prezzo_RISO_GRANA_VERDE_B = str(prezzo_RISO_GRANA_VERDE_B)
prezzo_RISO_FARINACCIO = str(prezzo_RISO_FARINACCIO)
# prezzo_RISO_FARINACCIO_B = str(prezzo_RISO_FARINACCIO_B)
prezzo_RISO_PULA_VERGINE = str(prezzo_RISO_PULA_VERGINE)
# prezzo_RISO_PULA_VERGINE_B = str(prezzo_RISO_PULA_VERGINE_B)
# prezzo_COTONE_V = str(prezzo_COTONE_V)
# prezzo_COTONE_B = str(prezzo_COTONE_B)


print("Prezzi della Borsa di Alessandria => valori medi annuali riferiti all'anno %s" % last_year)
print('Prezzi della Borsa di Bologna aggiornati al %s' % data_aggiornamento_B)
print('Prezzi della Borsa di Foggia aggiornati al %s' % data_aggiornamento_F)
print('%s' % intestazione_Milano)
print('Prezzi clal => valori medi riferiti agli ultimi 6 mesi')


print('______________________________________________________________________________________________')
print('|                  ALIMENTO                  |         PREZZO         |         FONTE         |')
print('|                                            |       (EURO/ton)       |                       |')
print('|____________________________________________|________________________|_______________________|')
print('|       PASTONE INTEGR. DI MAIS (costo pr.)  |      %s              | https://www.clal.it |' % prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR)
print('|       FIENO DI MEDICA DI 1 TG (costo pr.)  |      %s              | https://www.clal.it |' % prezzo_FIENO_MEDICA_1_TG_COSTO_PR)
print('|       FIENO DI MEDICA DI 2 TG (costo pr.)  |      %s              | https://www.clal.it |' % prezzo_FIENO_MEDICA_2_TG_COSTO_PR)
print('|       FIENO DI PRATO POLIFITA (costo pr.)  |      %s              | https://www.clal.it |' % prezzo_FIENO_PRATO_POLIFITA_COSTO_PR)
print('|       INSILATO DI LOIETTO                  |      %s              | Borsa Merci di Alessandria |' % prezzo_LOIETTO_INSILATO)
print('|       INSILATO DI MAIS                     |      %s              | Borsa Merci di Alessandria |' % prezzo_MAIS_INSILATO)
print('|       FARINACCIO DI FRUMENTO TENERO        |      %s              | Borsa Merci di Milano |' % prezzo_FRUMENTO_TENERO_FARINACCIO)
print('|       FARINACCIO DI FRUMENTO TENERO        |      %s              | Borsa Merci di Bologna |' % prezzo_FRUMENTO_TENERO_FARINACCIO_B)
print('|       TRITELLO DI FRUMENTO TENERO          |      %s              | Borsa Merci di Milano |' % prezzo_FRUMENTO_TENERO_TRITELLO)
print('|       TRITELLO DI FRUMENTO TENERO          |      %s              | Borsa Merci di Bologna |' % prezzo_FRUMENTO_TENERO_TRITELLO_B)
print('|       CRUSCA DI FRUMENTO TENERO            |      %s              | Borsa Merci di Milano |' % prezzo_FRUMENTO_TENERO_CRUSCA)
print('|       CRUSCA DI FRUMENTO TENERO            |      %s              | Borsa Merci di Bologna |' % prezzo_FRUMENTO_TENERO_CRUSCA_B)
print('|       CRUSCHELLO DI FRUMENTO TENERO        |      %s              | Borsa Merci di Milano |' % prezzo_FRUMENTO_TENERO_CRUSCHELLO)
print('|       CRUSCHELLO DI FRUMENTO TENERO        |      %s              | Borsa Merci di Bologna |' % prezzo_FRUMENTO_TENERO_CRUSCHELLO_B)
print('|       GERME DI FRUMENTO TENERO             |      %s              | Borsa Merci di Milano |' % prezzo_FRUMENTO_TENERO_GERME)
print('|       CRUSCA, CRUSCHELLO E TRITELLO F. D.  |      %s              | Borsa Merci di Bologna |' % prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B)
print('|       FARINACCIO DI FRUMENTO DURO          |      %s              | Borsa Merci di Milano |' % prezzo_FRUMENTO_DURO_FARINACCIO)
print('|       FARINACCIO DI FRUMENTO DURO          |      %s              | Borsa Merci di Bologna |' % prezzo_FRUMENTO_DURO_FARINACCIO_B)
print('|       FARINETTA DI FRUMENTO DURO           |      %s              | Borsa Merci di Bologna |' % prezzo_FRUMENTO_DURO_FARINETTA_B)
print('|       MAIS                                 |      %s              | Borsa Merci di Milano |' % prezzo_MAIS)
print('|       MAIS                                 |      %s              | Borsa Merci di Bologna |' % prezzo_MAIS_B)
print('|       FARINA DI MAIS                       |      %s              | Borsa Merci di Bologna |' % prezzo_MAIS_FARINA_B)
print('|       GLUTINE DI MAIS                      |      %s              | Borsa Merci di Milano |' % prezzo_MAIS_GLUTINE)
print('|       FARINA GLUTINATA DI MAIS             |      %s              | Borsa Merci di Milano |' % prezzo_MAIS_FARINA_GLUTINATA)
print('|       SEMOLA GLUTINATA DI MAIS             |      %s              | Borsa Merci di Milano |' % prezzo_MAIS_SEMOLA_GLUTINATA)
print('|       SEMOLA GLUTINATA DI MAIS             |      %s              | Borsa Merci di Bologna |' % prezzo_MAIS_SEMOLA_GLUTINATA_B)
print('|       SEGALE             		    |      %s              | Borsa Merci di Milano |' % prezzo_SEGALE)
print('|       FRUMENTO                             |      %s              | Borsa Merci di Bologna |' % prezzo_FRUMENTO_B)
print('|       ORZO                                 |      %s              | Borsa Merci di Milano |' % prezzo_ORZO)
print('|       ORZO                                 |      %s              | Borsa Merci di Bologna |' % prezzo_ORZO_B)
print('|       AVENA                                |      %s              | Borsa Merci di Milano |' % prezzo_AVENA)
print('|       TRITICALE                            |      %s              | Borsa Merci di Milano |' % prezzo_TRITICALE)
print('|       SORGO                                |      %s              | Borsa Merci di Milano |' % prezzo_SORGO)
print('|       SORGO                                |      %s              | Borsa Merci di Bologna |' % prezzo_SORGO_B)
print('|       MANIOCA                              |      %s              | Borsa Merci di Milano |' % prezzo_MANIOCA)
print('|       PISELLO                              |      %s              | Borsa Merci di Milano |' % prezzo_PISELLO)
print('|       PISELLO                              |      %s              | Borsa Merci di Bologna |' % prezzo_PISELLO_B)
print('|       FAVINO DA GRANELLA                   |      %s              | Borsa Merci di Bologna |' % prezzo_FAVINO_B)
# print('|       FAVINO DA FORAGGIO                 |      %s              | Borsa Merci di Foggia  |' % prezzo_FAVINO_FORAGGIO_F)
print('|       LUPINO (prezzo medio)                |      %s              | Borsa Merci di Alessandria  |' % prezzo_LUPINO)
print('|       SOIA                                 |      %s              | Borsa Merci di Milano |' % prezzo_SOIA)
print('|       SOIA                                 |      %s              | Borsa Merci di Bologna |' % prezzo_SOIA_B)
print('|       FARINA DI ESTRAZIONE DI COLZA        |      %s              | Borsa Merci di Milano |' % prezzo_COLZA_FE)
print('|       FARINA DI ESTRAZIONE DI COLZA        |      %s              | Borsa Merci di Bologna |' % prezzo_COLZA_FE_B)
print('|       FARINA DI ESTRAZIONE DI GIRASOLE DEC.|      %s              | Borsa Merci di Milano |' % prezzo_GIRASOLE_DECORTICATO_FE)
print('|       FARINA DI ESTRAZIONE DI GIRASOLE INT.|      %s              | Borsa Merci di Bologna |' % prezzo_GIRASOLE_INTEGRALE_FE_B)
print('|       FARINA DI ESTRAZIONE DI SOIA         |      %s              | Borsa Merci di Milano |' % prezzo_SOIA_FE)
print('|       FARINA DI ESTRAZIONE DI SOIA         |      %s              | Borsa Merci di Bologna |' % prezzo_SOIA_FE_B)
print('|       ERBA MEDICA DISIDRATATA EXTRA        |      %s              | Borsa Merci di Milano |' % prezzo_ERBA_MEDICA_DIS_EXTRA)
print('|       ERBA MEDICA DISIDRATATA 17x100       |      %s              | Borsa Merci di Bologna |' % prezzo_ERBA_MED_DIS_17_B)
print('|       ERBA MEDICA DISIDRATATA DI 1 QUALITÀ |      %s              | Borsa Merci di Milano |' % prezzo_ERBA_MEDICA_DIS_1_QUAL)
print('|       ERBA MEDICA DISIDRATATA 16x100       |      %s              | Borsa Merci di Bologna |' % prezzo_ERBA_MED_DIS_16_B)
print('|       ERBA MEDICA DISIDRATATA 14x100       |      %s              | Borsa Merci di Bologna |' % prezzo_ERBA_MED_DIS_14_B)
print('|       POLPE SECCHE DI BIETOLA              |      %s              | Borsa Merci di Milano |' % prezzo_BIETOLA_POLPE_SECCHE)
print('|       POLPE DI BIETOLA                     |      %s              | Borsa Merci di Bologna |' % prezzo_BIETOLA_POLPE_B)
print('|       CARRUBE FRANTUMATE                   |      %s              | Borsa Merci di Milano |' % prezzo_CARRUBE_FRANTUMATE)
print('|       FIENO MAGGENGO                       |      %s              | Borsa Merci di Milano |' % prezzo_FIENO_MAGGENGO)
print('|       FIENO DI 1 TAGLIO                    |      %s              | Borsa Merci di Bologna |' % prezzo_FIENO_1_TAGLIO_B)
print('|       FIENO DI 1 TAGLIO FIBRA LUNGA        |      %s              | Borsa Merci di Bologna |' % prezzo_FIENO_1_TAGLIO_FIBRA_LUNGA_B)
print('|       FIENO AGOSTANO                       |      %s              | Borsa Merci di Milano |' % prezzo_FIENO_AGOSTANO)
print('|       FIENO MEDICA                         |      %s              | Borsa Merci di Milano |' % prezzo_FIENO_MEDICA)
print('|       FIENO MEDICA 17x100 1 TAG. IN ROTOB. |      %s              | Borsa Merci di Bologna |' % prezzo_FIENO_MEDICA_17_1_TAGLIO_ROTBAL_B)
print('|       FIENO MEDICA 17x100 1 TAG. IN BALL.Q.|      %s              | Borsa Merci di Bologna |' % prezzo_FIENO_MEDICA_17_1_TAGLIO_BALQUA_B)
print('|       FIENO MEDICA 17x100 2 TAG. IN ROTOB. |      %s              | Borsa Merci di Bologna |' % prezzo_FIENO_MEDICA_17_2_TAGLIO_ROTBAL_B)
print('|       FIENO MEDICA 17x100 2 TAG. IN BALL.Q.|      %s              | Borsa Merci di Bologna |' % prezzo_FIENO_MEDICA_17_2_TAGLIO_BALQUA_B)
print('|       FIENO MEDICA 17x100 3 TAG. IN ROTOB. |      %s              | Borsa Merci di Bologna |' % prezzo_FIENO_MEDICA_17_3_TAGLIO_ROTBAL_B)
print('|       FIENO MEDICA 17x100 3 TAG. IN BALL.Q.|      %s              | Borsa Merci di Bologna |' % prezzo_FIENO_MEDICA_17_3_TAGLIO_BALQUA_B)
print('|       FIENO MEDICA 17x100 4 TAG. IN ROTOB. |      %s              | Borsa Merci di Bologna |' % prezzo_FIENO_MEDICA_17_4_TAGLIO_ROTBAL_B)
print('|       FIENO MEDICA 17x100 4 TAG. IN BALL.Q.|      %s              | Borsa Merci di Bologna |' % prezzo_FIENO_MEDICA_17_4_TAGLIO_BALQUA_B)
print('|       PAGLIA                               |      %s              | Borsa Merci di Milano |' % prezzo_PAGLIA)
print('|       PAGLIA                               |      %s              | Borsa Merci di Bologna |' % prezzo_PAGLIA_ROTBAL_B)
print('|       MELASSO                              |      %s              | Borsa Merci di Milano |' % prezzo_MELASSO)
print('|       MELASSO DI CANNA                     |      %s              | Borsa Merci di Bologna |' % prezzo_MELASSO_CANNA_B)
print('|       MELASSO DI BIETOLA                   |      %s              | Borsa Merci di Bologna |' % prezzo_MELASSO_BIETOLA_B)
print('|       BUCCETTE DI SOIA                     |      %s              | Borsa Merci di Milano |' % prezzo_SOIA_BUCCETTE)
print('|       BUCCETTE DI SOIA                     |      %s              | Borsa Merci di Bologna |' % prezzo_SOIA_BUCCETTE_B)

print('|       GRANA VERDE DI RISO                  |      %s              | Borsa Merci di Milano |' % prezzo_RISO_GRANA_VERDE)
print('|       GRANA VERDE DI RISO                  |      %s              | Borsa Merci di Bologna |' % prezzo_RISO_GRANA_VERDE_B)
print('|       FARINACCIO  DI RISO                  |      %s              | Borsa Merci di Milano |' % prezzo_RISO_FARINACCIO)
print('|       FARINACCIO  DI RISO                  |      %s              | Borsa Merci di Bologna |' % prezzo_RISO_FARINACCIO_B)
print('|       PULA VERGINE DI RISO                 |      %s              | Borsa Merci di Milano |' % prezzo_RISO_PULA_VERGINE)
print('|       PULA VERGINE DI RISO                 |      %s              | Borsa Merci di Bologna |' % prezzo_RISO_PULA_VERGINE_B)
# print('|       SEMI DI COTONE                       |      %s              | Borsa Merci di Verona |' % prezzo_COTONE_V)
print('|       SEMI DI COTONE                       |      %s              | Borsa Merci di Bologna |' % prezzo_COTONE_B)
print('______________________________________________________________________________________________')

