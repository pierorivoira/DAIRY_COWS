# File: Hello.py

print("Hello World!")