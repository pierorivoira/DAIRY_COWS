# PyR_1.0_w_04.04.22.py


# pip install html-table-parser-python 
# pip install testresources
# pip install --upgrade --force-reinstall matplotlib
# pip install --upgrade --force-reinstall Pillow 
# sudo apt install python-tk



#####################################
########## WINDOWS VERSION ##########
#####################################



from tkinter import *
from tkinter import Menu, ttk
from PIL import Image, ImageTk                          # get widget classes
from tkinter.messagebox import *                        # get standard dialogs
from tkinter.simpledialog import askstring
from tkinter.scrolledtext import ScrolledText           # or PP4E.Gui.Tour.scrolledtext
from tkinter.filedialog   import askopenfilename        # get standard dialogs
from tkinter.filedialog   import asksaveasfilename
from tkinter.filedialog   import askdirectory
from tkinter.colorchooser import askcolor               # they live in Lib\tkinter
from tkinter.messagebox   import askquestion, showerror
from tkinter.simpledialog import askfloat
from tkinter.simpledialog import askinteger
from quitter import Quitter
from PIL import ImageTk as itk
import math, os, sys
# import subprocess
import numpy as np
import tkinter as tk
from datetime import date, datetime
import datetime

global ARR, COSTO_RAZIONE, current_time, data, data_odierna, day, F, imgdir, now, P, PREZZI, S, size, today, user

today = date.today()
now = datetime.datetime.now()
day = datetime.datetime.now().strftime("%A")
data_odierna = today.strftime('%d/%m/%Y')
current_time = now.strftime("%H:%M:%S")


COSTO_RAZIONE = []
PREZZI = []

user = os.getlogin()
os.chdir('C:/Users/%s/PYTHON' % user)
imgdir = r'C:/Users/%s/PYTHON/' % user



class GuiOutput:
    font = ('courier', 10, 'normal')                     # in class for all, self for one
    
    def __init__(self, parent=None):
        self.text = None
        if parent: self.popupnow(parent)                 # pop up now or on first write

    def popupnow(self, parent=None):                     # in parent now, Toplevel later
        if self.text: return
        self.text = ScrolledText(parent or Toplevel())
        self.text.config(font=self.font)
        self.text.pack(expand=YES, fill=BOTH)
#       hscroll = Scrollbar(self.text, orient='horizontal')
#       hscroll.pack(side=BOTTOM, fill='x')
#       hscroll.config(command=self.text.xview)
#       xscrollcommand = hscroll.set

    def write(self, text):
        self.popupnow()
        self.text.insert(END, str(text))
        self.text.see(END)
        self.text.update()                                # update gui after each line

    def writelines(self, lines):                          # lines already have '\n'
        for line in lines: self.write(line)               # or map(self.write, lines)

class GuiInput:
    def __init__(self):
        self.buff = ''

    def inputLine(self):
        line = askstring('GuiInput', 'Enter input line + <crlf> (cancel=eof)')
        if line == None:
            return ''                                     # pop-up dialog for each line
        else:                                             # cancel tk.Menubutton means eof
            return line + '\n'                            # else add end-line marker

    def read(self, bytes=None):
        if not self.buff:
            self.buff = self.inputLine()
        if bytes:                                         # read by byte count
            text = self.buff[:bytes]                      # doesn't span lines
            self.buff = self.buff[bytes:]
        else:
            text = ''                                     # read all till eof
            line = self.buff
            while line:
                text = text + line
                line = self.inputLine()                   # until cancel=eof=''
        return text

    def readline(self):
        text = self.buff or self.inputLine()              # emulate file read methods
        self.buff = ''
        return text

    def readlines(self):
        lines = []                                        # read all lines
        while True:
            next = self.readline()
            if not next: break
            lines.append(next)
        return lines


def redirectedGuiFunc(func, *pargs, **kargs):
#   import sys
    saveStreams = sys.stdin, sys.stdout                    # map func streams to pop ups
    sys.stdin   = GuiInput()                               # pops up dialog as needed
    sys.stdout  = GuiOutput()                              # new output window per call
    sys.stderr  = sys.stdout
    result = func(*pargs, **kargs)                         # this is a blocking call
    sys.stdin, sys.stdout = saveStreams
    return result


def redirectedGuiShellCmd(command):
#   import os
    input  = os.popen(command, 'r')
    output = GuiOutput()
    def reader(input, output):                              # show a shell command's
        while True:                                         # standard output in a new
            line = input.readline()                         # pop-up text box widget;
            if not line: break                              # the readline call may block
            output.write(line)
    reader(input, output)



def metodo_di_calcolo():
    global metodo
    metodo = askstring('Entry', 'Scegli il metodo di calcolo della razione (per es.: americano, francese) \n')
    print(metodo)   

def specie_animale():
    global specie
    specie = askstring('Entry', 'Scegli la specie animale allevata (per es.: bovina, caprina, ovina) \n')
    print(specie) 

def attitudine_produttiva():
    global attitudine_produttiva
    attitudine_produttiva = askstring('Entry', "Scegli l'attitudine produttiva (per es.: latte, carne) \n")
    print(attitudine_produttiva) 

def fase_produttiva():
    global fase_produttiva
    fase_produttiva = askstring('Entry', 'Scegli la fase produttiva (per es.: lattazione, asciutta) \n')
    print(fase_produttiva) 

def peso():
    global LW
    LW = askfloat('Entry', 'Inserisci il peso medio di un gruppo omogeneo di animali (in kg) \n')
    print(LW)
    
def WOL():
    global WOL
    WOL = askinteger('Entry', 'Inserisci la settimana di lattazione media di un gruppo omogeneo di animali \n')
    print(WOL) 
    
def latte_prodotto():
    global MY
    MY = askfloat('Entry', 'Inserisci il livello produttivo giornaliero medio di un gruppo omogeneo di animali (in kg) \n')
    print(MY)       

def grasso():
    global FAT_milk
    FAT_milk = askfloat('Entry', 'Inserisci la % di grasso del latte di massa \n')
    print(FAT_milk)

def proteina():
    global CP_milk
    CP_milk = askfloat('Entry', 'Inserisci la % di proteina del latte di massa \n')
    print(CP_milk)

def lattosio():
    global LAC_milk
    LAC_milk = askfloat('Entry', 'Inserisci la % di lattosio del latte di massa \n')
    print(LAC_milk)

def numero_di_repliche():
    global N_repl
    N_repl = askinteger('Entry', 'Inserisci il numero di repliche (per es.: 100, 1000, 10000 \n)')
    print(N_repl)



def stampa_parametri():

    os.system('python crea_db_PARAMETRI_w.py') 
    from crea_db_PARAMETRI_w import specie, attitudine_produttiva, fase_produttiva, LW, WOL, MY, FAT_milk, CP_milk, LAC_milk, N_repl

        
    print('metodo di calcolo => AMERICANO')
    print('specie animale => %s,' % specie)
    print('attitudine produttiva => %s,' % attitudine_produttiva)
    print('fase produttiva => %s,' % fase_produttiva)
    print('peso vivo medio => %f kg,' % LW)
    print('settimana di lattazione media => %desima,' % WOL)
    print('livello produttivo medio => %f kg di latte al giorno,' % MY)
    print('percentuale di grasso del latte => %f,' % FAT_milk)
    print('percentuale di proteina del latte => %f,' % CP_milk)
    print('percentuale di lattosio del latte => %f.' % LAC_milk)
    print('numero di repliche => %d.' % N_repl)


###############################################################################################################################


def stampa_parametri_su_file():

    P = []
    P.append(specie)
    P.append(attitudine_produttiva)
    P.append(fase_produttiva)
    P.append(LW)
    P.append(WOL)
    P.append(MY)
    P.append(FAT_milk)
    P.append(CP_milk)
    P.append(LAC_milk)
    P.append(N_repl)

            
    with open('PARAMETRI.txt', 'w') as external_file:
        print(P, file=external_file)
    external_file.close()


###############################################################################################################################



def calcola_fabbisogni():

    os.system('python crea_db_PARAMETRI_w.py') 
    from crea_db_PARAMETRI_w import LW, WOL, MY, FAT_milk, CP_milk, LAC_milk

    global MW, FCM, DMI, CPI, RDPI, RUPI, FG, NDF, ADF, FAT, AM, NSC, ZUC, Ca_mant, Ca_latt, Ca_tot, P_mant, P_latt, P_tot, UFL_mant, UFL_latt, UFL_tot, F_arr 
    

    
    MW = LW**0.75							# peso metabolico
    FCM = (0.4+(0.15*FAT_milk))*MY			# latte corretto in grasso al 4%
    DMI = (0.372*FCM+0.0968*MW)*(1-math.exp(-0.192*(WOL+3.67)))	# capacità d'ingestione (kg di sostanza secca)
    CPI = 0.18*DMI*1000						# fabbisogno di proteina grezza (in grammi)
    RDPI = 0.6*CPI							#     //     //    //    degradabile (in grammi)
    RUPI = 0.4*CPI							#     //     //    //    indegradabile (in grammi)
    FG = 0.17*DMI*1000						#     //     // fibra grezza (in grammi)
    NDF = 0.012*LW*1000						#     //     // Neutral Detergent Fiber (in grammi)
    ADF = 0.2*DMI*1000						#     //     // Acid Detergent Fiber (in grammi)
    FAT = 0.05*DMI*1000						#     //     // grasso (in grammi)
    AM = 0.25*DMI*1000						#     //     // amido (in grammi)
    NSC = NDF/0.9							#     //     // Non Structural Carbohydrates (amido + zuccheri, in grammi)
    ZUC = NSC - AM							#     //     // zuccheri
    Ca_mant = LW*0.031/0.38					#     //     // mantenimento di Ca (in grammi)
    Ca_latt = FCM*1.22/0.38					#     //     // lattazione di Ca (in grammi)
    Ca_tot = Ca_mant+Ca_latt				#     //     totale di Ca (in grammi)
    P_mant = DMI*1.2						#     //     // mantenimento di P (in grammi)
    P_latt = FCM*0.9/0.6					#     //     // lattazione di P (in grammi)
    P_tot = P_mant+P_latt					#     //     totale di P (in grammi)
    UFL_mant = 0.08*MW/1.73					#     // energetico di mantenimento (in Unità Foraggere Latte)
    UFL_latt = (0.0929*FAT_milk+0.0547*CP_milk+0.0395*LAC_milk)*MY/1.73	#     // energetico di produzione (in Unità Foraggere Latte)
    									
# NE L (Mcal/kg) = (0.0929 x % fat) + (0.0563 x % true protein) + (0.0395 x % lactose)
# If lactose is not available, 4.85% should be assumed. Milk CP is determined by N x 6.38,	and milk CP contains about 7% non-protein nitrogen. The coefficient in the above equation for milk CP would be 0.0547.
# Eastridge, M. L. (2002). Energy in the new dairy NRC. The Ohio State University.


    UFL_tot = UFL_mant+UFL_latt
    
    F = []
    F.append(DMI)
    F.append(CPI)
    F.append(RDPI)
    F.append(RUPI)
    F.append(FG)
    F.append(NDF)
    F.append(ADF)
    F.append(FAT)
    F.append(AM)
    F.append(ZUC)
    F.append(Ca_tot)
    F.append(P_tot)
    F.append(UFL_tot)
    
    F_arr = np.array(F)

    
    with open('FABBISOGNI.txt', 'w') as external_file:
        print(F, file=external_file)
    external_file.close()
    
    print('FABBISOGNI calcolati con successo!')
    # print('Il seguente è il vettore dei fabbisogni <F_arr>')
    # print(F_arr)
    print('')
    print('Adesso puoi iniziare a scegliere gli alimenti')
    print('')    
    print("ATTENZIONE: se desideri indicare la quantità di insilato (o di pastone) di mais E QUELLA DEL MAIS GRANELLA, devi prima inserire l'insilato o il pastone (non entrambi) e POI LA GRANELLA DI MAIS")
    print('Quindi, la procedura da seguire è:')
    print('')
    print('PASSAGGIO N.1')
    print('')
    print('Menù Mais => seleziono <Insilato> => immetto la quantità (senza unità di misura)')
    print('OPPURE')
    print('Menù Mais => seleziono <Pastone integrale> => immetto la quantità (senza unità di misura)')    
    print('OPPURE')
    print('Menù Mais => seleziono <Pastone granella> => immetto la quantità (senza unità di misura)')
    print('')
    print('PASSAGGIO N.2')
    print('')
    print('Menù Mais => seleziono <Granella> => immetto la quantità (senza unità di misura)')
    print('')
    print('PASSAGGIO N.3')
    print('')
    print("Inserisco altri alimenti (fino ad un massimo di 8-9): avendone già inseriti 1 o 2 (l'insilato o il pastone di mais ed, eventualmente, la granella di mais), il totale non dovrà essere > di 10")
    print('')
    print('                                            *	*	*')
    
###############################################################################################################################


S = []
ARR = []


def stampa_fabbisogni():
    import random
    
    F = []
    F.append(DMI)
    F.append(CPI)
    F.append(RDPI)
    F.append(RUPI)
    F.append(FG)
    F.append(NDF)
    F.append(ADF)
    F.append(FAT)
    F.append(AM)
    F.append(ZUC)
    F.append(Ca_tot)
    F.append(P_tot)
    F.append(UFL_tot)

    
    print('capacità di ingestione => %f kg di sostanza secca,' % F[0])
    print('fabbisogno di proteina grezza => %f g,' % F[1])
    print('fabbisogno di proteina degradabile => %f g,' % F[2])
    print('fabbisogno di proteina indegradabile => %f g,' % F[3])
    print('fabbisogno di fibra grezza => %f g,' % F[4])
    print('fabbisogno di Neutral Detergent Fiber => %f g,' % F[5])
    print('fabbisogno di Acid Detergent Fiber => %f g,' % F[6]) 
    print('fabbisogno di grasso => %f g,' % F[7])
    print('fabbisogno di amido => %f g,' % F[8])
    print('fabbisogno di zuccheri => %f g,' % F[9])
    print('fabbisogno totale di Ca => %f g,' % F[10])
    print('fabbisogno totale di P => %f g,' % F[11])
    print('fabbisogno energetico totale => %f Unità Foraggere Latte. \n' % F[12])
    
    print(F)


def stampa_prezzi_teseo():
#   import os
    import ssl, urllib.request
    import pandas as pd				
    from html_table_parser.parser import HTMLTableParser		
    from datetime import datetime, timedelta
    from contextlib import redirect_stdout
    
    ssl._create_default_https_context = ssl._create_unverified_context					

# user = os.getlogin()
# os.chdir('C:/Users/%s/PYTHON' % user)

    data_aggiornamento_teseo = datetime.today().strftime('%d.%m.%Y')

# pd.set_option('display.max_rows', 200)
# pd.options.display.width=None

    def url_get_contents(url):					

        req = urllib.request.Request(url=url)			
        f = urllib.request.urlopen(req)
        return f.read()						

    xhtml = url_get_contents('https://teseo.clal.it').decode('utf-8')
    p = HTMLTableParser()						
    p.feed(xhtml)							
# print(len(p.tables))
# pprint(p.tables[58])						
# print("\n\nPANDAS DATAFRAME\n")				
    teseo = pd.DataFrame(p.tables[58])

# print('FONTE: https://teseo.clal.it/')
# print('Prezzi aggiornati al %s' % data_aggiornamento_teseo) 

    with open('listino_prezzi_teseo.txt', 'w', encoding = "utf-8") as f:
        with redirect_stdout(f):
            print(teseo)
        
    with open('listino_prezzi_teseo.txt', 'r') as file:
        filedata = file.read()

    filedata = filedata.replace("In calo", "=> ")
    filedata = filedata.replace("In aumento", "=> ")
    filedata = filedata.replace("Prezzo", "prezzo")
    filedata = filedata.replace("frumento", "Frumento")
    filedata = filedata.replace(" /ton ", "EURO/ton; VARIAZIONE: ")

    print('Prezzi aggiornati al %s (https://teseo.clal.it/?section=conf_cereali)' % data_aggiornamento_teseo)
    print(filedata)
    

def apri_ultima_razione():
    import os
    os.system('Notepad NUOVA_RAZIONE.txt')


###############################################################################################################################
###############################################################################################################################

def calcola_razione():
    import random
    
    os.system('python crea_db_FABBISOGNI_w.py')
    from crea_db_FABBISOGNI_w import F
    from crea_db_PARAMETRI_w import N_repl
    
    print('capacità di ingestione => %f kg di sostanza secca,' % F[0])
    print('fabbisogno di proteina grezza => %f g,' % F[1])
    print('fabbisogno di proteina degradabile => %f g,' % F[2])
    print('fabbisogno di proteina indegradabile => %f g,' % F[3])
    print('fabbisogno di fibra grezza => %f g,' % F[4])
    print('fabbisogno di Neutral Detergent Fiber => %f g,' % F[5])
    print('fabbisogno di Acid Detergent Fiber => %f g,' % F[6]) 
    print('fabbisogno di grasso => %f g,' % F[7])
    print('fabbisogno di amido => %f g,' % F[8])
    print('fabbisogno di zuccheri) => %f g,' % F[9])
    print('fabbisogno totale di Ca => %f g,' % F[10])
    print('fabbisogno totale di P => %f g,' % F[11])
    print('fabbisogno energetico totale => %f Unità Foraggere Latte. \n' % F[12])
    
    print(F)
    
    global F_arr
    F_arr = np.array(F)
    
    if len(S) == 3:                    
        print(S[0])
        print(S[1])
        print(S[2])
        print(ARR[0])
        print(ARR[1])
        print(ARR[2])
        
        print('Hai inserito 3 alimenti \n')

#       print("QUESTA È LA VERSIONE CORRETTA DELL'ALGORITMO")
        
        random_ARR_0_old = ARR[0] * random.random() * 10
        random_ARR_1_old = ARR[1] * random.random() * 10
        random_ARR_2_old = ARR[2] * random.random() * 10
        
# ogni alimento scelto dall'utente viene moltiplicato per un numero casuale compreso fra 0 e 10 (kg) 
# dichiaro random_ARR_x_old

        
        random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
        random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
        random_ARR_2_new = random_ARR_2_old * (random.random() + 0.5)
        
# dichiaro random_ARR_x_new
        
        SOMMA_old = random_ARR_0_old + random_ARR_1_old + random_ARR_2_old
        DELTA_old = SOMMA_old - F_arr
        print('La somma iniziale è...')
        print(SOMMA_old)

# dichiaro SOMMA_old e DELTA_old

        SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new
        DELTA_new = SOMMA_new - F_arr
        print('La nuova somma è...')
        print(SOMMA_new)
        print('La nuova differenza è...')
        print(DELTA_new)

# dichiaro SOMMA_new e DELTA_new
        
        quantità_alimento_1 = random_ARR_0_new / ARR[0]
        quantità_alimento_2 = random_ARR_1_new / ARR[1]
        quantità_alimento_3 = random_ARR_2_new / ARR[2]
        
# dichiaro gli apporti dei singoli alimenti

        i = 0

# inizializzo il contatore i        
        
        for i in range(N_repl):
        
            rules = [abs(DELTA_new[0]) < abs(DELTA_old[0]), abs(DELTA_new[1]) < abs(DELTA_old[1]), abs(DELTA_new[2]) < abs(DELTA_old[2])]

# dichiaro le regole da rispettare
                                    
            if all(rules):
            
                print('ESTRAGGO DALLA PROPOSAL DISTRIBUTION')
                i += 1
                print(i)
                                                         	               	        
                random_ARR_0_new = random_ARR_0_new * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_new * (random.random() + 0.5)
                random_ARR_2_new = random_ARR_2_new * (random.random() + 0.5)
                
# ACCETTO random_ARR_x_new e lo uso per aggiornare random_ARR_x_new stesso 
                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0]
                print(APPORTO_TOTALE_SOSTANZA_SECCA)

# aggiorno l'apporto di SS
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new
                DELTA_new = SOMMA_new - F_arr
                
# aggiorno SOMMA_new e DELTA_new                
                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                quantità_alimento_3 = random_ARR_2_new / ARR[2]
                
                
                if round(APPORTO_TOTALE_SOSTANZA_SECCA) == round(F_arr[0]):
                
                    break
                
                print(i)    
                print("SUCCESSO! L'APPORTO DI SOSTANZA SECCA CORRISPONDE AL FABBISOGNO.")

                    	                
            else:
                    
                random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
                random_ARR_2_new = random_ARR_2_old * (random.random() + 0.5)
                
# RIFIUTO random_ARR_x_new e lo ricalcolo a partire da random_ARR_x_old 
                
                print('FALLIMENTO')
                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0]
                print(APPORTO_TOTALE_SOSTANZA_SECCA)
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new
                DELTA_new = SOMMA_new - F_arr
                                                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                quantità_alimento_3 = random_ARR_2_new / ARR[2]
                

                                                     
        QUANTITÀ_TOTALE_TAL_QUALE = quantità_alimento_1[0] + quantità_alimento_2[0] + quantità_alimento_3[0]
        APPORTO_TOTALE_PROTEINA_GREZZA = random_ARR_0_new[1] + random_ARR_1_new[1] + random_ARR_2_new[1]
        APPORTO_TOTALE_PROTEINA_DEGRADABILE = random_ARR_0_new[2] + random_ARR_1_new[2] + random_ARR_2_new[2]
        APPORTO_TOTALE_PROTEINA_INDEGRADABILE = random_ARR_0_new[3] + random_ARR_1_new[3] + random_ARR_2_new[3]
        APPORTO_TOTALE_FIBRA_GREZZA = random_ARR_0_new[4] + random_ARR_1_new[4] + random_ARR_2_new[4]
        APPORTO_TOTALE_NDF = random_ARR_0_new[5] + random_ARR_1_new[5] + random_ARR_2_new[5]
        APPORTO_TOTALE_ADF = random_ARR_0_new[6] + random_ARR_1_new[6] + random_ARR_2_new[6]
        APPORTO_TOTALE_GRASSO = random_ARR_0_new[7] + random_ARR_1_new[7] + random_ARR_2_new[7]
        APPORTO_TOTALE_AMIDO = random_ARR_0_new[8] + random_ARR_1_new[8] + random_ARR_2_new[8]
        APPORTO_TOTALE_ZUCCHERI = random_ARR_0_new[9] + random_ARR_1_new[9] + random_ARR_2_new[9]
        APPORTO_TOTALE_Ca = random_ARR_0_new[10] + random_ARR_1_new[10] + random_ARR_2_new[10]
        APPORTO_TOTALE_P = random_ARR_0_new[11] + random_ARR_1_new[11] + random_ARR_2_new[11]
        APPORTO_TOTALE_UFL = random_ARR_0_new[12] + random_ARR_1_new[12] + random_ARR_2_new[12]
        
        DELTA_SOSTANZA_SECCA = APPORTO_TOTALE_SOSTANZA_SECCA - F[0]
        DELTA_PROTEINA_GREZZA = APPORTO_TOTALE_PROTEINA_GREZZA - F[1]
        DELTA_PROTEINA_DEGRADABILE = APPORTO_TOTALE_PROTEINA_DEGRADABILE - F[2]
        DELTA_PROTEINA_INDEGRADABILE = APPORTO_TOTALE_PROTEINA_INDEGRADABILE - F[3]
        DELTA_FIBRA_GREZZA = APPORTO_TOTALE_FIBRA_GREZZA - F[4]
        DELTA_NDF = APPORTO_TOTALE_NDF - F[5]
        DELTA_ADF = APPORTO_TOTALE_ADF - F[6]
        DELTA_GRASSO = APPORTO_TOTALE_GRASSO - F[7]
        DELTA_AMIDO = APPORTO_TOTALE_AMIDO - F[8]
        DELTA_ZUCCHERI = APPORTO_TOTALE_ZUCCHERI - F[9]
        DELTA_Ca = APPORTO_TOTALE_Ca - F[10]
        DELTA_P = APPORTO_TOTALE_P - F[11]
        DELTA_UFL = APPORTO_TOTALE_UFL - F[12]
    
                                        
        original = sys.stdout
        sys.stdout = open('NUOVA_RAZIONE.txt', 'w')
        
        
        if day == 'Monday': 
            print('RAZIONE di %s, creata lunedì %s, %s' % (user, data, current_time))
        if day == 'Tuesday': 
            print('RAZIONE di %s, creata martedì %s, %s' % (user, data, current_time))
        if day == 'Wednesday': 
            print('RAZIONE di %s, creata mercoledì %s, %s' % (user, data, current_time))
        if day == 'Thursday': 
            print('RAZIONE di %s, creata giovedì %s, %s' % (user, data, current_time))
        if day == 'Friday': 
            print('RAZIONE di %s, creata venerdì %s, %s' % (user, data, current_time))
        if day == 'Saturday': 
            print('RAZIONE di %s, creata sabato %s, %s' % (user, data, current_time))
        if day == 'Sunday': 
            print('RAZIONE di %s, creata domenica %s, %s' % (user, data, current_time))
        
        
        print('')
#       print('This is your redirected text:')
        print('')
        if i == 999:
            print('Il calcolo della razione non ha avuto successo; per favore chiudi il programma e riprova.')
        else:
            print('Il calcolo della razione è stato effettuato con successo alla %d^esima replica' % i)        
#       print(i)
        print('')
        print('Il fabbisogno di SOSTANZA SECCA è di %f' %  F_arr[0])
        print('')
        print("L'apporto totale di SOSTANZA SECCA è di %f" % APPORTO_TOTALE_SOSTANZA_SECCA)
        print('')
        print('out of loop')
        print('')        
        print('LEGENDA')
        print('')
        print("DMI => Dry Matter Intake (Capacità d'ingestione di Sostanza Secca)")
        print("CPI => Crude Protein Intake (Apporto di Proteina Grezza)")
        print("RDPI => Rumen Degradable Protein Intake (Apporto di Proteina Degradabile)")
        print("RUPI => Rumen Undegradable Protein Intake (Apporto di Proteina Indegradabile)")
        print("FG => Fibra Grezza (apporto di Fibra Grezza)")
        print("NDF => Neutral Detergent Fiber (apporto di Fibra resistente al Detergente Neutro)")
        print("ADF => Acid Detergent Fiber (apporto di Fibra resistente al Detergente Acido)")
        print("FAT => Fat (apporto di Grasso)")
        print("AM => Amido (apporto di Amido)")
        print("ZUC => Zuccheri (apporto di Zuccheri)")
        print("Ca => Calcio (apporto di Calcio)")
        print("P => Fosforo (apporto di Fosforo)")
        print("UFL => Unità Foraggere Latte (apporto di Energia Netta)")
        print('DMI', 'CPI', 'RDPI', 'RUPI', 'FG', 'NDF', 'ADF', 'FAT', 'AM', 'ZUC', 'Ca', 'P', 'UFL')                	                
        	                
                                
        print('apporti di %s: \n' % S[0])
        print(random_ARR_0_new)
        print('apporti di %s: \n' % S[1])
        print(random_ARR_1_new)
        print('apporti di %s: \n' % S[2])
        print(random_ARR_2_new)
        
                                
        print('%f kg %s' % (quantità_alimento_1[0], S[0]))
        print('%f kg %s' % (quantità_alimento_2[0], S[1]))
        print('%f kg %s' % (quantità_alimento_3[0], S[2]))
                        
        print('La razione fornisce %f kg di alimento tal quale' % QUANTITÀ_TOTALE_TAL_QUALE)
        print('La razione fornisce %f kg di sostanza secca' % APPORTO_TOTALE_SOSTANZA_SECCA)
        
        print("SOSTANZA SECCA: la differenza fra l'apporto totale => %f kg e la capacità d'ingestione => %f kg è: %f kg" % (APPORTO_TOTALE_SOSTANZA_SECCA, F[0], DELTA_SOSTANZA_SECCA))
        print("PROTEINA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_GREZZA, F[1], DELTA_PROTEINA_GREZZA)) 
        print("PROTEINA DEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_DEGRADABILE, F[2], DELTA_PROTEINA_DEGRADABILE))
        print("PROTEINA INDEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_INDEGRADABILE, F[3], DELTA_PROTEINA_INDEGRADABILE))
        print("FIBRA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_FIBRA_GREZZA, F[4], DELTA_FIBRA_GREZZA))
        print("NDF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_NDF, F[5], DELTA_NDF))
        print("ADF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ADF, F[6], DELTA_ADF))
        print("GRASSO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_GRASSO, F[7], DELTA_GRASSO)) 
        print("AMIDO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_AMIDO, F[8], DELTA_AMIDO))
        print("ZUCCHERI: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ZUCCHERI, F[9], DELTA_ZUCCHERI))
        print("Ca: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_Ca, F[10], DELTA_Ca))
        print("P: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_P, F[11], DELTA_P))
        print("UFL: la differenza fra l'apporto totale => %f UFL e il fabbisogno => %f UFL è: %f UFL" % (APPORTO_TOTALE_UFL, F[12], DELTA_UFL))
        
        sys.stdout = original
        print('This string goes to stdout, NOT the file!')

                                
    
    elif len(S) == 4: 
        print(S[0])
        print(S[1])
        print(S[2])
        print(S[3])
        print(ARR[0])
        print(ARR[1])
        print(ARR[2])
        print(ARR[3])
        
        print('Hai inserito 4 alimenti \n')

#       print("QUESTA È LA VERSIONE CORRETTA DELL'ALGORITMO")
        
        random_ARR_0_old = ARR[0] * random.random() * 10
        random_ARR_1_old = ARR[1] * random.random() * 10
        random_ARR_2_old = ARR[2] * random.random() * 10
        random_ARR_3_old = ARR[3] * random.random() * 10
        
# ogni alimento scelto dall'utente viene moltiplicato per un numero casuale compreso fra 0 e 10 (kg) 
# dichiaro random_ARR_x_old

        
        random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
        random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
        random_ARR_2_new = random_ARR_2_old * (random.random() + 0.5)
        random_ARR_3_new = random_ARR_3_old * (random.random() + 0.5)
        
# dichiaro random_ARR_x_new
        
        SOMMA_old = random_ARR_0_old + random_ARR_1_old + random_ARR_2_old + random_ARR_3_old
        DELTA_old = SOMMA_old - F_arr
        print('La somma iniziale è...')
        print(SOMMA_old)

# dichiaro SOMMA_old e DELTA_old

        SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new
        DELTA_new = SOMMA_new - F_arr
        print('La nuova somma è...')
        print(SOMMA_new)
        print('La nuova differenza è...')
        print(DELTA_new)

# dichiaro SOMMA_new e DELTA_new
        
        quantità_alimento_1 = random_ARR_0_new / ARR[0]
        quantità_alimento_2 = random_ARR_1_new / ARR[1]
        quantità_alimento_3 = random_ARR_2_new / ARR[2]
        quantità_alimento_4 = random_ARR_3_new / ARR[3]
        
# dichiaro gli apporti dei singoli alimenti

        i = 0

# inizializzo il contatore i        
        
        for i in range(N_repl):
        
            rules = [abs(DELTA_new[0]) < abs(DELTA_old[0]), abs(DELTA_new[1]) < abs(DELTA_old[1]), abs(DELTA_new[2]) < abs(DELTA_old[2])]

# dichiaro le regole da rispettare
                                    
            if all(rules):
            
                print('ESTRAGGO DALLA PROPOSAL DISTRIBUTION')
                i += 1
                print(i)
                
                                                         	               	        
                random_ARR_0_new = random_ARR_0_new * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_new * (random.random() + 0.5)
                random_ARR_2_new = random_ARR_2_new * (random.random() + 0.5)
                random_ARR_3_new = random_ARR_3_new * (random.random() + 0.5)
                
# ACCETTO random_ARR_x_new e lo uso per aggiornare random_ARR_x_new stesso 
                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0]
                print(APPORTO_TOTALE_SOSTANZA_SECCA)

# aggiorno l'apporto di SS
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new
                DELTA_new = SOMMA_new - F_arr
                
# aggiorno SOMMA_new e DELTA_new                
                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                quantità_alimento_3 = random_ARR_2_new / ARR[2]
                quantità_alimento_4 = random_ARR_3_new / ARR[3]
                
                if round(APPORTO_TOTALE_SOSTANZA_SECCA) == round(F_arr[0]):
                
                    break
                
                print(i)    
                print("SUCCESSO! L'APPORTO DI SOSTANZA SECCA CORRISPONDE AL FABBISOGNO.")

                    	                
            else:
                    
                random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
                random_ARR_2_new = random_ARR_2_old * (random.random() + 0.5)
                random_ARR_3_new = random_ARR_3_old * (random.random() + 0.5)
                
# RIFIUTO random_ARR_x_new e lo ricalcolo a partire da random_ARR_x_old 
                
                print('FALLIMENTO')
                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0]
                print(APPORTO_TOTALE_SOSTANZA_SECCA)
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new
                DELTA_new = SOMMA_new - F_arr
                                                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                quantità_alimento_3 = random_ARR_2_new / ARR[2]
                quantità_alimento_4 = random_ARR_3_new / ARR[3]
                
                        
        QUANTITÀ_TOTALE_TAL_QUALE = quantità_alimento_1[0] + quantità_alimento_2[0] + quantità_alimento_3[0] + quantità_alimento_4[0]
        APPORTO_TOTALE_PROTEINA_GREZZA = random_ARR_0_new[1] + random_ARR_1_new[1] + random_ARR_2_new[1] + random_ARR_3_new[1]
        APPORTO_TOTALE_PROTEINA_DEGRADABILE = random_ARR_0_new[2] + random_ARR_1_new[2] + random_ARR_2_new[2] + random_ARR_3_new[2]
        APPORTO_TOTALE_PROTEINA_INDEGRADABILE = random_ARR_0_new[3] + random_ARR_1_new[3] + random_ARR_2_new[3] + random_ARR_3_new[3]
        APPORTO_TOTALE_FIBRA_GREZZA = random_ARR_0_new[4] + random_ARR_1_new[4] + random_ARR_2_new[4] + random_ARR_3_new[4]
        APPORTO_TOTALE_NDF = random_ARR_0_new[5] + random_ARR_1_new[5] + random_ARR_2_new[5] + random_ARR_3_new[5]
        APPORTO_TOTALE_ADF = random_ARR_0_new[6] + random_ARR_1_new[6] + random_ARR_2_new[6] + random_ARR_3_new[6]
        APPORTO_TOTALE_GRASSO = random_ARR_0_new[7] + random_ARR_1_new[7] + random_ARR_2_new[7] + random_ARR_3_new[7]
        APPORTO_TOTALE_AMIDO = random_ARR_0_new[8] + random_ARR_1_new[8] + random_ARR_2_new[8] + random_ARR_3_new[8]
        APPORTO_TOTALE_ZUCCHERI = random_ARR_0_new[9] + random_ARR_1_new[9] + random_ARR_2_new[9] + random_ARR_3_new[9]
        APPORTO_TOTALE_Ca = random_ARR_0_new[10] + random_ARR_1_new[10] + random_ARR_2_new[10] + random_ARR_3_new[10]
        APPORTO_TOTALE_P = random_ARR_0_new[11] + random_ARR_1_new[11] + random_ARR_2_new[11] + random_ARR_3_new[11]
        APPORTO_TOTALE_UFL = random_ARR_0_new[12] + random_ARR_1_new[12] + random_ARR_2_new[12] + random_ARR_3_new[12]
        
        DELTA_SOSTANZA_SECCA = APPORTO_TOTALE_SOSTANZA_SECCA - F[0]
        DELTA_PROTEINA_GREZZA = APPORTO_TOTALE_PROTEINA_GREZZA - F[1]
        DELTA_PROTEINA_DEGRADABILE = APPORTO_TOTALE_PROTEINA_DEGRADABILE - F[2]
        DELTA_PROTEINA_INDEGRADABILE = APPORTO_TOTALE_PROTEINA_INDEGRADABILE - F[3]
        DELTA_FIBRA_GREZZA = APPORTO_TOTALE_FIBRA_GREZZA - F[4]
        DELTA_NDF = APPORTO_TOTALE_NDF - F[5]
        DELTA_ADF = APPORTO_TOTALE_ADF - F[6]
        DELTA_GRASSO = APPORTO_TOTALE_GRASSO - F[7]
        DELTA_AMIDO = APPORTO_TOTALE_AMIDO - F[8]
        DELTA_ZUCCHERI = APPORTO_TOTALE_ZUCCHERI - F[9]
        DELTA_Ca = APPORTO_TOTALE_Ca - F[10]
        DELTA_P = APPORTO_TOTALE_P - F[11]
        DELTA_UFL = APPORTO_TOTALE_UFL - F[12]

                
        original = sys.stdout
        sys.stdout = open('NUOVA_RAZIONE.txt', 'w')
        
        
        if day == 'Monday': 
            print('RAZIONE di %s, creata lunedì %s, %s' % (user, data, current_time))
        if day == 'Tuesday': 
            print('RAZIONE di %s, creata martedì %s, %s' % (user, data, current_time))
        if day == 'Wednesday': 
            print('RAZIONE di %s, creata mercoledì %s, %s' % (user, data, current_time))
        if day == 'Thursday': 
            print('RAZIONE di %s, creata giovedì %s, %s' % (user, data, current_time))
        if day == 'Friday': 
            print('RAZIONE di %s, creata venerdì %s, %s' % (user, data, current_time))
        if day == 'Saturday': 
            print('RAZIONE di %s, creata sabato %s, %s' % (user, data, current_time))
        if day == 'Sunday': 
            print('RAZIONE di %s, creata domenica %s, %s' % (user, data, current_time))
        
        
        print('')
#       print('This is your redirected text:')
        print('')
        if i == 999:
            print('Il calcolo della razione non ha avuto successo; per favore chiudi il programma e riprova.')
        else:
            print('Il calcolo della razione è stato effettuato con successo alla %d^esima replica' % i)        
#       print(i)
        print('')
        print('Il fabbisogno di SOSTANZA SECCA è di %f' %  F_arr[0])
        print('')
        print("L'apporto totale di SOSTANZA SECCA è di %f" % APPORTO_TOTALE_SOSTANZA_SECCA)
        print('')
        print('out of loop')
        print('')        
        print('LEGENDA')
        print('')
        print("DMI => Dry Matter Intake (Capacità d'ingestione di Sostanza Secca)")
        print("CPI => Crude Protein Intake (Apporto di Proteina Grezza)")
        print("RDPI => Rumen Degradable Protein Intake (Apporto di Proteina Degradabile)")
        print("RUPI => Rumen Undegradable Protein Intake (Apporto di Proteina Indegradabile)")
        print("FG => Fibra Grezza (apporto di Fibra Grezza)")
        print("NDF => Neutral Detergent Fiber (apporto di Fibra resistente al Detergente Neutro)")
        print("ADF => Acid Detergent Fiber (apporto di Fibra resistente al Detergente Acido)")
        print("FAT => Fat (apporto di Grasso)")
        print("AM => Amido (apporto di Amido)")
        print("ZUC => Zuccheri (apporto di Zuccheri)")
        print("Ca => Calcio (apporto di Calcio)")
        print("P => Fosforo (apporto di Fosforo)")
        print("UFL => Unità Foraggere Latte (apporto di Energia Netta)")
        print('DMI', 'CPI', 'RDPI', 'RUPI', 'FG', 'NDF', 'ADF', 'FAT', 'AM', 'ZUC', 'Ca', 'P', 'UFL')                	                


                                
        print('apporti di %s: \n' % S[0])
        print(random_ARR_0_new)
        print('apporti di %s: \n' % S[1])
        print(random_ARR_1_new)
        print('apporti di %s: \n' % S[2])
        print(random_ARR_2_new)
        print('apporti di %s: \n' % S[3])
        print(random_ARR_3_new)
        
                                
        print('%f kg %s' % (quantità_alimento_1[0], S[0]))
        print('%f kg %s' % (quantità_alimento_2[0], S[1]))
        print('%f kg %s' % (quantità_alimento_3[0], S[2]))
        print('%f kg %s' % (quantità_alimento_4[0], S[3]))
                        
        print('La razione fornisce %f kg di alimento tal quale' % QUANTITÀ_TOTALE_TAL_QUALE)
        print('La razione fornisce %f kg di sostanza secca' % APPORTO_TOTALE_SOSTANZA_SECCA)
        
        print("SOSTANZA SECCA: la differenza fra l'apporto totale => %f kg e la capacità d'ingestione => %f kg è: %f kg" % (APPORTO_TOTALE_SOSTANZA_SECCA, F[0], DELTA_SOSTANZA_SECCA))
        print("PROTEINA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_GREZZA, F[1], DELTA_PROTEINA_GREZZA)) 
        print("PROTEINA DEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_DEGRADABILE, F[2], DELTA_PROTEINA_DEGRADABILE))
        print("PROTEINA INDEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_INDEGRADABILE, F[3], DELTA_PROTEINA_INDEGRADABILE))
        print("FIBRA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_FIBRA_GREZZA, F[4], DELTA_FIBRA_GREZZA))
        print("NDF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_NDF, F[5], DELTA_NDF))
        print("ADF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ADF, F[6], DELTA_ADF))
        print("GRASSO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_GRASSO, F[7], DELTA_GRASSO)) 
        print("AMIDO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_AMIDO, F[8], DELTA_AMIDO))
        print("ZUCCHERI: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ZUCCHERI, F[9], DELTA_ZUCCHERI))
        print("Ca: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_Ca, F[10], DELTA_Ca))
        print("P: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_P, F[11], DELTA_P))
        print("UFL: la differenza fra l'apporto totale => %f UFL e il fabbisogno => %f UFL è: %f UFL" % (APPORTO_TOTALE_UFL, F[12], DELTA_UFL))
        
        sys.stdout = original
        print('This string goes to stdout, NOT the file!')

        
                                        

    elif len(S) == 5: 
        print(S[0])
        print(S[1])
        print(S[2])
        print(S[3])
        print(S[4])
        print(ARR[0])
        print(ARR[1])
        print(ARR[2])
        print(ARR[3])
        print(ARR[4])
        
        print('Hai inserito 5 alimenti \n')
        
#       print("QUESTA È LA VERSIONE CORRETTA DELL'ALGORITMO")
        
        random_ARR_0_old = ARR[0] * random.random() * 10
        random_ARR_1_old = ARR[1] * random.random() * 10
        random_ARR_2_old = ARR[2] * random.random() * 10
        random_ARR_3_old = ARR[3] * random.random() * 10
        random_ARR_4_old = ARR[4] * random.random() * 10
        
# ogni alimento scelto dall'utente viene moltiplicato per un numero casuale compreso fra 0 e 10 (kg) 
# dichiaro random_ARR_x_old

        
        random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
        random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
        random_ARR_2_new = random_ARR_2_old * (random.random() + 0.5)
        random_ARR_3_new = random_ARR_3_old * (random.random() + 0.5)
        random_ARR_4_new = random_ARR_4_old * (random.random() + 0.5)
        
# dichiaro random_ARR_x_new
        
        SOMMA_old = random_ARR_0_old + random_ARR_1_old + random_ARR_2_old + random_ARR_3_old + random_ARR_4_old
        DELTA_old = SOMMA_old - F_arr
        print('La somma iniziale è...')
        print(SOMMA_old)

# dichiaro SOMMA_old e DELTA_old

        SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new
        DELTA_new = SOMMA_new - F_arr
        print('La nuova somma è...')
        print(SOMMA_new)
        print('La nuova differenza è...')
        print(DELTA_new)

# dichiaro SOMMA_new e DELTA_new
        
        quantità_alimento_1 = random_ARR_0_new / ARR[0]
        quantità_alimento_2 = random_ARR_1_new / ARR[1]
        quantità_alimento_3 = random_ARR_2_new / ARR[2]
        quantità_alimento_4 = random_ARR_3_new / ARR[3]
        quantità_alimento_5 = random_ARR_4_new / ARR[4]
        
# dichiaro gli apporti dei singoli alimenti

# dichiaro gli apporti dei singoli alimenti

        i = 0

# inizializzo il contatore i        
        
        for i in range(N_repl):
        
            rules = [abs(DELTA_new[0]) < abs(DELTA_old[0]), abs(DELTA_new[1]) < abs(DELTA_old[1]), abs(DELTA_new[2]) < abs(DELTA_old[2])]

# dichiaro le regole da rispettare
                                    
            if all(rules):
            
                print('ESTRAGGO DALLA PROPOSAL DISTRIBUTION')
                i += 1
                print(i)
                                                         	               	        
                random_ARR_0_new = random_ARR_0_new * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_new * (random.random() + 0.5)
                random_ARR_2_new = random_ARR_2_new * (random.random() + 0.5)
                random_ARR_3_new = random_ARR_3_new * (random.random() + 0.5)
                random_ARR_4_new = random_ARR_4_new * (random.random() + 0.5)
                
# ACCETTO random_ARR_x_new e lo uso per aggiornare random_ARR_x_new stesso 
                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0]
                print(APPORTO_TOTALE_SOSTANZA_SECCA)

# aggiorno l'apporto di SS
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new
                DELTA_new = SOMMA_new - F_arr
                
# aggiorno SOMMA_new e DELTA_new                
                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                quantità_alimento_3 = random_ARR_2_new / ARR[2]
                quantità_alimento_4 = random_ARR_3_new / ARR[3]
                quantità_alimento_5 = random_ARR_4_new / ARR[4]
                
                if round(APPORTO_TOTALE_SOSTANZA_SECCA) == round(F_arr[0]):
                
                    break
                
                print(i)    
                print("SUCCESSO! L'APPORTO DI SOSTANZA SECCA CORRISPONDE AL FABBISOGNO.")

                    	                
            else:
                    
                random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
                random_ARR_2_new = random_ARR_2_old * (random.random() + 0.5)
                random_ARR_3_new = random_ARR_3_old * (random.random() + 0.5)
                random_ARR_4_new = random_ARR_4_old * (random.random() + 0.5)
                
# RIFIUTO random_ARR_x_new e lo ricalcolo a partire da random_ARR_x_old 
                
                print('FALLIMENTO')
                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0]
                print(APPORTO_TOTALE_SOSTANZA_SECCA)
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new
                DELTA_new = SOMMA_new - F_arr
                                                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                quantità_alimento_3 = random_ARR_2_new / ARR[2]
                quantità_alimento_4 = random_ARR_3_new / ARR[3]
                quantità_alimento_5 = random_ARR_4_new / ARR[4]
                
                                                
                
        QUANTITÀ_TOTALE_TAL_QUALE = quantità_alimento_1[0] + quantità_alimento_2[0] + quantità_alimento_3[0] + quantità_alimento_4[0] + quantità_alimento_5[0] 
        APPORTO_TOTALE_PROTEINA_GREZZA = random_ARR_0_new[1] + random_ARR_1_new[1] + random_ARR_2_new[1] + random_ARR_3_new[1] + random_ARR_4_new[1]
        APPORTO_TOTALE_PROTEINA_DEGRADABILE = random_ARR_0_new[2] + random_ARR_1_new[2] + random_ARR_2_new[2] + random_ARR_3_new[2] + random_ARR_4_new[2]
        APPORTO_TOTALE_PROTEINA_INDEGRADABILE = random_ARR_0_new[3] + random_ARR_1_new[3] + random_ARR_2_new[3] + random_ARR_3_new[3] + random_ARR_4_new[3]
        APPORTO_TOTALE_FIBRA_GREZZA = random_ARR_0_new[4] + random_ARR_1_new[4] + random_ARR_2_new[4] + random_ARR_3_new[4] + random_ARR_4_new[4]
        APPORTO_TOTALE_NDF = random_ARR_0_new[5] + random_ARR_1_new[5] + random_ARR_2_new[5] + random_ARR_3_new[5] + random_ARR_4_new[5]
        APPORTO_TOTALE_ADF = random_ARR_0_new[6] + random_ARR_1_new[6] + random_ARR_2_new[6] + random_ARR_3_new[6] + random_ARR_4_new[6]
        APPORTO_TOTALE_GRASSO = random_ARR_0_new[7] + random_ARR_1_new[7] + random_ARR_2_new[7] + random_ARR_3_new[7] + random_ARR_4_new[7]
        APPORTO_TOTALE_AMIDO = random_ARR_0_new[8] + random_ARR_1_new[8] + random_ARR_2_new[8] + random_ARR_3_new[8] + random_ARR_4_new[8]
        APPORTO_TOTALE_ZUCCHERI = random_ARR_0_new[9] + random_ARR_1_new[9] + random_ARR_2_new[9] + random_ARR_3_new[9] + random_ARR_4_new[9]
        APPORTO_TOTALE_Ca = random_ARR_0_new[10] + random_ARR_1_new[10] + random_ARR_2_new[10] + random_ARR_3_new[10] + random_ARR_4_new[10]
        APPORTO_TOTALE_P = random_ARR_0_new[11] + random_ARR_1_new[11] + random_ARR_2_new[11] + random_ARR_3_new[11] + random_ARR_4_new[11]
        APPORTO_TOTALE_UFL = random_ARR_0_new[12] + random_ARR_1_new[12] + random_ARR_2_new[12] + random_ARR_3_new[12] + random_ARR_4_new[12]

        
        DELTA_SOSTANZA_SECCA = APPORTO_TOTALE_SOSTANZA_SECCA - F[0]
        DELTA_PROTEINA_GREZZA = APPORTO_TOTALE_PROTEINA_GREZZA - F[1]
        DELTA_PROTEINA_DEGRADABILE = APPORTO_TOTALE_PROTEINA_DEGRADABILE - F[2]
        DELTA_PROTEINA_INDEGRADABILE = APPORTO_TOTALE_PROTEINA_INDEGRADABILE - F[3]
        DELTA_FIBRA_GREZZA = APPORTO_TOTALE_FIBRA_GREZZA - F[4]
        DELTA_NDF = APPORTO_TOTALE_NDF - F[5]
        DELTA_ADF = APPORTO_TOTALE_ADF - F[6]
        DELTA_GRASSO = APPORTO_TOTALE_GRASSO - F[7]
        DELTA_AMIDO = APPORTO_TOTALE_AMIDO - F[8]
        DELTA_ZUCCHERI = APPORTO_TOTALE_ZUCCHERI - F[9]
        DELTA_Ca = APPORTO_TOTALE_Ca - F[10]
        DELTA_P = APPORTO_TOTALE_P - F[11]
        DELTA_UFL = APPORTO_TOTALE_UFL - F[12]

                
        original = sys.stdout
        sys.stdout = open('NUOVA_RAZIONE.txt', 'w')
        
        
        if day == 'Monday': 
            print('RAZIONE di %s, creata lunedì %s, %s' % (user, data, current_time))
        if day == 'Tuesday': 
            print('RAZIONE di %s, creata martedì %s, %s' % (user, data, current_time))
        if day == 'Wednesday': 
            print('RAZIONE di %s, creata mercoledì %s, %s' % (user, data, current_time))
        if day == 'Thursday': 
            print('RAZIONE di %s, creata giovedì %s, %s' % (user, data, current_time))
        if day == 'Friday': 
            print('RAZIONE di %s, creata venerdì %s, %s' % (user, data, current_time))
        if day == 'Saturday': 
            print('RAZIONE di %s, creata sabato %s, %s' % (user, data, current_time))
        if day == 'Sunday': 
            print('RAZIONE di %s, creata domenica %s, %s' % (user, data, current_time))
        
        
        print('')
#       print('This is your redirected text:')
        print('')
        if i == 999:
            print('Il calcolo della razione non ha avuto successo; per favore chiudi il programma e riprova.')
        else:
            print('Il calcolo della razione è stato effettuato con successo alla %d^esima replica' % i)        
#       print(i)
        print('')
        print('Il fabbisogno di SOSTANZA SECCA è di %f' %  F_arr[0])
        print('')
        print("L'apporto totale di SOSTANZA SECCA è di %f" % APPORTO_TOTALE_SOSTANZA_SECCA)
        print('')
        print('out of loop')
        print('')        
        print('LEGENDA')
        print('')
        print("DMI => Dry Matter Intake (Capacità d'ingestione di Sostanza Secca)")
        print("CPI => Crude Protein Intake (Apporto di Proteina Grezza)")
        print("RDPI => Rumen Degradable Protein Intake (Apporto di Proteina Degradabile)")
        print("RUPI => Rumen Undegradable Protein Intake (Apporto di Proteina Indegradabile)")
        print("FG => Fibra Grezza (apporto di Fibra Grezza)")
        print("NDF => Neutral Detergent Fiber (apporto di Fibra resistente al Detergente Neutro)")
        print("ADF => Acid Detergent Fiber (apporto di Fibra resistente al Detergente Acido)")
        print("FAT => Fat (apporto di Grasso)")
        print("AM => Amido (apporto di Amido)")
        print("ZUC => Zuccheri (apporto di Zuccheri)")
        print("Ca => Calcio (apporto di Calcio)")
        print("P => Fosforo (apporto di Fosforo)")
        print("UFL => Unità Foraggere Latte (apporto di Energia Netta)")
        print('DMI', 'CPI', 'RDPI', 'RUPI', 'FG', 'NDF', 'ADF', 'FAT', 'AM', 'ZUC', 'Ca', 'P', 'UFL')                	                

                                
        print('apporti di %s: \n' % S[0])
        print(random_ARR_0_new)
        print('apporti di %s: \n' % S[1])
        print(random_ARR_1_new)
        print('apporti di %s: \n' % S[2])
        print(random_ARR_2_new)
        print('apporti di %s: \n' % S[3])
        print(random_ARR_3_new)
        print('apporti di %s: \n' % S[4])
        print(random_ARR_4_new)
        
                                
        print('%f kg %s' % (quantità_alimento_1[0], S[0]))
        print('%f kg %s' % (quantità_alimento_2[0], S[1]))
        print('%f kg %s' % (quantità_alimento_3[0], S[2]))
        print('%f kg %s' % (quantità_alimento_4[0], S[3]))
        print('%f kg %s' % (quantità_alimento_5[0], S[4]))
                        
        print('La razione fornisce %f kg di alimento tal quale' % QUANTITÀ_TOTALE_TAL_QUALE)
        print('La razione fornisce %f kg di sostanza secca' % APPORTO_TOTALE_SOSTANZA_SECCA)
        
        print("SOSTANZA SECCA: la differenza fra l'apporto totale => %f kg e la capacità d'ingestione => %f kg è: %f kg" % (APPORTO_TOTALE_SOSTANZA_SECCA, F[0], DELTA_SOSTANZA_SECCA))
        print("PROTEINA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_GREZZA, F[1], DELTA_PROTEINA_GREZZA)) 
        print("PROTEINA DEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_DEGRADABILE, F[2], DELTA_PROTEINA_DEGRADABILE))
        print("PROTEINA INDEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_INDEGRADABILE, F[3], DELTA_PROTEINA_INDEGRADABILE))
        print("FIBRA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_FIBRA_GREZZA, F[4], DELTA_FIBRA_GREZZA))
        print("NDF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_NDF, F[5], DELTA_NDF))
        print("ADF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ADF, F[6], DELTA_ADF))
        print("GRASSO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_GRASSO, F[7], DELTA_GRASSO)) 
        print("AMIDO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_AMIDO, F[8], DELTA_AMIDO))
        print("ZUCCHERI: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ZUCCHERI, F[9], DELTA_ZUCCHERI))
        print("Ca: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_Ca, F[10], DELTA_Ca))
        print("P: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_P, F[11], DELTA_P))
        print("UFL: la differenza fra l'apporto totale => %f UFL e il fabbisogno => %f UFL è: %f UFL" % (APPORTO_TOTALE_UFL, F[12], DELTA_UFL))
        
        sys.stdout = original
        print('This string goes to stdout, NOT the file!')

        

                    
    elif len(S) == 6: 
        print(S[0])
        print(S[1])
        print(S[2])
        print(S[3])
        print(S[4])
        print(S[5])
        print(ARR[0])
        print(ARR[1])
        print(ARR[2])
        print(ARR[3])
        print(ARR[4])
        print(ARR[5])
        
        print('Hai inserito 6 alimenti \n')
        
#       print("QUESTA È LA VERSIONE CORRETTA DELL'ALGORITMO")
        
        random_ARR_0_old = ARR[0] * random.random() * 10
        random_ARR_1_old = ARR[1] * random.random() * 10
        random_ARR_2_old = ARR[2] * random.random() * 10
        random_ARR_3_old = ARR[3] * random.random() * 10
        random_ARR_4_old = ARR[4] * random.random() * 10
        random_ARR_5_old = ARR[5] * random.random() * 10
        

# ogni alimento scelto dall'utente viene moltiplicato per un numero casuale compreso fra 0 e 10 (kg) 
# dichiaro random_ARR_x_old

        
        random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
        random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
        random_ARR_2_new = random_ARR_2_old * (random.random() + 0.5)
        random_ARR_3_new = random_ARR_3_old * (random.random() + 0.5)
        random_ARR_4_new = random_ARR_4_old * (random.random() + 0.5)
        random_ARR_5_new = random_ARR_5_old * (random.random() + 0.5)
        

# dichiaro random_ARR_x_new
        
        SOMMA_old = random_ARR_0_old + random_ARR_1_old + random_ARR_2_old + random_ARR_3_old + random_ARR_4_old + random_ARR_5_old
        DELTA_old = SOMMA_old - F_arr
        print('La somma iniziale è...')
        print(SOMMA_old)

# dichiaro SOMMA_old e DELTA_old

        SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new + random_ARR_5_new
        DELTA_new = SOMMA_new - F_arr
        print('La nuova somma è...')
        print(SOMMA_new)
        print('La nuova differenza è...')
        print(DELTA_new)

# dichiaro SOMMA_new e DELTA_new
        
        quantità_alimento_1 = random_ARR_0_new / ARR[0]
        quantità_alimento_2 = random_ARR_1_new / ARR[1]
        quantità_alimento_3 = random_ARR_2_new / ARR[2]
        quantità_alimento_4 = random_ARR_3_new / ARR[3]
        quantità_alimento_5 = random_ARR_4_new / ARR[4]
        quantità_alimento_6 = random_ARR_5_new / ARR[5]
        

# dichiaro gli apporti dei singoli alimenti

        i = 0

# inizializzo il contatore i        
        
        for i in range(N_repl):
        
            rules = [abs(DELTA_new[0]) < abs(DELTA_old[0]), abs(DELTA_new[1]) < abs(DELTA_old[1]), abs(DELTA_new[2]) < abs(DELTA_old[2])]

# dichiaro le regole da rispettare
                                    
            if all(rules):
            
                print('ESTRAGGO DALLA PROPOSAL DISTRIBUTION')
                i += 1
                print(i)
                                                         	               	        
                random_ARR_0_new = random_ARR_0_new * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_new * (random.random() + 0.5)
                random_ARR_2_new = random_ARR_2_new * (random.random() + 0.5)
                random_ARR_3_new = random_ARR_3_new * (random.random() + 0.5)
                random_ARR_4_new = random_ARR_4_new * (random.random() + 0.5)
                random_ARR_5_new = random_ARR_5_new * (random.random() + 0.5)
                

# ACCETTO random_ARR_x_new e lo uso per aggiornare random_ARR_x_new stesso 
                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0]
                print(APPORTO_TOTALE_SOSTANZA_SECCA)

# aggiorno l'apporto di SS
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new + random_ARR_5_new
                DELTA_new = SOMMA_new - F_arr
                
# aggiorno SOMMA_new e DELTA_new                
                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                quantità_alimento_3 = random_ARR_2_new / ARR[2]
                quantità_alimento_4 = random_ARR_3_new / ARR[3]
                quantità_alimento_5 = random_ARR_4_new / ARR[4]
                quantità_alimento_6 = random_ARR_5_new / ARR[5]

                
                if round(APPORTO_TOTALE_SOSTANZA_SECCA) == round(F_arr[0]):
                
                    break
                
                print(i)    
                print("SUCCESSO! L'APPORTO DI SOSTANZA SECCA CORRISPONDE AL FABBISOGNO.")

                    
                    	                
            else:
                    
                random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
                random_ARR_2_new = random_ARR_2_old * (random.random() + 0.5)
                random_ARR_3_new = random_ARR_3_old * (random.random() + 0.5)
                random_ARR_4_new = random_ARR_4_old * (random.random() + 0.5)
                random_ARR_5_new = random_ARR_5_old * (random.random() + 0.5)
                

# RIFIUTO random_ARR_x_new e lo ricalcolo a partire da random_ARR_x_old 
                
                print('FALLIMENTO')
                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0]
                print(APPORTO_TOTALE_SOSTANZA_SECCA)
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new + random_ARR_5_new
                DELTA_new = SOMMA_new - F_arr
                                                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                quantità_alimento_3 = random_ARR_2_new / ARR[2]
                quantità_alimento_4 = random_ARR_3_new / ARR[3]
                quantità_alimento_5 = random_ARR_4_new / ARR[4]
                quantità_alimento_6 = random_ARR_5_new / ARR[5]
                

                
        QUANTITÀ_TOTALE_TAL_QUALE = quantità_alimento_1[0] + quantità_alimento_2[0] + quantità_alimento_3[0] + quantità_alimento_4[0] + quantità_alimento_5[0] + quantità_alimento_6[0] 
        APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0]
        APPORTO_TOTALE_PROTEINA_GREZZA = random_ARR_0_new[1] + random_ARR_1_new[1] + random_ARR_2_new[1] + random_ARR_3_new[1] + random_ARR_4_new[1] + random_ARR_5_new[1]
        APPORTO_TOTALE_PROTEINA_DEGRADABILE = random_ARR_0_new[2] + random_ARR_1_new[2] + random_ARR_2_new[2] + random_ARR_3_new[2] + random_ARR_4_new[2] + random_ARR_5_new[2]
        APPORTO_TOTALE_PROTEINA_INDEGRADABILE = random_ARR_0_new[3] + random_ARR_1_new[3] + random_ARR_2_new[3] + random_ARR_3_new[3] + random_ARR_4_new[3] + random_ARR_5_new[3]
        APPORTO_TOTALE_FIBRA_GREZZA = random_ARR_0_new[4] + random_ARR_1_new[4] + random_ARR_2_new[4] + random_ARR_3_new[4] + random_ARR_4_new[4] + random_ARR_5_new[4]
        APPORTO_TOTALE_NDF = random_ARR_0_new[5] + random_ARR_1_new[5] + random_ARR_2_new[5] + random_ARR_3_new[5] + random_ARR_4_new[5] + random_ARR_5_new[5]
        APPORTO_TOTALE_ADF = random_ARR_0_new[6] + random_ARR_1_new[6] + random_ARR_2_new[6] + random_ARR_3_new[6] + random_ARR_4_new[6] + random_ARR_5_new[6]
        APPORTO_TOTALE_GRASSO = random_ARR_0_new[7] + random_ARR_1_new[7] + random_ARR_2_new[7] + random_ARR_3_new[7] + random_ARR_4_new[7] + random_ARR_5_new[7]
        APPORTO_TOTALE_AMIDO = random_ARR_0_new[8] + random_ARR_1_new[8] + random_ARR_2_new[8] + random_ARR_3_new[8] + random_ARR_4_new[8] + random_ARR_5_new[8]
        APPORTO_TOTALE_ZUCCHERI = random_ARR_0_new[9] + random_ARR_1_new[9] + random_ARR_2_new[9] + random_ARR_3_new[9] + random_ARR_4_new[9] + random_ARR_5_new[9]
        APPORTO_TOTALE_Ca = random_ARR_0_new[10] + random_ARR_1_new[10] + random_ARR_2_new[10] + random_ARR_3_new[10] + random_ARR_4_new[10] + random_ARR_5_new[10]
        APPORTO_TOTALE_P = random_ARR_0_new[11] + random_ARR_1_new[11] + random_ARR_2_new[11] + random_ARR_3_new[11] + random_ARR_4_new[11] + random_ARR_5_new[11]
        APPORTO_TOTALE_UFL = random_ARR_0_new[12] + random_ARR_1_new[12] + random_ARR_2_new[12] + random_ARR_3_new[12] + random_ARR_4_new[12] + random_ARR_5_new[12]
        
        DELTA_SOSTANZA_SECCA = APPORTO_TOTALE_SOSTANZA_SECCA - F[0]
        DELTA_PROTEINA_GREZZA = APPORTO_TOTALE_PROTEINA_GREZZA - F[1]
        DELTA_PROTEINA_DEGRADABILE = APPORTO_TOTALE_PROTEINA_DEGRADABILE - F[2]
        DELTA_PROTEINA_INDEGRADABILE = APPORTO_TOTALE_PROTEINA_INDEGRADABILE - F[3]
        DELTA_FIBRA_GREZZA = APPORTO_TOTALE_FIBRA_GREZZA - F[4]
        DELTA_NDF = APPORTO_TOTALE_NDF - F[5]
        DELTA_ADF = APPORTO_TOTALE_ADF - F[6]
        DELTA_GRASSO = APPORTO_TOTALE_GRASSO - F[7]
        DELTA_AMIDO = APPORTO_TOTALE_AMIDO - F[8]
        DELTA_ZUCCHERI = APPORTO_TOTALE_ZUCCHERI - F[9]
        DELTA_Ca = APPORTO_TOTALE_Ca - F[10]
        DELTA_P = APPORTO_TOTALE_P - F[11]
        DELTA_UFL = APPORTO_TOTALE_UFL - F[12]

                
        original = sys.stdout
        sys.stdout = open('NUOVA_RAZIONE.txt', 'w')
        
        
        if day == 'Monday': 
            print('RAZIONE di %s, creata lunedì %s, %s' % (user, data, current_time))
        if day == 'Tuesday': 
            print('RAZIONE di %s, creata martedì %s, %s' % (user, data, current_time))
        if day == 'Wednesday': 
            print('RAZIONE di %s, creata mercoledì %s, %s' % (user, data, current_time))
        if day == 'Thursday': 
            print('RAZIONE di %s, creata giovedì %s, %s' % (user, data, current_time))
        if day == 'Friday': 
            print('RAZIONE di %s, creata venerdì %s, %s' % (user, data, current_time))
        if day == 'Saturday': 
            print('RAZIONE di %s, creata sabato %s, %s' % (user, data, current_time))
        if day == 'Sunday': 
            print('RAZIONE di %s, creata domenica %s, %s' % (user, data, current_time))
        
        
        print('')
#       print('This is your redirected text:')
        print('')
        if i == 999:
            print('Il calcolo della razione non ha avuto successo; per favore chiudi il programma e riprova.')
        else:
            print('Il calcolo della razione è stato effettuato con successo alla %d^esima replica' % i)        
#       print(i)
        print('')
        print('Il fabbisogno di SOSTANZA SECCA è di %f' %  F_arr[0])
        print('')
        print("L'apporto totale di SOSTANZA SECCA è di %f" % APPORTO_TOTALE_SOSTANZA_SECCA)
        print('')
        print('out of loop')
        print('')        
        print('LEGENDA')
        print('')
        print("DMI => Dry Matter Intake (Capacità d'ingestione di Sostanza Secca)")
        print("CPI => Crude Protein Intake (Apporto di Proteina Grezza)")
        print("RDPI => Rumen Degradable Protein Intake (Apporto di Proteina Degradabile)")
        print("RUPI => Rumen Undegradable Protein Intake (Apporto di Proteina Indegradabile)")
        print("FG => Fibra Grezza (apporto di Fibra Grezza)")
        print("NDF => Neutral Detergent Fiber (apporto di Fibra resistente al Detergente Neutro)")
        print("ADF => Acid Detergent Fiber (apporto di Fibra resistente al Detergente Acido)")
        print("FAT => Fat (apporto di Grasso)")
        print("AM => Amido (apporto di Amido)")
        print("ZUC => Zuccheri (apporto di Zuccheri)")
        print("Ca => Calcio (apporto di Calcio)")
        print("P => Fosforo (apporto di Fosforo)")
        print("UFL => Unità Foraggere Latte (apporto di Energia Netta)")
        print('DMI', 'CPI', 'RDPI', 'RUPI', 'FG', 'NDF', 'ADF', 'FAT', 'AM', 'ZUC', 'Ca', 'P', 'UFL')                	                

                                
        print('apporti di %s: \n' % S[0])
        print(random_ARR_0_new)
        print('apporti di %s: \n' % S[1])
        print(random_ARR_1_new)
        print('apporti di %s: \n' % S[2])
        print(random_ARR_2_new)
        print('apporti di %s: \n' % S[3])
        print(random_ARR_3_new)
        print('apporti di %s: \n' % S[4])
        print(random_ARR_4_new)
        print('apporti di %s: \n' % S[5])
        print(random_ARR_5_new)
                
                                
        print('%f kg %s' % (quantità_alimento_1[0], S[0]))
        print('%f kg %s' % (quantità_alimento_2[0], S[1]))
        print('%f kg %s' % (quantità_alimento_3[0], S[2]))
        print('%f kg %s' % (quantità_alimento_4[0], S[3]))
        print('%f kg %s' % (quantità_alimento_5[0], S[4]))
        print('%f kg %s' % (quantità_alimento_6[0], S[5]))
        
                
        print('La razione fornisce %f kg di alimento tal quale' % QUANTITÀ_TOTALE_TAL_QUALE)
        print('La razione fornisce %f kg di sostanza secca' % APPORTO_TOTALE_SOSTANZA_SECCA)
        
        print("SOSTANZA SECCA: la differenza fra l'apporto totale => %f kg e la capacità d'ingestione => %f kg è: %f kg" % (APPORTO_TOTALE_SOSTANZA_SECCA, F[0], DELTA_SOSTANZA_SECCA))
        print("PROTEINA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_GREZZA, F[1], DELTA_PROTEINA_GREZZA)) 
        print("PROTEINA DEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_DEGRADABILE, F[2], DELTA_PROTEINA_DEGRADABILE))
        print("PROTEINA INDEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_INDEGRADABILE, F[3], DELTA_PROTEINA_INDEGRADABILE))
        print("FIBRA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_FIBRA_GREZZA, F[4], DELTA_FIBRA_GREZZA))
        print("NDF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_NDF, F[5], DELTA_NDF))
        print("ADF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ADF, F[6], DELTA_ADF))
        print("GRASSO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_GRASSO, F[7], DELTA_GRASSO)) 
        print("AMIDO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_AMIDO, F[8], DELTA_AMIDO))
        print("ZUCCHERI: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ZUCCHERI, F[9], DELTA_ZUCCHERI))
        print("Ca: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_Ca, F[10], DELTA_Ca))
        print("P: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_P, F[11], DELTA_P))
        print("UFL: la differenza fra l'apporto totale => %f UFL e il fabbisogno => %f UFL è: %f UFL" % (APPORTO_TOTALE_UFL, F[12], DELTA_UFL))
        
        sys.stdout = original
        print('This string goes to stdout, NOT the file!')

        

        
    elif len(S) == 7: 
        print(S[0])
        print(S[1])
        print(S[2])
        print(S[3])
        print(S[4])
        print(S[5])
        print(S[6])
        print(ARR[0])
        print(ARR[1])
        print(ARR[2])
        print(ARR[3])
        print(ARR[4])
        print(ARR[5])
        print(ARR[6])
        
        print('Hai inserito 7 alimenti \n')
#       print("QUESTA È LA VERSIONE CORRETTA DELL'ALGORITMO")
        
        random_ARR_0_old = ARR[0] * random.random() * 10
        random_ARR_1_old = ARR[1] * random.random() * 10
        random_ARR_2_old = ARR[2] * random.random() * 10
        random_ARR_3_old = ARR[3] * random.random() * 10
        random_ARR_4_old = ARR[4] * random.random() * 10
        random_ARR_5_old = ARR[5] * random.random() * 10
        random_ARR_6_old = ARR[6] * random.random() * 10

# ogni alimento scelto dall'utente viene moltiplicato per un numero casuale compreso fra 0 e 10 (kg) 
# dichiaro random_ARR_x_old

        
        random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
        random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
        random_ARR_2_new = random_ARR_2_old * (random.random() + 0.5)
        random_ARR_3_new = random_ARR_3_old * (random.random() + 0.5)
        random_ARR_4_new = random_ARR_4_old * (random.random() + 0.5)
        random_ARR_5_new = random_ARR_5_old * (random.random() + 0.5)
        random_ARR_6_new = random_ARR_6_old * (random.random() + 0.5)

# dichiaro random_ARR_x_new
        
        APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0] + random_ARR_6_new[0]

# dichiaro APPORTO_TOTALE_SOSTANZA_SECCA

        
        SOMMA_old = random_ARR_0_old + random_ARR_1_old + random_ARR_2_old + random_ARR_3_old + random_ARR_4_old + random_ARR_5_old + random_ARR_6_old
        DELTA_old = SOMMA_old - F_arr
        print('La somma iniziale è...')
        print(SOMMA_old)

# dichiaro SOMMA_old e DELTA_old

        SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new + random_ARR_5_new + random_ARR_6_new
        DELTA_new = SOMMA_new - F_arr
        print('La nuova somma è...')
        print(SOMMA_new)
        print('La nuova differenza è...')
        print(DELTA_new)

# dichiaro SOMMA_new e DELTA_new
        
        quantità_alimento_1 = random_ARR_0_new / ARR[0]
        quantità_alimento_2 = random_ARR_1_new / ARR[1]
        quantità_alimento_3 = random_ARR_2_new / ARR[2]
        quantità_alimento_4 = random_ARR_3_new / ARR[3]
        quantità_alimento_5 = random_ARR_4_new / ARR[4]
        quantità_alimento_6 = random_ARR_5_new / ARR[5]
        quantità_alimento_7 = random_ARR_6_new / ARR[6]

# dichiaro gli apporti dei singoli alimenti

        i = 0

# inizializzo il contatore i        
        
        for i in range(N_repl):
        
            rules = [abs(DELTA_new[0]) < abs(DELTA_old[0]), abs(DELTA_new[1]) < abs(DELTA_old[1]), abs(DELTA_new[2]) < abs(DELTA_old[2])]

# dichiaro le regole da rispettare
                                    
            if all(rules):
            
                print('ESTRAGGO DALLA PROPOSAL DISTRIBUTION')
                i += 1
                print(i)
                                                                                                             	            
                random_ARR_0_new = random_ARR_0_new * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_new * (random.random() + 0.5)
                random_ARR_2_new = random_ARR_2_new * (random.random() + 0.5)
                random_ARR_3_new = random_ARR_3_new * (random.random() + 0.5)
                random_ARR_4_new = random_ARR_4_new * (random.random() + 0.5)
                random_ARR_5_new = random_ARR_5_new * (random.random() + 0.5)
                random_ARR_6_new = random_ARR_6_new * (random.random() + 0.5)

# ACCETTO random_ARR_x_new e lo uso per aggiornare random_ARR_x_new stesso 
                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0] + random_ARR_6_new[0]

# aggiorno l'apporto di SS
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new + random_ARR_5_new + random_ARR_6_new
                DELTA_new = SOMMA_new - F_arr
                
# aggiorno SOMMA_new e DELTA_new                
                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                quantità_alimento_3 = random_ARR_2_new / ARR[2]
                quantità_alimento_4 = random_ARR_3_new / ARR[3]
                quantità_alimento_5 = random_ARR_4_new / ARR[4]
                quantità_alimento_6 = random_ARR_5_new / ARR[5]
                quantità_alimento_7 = random_ARR_6_new / ARR[6]
                
                if round(APPORTO_TOTALE_SOSTANZA_SECCA) == round(F_arr[0]):
                
                    break
                
                print(i)    
                print("SUCCESSO! L'APPORTO DI SOSTANZA SECCA CORRISPONDE AL FABBISOGNO.")


            else:
            
                random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
                random_ARR_2_new = random_ARR_2_old * (random.random() + 0.5)
                random_ARR_3_new = random_ARR_3_old * (random.random() + 0.5)
                random_ARR_4_new = random_ARR_4_old * (random.random() + 0.5)
                random_ARR_5_new = random_ARR_5_old * (random.random() + 0.5)
                random_ARR_6_new = random_ARR_6_old * (random.random() + 0.5)

# RIFIUTO random_ARR_x_new e lo ricalcolo a partire da random_ARR_x_old 
                
                print('FALLIMENTO')
                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0] + random_ARR_6_new[0]
                print(APPORTO_TOTALE_SOSTANZA_SECCA)
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new + random_ARR_5_new + random_ARR_6_new
                DELTA_new = SOMMA_new - F_arr
                                                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                quantità_alimento_3 = random_ARR_2_new / ARR[2]
                quantità_alimento_4 = random_ARR_3_new / ARR[3]
                quantità_alimento_5 = random_ARR_4_new / ARR[4]
                quantità_alimento_6 = random_ARR_5_new / ARR[5]
                quantità_alimento_7 = random_ARR_6_new / ARR[6]

        
        
        QUANTITÀ_TOTALE_TAL_QUALE = quantità_alimento_1[0] + quantità_alimento_2[0] + quantità_alimento_3[0] + quantità_alimento_4[0] + quantità_alimento_5[0] + quantità_alimento_6[0] + quantità_alimento_7[0] 
        APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0] + random_ARR_6_new[0]
        APPORTO_TOTALE_PROTEINA_GREZZA = random_ARR_0_new[1] + random_ARR_1_new[1] + random_ARR_2_new[1] + random_ARR_3_new[1] + random_ARR_4_new[1] + random_ARR_5_new[1] + random_ARR_6_new[1]
        APPORTO_TOTALE_PROTEINA_DEGRADABILE = random_ARR_0_new[2] + random_ARR_1_new[2] + random_ARR_2_new[2] + random_ARR_3_new[2] + random_ARR_4_new[2] + random_ARR_5_new[2] + random_ARR_6_new[2]
        APPORTO_TOTALE_PROTEINA_INDEGRADABILE = random_ARR_0_new[3] + random_ARR_1_new[3] + random_ARR_2_new[3] + random_ARR_3_new[3] + random_ARR_4_new[3] + random_ARR_5_new[3] + random_ARR_6_new[3]
        APPORTO_TOTALE_FIBRA_GREZZA = random_ARR_0_new[4] + random_ARR_1_new[4] + random_ARR_2_new[4] + random_ARR_3_new[4] + random_ARR_4_new[4] + random_ARR_5_new[4] + random_ARR_6_new[4]
        APPORTO_TOTALE_NDF = random_ARR_0_new[5] + random_ARR_1_new[5] + random_ARR_2_new[5] + random_ARR_3_new[5] + random_ARR_4_new[5] + random_ARR_5_new[5] + random_ARR_6_new[5]
        APPORTO_TOTALE_ADF = random_ARR_0_new[6] + random_ARR_1_new[6] + random_ARR_2_new[6] + random_ARR_3_new[6] + random_ARR_4_new[6] + random_ARR_5_new[6] + random_ARR_6_new[6]
        APPORTO_TOTALE_GRASSO = random_ARR_0_new[7] + random_ARR_1_new[7] + random_ARR_2_new[7] + random_ARR_3_new[7] + random_ARR_4_new[7] + random_ARR_5_new[7] + random_ARR_6_new[7]
        APPORTO_TOTALE_AMIDO = random_ARR_0_new[8] + random_ARR_1_new[8] + random_ARR_2_new[8] + random_ARR_3_new[8] + random_ARR_4_new[8] + random_ARR_5_new[8] + random_ARR_6_new[8]
        APPORTO_TOTALE_ZUCCHERI = random_ARR_0_new[9] + random_ARR_1_new[9] + random_ARR_2_new[9] + random_ARR_3_new[9] + random_ARR_4_new[9] + random_ARR_5_new[9] + random_ARR_6_new[9]
        APPORTO_TOTALE_Ca = random_ARR_0_new[10] + random_ARR_1_new[10] + random_ARR_2_new[10] + random_ARR_3_new[10] + random_ARR_4_new[10] + random_ARR_5_new[10] + random_ARR_6_new[10]
        APPORTO_TOTALE_P = random_ARR_0_new[11] + random_ARR_1_new[11] + random_ARR_2_new[11] + random_ARR_3_new[11] + random_ARR_4_new[11] + random_ARR_5_new[11] + random_ARR_6_new[11]
        APPORTO_TOTALE_UFL = random_ARR_0_new[12] + random_ARR_1_new[12] + random_ARR_2_new[12] + random_ARR_3_new[12] + random_ARR_4_new[12] + random_ARR_5_new[12] + random_ARR_6_new[12]
        
        DELTA_SOSTANZA_SECCA = APPORTO_TOTALE_SOSTANZA_SECCA - F[0]
        DELTA_PROTEINA_GREZZA = APPORTO_TOTALE_PROTEINA_GREZZA - F[1]
        DELTA_PROTEINA_DEGRADABILE = APPORTO_TOTALE_PROTEINA_DEGRADABILE - F[2]
        DELTA_PROTEINA_INDEGRADABILE = APPORTO_TOTALE_PROTEINA_INDEGRADABILE - F[3]
        DELTA_FIBRA_GREZZA = APPORTO_TOTALE_FIBRA_GREZZA - F[4]
        DELTA_NDF = APPORTO_TOTALE_NDF - F[5]
        DELTA_ADF = APPORTO_TOTALE_ADF - F[6]
        DELTA_GRASSO = APPORTO_TOTALE_GRASSO - F[7]
        DELTA_AMIDO = APPORTO_TOTALE_AMIDO - F[8]
        DELTA_ZUCCHERI = APPORTO_TOTALE_ZUCCHERI - F[9]
        DELTA_Ca = APPORTO_TOTALE_Ca - F[10]
        DELTA_P = APPORTO_TOTALE_P - F[11]
        DELTA_UFL = APPORTO_TOTALE_UFL - F[12]
        
        original = sys.stdout
        sys.stdout = open('NUOVA_RAZIONE.txt', 'w')
        
        
        if day == 'Monday': 
            print('RAZIONE di %s, creata lunedì %s, %s' % (user, data, current_time))
        if day == 'Tuesday': 
            print('RAZIONE di %s, creata martedì %s, %s' % (user, data, current_time))
        if day == 'Wednesday': 
            print('RAZIONE di %s, creata mercoledì %s, %s' % (user, data, current_time))
        if day == 'Thursday': 
            print('RAZIONE di %s, creata giovedì %s, %s' % (user, data, current_time))
        if day == 'Friday': 
            print('RAZIONE di %s, creata venerdì %s, %s' % (user, data, current_time))
        if day == 'Saturday': 
            print('RAZIONE di %s, creata sabato %s, %s' % (user, data, current_time))
        if day == 'Sunday': 
            print('RAZIONE di %s, creata domenica %s, %s' % (user, data, current_time))
        
        
        print('')
#       print('This is your redirected text:')
        print('')
        if i == 999:
            print('Il calcolo della razione non ha avuto successo; per favore chiudi il programma e riprova.')
        else:
            print('Il calcolo della razione è stato effettuato con successo alla %d^esima replica' % i)        
#       print(i)
        print('')
        print('Il fabbisogno di SOSTANZA SECCA è di %f' %  F_arr[0])
        print('')
        print("L'apporto totale di SOSTANZA SECCA è di %f" % APPORTO_TOTALE_SOSTANZA_SECCA)
        print('')
        print('out of loop')
        print('')        
        print('LEGENDA')
        print('')
        print("DMI => Dry Matter Intake (Capacità d'ingestione di Sostanza Secca)")
        print("CPI => Crude Protein Intake (Apporto di Proteina Grezza)")
        print("RDPI => Rumen Degradable Protein Intake (Apporto di Proteina Degradabile)")
        print("RUPI => Rumen Undegradable Protein Intake (Apporto di Proteina Indegradabile)")
        print("FG => Fibra Grezza (apporto di Fibra Grezza)")
        print("NDF => Neutral Detergent Fiber (apporto di Fibra resistente al Detergente Neutro)")
        print("ADF => Acid Detergent Fiber (apporto di Fibra resistente al Detergente Acido)")
        print("FAT => Fat (apporto di Grasso)")
        print("AM => Amido (apporto di Amido)")
        print("ZUC => Zuccheri (apporto di Zuccheri)")
        print("Ca => Calcio (apporto di Calcio)")
        print("P => Fosforo (apporto di Fosforo)")
        print("UFL => Unità Foraggere Latte (apporto di Energia Netta)")
        print('DMI', 'CPI', 'RDPI', 'RUPI', 'FG', 'NDF', 'ADF', 'FAT', 'AM', 'ZUC', 'Ca', 'P', 'UFL')                	                
        	                
                                
        print('apporti di %s: \n' % S[0])
        print(random_ARR_0_new)
        print('apporti di %s: \n' % S[1])
        print(random_ARR_1_new)
        print('apporti di %s: \n' % S[2])
        print(random_ARR_2_new)
        print('apporti di %s: \n' % S[3])
        print(random_ARR_3_new)
        print('apporti di %s: \n' % S[4])
        print(random_ARR_4_new)
        print('apporti di %s: \n' % S[5])
        print(random_ARR_5_new)
        print('apporti di %s: \n' % S[6])
        print(random_ARR_6_new)
        
                                
        print('%f kg %s' % (quantità_alimento_1[0], S[0]))
        print('%f kg %s' % (quantità_alimento_2[0], S[1]))
        print('%f kg %s' % (quantità_alimento_3[0], S[2]))
        print('%f kg %s' % (quantità_alimento_4[0], S[3]))
        print('%f kg %s' % (quantità_alimento_5[0], S[4]))
        print('%f kg %s' % (quantità_alimento_6[0], S[5]))
        print('%f kg %s' % (quantità_alimento_7[0], S[6]))
                
        print('La razione fornisce %f kg di alimento tal quale' % QUANTITÀ_TOTALE_TAL_QUALE)
        print('La razione fornisce %f kg di sostanza secca' % APPORTO_TOTALE_SOSTANZA_SECCA)
        
        print("SOSTANZA SECCA: la differenza fra l'apporto totale => %f kg e la capacità d'ingestione => %f kg è: %f kg" % (APPORTO_TOTALE_SOSTANZA_SECCA, F[0], DELTA_SOSTANZA_SECCA))
        print("PROTEINA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_GREZZA, F[1], DELTA_PROTEINA_GREZZA)) 
        print("PROTEINA DEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_DEGRADABILE, F[2], DELTA_PROTEINA_DEGRADABILE))
        print("PROTEINA INDEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_INDEGRADABILE, F[3], DELTA_PROTEINA_INDEGRADABILE))
        print("FIBRA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_FIBRA_GREZZA, F[4], DELTA_FIBRA_GREZZA))
        print("NDF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_NDF, F[5], DELTA_NDF))
        print("ADF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ADF, F[6], DELTA_ADF))
        print("GRASSO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_GRASSO, F[7], DELTA_GRASSO)) 
        print("AMIDO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_AMIDO, F[8], DELTA_AMIDO))
        print("ZUCCHERI: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ZUCCHERI, F[9], DELTA_ZUCCHERI))
        print("Ca: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_Ca, F[10], DELTA_Ca))
        print("P: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_P, F[11], DELTA_P))
        print("UFL: la differenza fra l'apporto totale => %f UFL e il fabbisogno => %f UFL è: %f UFL" % (APPORTO_TOTALE_UFL, F[12], DELTA_UFL))
        
        sys.stdout = original
        print('This string goes to stdout, NOT the file!')

                        
        

        
    elif len(S) == 8: 
        print(S[0])
        print(S[1])
        print(S[2])
        print(S[3])
        print(S[4])
        print(S[5])
        print(S[6])
        print(S[7])
        print(ARR[0])
        print(ARR[1])
        print(ARR[2])
        print(ARR[3])
        print(ARR[4])
        print(ARR[5])
        print(ARR[6])
        print(ARR[7])
        
        print('Hai inserito 8 alimenti \n')
        
#       print("QUESTA È LA VERSIONE CORRETTA DELL'ALGORITMO")
        
        random_ARR_0_old = ARR[0] * random.random() * 10
        random_ARR_1_old = ARR[1] * random.random() * 10
        random_ARR_2_old = ARR[2] * random.random() * 10
        random_ARR_3_old = ARR[3] * random.random() * 10
        random_ARR_4_old = ARR[4] * random.random() * 10
        random_ARR_5_old = ARR[5] * random.random() * 10
        random_ARR_6_old = ARR[6] * random.random() * 10
        random_ARR_7_old = ARR[7] * random.random() * 10

# ogni alimento scelto dall'utente viene moltiplicato per un numero casuale compreso fra 0 e 10 (kg) 
# dichiaro random_ARR_x_old

        
        random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
        random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
        random_ARR_2_new = random_ARR_2_old * (random.random() + 0.5)
        random_ARR_3_new = random_ARR_3_old * (random.random() + 0.5)
        random_ARR_4_new = random_ARR_4_old * (random.random() + 0.5)
        random_ARR_5_new = random_ARR_5_old * (random.random() + 0.5)
        random_ARR_6_new = random_ARR_6_old * (random.random() + 0.5)
        random_ARR_7_new = random_ARR_7_old * (random.random() + 0.5)

# dichiaro random_ARR_x_new
        
        SOMMA_old = random_ARR_0_old + random_ARR_1_old + random_ARR_2_old + random_ARR_3_old + random_ARR_4_old + random_ARR_5_old + random_ARR_6_old + random_ARR_7_old
        DELTA_old = SOMMA_old - F_arr
        print('La somma iniziale è...')
        print(SOMMA_old)

# dichiaro SOMMA_old e DELTA_old

        SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new + random_ARR_5_new + random_ARR_6_new + random_ARR_7_new
        DELTA_new = SOMMA_new - F_arr
        print('La nuova somma è...')
        print(SOMMA_new)
        print('La nuova differenza è...')
        print(DELTA_new)

# dichiaro SOMMA_new e DELTA_new
        
        quantità_alimento_1 = random_ARR_0_new / ARR[0]
        quantità_alimento_2 = random_ARR_1_new / ARR[1]
        quantità_alimento_3 = random_ARR_2_new / ARR[2]
        quantità_alimento_4 = random_ARR_3_new / ARR[3]
        quantità_alimento_5 = random_ARR_4_new / ARR[4]
        quantità_alimento_6 = random_ARR_5_new / ARR[5]
        quantità_alimento_7 = random_ARR_6_new / ARR[6]
        quantità_alimento_8 = random_ARR_7_new / ARR[7]

# dichiaro gli apporti dei singoli alimenti

# dichiaro gli apporti dei singoli alimenti

        i = 0

# inizializzo il contatore i        
        
        for i in range(N_repl):
        
            rules = [abs(DELTA_new[0]) < abs(DELTA_old[0]), abs(DELTA_new[1]) < abs(DELTA_old[1]), abs(DELTA_new[2]) < abs(DELTA_old[2])]

# dichiaro le regole da rispettare
                                    
            if all(rules):
            
                print('ESTRAGGO DALLA PROPOSAL DISTRIBUTION')
                i += 1
                print(i)
                                                         	               	        
                random_ARR_0_new = random_ARR_0_new * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_new * (random.random() + 0.5)
                random_ARR_2_new = random_ARR_2_new * (random.random() + 0.5)
                random_ARR_3_new = random_ARR_3_new * (random.random() + 0.5)
                random_ARR_4_new = random_ARR_4_new * (random.random() + 0.5)
                random_ARR_5_new = random_ARR_5_new * (random.random() + 0.5)
                random_ARR_6_new = random_ARR_6_new * (random.random() + 0.5)
                random_ARR_7_new = random_ARR_7_new * (random.random() + 0.5)

# ACCETTO random_ARR_x_new e lo uso per aggiornare random_ARR_x_new stesso 
                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0] + random_ARR_6_new[0] + random_ARR_7_new[0]
                print(APPORTO_TOTALE_SOSTANZA_SECCA)

# aggiorno l'apporto di SS
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new + random_ARR_5_new + random_ARR_6_new + random_ARR_7_new
                DELTA_new = SOMMA_new - F_arr
                
# aggiorno SOMMA_new e DELTA_new                
                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                quantità_alimento_3 = random_ARR_2_new / ARR[2]
                quantità_alimento_4 = random_ARR_3_new / ARR[3]
                quantità_alimento_5 = random_ARR_4_new / ARR[4]
                quantità_alimento_6 = random_ARR_5_new / ARR[5]
                quantità_alimento_7 = random_ARR_6_new / ARR[6]
                quantità_alimento_8 = random_ARR_7_new / ARR[7]
                
                if round(APPORTO_TOTALE_SOSTANZA_SECCA) == round(F_arr[0]):
                
                    break
                
                print(i)    
                print("SUCCESSO! L'APPORTO DI SOSTANZA SECCA CORRISPONDE AL FABBISOGNO.")

                                       	                
            else:
                    
                random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
                random_ARR_2_new = random_ARR_2_old * (random.random() + 0.5)
                random_ARR_3_new = random_ARR_3_old * (random.random() + 0.5)
                random_ARR_4_new = random_ARR_4_old * (random.random() + 0.5)
                random_ARR_5_new = random_ARR_5_old * (random.random() + 0.5)
                random_ARR_6_new = random_ARR_6_old * (random.random() + 0.5)
                random_ARR_7_new = random_ARR_7_old * (random.random() + 0.5)

# RIFIUTO random_ARR_x_new e lo ricalcolo a partire da random_ARR_x_old 
                
                print('FALLIMENTO')
                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0] + random_ARR_6_new[0] + random_ARR_7_new[0]
                print(APPORTO_TOTALE_SOSTANZA_SECCA)
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new + random_ARR_5_new + random_ARR_6_new + random_ARR_7_new
                DELTA_new = SOMMA_new - F_arr
                                                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                quantità_alimento_3 = random_ARR_2_new / ARR[2]
                quantità_alimento_4 = random_ARR_3_new / ARR[3]
                quantità_alimento_5 = random_ARR_4_new / ARR[4]
                quantità_alimento_6 = random_ARR_5_new / ARR[5]
                quantità_alimento_7 = random_ARR_6_new / ARR[6]
                quantità_alimento_8 = random_ARR_7_new / ARR[7]

        
        
        QUANTITÀ_TOTALE_TAL_QUALE = quantità_alimento_1[0] + quantità_alimento_2[0] + quantità_alimento_3[0] + quantità_alimento_4[0] + quantità_alimento_5[0] + quantità_alimento_6[0] + quantità_alimento_7[0] + quantità_alimento_8[0]  
        APPORTO_TOTALE_PROTEINA_GREZZA = random_ARR_0_new[1] + random_ARR_1_new[1] + random_ARR_2_new[1] + random_ARR_3_new[1] + random_ARR_4_new[1] + random_ARR_5_new[1] + random_ARR_6_new[1] + random_ARR_7_new[1]
        APPORTO_TOTALE_PROTEINA_DEGRADABILE = random_ARR_0_new[2] + random_ARR_1_new[2] + random_ARR_2_new[2] + random_ARR_3_new[2] + random_ARR_4_new[2] + random_ARR_5_new[2] + random_ARR_6_new[2] + random_ARR_7_new[2]
        APPORTO_TOTALE_PROTEINA_INDEGRADABILE = random_ARR_0_new[3] + random_ARR_1_new[3] + random_ARR_2_new[3] + random_ARR_3_new[3] + random_ARR_4_new[3] + random_ARR_5_new[3] + random_ARR_6_new[3] + random_ARR_7_new[3]
        APPORTO_TOTALE_FIBRA_GREZZA = random_ARR_0_new[4] + random_ARR_1_new[4] + random_ARR_2_new[4] + random_ARR_3_new[4] + random_ARR_4_new[4] + random_ARR_5_new[4] + random_ARR_6_new[4] + random_ARR_7_new[4]
        APPORTO_TOTALE_NDF = random_ARR_0_new[5] + random_ARR_1_new[5] + random_ARR_2_new[5] + random_ARR_3_new[5] + random_ARR_4_new[5] + random_ARR_5_new[5] + random_ARR_6_new[5] + random_ARR_7_new[5]
        APPORTO_TOTALE_ADF = random_ARR_0_new[6] + random_ARR_1_new[6] + random_ARR_2_new[6] + random_ARR_3_new[6] + random_ARR_4_new[6] + random_ARR_5_new[6] + random_ARR_6_new[6] + random_ARR_7_new[6]
        APPORTO_TOTALE_GRASSO = random_ARR_0_new[7] + random_ARR_1_new[7] + random_ARR_2_new[7] + random_ARR_3_new[7] + random_ARR_4_new[7] + random_ARR_5_new[7] + random_ARR_6_new[7] + random_ARR_7_new[7]
        APPORTO_TOTALE_AMIDO = random_ARR_0_new[8] + random_ARR_1_new[8] + random_ARR_2_new[8] + random_ARR_3_new[8] + random_ARR_4_new[8] + random_ARR_5_new[8] + random_ARR_6_new[8] + random_ARR_7_new[8]
        APPORTO_TOTALE_ZUCCHERI = random_ARR_0_new[9] + random_ARR_1_new[9] + random_ARR_2_new[9] + random_ARR_3_new[9] + random_ARR_4_new[9] + random_ARR_5_new[9] + random_ARR_6_new[9] + random_ARR_7_new[9]
        APPORTO_TOTALE_Ca = random_ARR_0_new[10] + random_ARR_1_new[10] + random_ARR_2_new[10] + random_ARR_3_new[10] + random_ARR_4_new[10] + random_ARR_5_new[10] + random_ARR_6_new[10] + random_ARR_7_new[10]
        APPORTO_TOTALE_P = random_ARR_0_new[11] + random_ARR_1_new[11] + random_ARR_2_new[11] + random_ARR_3_new[11] + random_ARR_4_new[11] + random_ARR_5_new[11] + random_ARR_6_new[11] + random_ARR_7_new[11]
        APPORTO_TOTALE_UFL = random_ARR_0_new[12] + random_ARR_1_new[12] + random_ARR_2_new[12] + random_ARR_3_new[12] + random_ARR_4_new[12] + random_ARR_5_new[12] + random_ARR_6_new[12] + random_ARR_7_new[12]
        
        
        DELTA_SOSTANZA_SECCA = APPORTO_TOTALE_SOSTANZA_SECCA - F[0]
        DELTA_PROTEINA_GREZZA = APPORTO_TOTALE_PROTEINA_GREZZA - F[1]
        DELTA_PROTEINA_DEGRADABILE = APPORTO_TOTALE_PROTEINA_DEGRADABILE - F[2]
        DELTA_PROTEINA_INDEGRADABILE = APPORTO_TOTALE_PROTEINA_INDEGRADABILE - F[3]
        DELTA_FIBRA_GREZZA = APPORTO_TOTALE_FIBRA_GREZZA - F[4]
        DELTA_NDF = APPORTO_TOTALE_NDF - F[5]
        DELTA_ADF = APPORTO_TOTALE_ADF - F[6]
        DELTA_GRASSO = APPORTO_TOTALE_GRASSO - F[7]
        DELTA_AMIDO = APPORTO_TOTALE_AMIDO - F[8]
        DELTA_ZUCCHERI = APPORTO_TOTALE_ZUCCHERI - F[9]
        DELTA_Ca = APPORTO_TOTALE_Ca - F[10]
        DELTA_P = APPORTO_TOTALE_P - F[11]
        DELTA_UFL = APPORTO_TOTALE_UFL - F[12]

        original = sys.stdout
        sys.stdout = open('NUOVA_RAZIONE.txt', 'w')
        
        
        if day == 'Monday': 
            print('RAZIONE di %s, creata lunedì %s, %s' % (user, data, current_time))
        if day == 'Tuesday': 
            print('RAZIONE di %s, creata martedì %s, %s' % (user, data, current_time))
        if day == 'Wednesday': 
            print('RAZIONE di %s, creata mercoledì %s, %s' % (user, data, current_time))
        if day == 'Thursday': 
            print('RAZIONE di %s, creata giovedì %s, %s' % (user, data, current_time))
        if day == 'Friday': 
            print('RAZIONE di %s, creata venerdì %s, %s' % (user, data, current_time))
        if day == 'Saturday': 
            print('RAZIONE di %s, creata sabato %s, %s' % (user, data, current_time))
        if day == 'Sunday': 
            print('RAZIONE di %s, creata domenica %s, %s' % (user, data, current_time))
        
        
        print('')
#       print('This is your redirected text:')
        print('')
        if i == 999:
            print('Il calcolo della razione non ha avuto successo; per favore chiudi il programma e riprova.')
        else:
            print('Il calcolo della razione è stato effettuato con successo alla %d^esima replica' % i)        
#       print(i)
        print('')
        print('Il fabbisogno di SOSTANZA SECCA è di %f' %  F_arr[0])
        print('')
        print("L'apporto totale di SOSTANZA SECCA è di %f" % APPORTO_TOTALE_SOSTANZA_SECCA)
        print('')
        print('out of loop')
        print('')        
        print('LEGENDA')
        print('')
        print("DMI => Dry Matter Intake (Capacità d'ingestione di Sostanza Secca)")
        print("CPI => Crude Protein Intake (Apporto di Proteina Grezza)")
        print("RDPI => Rumen Degradable Protein Intake (Apporto di Proteina Degradabile)")
        print("RUPI => Rumen Undegradable Protein Intake (Apporto di Proteina Indegradabile)")
        print("FG => Fibra Grezza (apporto di Fibra Grezza)")
        print("NDF => Neutral Detergent Fiber (apporto di Fibra resistente al Detergente Neutro)")
        print("ADF => Acid Detergent Fiber (apporto di Fibra resistente al Detergente Acido)")
        print("FAT => Fat (apporto di Grasso)")
        print("AM => Amido (apporto di Amido)")
        print("ZUC => Zuccheri (apporto di Zuccheri)")
        print("Ca => Calcio (apporto di Calcio)")
        print("P => Fosforo (apporto di Fosforo)")
        print("UFL => Unità Foraggere Latte (apporto di Energia Netta)")
        print('DMI', 'CPI', 'RDPI', 'RUPI', 'FG', 'NDF', 'ADF', 'FAT', 'AM', 'ZUC', 'Ca', 'P', 'UFL')                	                

                                
        print('apporti di %s: \n' % S[0])
        print(random_ARR_0_new)
        print('apporti di %s: \n' % S[1])
        print(random_ARR_1_new)
        print('apporti di %s: \n' % S[2])
        print(random_ARR_2_new)
        print('apporti di %s: \n' % S[3])
        print(random_ARR_3_new)
        print('apporti di %s: \n' % S[4])
        print(random_ARR_4_new)
        print('apporti di %s: \n' % S[5])
        print(random_ARR_5_new)
        print('apporti di %s: \n' % S[6])
        print(random_ARR_6_new)
        print('apporti di %s: \n' % S[7])
        print(random_ARR_7_new)

        
                                
        print('%f kg %s' % (quantità_alimento_1[0], S[0]))
        print('%f kg %s' % (quantità_alimento_2[0], S[1]))
        print('%f kg %s' % (quantità_alimento_3[0], S[2]))
        print('%f kg %s' % (quantità_alimento_4[0], S[3]))
        print('%f kg %s' % (quantità_alimento_5[0], S[4]))
        print('%f kg %s' % (quantità_alimento_6[0], S[5]))
        print('%f kg %s' % (quantità_alimento_7[0], S[6]))
        print('%f kg %s' % (quantità_alimento_8[0], S[7]))
                
        print('La razione fornisce %f kg di alimento tal quale' % QUANTITÀ_TOTALE_TAL_QUALE)
        print('La razione fornisce %f kg di sostanza secca' % APPORTO_TOTALE_SOSTANZA_SECCA)
        
        print("SOSTANZA SECCA: la differenza fra l'apporto totale => %f kg e la capacità d'ingestione => %f kg è: %f kg" % (APPORTO_TOTALE_SOSTANZA_SECCA, F[0], DELTA_SOSTANZA_SECCA))
        print("PROTEINA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_GREZZA, F[1], DELTA_PROTEINA_GREZZA)) 
        print("PROTEINA DEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_DEGRADABILE, F[2], DELTA_PROTEINA_DEGRADABILE))
        print("PROTEINA INDEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_INDEGRADABILE, F[3], DELTA_PROTEINA_INDEGRADABILE))
        print("FIBRA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_FIBRA_GREZZA, F[4], DELTA_FIBRA_GREZZA))
        print("NDF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_NDF, F[5], DELTA_NDF))
        print("ADF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ADF, F[6], DELTA_ADF))
        print("GRASSO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_GRASSO, F[7], DELTA_GRASSO)) 
        print("AMIDO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_AMIDO, F[8], DELTA_AMIDO))
        print("ZUCCHERI: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ZUCCHERI, F[9], DELTA_ZUCCHERI))
        print("Ca: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_Ca, F[10], DELTA_Ca))
        print("P: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_P, F[11], DELTA_P))
        print("UFL: la differenza fra l'apporto totale => %f UFL e il fabbisogno => %f UFL è: %f UFL" % (APPORTO_TOTALE_UFL, F[12], DELTA_UFL))
        
        sys.stdout = original
        print('This string goes to stdout, NOT the file!')

                        
                
    elif len(S) == 9: 
        print(S[0])
        print(S[1])
        print(S[2])
        print(S[3])
        print(S[4])
        print(S[5])
        print(S[6])
        print(S[7])
        print(S[8])
        print(ARR[0])
        print(ARR[1])
        print(ARR[2])
        print(ARR[3])
        print(ARR[4])
        print(ARR[5])
        print(ARR[6])
        print(ARR[7])
        print(ARR[8])
        
        print('Hai inserito 9 alimenti \n')

#       print("QUESTA È LA VERSIONE CORRETTA DELL'ALGORITMO")
        
        random_ARR_0_old = ARR[0] * random.random() * 10
        random_ARR_1_old = ARR[1] * random.random() * 10
        random_ARR_2_old = ARR[2] * random.random() * 10
        random_ARR_3_old = ARR[3] * random.random() * 10
        random_ARR_4_old = ARR[4] * random.random() * 10
        random_ARR_5_old = ARR[5] * random.random() * 10
        random_ARR_6_old = ARR[6] * random.random() * 10
        random_ARR_7_old = ARR[7] * random.random() * 10
        random_ARR_8_old = ARR[8] * random.random() * 10

# ogni alimento scelto dall'utente viene moltiplicato per un numero casuale compreso fra 0 e 10 (kg) 
# dichiaro random_ARR_x_old

        
        random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
        random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
        random_ARR_2_new = random_ARR_2_old * (random.random() + 0.5)
        random_ARR_3_new = random_ARR_3_old * (random.random() + 0.5)
        random_ARR_4_new = random_ARR_4_old * (random.random() + 0.5)
        random_ARR_5_new = random_ARR_5_old * (random.random() + 0.5)
        random_ARR_6_new = random_ARR_6_old * (random.random() + 0.5)
        random_ARR_7_new = random_ARR_7_old * (random.random() + 0.5)
        random_ARR_8_new = random_ARR_8_old * (random.random() + 0.5)

# dichiaro random_ARR_x_new
        
        SOMMA_old = random_ARR_0_old + random_ARR_1_old + random_ARR_2_old + random_ARR_3_old + random_ARR_4_old + random_ARR_5_old + random_ARR_6_old + random_ARR_7_old + random_ARR_8_old
        DELTA_old = SOMMA_old - F_arr
        print('La somma iniziale è...')
        print(SOMMA_old)

# dichiaro SOMMA_old e DELTA_old

        SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new + random_ARR_5_new + random_ARR_6_new + random_ARR_7_new + random_ARR_8_new
        DELTA_new = SOMMA_new - F_arr
        print('La nuova somma è...')
        print(SOMMA_new)
        print('La nuova differenza è...')
        print(DELTA_new)

# dichiaro SOMMA_new e DELTA_new
        
        quantità_alimento_1 = random_ARR_0_new / ARR[0]
        quantità_alimento_2 = random_ARR_1_new / ARR[1]
        quantità_alimento_3 = random_ARR_2_new / ARR[2]
        quantità_alimento_4 = random_ARR_3_new / ARR[3]
        quantità_alimento_5 = random_ARR_4_new / ARR[4]
        quantità_alimento_6 = random_ARR_5_new / ARR[5]
        quantità_alimento_7 = random_ARR_6_new / ARR[6]
        quantità_alimento_8 = random_ARR_7_new / ARR[7]
        quantità_alimento_9 = random_ARR_8_new / ARR[8]

# dichiaro gli apporti dei singoli alimenti

# dichiaro gli apporti dei singoli alimenti

        i = 0

# inizializzo il contatore i        
        
        for i in range(N_repl):
        
            rules = [abs(DELTA_new[0]) < abs(DELTA_old[0]), abs(DELTA_new[1]) < abs(DELTA_old[1]), abs(DELTA_new[2]) < abs(DELTA_old[2])]

# dichiaro le regole da rispettare
                                    
            if all(rules):
            
                print('ESTRAGGO DALLA PROPOSAL DISTRIBUTION')
                i += 1
                print(i)
                                                         	               	        
                random_ARR_0_new = random_ARR_0_new * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_new * (random.random() + 0.5)
                random_ARR_2_new = random_ARR_2_new * (random.random() + 0.5)
                random_ARR_3_new = random_ARR_3_new * (random.random() + 0.5)
                random_ARR_4_new = random_ARR_4_new * (random.random() + 0.5)
                random_ARR_5_new = random_ARR_5_new * (random.random() + 0.5)
                random_ARR_6_new = random_ARR_6_new * (random.random() + 0.5)
                random_ARR_7_new = random_ARR_7_new * (random.random() + 0.5)
                random_ARR_8_new = random_ARR_8_new * (random.random() + 0.5)

# ACCETTO random_ARR_x_new e lo uso per aggiornare random_ARR_x_new stesso 
                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0] + random_ARR_6_new[0] + random_ARR_7_new[0] + random_ARR_8_new[0]
                print(APPORTO_TOTALE_SOSTANZA_SECCA)

# aggiorno l'apporto di SS
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new + random_ARR_5_new + random_ARR_6_new + random_ARR_7_new + random_ARR_8_new
                DELTA_new = SOMMA_new - F_arr
                
# aggiorno SOMMA_new e DELTA_new                
                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                quantità_alimento_3 = random_ARR_2_new / ARR[2]
                quantità_alimento_4 = random_ARR_3_new / ARR[3]
                quantità_alimento_5 = random_ARR_4_new / ARR[4]
                quantità_alimento_6 = random_ARR_5_new / ARR[5]
                quantità_alimento_7 = random_ARR_6_new / ARR[6]
                quantità_alimento_8 = random_ARR_7_new / ARR[7]
                quantità_alimento_9 = random_ARR_8_new / ARR[8]
                
                if round(APPORTO_TOTALE_SOSTANZA_SECCA) == round(F_arr[0]):
                
                    break
                
                print(i)    
                print("SUCCESSO! L'APPORTO DI SOSTANZA SECCA CORRISPONDE AL FABBISOGNO.")

                    	                
            else:
                    
                random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
                random_ARR_2_new = random_ARR_2_old * (random.random() + 0.5)
                random_ARR_3_new = random_ARR_3_old * (random.random() + 0.5)
                random_ARR_4_new = random_ARR_4_old * (random.random() + 0.5)
                random_ARR_5_new = random_ARR_5_old * (random.random() + 0.5)
                random_ARR_6_new = random_ARR_6_old * (random.random() + 0.5)
                random_ARR_7_new = random_ARR_7_old * (random.random() + 0.5)
                random_ARR_8_new = random_ARR_8_old * (random.random() + 0.5)

# RIFIUTO random_ARR_x_new e lo ricalcolo a partire da random_ARR_x_old 
                
                print('FALLIMENTO')
                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0] + random_ARR_6_new[0] + random_ARR_7_new[0] + random_ARR_8_new[0]
                print(APPORTO_TOTALE_SOSTANZA_SECCA)
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new + random_ARR_5_new + random_ARR_6_new + random_ARR_7_new + random_ARR_8_new
                DELTA_new = SOMMA_new - F_arr
                                                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                quantità_alimento_3 = random_ARR_2_new / ARR[2]
                quantità_alimento_4 = random_ARR_3_new / ARR[3]
                quantità_alimento_5 = random_ARR_4_new / ARR[4]
                quantità_alimento_6 = random_ARR_5_new / ARR[5]
                quantità_alimento_7 = random_ARR_6_new / ARR[6]
                quantità_alimento_8 = random_ARR_7_new / ARR[7]
                quantità_alimento_9 = random_ARR_7_new / ARR[8]


        
        QUANTITÀ_TOTALE_TAL_QUALE = quantità_alimento_1[0] + quantità_alimento_2[0] + quantità_alimento_3[0] + quantità_alimento_4[0] + quantità_alimento_5[0] + quantità_alimento_6[0] + quantità_alimento_7[0] + quantità_alimento_8[0] + quantità_alimento_9[0] 
        APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0] + random_ARR_6_new[0] + random_ARR_7_new[0] + random_ARR_8_new[0]
        APPORTO_TOTALE_PROTEINA_GREZZA = random_ARR_0_new[1] + random_ARR_1_new[1] + random_ARR_2_new[1] + random_ARR_3_new[1] + random_ARR_4_new[1] + random_ARR_5_new[1] + random_ARR_6_new[1] + random_ARR_7_new[1] + random_ARR_8_new[1]
        APPORTO_TOTALE_PROTEINA_DEGRADABILE = random_ARR_0_new[2] + random_ARR_1_new[2] + random_ARR_2_new[2] + random_ARR_3_new[2] + random_ARR_4_new[2] + random_ARR_5_new[2] + random_ARR_6_new[2] + random_ARR_7_new[2] + random_ARR_8_new[2]
        APPORTO_TOTALE_PROTEINA_INDEGRADABILE = random_ARR_0_new[3] + random_ARR_1_new[3] + random_ARR_2_new[3] + random_ARR_3_new[3] + random_ARR_4_new[3] + random_ARR_5_new[3] + random_ARR_6_new[3] + random_ARR_7_new[3] + random_ARR_8_new[3]
        APPORTO_TOTALE_FIBRA_GREZZA = random_ARR_0_new[4] + random_ARR_1_new[4] + random_ARR_2_new[4] + random_ARR_3_new[4] + random_ARR_4_new[4] + random_ARR_5_new[4] + random_ARR_6_new[4] + random_ARR_7_new[4] + random_ARR_8_new[4]
        APPORTO_TOTALE_NDF = random_ARR_0_new[5] + random_ARR_1_new[5] + random_ARR_2_new[5] + random_ARR_3_new[5] + random_ARR_4_new[5] + random_ARR_5_new[5] + random_ARR_6_new[5] + random_ARR_7_new[5] + random_ARR_8_new[5]
        APPORTO_TOTALE_ADF = random_ARR_0_new[6] + random_ARR_1_new[6] + random_ARR_2_new[6] + random_ARR_3_new[6] + random_ARR_4_new[6] + random_ARR_5_new[6] + random_ARR_6_new[6] + random_ARR_7_new[6] + random_ARR_8_new[6]
        APPORTO_TOTALE_GRASSO = random_ARR_0_new[7] + random_ARR_1_new[7] + random_ARR_2_new[7] + random_ARR_3_new[7] + random_ARR_4_new[7] + random_ARR_5_new[7] + random_ARR_6_new[7] + random_ARR_7_new[7] + random_ARR_8_new[7]
        APPORTO_TOTALE_AMIDO = random_ARR_0_new[8] + random_ARR_1_new[8] + random_ARR_2_new[8] + random_ARR_3_new[8] + random_ARR_4_new[8] + random_ARR_5_new[8] + random_ARR_6_new[8] + random_ARR_7_new[8] + random_ARR_8_new[8]
        APPORTO_TOTALE_ZUCCHERI = random_ARR_0_new[9] + random_ARR_1_new[9] + random_ARR_2_new[9] + random_ARR_3_new[9] + random_ARR_4_new[9] + random_ARR_5_new[9] + random_ARR_6_new[9] + random_ARR_7_new[9] + random_ARR_8_new[9]
        APPORTO_TOTALE_Ca = random_ARR_0_new[10] + random_ARR_1_new[10] + random_ARR_2_new[10] + random_ARR_3_new[10] + random_ARR_4_new[10] + random_ARR_5_new[10] + random_ARR_6_new[10] + random_ARR_7_new[10] + random_ARR_8_new[10]
        APPORTO_TOTALE_P = random_ARR_0_new[11] + random_ARR_1_new[11] + random_ARR_2_new[11] + random_ARR_3_new[11] + random_ARR_4_new[11] + random_ARR_5_new[11] + random_ARR_6_new[11] + random_ARR_7_new[11] + random_ARR_8_new[11]
        APPORTO_TOTALE_UFL = random_ARR_0_new[12] + random_ARR_1_new[12] + random_ARR_2_new[12] + random_ARR_3_new[12] + random_ARR_4_new[12] + random_ARR_5_new[12] + random_ARR_6_new[12] + random_ARR_7_new[12] + random_ARR_8_new[12]

        
        DELTA_SOSTANZA_SECCA = APPORTO_TOTALE_SOSTANZA_SECCA - F[0]
        DELTA_PROTEINA_GREZZA = APPORTO_TOTALE_PROTEINA_GREZZA - F[1]
        DELTA_PROTEINA_DEGRADABILE = APPORTO_TOTALE_PROTEINA_DEGRADABILE - F[2]
        DELTA_PROTEINA_INDEGRADABILE = APPORTO_TOTALE_PROTEINA_INDEGRADABILE - F[3]
        DELTA_FIBRA_GREZZA = APPORTO_TOTALE_FIBRA_GREZZA - F[4]
        DELTA_NDF = APPORTO_TOTALE_NDF - F[5]
        DELTA_ADF = APPORTO_TOTALE_ADF - F[6]
        DELTA_GRASSO = APPORTO_TOTALE_GRASSO - F[7]
        DELTA_AMIDO = APPORTO_TOTALE_AMIDO - F[8]
        DELTA_ZUCCHERI = APPORTO_TOTALE_ZUCCHERI - F[9]
        DELTA_Ca = APPORTO_TOTALE_Ca - F[10]
        DELTA_P = APPORTO_TOTALE_P - F[11]
        DELTA_UFL = APPORTO_TOTALE_UFL - F[12]

                
        original = sys.stdout
        sys.stdout = open('NUOVA_RAZIONE.txt', 'w')
        
        
        if day == 'Monday': 
            print('RAZIONE di %s, creata lunedì %s, %s' % (user, data, current_time))
        if day == 'Tuesday': 
            print('RAZIONE di %s, creata martedì %s, %s' % (user, data, current_time))
        if day == 'Wednesday': 
            print('RAZIONE di %s, creata mercoledì %s, %s' % (user, data, current_time))
        if day == 'Thursday': 
            print('RAZIONE di %s, creata giovedì %s, %s' % (user, data, current_time))
        if day == 'Friday': 
            print('RAZIONE di %s, creata venerdì %s, %s' % (user, data, current_time))
        if day == 'Saturday': 
            print('RAZIONE di %s, creata sabato %s, %s' % (user, data, current_time))
        if day == 'Sunday': 
            print('RAZIONE di %s, creata domenica %s, %s' % (user, data, current_time))
        
        
        print('')
#       print('This is your redirected text:')
        print('')
        if i == 999:
            print('Il calcolo della razione non ha avuto successo; per favore chiudi il programma e riprova.')
        else:
            print('Il calcolo della razione è stato effettuato con successo alla %d^esima replica' % i)        
#       print(i)
        print('')
        print('Il fabbisogno di SOSTANZA SECCA è di %f' %  F_arr[0])
        print('')
        print("L'apporto totale di SOSTANZA SECCA è di %f" % APPORTO_TOTALE_SOSTANZA_SECCA)
        print('')
        print('out of loop')
        print('')        
        print('LEGENDA')
        print('')
        print("DMI => Dry Matter Intake (Capacità d'ingestione di Sostanza Secca)")
        print("CPI => Crude Protein Intake (Apporto di Proteina Grezza)")
        print("RDPI => Rumen Degradable Protein Intake (Apporto di Proteina Degradabile)")
        print("RUPI => Rumen Undegradable Protein Intake (Apporto di Proteina Indegradabile)")
        print("FG => Fibra Grezza (apporto di Fibra Grezza)")
        print("NDF => Neutral Detergent Fiber (apporto di Fibra resistente al Detergente Neutro)")
        print("ADF => Acid Detergent Fiber (apporto di Fibra resistente al Detergente Acido)")
        print("FAT => Fat (apporto di Grasso)")
        print("AM => Amido (apporto di Amido)")
        print("ZUC => Zuccheri (apporto di Zuccheri)")
        print("Ca => Calcio (apporto di Calcio)")
        print("P => Fosforo (apporto di Fosforo)")
        print("UFL => Unità Foraggere Latte (apporto di Energia Netta)")
        print('DMI', 'CPI', 'RDPI', 'RUPI', 'FG', 'NDF', 'ADF', 'FAT', 'AM', 'ZUC', 'Ca', 'P', 'UFL')                	                

                                
        print('apporti di %s: \n' % S[0])
        print(random_ARR_0_new)
        print('apporti di %s: \n' % S[1])
        print(random_ARR_1_new)
        print('apporti di %s: \n' % S[2])
        print(random_ARR_2_new)
        print('apporti di %s: \n' % S[3])
        print(random_ARR_3_new)
        print('apporti di %s: \n' % S[4])
        print(random_ARR_4_new)
        print('apporti di %s: \n' % S[5])
        print(random_ARR_5_new)
        print('apporti di %s: \n' % S[6])
        print(random_ARR_6_new)
        print('apporti di %s: \n' % S[7])
        print(random_ARR_7_new)
        print('apporti di %s: \n' % S[8])
        print(random_ARR_8_new)


        
                                
        print('%f kg %s' % (quantità_alimento_1[0], S[0]))
        print('%f kg %s' % (quantità_alimento_2[0], S[1]))
        print('%f kg %s' % (quantità_alimento_3[0], S[2]))
        print('%f kg %s' % (quantità_alimento_4[0], S[3]))
        print('%f kg %s' % (quantità_alimento_5[0], S[4]))
        print('%f kg %s' % (quantità_alimento_6[0], S[5]))
        print('%f kg %s' % (quantità_alimento_7[0], S[6]))
        print('%f kg %s' % (quantità_alimento_8[0], S[7]))
        print('%f kg %s' % (quantità_alimento_9[0], S[8]))
                
        print('La razione fornisce %f kg di alimento tal quale' % QUANTITÀ_TOTALE_TAL_QUALE)
        print('La razione fornisce %f kg di sostanza secca' % APPORTO_TOTALE_SOSTANZA_SECCA)
        
        print("SOSTANZA SECCA: la differenza fra l'apporto totale => %f kg e la capacità d'ingestione => %f kg è: %f kg" % (APPORTO_TOTALE_SOSTANZA_SECCA, F[0], DELTA_SOSTANZA_SECCA))
        print("PROTEINA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_GREZZA, F[1], DELTA_PROTEINA_GREZZA)) 
        print("PROTEINA DEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_DEGRADABILE, F[2], DELTA_PROTEINA_DEGRADABILE))
        print("PROTEINA INDEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_INDEGRADABILE, F[3], DELTA_PROTEINA_INDEGRADABILE))
        print("FIBRA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_FIBRA_GREZZA, F[4], DELTA_FIBRA_GREZZA))
        print("NDF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_NDF, F[5], DELTA_NDF))
        print("ADF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ADF, F[6], DELTA_ADF))
        print("GRASSO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_GRASSO, F[7], DELTA_GRASSO)) 
        print("AMIDO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_AMIDO, F[8], DELTA_AMIDO))
        print("ZUCCHERI: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ZUCCHERI, F[9], DELTA_ZUCCHERI))
        print("Ca: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_Ca, F[10], DELTA_Ca))
        print("P: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_P, F[11], DELTA_P))
        print("UFL: la differenza fra l'apporto totale => %f UFL e il fabbisogno => %f UFL è: %f UFL" % (APPORTO_TOTALE_UFL, F[12], DELTA_UFL))
        
        sys.stdout = original
        print('This string goes to stdout, NOT the file!')

                        
                
    elif len(S) == 10: 
        print(S[0])
        print(S[1])
        print(S[2])
        print(S[3])
        print(S[4])
        print(S[5])
        print(S[6])
        print(S[7])
        print(S[8])
        print(S[9])
        print(ARR[0])
        print(ARR[1])
        print(ARR[2])
        print(ARR[3])
        print(ARR[4])
        print(ARR[5])
        print(ARR[6])
        print(ARR[7])
        print(ARR[8])
        print(ARR[9])
        
        print('Hai inserito 10 alimenti \n')

#       print("QUESTA È LA VERSIONE CORRETTA DELL'ALGORITMO")
        
        random_ARR_0_old = ARR[0] * random.random() * 10
        random_ARR_1_old = ARR[1] * random.random() * 10
        random_ARR_2_old = ARR[2] * random.random() * 10
        random_ARR_3_old = ARR[3] * random.random() * 10
        random_ARR_4_old = ARR[4] * random.random() * 10
        random_ARR_5_old = ARR[5] * random.random() * 10
        random_ARR_6_old = ARR[6] * random.random() * 10
        random_ARR_7_old = ARR[7] * random.random() * 10
        random_ARR_8_old = ARR[8] * random.random() * 10
        random_ARR_9_old = ARR[9] * random.random() * 10

# ogni alimento scelto dall'utente viene moltiplicato per un numero casuale compreso fra 0 e 10 (kg) 
# dichiaro random_ARR_x_old

        
        random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
        random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
        random_ARR_2_new = random_ARR_2_old * (random.random() + 0.5)
        random_ARR_3_new = random_ARR_3_old * (random.random() + 0.5)
        random_ARR_4_new = random_ARR_4_old * (random.random() + 0.5)
        random_ARR_5_new = random_ARR_5_old * (random.random() + 0.5)
        random_ARR_6_new = random_ARR_6_old * (random.random() + 0.5)
        random_ARR_7_new = random_ARR_7_old * (random.random() + 0.5)
        random_ARR_8_new = random_ARR_8_old * (random.random() + 0.5)
        random_ARR_9_new = random_ARR_9_old * (random.random() + 0.5)

# dichiaro random_ARR_x_new
        
        SOMMA_old = random_ARR_0_old + random_ARR_1_old + random_ARR_2_old + random_ARR_3_old + random_ARR_4_old + random_ARR_5_old + random_ARR_6_old + random_ARR_7_old + random_ARR_8_old + random_ARR_9_old
        DELTA_old = SOMMA_old - F_arr
        print('La somma iniziale è...')
        print(SOMMA_old)

# dichiaro SOMMA_old e DELTA_old

        SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new + random_ARR_5_new + random_ARR_6_new + random_ARR_7_new + random_ARR_8_new + random_ARR_9_new
        DELTA_new = SOMMA_new - F_arr
        print('La nuova somma è...')
        print(SOMMA_new)
        print('La nuova differenza è...')
        print(DELTA_new)

# dichiaro SOMMA_new e DELTA_new
        
        quantità_alimento_1 = random_ARR_0_new / ARR[0]
        quantità_alimento_2 = random_ARR_1_new / ARR[1]
        quantità_alimento_3 = random_ARR_2_new / ARR[2]
        quantità_alimento_4 = random_ARR_3_new / ARR[3]
        quantità_alimento_5 = random_ARR_4_new / ARR[4]
        quantità_alimento_6 = random_ARR_5_new / ARR[5]
        quantità_alimento_7 = random_ARR_6_new / ARR[6]
        quantità_alimento_8 = random_ARR_7_new / ARR[7]
        quantità_alimento_9 = random_ARR_8_new / ARR[8]
        quantità_alimento_10 = random_ARR_9_new / ARR[9]

# dichiaro gli apporti dei singoli alimenti

# dichiaro gli apporti dei singoli alimenti

        i = 0

# inizializzo il contatore i        
        
        for i in range(N_repl):
        
            rules = [abs(DELTA_new[0]) < abs(DELTA_old[0]), abs(DELTA_new[1]) < abs(DELTA_old[1]), abs(DELTA_new[2]) < abs(DELTA_old[2])]

# dichiaro le regole da rispettare
                                    
            if all(rules):
            
                print('ESTRAGGO DALLA PROPOSAL DISTRIBUTION')
                i += 1
                print(i)
                                                         	               	        
                random_ARR_0_new = random_ARR_0_new * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_new * (random.random() + 0.5)
                random_ARR_2_new = random_ARR_2_new * (random.random() + 0.5)
                random_ARR_3_new = random_ARR_3_new * (random.random() + 0.5)
                random_ARR_4_new = random_ARR_4_new * (random.random() + 0.5)
                random_ARR_5_new = random_ARR_5_new * (random.random() + 0.5)
                random_ARR_6_new = random_ARR_6_new * (random.random() + 0.5)
                random_ARR_7_new = random_ARR_7_new * (random.random() + 0.5)
                random_ARR_8_new = random_ARR_8_new * (random.random() + 0.5)
                random_ARR_9_new = random_ARR_9_new * (random.random() + 0.5)

# ACCETTO random_ARR_x_new e lo uso per aggiornare random_ARR_x_new stesso 
                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0] + random_ARR_6_new[0] + random_ARR_7_new[0] + random_ARR_8_new[0] + random_ARR_9_new[0]
                print(APPORTO_TOTALE_SOSTANZA_SECCA)

# aggiorno l'apporto di SS
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new + random_ARR_5_new + random_ARR_6_new + random_ARR_7_new + random_ARR_8_new + random_ARR_9_new
                DELTA_new = SOMMA_new - F_arr
                
# aggiorno SOMMA_new e DELTA_new                
                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                quantità_alimento_3 = random_ARR_2_new / ARR[2]
                quantità_alimento_4 = random_ARR_3_new / ARR[3]
                quantità_alimento_5 = random_ARR_4_new / ARR[4]
                quantità_alimento_6 = random_ARR_5_new / ARR[5]
                quantità_alimento_7 = random_ARR_6_new / ARR[6]
                quantità_alimento_8 = random_ARR_7_new / ARR[7]
                quantità_alimento_9 = random_ARR_8_new / ARR[8]
                quantità_alimento_10 = random_ARR_9_new / ARR[9]
                
                if round(APPORTO_TOTALE_SOSTANZA_SECCA) == round(F_arr[0]):
                
                    break
                
                print(i)    
                print("SUCCESSO! L'APPORTO DI SOSTANZA SECCA CORRISPONDE AL FABBISOGNO.")

                    
                    	                
            else:
                    
                random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
                random_ARR_2_new = random_ARR_2_old * (random.random() + 0.5)
                random_ARR_3_new = random_ARR_3_old * (random.random() + 0.5)
                random_ARR_4_new = random_ARR_4_old * (random.random() + 0.5)
                random_ARR_5_new = random_ARR_5_old * (random.random() + 0.5)
                random_ARR_6_new = random_ARR_6_old * (random.random() + 0.5)
                random_ARR_7_new = random_ARR_7_old * (random.random() + 0.5)
                random_ARR_8_new = random_ARR_8_old * (random.random() + 0.5)
                random_ARR_9_new = random_ARR_9_old * (random.random() + 0.5)

# RIFIUTO random_ARR_x_new e lo ricalcolo a partire da random_ARR_x_old 
                
                print('FALLIMENTO')
                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0] + random_ARR_6_new[0] + random_ARR_7_new[0] + random_ARR_8_new[0] + random_ARR_9_new[0]
                print(APPORTO_TOTALE_SOSTANZA_SECCA)
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new + random_ARR_5_new + random_ARR_6_new + random_ARR_7_new + random_ARR_8_new + random_ARR_9_new
                DELTA_new = SOMMA_new - F_arr
                                                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                quantità_alimento_3 = random_ARR_2_new / ARR[2]
                quantità_alimento_4 = random_ARR_3_new / ARR[3]
                quantità_alimento_5 = random_ARR_4_new / ARR[4]
                quantità_alimento_6 = random_ARR_5_new / ARR[5]
                quantità_alimento_7 = random_ARR_6_new / ARR[6]
                quantità_alimento_8 = random_ARR_7_new / ARR[7]
                quantità_alimento_9 = random_ARR_8_new / ARR[8]
                quantità_alimento_10 = random_ARR_9_new / ARR[9]

                
        QUANTITÀ_TOTALE_TAL_QUALE = quantità_alimento_1[0] + quantità_alimento_2[0] + quantità_alimento_3[0] + quantità_alimento_4[0] + quantità_alimento_5[0] + quantità_alimento_6[0] + quantità_alimento_7[0] + quantità_alimento_8[0] + quantità_alimento_9[0] + quantità_alimento_10[0] 
        APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0] + random_ARR_6_new[0] + random_ARR_7_new[0] + random_ARR_8_new[0] + random_ARR_9_new[0]
        APPORTO_TOTALE_PROTEINA_GREZZA = random_ARR_0_new[1] + random_ARR_1_new[1] + random_ARR_2_new[1] + random_ARR_3_new[1] + random_ARR_4_new[1] + random_ARR_5_new[1] + random_ARR_6_new[1] + random_ARR_7_new[1] + random_ARR_8_new[1] + random_ARR_9_new[1]
        APPORTO_TOTALE_PROTEINA_DEGRADABILE = random_ARR_0_new[2] + random_ARR_1_new[2] + random_ARR_2_new[2] + random_ARR_3_new[2] + random_ARR_4_new[2] + random_ARR_5_new[2] + random_ARR_6_new[2] + random_ARR_7_new[2] + random_ARR_8_new[2] + random_ARR_9_new[2]
        APPORTO_TOTALE_PROTEINA_INDEGRADABILE = random_ARR_0_new[3] + random_ARR_1_new[3] + random_ARR_2_new[3] + random_ARR_3_new[3] + random_ARR_4_new[3] + random_ARR_5_new[3] + random_ARR_6_new[3] + random_ARR_7_new[3] + random_ARR_8_new[3] + random_ARR_9_new[3]
        APPORTO_TOTALE_FIBRA_GREZZA = random_ARR_0_new[4] + random_ARR_1_new[4] + random_ARR_2_new[4] + random_ARR_3_new[4] + random_ARR_4_new[4] + random_ARR_5_new[4] + random_ARR_6_new[4] + random_ARR_7_new[4] + random_ARR_8_new[4] + random_ARR_9_new[4]
        APPORTO_TOTALE_NDF = random_ARR_0_new[5] + random_ARR_1_new[5] + random_ARR_2_new[5] + random_ARR_3_new[5] + random_ARR_4_new[5] + random_ARR_5_new[5] + random_ARR_6_new[5] + random_ARR_7_new[5] + random_ARR_8_new[5] + random_ARR_9_new[5]
        APPORTO_TOTALE_ADF = random_ARR_0_new[6] + random_ARR_1_new[6] + random_ARR_2_new[6] + random_ARR_3_new[6] + random_ARR_4_new[6] + random_ARR_5_new[6] + random_ARR_6_new[6] + random_ARR_7_new[6] + random_ARR_8_new[6] + random_ARR_9_new[6]
        APPORTO_TOTALE_GRASSO = random_ARR_0_new[7] + random_ARR_1_new[7] + random_ARR_2_new[7] + random_ARR_3_new[7] + random_ARR_4_new[7] + random_ARR_5_new[7] + random_ARR_6_new[7] + random_ARR_7_new[7] + random_ARR_8_new[7] + random_ARR_9_new[7]
        APPORTO_TOTALE_AMIDO = random_ARR_0_new[8] + random_ARR_1_new[8] + random_ARR_2_new[8] + random_ARR_3_new[8] + random_ARR_4_new[8] + random_ARR_5_new[8] + random_ARR_6_new[8] + random_ARR_7_new[8] + random_ARR_8_new[8] + random_ARR_9_new[8]
        APPORTO_TOTALE_ZUCCHERI = random_ARR_0_new[9] + random_ARR_1_new[9] + random_ARR_2_new[9] + random_ARR_3_new[9] + random_ARR_4_new[9] + random_ARR_5_new[9] + random_ARR_6_new[9] + random_ARR_7_new[9] + random_ARR_8_new[9] + random_ARR_9_new[9]
        APPORTO_TOTALE_Ca = random_ARR_0_new[10] + random_ARR_1_new[10] + random_ARR_2_new[10] + random_ARR_3_new[10] + random_ARR_4_new[10] + random_ARR_5_new[10] + random_ARR_6_new[10] + random_ARR_7_new[10] + random_ARR_8_new[10] + random_ARR_9_new[10]
        APPORTO_TOTALE_P = random_ARR_0_new[11] + random_ARR_1_new[11] + random_ARR_2_new[11] + random_ARR_3_new[11] + random_ARR_4_new[11] + random_ARR_5_new[11] + random_ARR_6_new[11] + random_ARR_7_new[11] + random_ARR_8_new[11] + random_ARR_9_new[11]
        APPORTO_TOTALE_UFL = random_ARR_0_new[12] + random_ARR_1_new[12] + random_ARR_2_new[12] + random_ARR_3_new[12] + random_ARR_4_new[12] + random_ARR_5_new[12] + random_ARR_6_new[12] + random_ARR_7_new[12] + random_ARR_8_new[12] + random_ARR_9_new[12]
        

        DELTA_SOSTANZA_SECCA = APPORTO_TOTALE_SOSTANZA_SECCA - F[0]
        DELTA_PROTEINA_GREZZA = APPORTO_TOTALE_PROTEINA_GREZZA - F[1]
        DELTA_PROTEINA_DEGRADABILE = APPORTO_TOTALE_PROTEINA_DEGRADABILE - F[2]
        DELTA_PROTEINA_INDEGRADABILE = APPORTO_TOTALE_PROTEINA_INDEGRADABILE - F[3]
        DELTA_FIBRA_GREZZA = APPORTO_TOTALE_FIBRA_GREZZA - F[4]
        DELTA_NDF = APPORTO_TOTALE_NDF - F[5]
        DELTA_ADF = APPORTO_TOTALE_ADF - F[6]
        DELTA_GRASSO = APPORTO_TOTALE_GRASSO - F[7]
        DELTA_AMIDO = APPORTO_TOTALE_AMIDO - F[8]
        DELTA_ZUCCHERI = APPORTO_TOTALE_ZUCCHERI - F[9]
        DELTA_Ca = APPORTO_TOTALE_Ca - F[10]
        DELTA_P = APPORTO_TOTALE_P - F[11]
        DELTA_UFL = APPORTO_TOTALE_UFL - F[12]

                
        original = sys.stdout
        sys.stdout = open('NUOVA_RAZIONE.txt', 'w')
        
        
        if day == 'Monday': 
            print('RAZIONE di %s, creata lunedì %s, %s' % (user, data, current_time))
        if day == 'Tuesday': 
            print('RAZIONE di %s, creata martedì %s, %s' % (user, data, current_time))
        if day == 'Wednesday': 
            print('RAZIONE di %s, creata mercoledì %s, %s' % (user, data, current_time))
        if day == 'Thursday': 
            print('RAZIONE di %s, creata giovedì %s, %s' % (user, data, current_time))
        if day == 'Friday': 
            print('RAZIONE di %s, creata venerdì %s, %s' % (user, data, current_time))
        if day == 'Saturday': 
            print('RAZIONE di %s, creata sabato %s, %s' % (user, data, current_time))
        if day == 'Sunday': 
            print('RAZIONE di %s, creata domenica %s, %s' % (user, data, current_time))
        
        
        print('')
#       print('This is your redirected text:')
        print('')
        if i == 999:
            print('Il calcolo della razione non ha avuto successo; per favore chiudi il programma e riprova.')
        else:
            print('Il calcolo della razione è stato effettuato con successo alla %d^esima replica' % i)        
#       print(i)
        print('')
        print('Il fabbisogno di SOSTANZA SECCA è di %f' %  F_arr[0])
        print('')
        print("L'apporto totale di SOSTANZA SECCA è di %f" % APPORTO_TOTALE_SOSTANZA_SECCA)
        print('')
        print('out of loop')
        print('')        
        print('LEGENDA')
        print('')
        print("DMI => Dry Matter Intake (Capacità d'ingestione di Sostanza Secca)")
        print("CPI => Crude Protein Intake (Apporto di Proteina Grezza)")
        print("RDPI => Rumen Degradable Protein Intake (Apporto di Proteina Degradabile)")
        print("RUPI => Rumen Undegradable Protein Intake (Apporto di Proteina Indegradabile)")
        print("FG => Fibra Grezza (apporto di Fibra Grezza)")
        print("NDF => Neutral Detergent Fiber (apporto di Fibra resistente al Detergente Neutro)")
        print("ADF => Acid Detergent Fiber (apporto di Fibra resistente al Detergente Acido)")
        print("FAT => Fat (apporto di Grasso)")
        print("AM => Amido (apporto di Amido)")
        print("ZUC => Zuccheri (apporto di Zuccheri)")
        print("Ca => Calcio (apporto di Calcio)")
        print("P => Fosforo (apporto di Fosforo)")
        print("UFL => Unità Foraggere Latte (apporto di Energia Netta)")
        print('DMI', 'CPI', 'RDPI', 'RUPI', 'FG', 'NDF', 'ADF', 'FAT', 'AM', 'ZUC', 'Ca', 'P', 'UFL')                	                

                                
        print('apporti di %s: \n' % S[0])
        print(random_ARR_0_new)
        print('apporti di %s: \n' % S[1])
        print(random_ARR_1_new)
        print('apporti di %s: \n' % S[2])
        print(random_ARR_2_new)
        print('apporti di %s: \n' % S[3])
        print(random_ARR_3_new)
        print('apporti di %s: \n' % S[4])
        print(random_ARR_4_new)
        print('apporti di %s: \n' % S[5])
        print(random_ARR_5_new)
        print('apporti di %s: \n' % S[6])
        print(random_ARR_6_new)
        print('apporti di %s: \n' % S[7])
        print(random_ARR_7_new)
        print('apporti di %s: \n' % S[8])
        print(random_ARR_8_new)
        print('apporti di %s: \n' % S[9])
        print(random_ARR_9_new)



        
                                
        print('%f kg %s' % (quantità_alimento_1[0], S[0]))
        print('%f kg %s' % (quantità_alimento_2[0], S[1]))
        print('%f kg %s' % (quantità_alimento_3[0], S[2]))
        print('%f kg %s' % (quantità_alimento_4[0], S[3]))
        print('%f kg %s' % (quantità_alimento_5[0], S[4]))
        print('%f kg %s' % (quantità_alimento_6[0], S[5]))
        print('%f kg %s' % (quantità_alimento_7[0], S[6]))
        print('%f kg %s' % (quantità_alimento_8[0], S[7]))
        print('%f kg %s' % (quantità_alimento_9[0], S[8]))
        print('%f kg %s' % (quantità_alimento_10[0], S[9]))
                
        print('La razione fornisce %f kg di alimento tal quale' % QUANTITÀ_TOTALE_TAL_QUALE)
        print('La razione fornisce %f kg di sostanza secca' % APPORTO_TOTALE_SOSTANZA_SECCA)
        
        print("SOSTANZA SECCA: la differenza fra l'apporto totale => %f kg e la capacità d'ingestione => %f kg è: %f kg" % (APPORTO_TOTALE_SOSTANZA_SECCA, F[0], DELTA_SOSTANZA_SECCA))
        print("PROTEINA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_GREZZA, F[1], DELTA_PROTEINA_GREZZA)) 
        print("PROTEINA DEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_DEGRADABILE, F[2], DELTA_PROTEINA_DEGRADABILE))
        print("PROTEINA INDEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_INDEGRADABILE, F[3], DELTA_PROTEINA_INDEGRADABILE))
        print("FIBRA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_FIBRA_GREZZA, F[4], DELTA_FIBRA_GREZZA))
        print("NDF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_NDF, F[5], DELTA_NDF))
        print("ADF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ADF, F[6], DELTA_ADF))
        print("GRASSO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_GRASSO, F[7], DELTA_GRASSO)) 
        print("AMIDO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_AMIDO, F[8], DELTA_AMIDO))
        print("ZUCCHERI: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ZUCCHERI, F[9], DELTA_ZUCCHERI))
        print("Ca: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_Ca, F[10], DELTA_Ca))
        print("P: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_P, F[11], DELTA_P))
        print("UFL: la differenza fra l'apporto totale => %f UFL e il fabbisogno => %f UFL è: %f UFL" % (APPORTO_TOTALE_UFL, F[12], DELTA_UFL))
        
        sys.stdout = original
        print('This string goes to stdout, NOT the file!')

        


               
    else:
        print('ERRORE! Hai inserito un numero di alimenti non previsto. \n')

    
    with open('alimenti.txt', 'w') as external_file:
        print(S, file=external_file)
    external_file.close()
    
    with open('vettori.txt', 'w') as external_file:
        print(ARR, file=external_file)
    external_file.close()
    
    with open('fabbisogni.txt', 'w') as external_file:
        print(F, file=external_file)
    external_file.close()
    

    
    
###############################################################################################################################        
###############################################################################################################################





def apporto_insilato_mais():
    global M, Q, app_MAIS, app_INSIMA, Q_INSIMA, INSIMA_arr, F_arr_ric
    from crea_db_PREZZI_Alessandria_w import prezzo_MAIS_INSILATO
    prezzo_MAIS_INSILATO = float(prezzo_MAIS_INSILATO)
    Q_INSIMA = askfloat('Entry', 'Inserisci la quantità di insilato (in kg) \n')
    Q = Q_INSIMA
    os.system('python crea_db_FABBISOGNI_w.py')
    from crea_db_FABBISOGNI_w import F    
    from importa_MySQLdb_insilato_mais import INSIMA_arr
    M = 'insilato di mais'
    app_INSIMA = Q_INSIMA * INSIMA_arr
    app_MAIS = app_INSIMA
    F_arr = np.array(F)
    F_arr_ric = F_arr - app_INSIMA     
    print('Hai inserito %f kg di insilato di mais' % Q_INSIMA)

def apporto_pastone_mais_integrale():
    global M, Q, app_MAIS, app_PASTOMAISINT, Q_PASTOMAISINT, PASTOMAISINT_arr, F_arr_ric
    Q_PASTOMAISINT = askfloat('Entry', 'Inserisci la quantità di pastone integrale (in kg) \n')
    Q = Q_PASTOMAISINT
    os.system('python crea_db_FABBISOGNI_w.py')
    from crea_db_FABBISOGNI_w import F
    from importa_MySQLdb_pastone_mais_integrale import PASTOMAISINT_arr
    M = 'pastone mais integrale'
    app_PASTOMAISINT = Q_PASTOMAISINT * PASTOMAISINT_arr
    app_MAIS = app_PASTOMAISINT 
    F_arr = np.array(F)
    F_arr_ric = F_arr - app_PASTOMAISINT     
    print('Hai inserito %f kg di pastone integrale di mais' % Q_PASTOMAISINT)
    
def apporto_pastone_mais_granella():
    global M, Q, app_MAIS, app_PASTOMAISGRA, Q_PASTOMAISGRA, PASTOMAISGRA_arr, F_arr_ric
    Q_PASTOMAISGRA = askfloat('Entry', 'Inserisci la quantità di pastone granella (in kg) \n')
    Q = Q_PASTOMAISGRA
    os.system('python crea_db_FABBISOGNI_w.py')
    from crea_db_FABBISOGNI_w import F
    from importa_MySQLdb_pastone_mais_granella import PASTOMAISGRA_arr
    M = 'pastone mais granella'
    app_PASTOMAISGRA = Q_PASTOMAISGRA * PASTOMAISGRA_arr
    app_MAIS = app_PASTOMAISGRA 
    F_arr = np.array(F)
    F_arr_ric = F_arr - app_PASTOMAISGRA     
    print('Hai inserito %f kg di pastone di mais granella' % Q_PASTOMAISGRA)

def apporto_mais_granella():
    global MG, QM, app_MAISGRA, Q_MAISGRA, MAISGRA_arr, F_arr_ric, F_arr_ricalcolato
    Q_MAISGRA = askfloat('Entry', 'Inserisci la quantità di mais granella (in kg) \n')
    QM = Q_MAISGRA
    os.system('python crea_db_FABBISOGNI_w.py')
    from crea_db_FABBISOGNI_w import F
    from importa_MySQLdb_mais_granella import MAISGRA_arr
    MG = 'mais granella'
    app_MAISGRA = Q_MAISGRA * MAISGRA_arr 
    F_arr = np.array(F)
    F_arr_ricalcolato = F_arr_ric - app_MAISGRA     
    print('Hai inserito %f kg di mais granella' % Q_MAISGRA)

   
###############################################################################################################################        
###############################################################################################################################



def ricalcola_razione():

    import random
    
    os.system('python crea_db_FABBISOGNI_w.py')
    from crea_db_FABBISOGNI_w import F
    print(F)
#   print('Questo è il vettore <F>')
#   print('Riga 2630')
    
    from crea_db_PARAMETRI_w import N_repl
    
        
    print('capacità di ingestione => %f kg di sostanza secca,' % F[0])
    print('fabbisogno di proteina grezza => %f g,' % F[1])
    print('fabbisogno di proteina degradabile => %f g,' % F[2])
    print('fabbisogno di proteina indegradabile => %f g,' % F[3])
    print('fabbisogno di fibra grezza => %f g,' % F[4])
    print('fabbisogno di Neutral Detergent Fiber => %f g,' % F[5])
    print('fabbisogno di Acid Detergent Fiber => %f g,' % F[6]) 
    print('fabbisogno di grasso => %f g,' % F[7])
    print('fabbisogno di amido => %f g,' % F[8])
    print('fabbisogno di zuccheri) => %f g,' % F[9])
    print('fabbisogno totale di Ca => %f g,' % F[10])
    print('fabbisogno totale di P => %f g,' % F[11])
    print('fabbisogno energetico totale => %f Unità Foraggere Latte. \n' % F[12])
    
    
    global F_arr_ric, F_arr_ricalcolato
    F_arr = np.array(F)
#   print("Sono arrivato alla riga 2627: <F_arr = np.array(F)>")
#   print('Il vettore <F_arr> è stato calcolato correttamente')
    
    print(F_arr)
    print('Questo è il vettore <F_arr>')
    print('Riga 2627')
    
#   F_arr_ric = []
#   F_arr_ricalcolato = []
    
    if Q_MAISGRA:
        F_arr_ric = F_arr_ricalcolato
        F_arr = F_arr_ric        
        print(F_arr_ricalcolato)
         
    else:
        F_arr_ric = F_arr_ric
        F_arr = F_arr_ric
        print(F_arr_ric)
        

    print(F)
    print(F_arr)


    if len(S) == 2:                    
        print(S[0])
        print(S[1])
        print(ARR[0])
        print(ARR[1])
        
        
        print('Hai inserito 2 alimenti \n')

#       print("QUESTA È LA VERSIONE CORRETTA DELL'ALGORITMO")
        
        random_ARR_0_old = ARR[0] * random.random() * 10
        random_ARR_1_old = ARR[1] * random.random() * 10
        
        
# ogni alimento scelto dall'utente viene moltiplicato per un numero casuale compreso fra 0 e 10 (kg) 
# dichiaro random_ARR_x_old

        
        random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
        random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
        
        
# dichiaro random_ARR_x_new
        
        SOMMA_old = random_ARR_0_old + random_ARR_1_old
        DELTA_old = SOMMA_old - F_arr
        print('La somma iniziale è...')
        print(SOMMA_old)

# dichiaro SOMMA_old e DELTA_old

        SOMMA_new = random_ARR_0_new + random_ARR_1_new
        DELTA_new = SOMMA_new - F_arr
        print('La nuova somma è...')
        print(SOMMA_new)
        print('La nuova differenza è...')
        print(DELTA_new)

# dichiaro SOMMA_new e DELTA_new
        
        quantità_alimento_1 = random_ARR_0_new / ARR[0]
        quantità_alimento_2 = random_ARR_1_new / ARR[1]
        
        
# dichiaro gli apporti dei singoli alimenti

        i = 0

# inizializzo il contatore i        
        
        for i in range(N_repl):
        
            rules = [abs(DELTA_new[0]) < abs(DELTA_old[0]), abs(DELTA_new[1]) < abs(DELTA_old[1]), abs(DELTA_new[2]) < abs(DELTA_old[2])]

# dichiaro le regole da rispettare
                                    
            if all(rules):
            
                print('ESTRAGGO DALLA PROPOSAL DISTRIBUTION')
                i += 1
                print(i)
                                                         	               	        
                random_ARR_0_new = random_ARR_0_new * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_new * (random.random() + 0.5)
                
                
# ACCETTO random_ARR_x_new e lo uso per aggiornare random_ARR_x_new stesso 
                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0]
                print(APPORTO_TOTALE_SOSTANZA_SECCA)

# aggiorno l'apporto di SS
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new
                DELTA_new = SOMMA_new - F_arr
                
# aggiorno SOMMA_new e DELTA_new                
                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                
                
                
                if round(APPORTO_TOTALE_SOSTANZA_SECCA) == round(F_arr[0]):
                
                    break
                
                print(i)    
                print("SUCCESSO! L'APPORTO DI SOSTANZA SECCA CORRISPONDE AL FABBISOGNO.")

                    	                
            else:
                    
                random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
                
                
# RIFIUTO random_ARR_x_new e lo ricalcolo a partire da random_ARR_x_old 
                
                print('FALLIMENTO')



                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0]
                print(APPORTO_TOTALE_SOSTANZA_SECCA)
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new
                DELTA_new = SOMMA_new - F_arr
                                                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                

        if QM:
        
            QUANTITÀ_TOTALE_TAL_QUALE = QM + Q + quantità_alimento_1[0] + quantità_alimento_2[0]
            APPORTO_DEFINITIVO_SOSTANZA_SECCA = app_MAISGRA[0] + app_MAIS[0] + random_ARR_0_new[0] + random_ARR_1_new[0] 
            APPORTO_TOTALE_PROTEINA_GREZZA = app_MAISGRA[1] + app_MAIS[1] + random_ARR_0_new[1] + random_ARR_1_new[1]
            APPORTO_TOTALE_PROTEINA_DEGRADABILE = app_MAISGRA[2] + app_MAIS[2] + random_ARR_0_new[2] + random_ARR_1_new[2]
            APPORTO_TOTALE_PROTEINA_INDEGRADABILE = app_MAISGRA[3] + app_MAIS[3] + random_ARR_0_new[3] + random_ARR_1_new[3]
            APPORTO_TOTALE_FIBRA_GREZZA = app_MAISGRA[4] + app_MAIS[4] + random_ARR_0_new[4] + random_ARR_1_new[4]
            APPORTO_TOTALE_NDF = app_MAISGRA[5] + app_MAIS[5] + random_ARR_0_new[5] + random_ARR_1_new[5]
            APPORTO_TOTALE_ADF = app_MAISGRA[6] + app_MAIS[6] + random_ARR_0_new[6] + random_ARR_1_new[6]
            APPORTO_TOTALE_GRASSO = app_MAISGRA[7] + app_MAIS[7] + random_ARR_0_new[7] + random_ARR_1_new[7]
            APPORTO_TOTALE_AMIDO = app_MAISGRA[8] + app_MAIS[8] + random_ARR_0_new[8] + random_ARR_1_new[8]
            APPORTO_TOTALE_ZUCCHERI = app_MAISGRA[9] + app_MAIS[9] + random_ARR_0_new[9] + random_ARR_1_new[9]
            APPORTO_TOTALE_Ca = app_MAISGRA[10] + app_MAIS[10] + random_ARR_0_new[10] + random_ARR_1_new[10]
            APPORTO_TOTALE_P = app_MAISGRA[11] + app_MAIS[11] + random_ARR_0_new[11] + random_ARR_1_new[11]
            APPORTO_TOTALE_UFL = app_MAISGRA[12] + app_MAIS[12] + random_ARR_0_new[12] + random_ARR_1_new[12]

        else:
                                                             
            QUANTITÀ_TOTALE_TAL_QUALE = Q + quantità_alimento_1[0] + quantità_alimento_2[0]
            APPORTO_DEFINITIVO_SOSTANZA_SECCA = app_MAIS[0] + random_ARR_0_new[0] + random_ARR_1_new[0] 
            APPORTO_TOTALE_PROTEINA_GREZZA = app_MAIS[1] + random_ARR_0_new[1] + random_ARR_1_new[1]
            APPORTO_TOTALE_PROTEINA_DEGRADABILE = app_MAIS[2] + random_ARR_0_new[2] + random_ARR_1_new[2]
            APPORTO_TOTALE_PROTEINA_INDEGRADABILE = app_MAIS[3] + random_ARR_0_new[3] + random_ARR_1_new[3]
            APPORTO_TOTALE_FIBRA_GREZZA = app_MAIS[4] + random_ARR_0_new[4] + random_ARR_1_new[4]
            APPORTO_TOTALE_NDF = app_MAIS[5] + random_ARR_0_new[5] + random_ARR_1_new[5]
            APPORTO_TOTALE_ADF = app_MAIS[6] + random_ARR_0_new[6] + random_ARR_1_new[6]
            APPORTO_TOTALE_GRASSO = app_MAIS[7] + random_ARR_0_new[7] + random_ARR_1_new[7]
            APPORTO_TOTALE_AMIDO = app_MAIS[8] + random_ARR_0_new[8] + random_ARR_1_new[8]
            APPORTO_TOTALE_ZUCCHERI = app_MAIS[9] + random_ARR_0_new[9] + random_ARR_1_new[9]
            APPORTO_TOTALE_Ca = app_MAIS[10] + random_ARR_0_new[10] + random_ARR_1_new[10]
            APPORTO_TOTALE_P = app_MAIS[11] + random_ARR_0_new[11] + random_ARR_1_new[11]
            APPORTO_TOTALE_UFL = app_MAIS[12] + random_ARR_0_new[12] + random_ARR_1_new[12]
        
        DELTA_SOSTANZA_SECCA = APPORTO_DEFINITIVO_SOSTANZA_SECCA - F[0]
        DELTA_PROTEINA_GREZZA = APPORTO_TOTALE_PROTEINA_GREZZA - F[1]
        DELTA_PROTEINA_DEGRADABILE = APPORTO_TOTALE_PROTEINA_DEGRADABILE - F[2]
        DELTA_PROTEINA_INDEGRADABILE = APPORTO_TOTALE_PROTEINA_INDEGRADABILE - F[3]
        DELTA_FIBRA_GREZZA = APPORTO_TOTALE_FIBRA_GREZZA - F[4]
        DELTA_NDF = APPORTO_TOTALE_NDF - F[5]
        DELTA_ADF = APPORTO_TOTALE_ADF - F[6]
        DELTA_GRASSO = APPORTO_TOTALE_GRASSO - F[7]
        DELTA_AMIDO = APPORTO_TOTALE_AMIDO - F[8]
        DELTA_ZUCCHERI = APPORTO_TOTALE_ZUCCHERI - F[9]
        DELTA_Ca = APPORTO_TOTALE_Ca - F[10]
        DELTA_P = APPORTO_TOTALE_P - F[11]
        DELTA_UFL = APPORTO_TOTALE_UFL - F[12]
    
                                        
        original = sys.stdout
        sys.stdout = open('NUOVA_RAZIONE.txt', 'w')
        
        
        if day == 'Monday': 
            print('RAZIONE di %s, creata lunedì %s, %s' % (user, data, current_time))
        if day == 'Tuesday': 
            print('RAZIONE di %s, creata martedì %s, %s' % (user, data, current_time))
        if day == 'Wednesday': 
            print('RAZIONE di %s, creata mercoledì %s, %s' % (user, data, current_time))
        if day == 'Thursday': 
            print('RAZIONE di %s, creata giovedì %s, %s' % (user, data, current_time))
        if day == 'Friday': 
            print('RAZIONE di %s, creata venerdì %s, %s' % (user, data, current_time))
        if day == 'Saturday': 
            print('RAZIONE di %s, creata sabato %s, %s' % (user, data, current_time))
        if day == 'Sunday': 
            print('RAZIONE di %s, creata domenica %s, %s' % (user, data, current_time))
        
        
        print('')
#       print('This is your redirected text:')
        print('')
        if i == 999:
            print('Il calcolo della razione non ha avuto successo; per favore chiudi il programma e riprova.')
        else:
            print('Il calcolo della razione è stato effettuato con successo alla %d^esima replica' % i)        
#       print(i)
        print('')
        print('Il fabbisogno di SOSTANZA SECCA è di %f' %  F_arr[0])
        print('')
        print("L'apporto totale di SOSTANZA SECCA è di %f" % APPORTO_TOTALE_SOSTANZA_SECCA)
        print('')
        print('out of loop')
        print('')        
        print('LEGENDA')
        print('')
        print("DMI => Dry Matter Intake (Capacità d'ingestione di Sostanza Secca)")
        print("CPI => Crude Protein Intake (Apporto di Proteina Grezza)")
        print("RDPI => Rumen Degradable Protein Intake (Apporto di Proteina Degradabile)")
        print("RUPI => Rumen Undegradable Protein Intake (Apporto di Proteina Indegradabile)")
        print("FG => Fibra Grezza (apporto di Fibra Grezza)")
        print("NDF => Neutral Detergent Fiber (apporto di Fibra resistente al Detergente Neutro)")
        print("ADF => Acid Detergent Fiber (apporto di Fibra resistente al Detergente Acido)")
        print("FAT => Fat (apporto di Grasso)")
        print("AM => Amido (apporto di Amido)")
        print("ZUC => Zuccheri (apporto di Zuccheri)")
        print("Ca => Calcio (apporto di Calcio)")
        print("P => Fosforo (apporto di Fosforo)")
        print("UFL => Unità Foraggere Latte (apporto di Energia Netta)")
        print('DMI', 'CPI', 'RDPI', 'RUPI', 'FG', 'NDF', 'ADF', 'FAT', 'AM', 'ZUC', 'Ca', 'P', 'UFL')                	                
        	                
        if MG:
        
            print('apporti di %s: \n' % M)
            print(app_MAIS)
            print('apporti di %s: \n' % MG)
            print(app_MAISGRA)                        
            print('apporti di %s: \n' % S[0])
            print(random_ARR_0_new)
            print('apporti di %s: \n' % S[1])
            print(random_ARR_1_new)
            
        else:
        
            print('apporti di %s: \n' % M)
            print(app_MAIS)
            print('apporti di %s: \n' % S[0])
            print(random_ARR_0_new)
            print('apporti di %s: \n' % S[1])
            print(random_ARR_1_new)
                
        
        if M == 'insilato di mais':
            print('La razione fornisce %f kg di %s' % (Q_INSIMA, M))
            
            
        elif M == 'pastone mais integrale':
            print('La razione fornisce %f kg di %s\n' % (Q_PASTOMAISINT, M))
            
            
        elif M == 'pastone mais granella':
            print('La razione fornisce %f kg di %s\n' % (Q_PASTOMAISGRA, M))
            

        
        if Q_MAISGRA:
            print('La razione fornisce %f kg di %s\n' % (QM, MG))
            print('%f kg %s' % (QM, MG))                                         
            print('%f kg %s' % (Q, M))                        
            print('%f kg %s' % (quantità_alimento_1[0], S[0]))
            print('%f kg %s' % (quantità_alimento_2[0], S[1]))
            
        else:
            print('%f kg %s' % (Q, M))                        
            print('%f kg %s' % (quantità_alimento_1[0], S[0]))
            print('%f kg %s' % (quantità_alimento_2[0], S[1]))

                                
        print('La razione fornisce %f kg di alimento tal quale' % QUANTITÀ_TOTALE_TAL_QUALE)
        print('La razione fornisce %f kg di sostanza secca' % APPORTO_DEFINITIVO_SOSTANZA_SECCA)
        
        print("SOSTANZA SECCA: la differenza fra l'apporto totale => %f kg e la capacità d'ingestione => %f kg è: %f kg" % (APPORTO_DEFINITIVO_SOSTANZA_SECCA, F[0], DELTA_SOSTANZA_SECCA))
        print("PROTEINA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_GREZZA, F[1], DELTA_PROTEINA_GREZZA)) 
        print("PROTEINA DEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_DEGRADABILE, F[2], DELTA_PROTEINA_DEGRADABILE))
        print("PROTEINA INDEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_INDEGRADABILE, F[3], DELTA_PROTEINA_INDEGRADABILE))
        print("FIBRA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_FIBRA_GREZZA, F[4], DELTA_FIBRA_GREZZA))
        print("NDF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_NDF, F[5], DELTA_NDF))
        print("ADF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ADF, F[6], DELTA_ADF))
        print("GRASSO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_GRASSO, F[7], DELTA_GRASSO)) 
        print("AMIDO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_AMIDO, F[8], DELTA_AMIDO))
        print("ZUCCHERI: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ZUCCHERI, F[9], DELTA_ZUCCHERI))
        print("Ca: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_Ca, F[10], DELTA_Ca))
        print("P: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_P, F[11], DELTA_P))
        print("UFL: la differenza fra l'apporto totale => %f UFL e il fabbisogno => %f UFL è: %f UFL" % (APPORTO_TOTALE_UFL, F[12], DELTA_UFL))
        
        sys.stdout = original
        print('This string goes to stdout, NOT the file!')



    elif len(S) == 3:                    
        print(S[0])
        print(S[1])
        print(S[2])
        print(ARR[0])
        print(ARR[1])
        print(ARR[2])
        
        print('Hai inserito 3 alimenti \n')

#       print("QUESTA È LA VERSIONE CORRETTA DELL'ALGORITMO")
        
        random_ARR_0_old = ARR[0] * random.random() * 10
        random_ARR_1_old = ARR[1] * random.random() * 10
        random_ARR_2_old = ARR[2] * random.random() * 10
        
# ogni alimento scelto dall'utente viene moltiplicato per un numero casuale compreso fra 0 e 10 (kg) 
# dichiaro random_ARR_x_old

        
        random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
        random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
        random_ARR_2_new = random_ARR_2_old * (random.random() + 0.5)
        
# dichiaro random_ARR_x_new
        
        SOMMA_old = random_ARR_0_old + random_ARR_1_old + random_ARR_2_old
        DELTA_old = SOMMA_old - F_arr
        print('La somma iniziale è...')
        print(SOMMA_old)

# dichiaro SOMMA_old e DELTA_old

        SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new
        DELTA_new = SOMMA_new - F_arr
        print('La nuova somma è...')
        print(SOMMA_new)
        print('La nuova differenza è...')
        print(DELTA_new)

# dichiaro SOMMA_new e DELTA_new
        
        quantità_alimento_1 = random_ARR_0_new / ARR[0]
        quantità_alimento_2 = random_ARR_1_new / ARR[1]
        quantità_alimento_3 = random_ARR_2_new / ARR[2]
        
# dichiaro gli apporti dei singoli alimenti

        i = 0

# inizializzo il contatore i        
        
        for i in range(N_repl):
        
            rules = [abs(DELTA_new[0]) < abs(DELTA_old[0]), abs(DELTA_new[1]) < abs(DELTA_old[1]), abs(DELTA_new[2]) < abs(DELTA_old[2])]

# dichiaro le regole da rispettare
                                    
            if all(rules):
            
                print('ESTRAGGO DALLA PROPOSAL DISTRIBUTION')
                i += 1
                print(i)
                                                         	               	        
                random_ARR_0_new = random_ARR_0_new * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_new * (random.random() + 0.5)
                random_ARR_2_new = random_ARR_2_new * (random.random() + 0.5)
                
# ACCETTO random_ARR_x_new e lo uso per aggiornare random_ARR_x_new stesso 
                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0]
                print(APPORTO_TOTALE_SOSTANZA_SECCA)

# aggiorno l'apporto di SS
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new
                DELTA_new = SOMMA_new - F_arr
                
# aggiorno SOMMA_new e DELTA_new                
                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                quantità_alimento_3 = random_ARR_2_new / ARR[2]
                
                
                if round(APPORTO_TOTALE_SOSTANZA_SECCA) == round(F_arr[0]):
                
                    break
                
                print(i)    
                print("SUCCESSO! L'APPORTO DI SOSTANZA SECCA CORRISPONDE AL FABBISOGNO.")

                    	                
            else:
                    
                random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
                random_ARR_2_new = random_ARR_2_old * (random.random() + 0.5)
                
# RIFIUTO random_ARR_x_new e lo ricalcolo a partire da random_ARR_x_old 
                
                print('FALLIMENTO')

    
                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0]
                print(APPORTO_TOTALE_SOSTANZA_SECCA)
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new
                DELTA_new = SOMMA_new - F_arr
                                                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                quantità_alimento_3 = random_ARR_2_new / ARR[2]
                

        if QM:
        
            QUANTITÀ_TOTALE_TAL_QUALE = QM + Q + quantità_alimento_1[0] + quantità_alimento_2[0] + quantità_alimento_3[0]
            APPORTO_DEFINITIVO_SOSTANZA_SECCA = app_MAISGRA[0] + app_MAIS[0] + random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] 
            APPORTO_TOTALE_PROTEINA_GREZZA = app_MAISGRA[1] + app_MAIS[1] + random_ARR_0_new[1] + random_ARR_1_new[1] + random_ARR_2_new[1]
            APPORTO_TOTALE_PROTEINA_DEGRADABILE = app_MAISGRA[2] + app_MAIS[2] + random_ARR_0_new[2] + random_ARR_1_new[2] + random_ARR_2_new[2]
            APPORTO_TOTALE_PROTEINA_INDEGRADABILE = app_MAISGRA[3] + app_MAIS[3] + random_ARR_0_new[3] + random_ARR_1_new[3] + random_ARR_2_new[3]
            APPORTO_TOTALE_FIBRA_GREZZA = app_MAISGRA[4] + app_MAIS[4] + random_ARR_0_new[4] + random_ARR_1_new[4] + random_ARR_2_new[4]
            APPORTO_TOTALE_NDF = app_MAISGRA[5] + app_MAIS[5] + random_ARR_0_new[5] + random_ARR_1_new[5] + random_ARR_2_new[5]
            APPORTO_TOTALE_ADF = app_MAISGRA[6] + app_MAIS[6] + random_ARR_0_new[6] + random_ARR_1_new[6] + random_ARR_2_new[6]
            APPORTO_TOTALE_GRASSO = app_MAISGRA[7] + app_MAIS[7] + random_ARR_0_new[7] + random_ARR_1_new[7] + random_ARR_2_new[7]
            APPORTO_TOTALE_AMIDO = app_MAISGRA[8] + app_MAIS[8] + random_ARR_0_new[8] + random_ARR_1_new[8] + random_ARR_2_new[8]
            APPORTO_TOTALE_ZUCCHERI = app_MAISGRA[9] + app_MAIS[9] + random_ARR_0_new[9] + random_ARR_1_new[9] + random_ARR_2_new[9]
            APPORTO_TOTALE_Ca = app_MAISGRA[10] + app_MAIS[10] + random_ARR_0_new[10] + random_ARR_1_new[10] + random_ARR_2_new[10]
            APPORTO_TOTALE_P = app_MAISGRA[11] + app_MAIS[11] + random_ARR_0_new[11] + random_ARR_1_new[11] + random_ARR_2_new[11]
            APPORTO_TOTALE_UFL = app_MAISGRA[12] + app_MAIS[12] + random_ARR_0_new[12] + random_ARR_1_new[12] + random_ARR_2_new[12]

        
        else:                                             
        
            QUANTITÀ_TOTALE_TAL_QUALE = Q + quantità_alimento_1[0] + quantità_alimento_2[0] + quantità_alimento_3[0]
            APPORTO_DEFINITIVO_SOSTANZA_SECCA = app_MAIS[0] + random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] 
            APPORTO_TOTALE_PROTEINA_GREZZA = app_MAIS[1] + random_ARR_0_new[1] + random_ARR_1_new[1] + random_ARR_2_new[1]
            APPORTO_TOTALE_PROTEINA_DEGRADABILE = app_MAIS[2] + random_ARR_0_new[2] + random_ARR_1_new[2] + random_ARR_2_new[2]
            APPORTO_TOTALE_PROTEINA_INDEGRADABILE = app_MAIS[3] + random_ARR_0_new[3] + random_ARR_1_new[3] + random_ARR_2_new[3]
            APPORTO_TOTALE_FIBRA_GREZZA = app_MAIS[4] + random_ARR_0_new[4] + random_ARR_1_new[4] + random_ARR_2_new[4]
            APPORTO_TOTALE_NDF = app_MAIS[5] + random_ARR_0_new[5] + random_ARR_1_new[5] + random_ARR_2_new[5]
            APPORTO_TOTALE_ADF = app_MAIS[6] + random_ARR_0_new[6] + random_ARR_1_new[6] + random_ARR_2_new[6]
            APPORTO_TOTALE_GRASSO = app_MAIS[7] + random_ARR_0_new[7] + random_ARR_1_new[7] + random_ARR_2_new[7]
            APPORTO_TOTALE_AMIDO = app_MAIS[8] + random_ARR_0_new[8] + random_ARR_1_new[8] + random_ARR_2_new[8]
            APPORTO_TOTALE_ZUCCHERI = app_MAIS[9] + random_ARR_0_new[9] + random_ARR_1_new[9] + random_ARR_2_new[9]
            APPORTO_TOTALE_Ca = app_MAIS[10] + random_ARR_0_new[10] + random_ARR_1_new[10] + random_ARR_2_new[10]
            APPORTO_TOTALE_P = app_MAIS[11] + random_ARR_0_new[11] + random_ARR_1_new[11] + random_ARR_2_new[11]
            APPORTO_TOTALE_UFL = app_MAIS[12] + random_ARR_0_new[12] + random_ARR_1_new[12] + random_ARR_2_new[12]
        
        DELTA_SOSTANZA_SECCA = APPORTO_DEFINITIVO_SOSTANZA_SECCA - F[0]
        DELTA_PROTEINA_GREZZA = APPORTO_TOTALE_PROTEINA_GREZZA - F[1]
        DELTA_PROTEINA_DEGRADABILE = APPORTO_TOTALE_PROTEINA_DEGRADABILE - F[2]
        DELTA_PROTEINA_INDEGRADABILE = APPORTO_TOTALE_PROTEINA_INDEGRADABILE - F[3]
        DELTA_FIBRA_GREZZA = APPORTO_TOTALE_FIBRA_GREZZA - F[4]
        DELTA_NDF = APPORTO_TOTALE_NDF - F[5]
        DELTA_ADF = APPORTO_TOTALE_ADF - F[6]
        DELTA_GRASSO = APPORTO_TOTALE_GRASSO - F[7]
        DELTA_AMIDO = APPORTO_TOTALE_AMIDO - F[8]
        DELTA_ZUCCHERI = APPORTO_TOTALE_ZUCCHERI - F[9]
        DELTA_Ca = APPORTO_TOTALE_Ca - F[10]
        DELTA_P = APPORTO_TOTALE_P - F[11]
        DELTA_UFL = APPORTO_TOTALE_UFL - F[12]
    
                                        
        original = sys.stdout
        sys.stdout = open('NUOVA_RAZIONE.txt', 'w')
        
        
        if day == 'Monday': 
            print('RAZIONE di %s, creata lunedì %s, %s' % (user, data, current_time))
        if day == 'Tuesday': 
            print('RAZIONE di %s, creata martedì %s, %s' % (user, data, current_time))
        if day == 'Wednesday': 
            print('RAZIONE di %s, creata mercoledì %s, %s' % (user, data, current_time))
        if day == 'Thursday': 
            print('RAZIONE di %s, creata giovedì %s, %s' % (user, data, current_time))
        if day == 'Friday': 
            print('RAZIONE di %s, creata venerdì %s, %s' % (user, data, current_time))
        if day == 'Saturday': 
            print('RAZIONE di %s, creata sabato %s, %s' % (user, data, current_time))
        if day == 'Sunday': 
            print('RAZIONE di %s, creata domenica %s, %s' % (user, data, current_time))
        
        
        print('')
#       print('This is your redirected text:')
        print('')
        if i == 999:
            print('Il calcolo della razione non ha avuto successo; per favore chiudi il programma e riprova.')
        else:
            print('Il calcolo della razione è stato effettuato con successo alla %d^esima replica' % i)        
#       print(i)
        print('')
        print('Il fabbisogno di SOSTANZA SECCA è di %f' %  F_arr[0])
        print('')
        print("L'apporto totale di SOSTANZA SECCA è di %f" % APPORTO_TOTALE_SOSTANZA_SECCA)
        print('')
        print('out of loop')
        print('')        
        print('LEGENDA')
        print('')
        print("DMI => Dry Matter Intake (Capacità d'ingestione di Sostanza Secca)")
        print("CPI => Crude Protein Intake (Apporto di Proteina Grezza)")
        print("RDPI => Rumen Degradable Protein Intake (Apporto di Proteina Degradabile)")
        print("RUPI => Rumen Undegradable Protein Intake (Apporto di Proteina Indegradabile)")
        print("FG => Fibra Grezza (apporto di Fibra Grezza)")
        print("NDF => Neutral Detergent Fiber (apporto di Fibra resistente al Detergente Neutro)")
        print("ADF => Acid Detergent Fiber (apporto di Fibra resistente al Detergente Acido)")
        print("FAT => Fat (apporto di Grasso)")
        print("AM => Amido (apporto di Amido)")
        print("ZUC => Zuccheri (apporto di Zuccheri)")
        print("Ca => Calcio (apporto di Calcio)")
        print("P => Fosforo (apporto di Fosforo)")
        print("UFL => Unità Foraggere Latte (apporto di Energia Netta)")
        print('DMI', 'CPI', 'RDPI', 'RUPI', 'FG', 'NDF', 'ADF', 'FAT', 'AM', 'ZUC', 'Ca', 'P', 'UFL')                	                
        	                
        if MG:
        
            print('apporti di %s: \n' % M)
            print(app_MAIS)
            print('apporti di %s: \n' % MG)
            print(app_MAISGRA)                        
            print('apporti di %s: \n' % S[0])
            print(random_ARR_0_new)
            print('apporti di %s: \n' % S[1])
            print(random_ARR_1_new)
            print('apporti di %s: \n' % S[2])
            print(random_ARR_2_new)
            
        else:
        
            print('apporti di %s: \n' % M)
            print(app_MAIS)
            print('apporti di %s: \n' % S[0])
            print(random_ARR_0_new)
            print('apporti di %s: \n' % S[1])
            print(random_ARR_1_new)
            print('apporti di %s: \n' % S[2])
            print(random_ARR_2_new)

                                
        print('apporti di %s: \n' % S[0])
        print(random_ARR_0_new)
        print('apporti di %s: \n' % S[1])
        print(random_ARR_1_new)
        
        

        if M == 'insilato di mais':
            print('La razione fornisce %f kg di %s' % (Q_INSIMA, M))
            
            
        elif M == 'pastone mais integrale':
            print('La razione fornisce %f kg di %s\n' % (Q_PASTOMAISINT, M))
            
            
        elif M == 'pastone mais granella':
            print('La razione fornisce %f kg di %s\n' % (Q_PASTOMAISGRA, M))
            

        if Q_MAISGRA:
            print('La razione fornisce %f kg di %s\n' % (QM, MG))
            print('%f kg %s' % (QM, MG))                                         
            print('%f kg %s' % (Q, M))                        
            print('%f kg %s' % (quantità_alimento_1[0], S[0]))
            print('%f kg %s' % (quantità_alimento_2[0], S[1]))
            print('%f kg %s' % (quantità_alimento_3[0], S[2]))
            
        else:
            print('%f kg %s' % (Q, M))                        
            print('%f kg %s' % (quantità_alimento_1[0], S[0]))
            print('%f kg %s' % (quantità_alimento_2[0], S[1]))
            print('%f kg %s' % (quantità_alimento_3[0], S[2]))

                                                
        print('La razione fornisce %f kg di alimento tal quale' % QUANTITÀ_TOTALE_TAL_QUALE)
        print('La razione fornisce %f kg di sostanza secca' % APPORTO_DEFINITIVO_SOSTANZA_SECCA)
        
        print("SOSTANZA SECCA: la differenza fra l'apporto totale => %f kg e la capacità d'ingestione => %f kg è: %f kg" % (APPORTO_DEFINITIVO_SOSTANZA_SECCA, F[0], DELTA_SOSTANZA_SECCA))
        print("PROTEINA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_GREZZA, F[1], DELTA_PROTEINA_GREZZA)) 
        print("PROTEINA DEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_DEGRADABILE, F[2], DELTA_PROTEINA_DEGRADABILE))
        print("PROTEINA INDEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_INDEGRADABILE, F[3], DELTA_PROTEINA_INDEGRADABILE))
        print("FIBRA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_FIBRA_GREZZA, F[4], DELTA_FIBRA_GREZZA))
        print("NDF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_NDF, F[5], DELTA_NDF))
        print("ADF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ADF, F[6], DELTA_ADF))
        print("GRASSO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_GRASSO, F[7], DELTA_GRASSO)) 
        print("AMIDO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_AMIDO, F[8], DELTA_AMIDO))
        print("ZUCCHERI: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ZUCCHERI, F[9], DELTA_ZUCCHERI))
        print("Ca: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_Ca, F[10], DELTA_Ca))
        print("P: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_P, F[11], DELTA_P))
        print("UFL: la differenza fra l'apporto totale => %f UFL e il fabbisogno => %f UFL è: %f UFL" % (APPORTO_TOTALE_UFL, F[12], DELTA_UFL))
        
        sys.stdout = original
        print('This string goes to stdout, NOT the file!')

                                
    
    elif len(S) == 4: 
        print(S[0])
        print(S[1])
        print(S[2])
        print(S[3])
        print(ARR[0])
        print(ARR[1])
        print(ARR[2])
        print(ARR[3])
        
        print('Hai inserito 4 alimenti \n')

#       print("QUESTA È LA VERSIONE CORRETTA DELL'ALGORITMO")
        
        random_ARR_0_old = ARR[0] * random.random() * 10
        random_ARR_1_old = ARR[1] * random.random() * 10
        random_ARR_2_old = ARR[2] * random.random() * 10
        random_ARR_3_old = ARR[3] * random.random() * 10
        
# ogni alimento scelto dall'utente viene moltiplicato per un numero casuale compreso fra 0 e 10 (kg) 
# dichiaro random_ARR_x_old

        
        random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
        random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
        random_ARR_2_new = random_ARR_2_old * (random.random() + 0.5)
        random_ARR_3_new = random_ARR_3_old * (random.random() + 0.5)
        
# dichiaro random_ARR_x_new
        
        SOMMA_old = random_ARR_0_old + random_ARR_1_old + random_ARR_2_old + random_ARR_3_old
        DELTA_old = SOMMA_old - F_arr
        print('La somma iniziale è...')
        print(SOMMA_old)

# dichiaro SOMMA_old e DELTA_old

        SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new
        DELTA_new = SOMMA_new - F_arr
        print('La nuova somma è...')
        print(SOMMA_new)
        print('La nuova differenza è...')
        print(DELTA_new)

# dichiaro SOMMA_new e DELTA_new
        
        quantità_alimento_1 = random_ARR_0_new / ARR[0]
        quantità_alimento_2 = random_ARR_1_new / ARR[1]
        quantità_alimento_3 = random_ARR_2_new / ARR[2]
        quantità_alimento_4 = random_ARR_3_new / ARR[3]
        
# dichiaro gli apporti dei singoli alimenti

        i = 0

# inizializzo il contatore i        
        
        for i in range(N_repl):
        
            rules = [abs(DELTA_new[0]) < abs(DELTA_old[0]), abs(DELTA_new[1]) < abs(DELTA_old[1]), abs(DELTA_new[2]) < abs(DELTA_old[2])]

# dichiaro le regole da rispettare
                                    
            if all(rules):
            
                print('ESTRAGGO DALLA PROPOSAL DISTRIBUTION')
                i += 1
                print(i)
                
                                                         	               	        
                random_ARR_0_new = random_ARR_0_new * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_new * (random.random() + 0.5)
                random_ARR_2_new = random_ARR_2_new * (random.random() + 0.5)
                random_ARR_3_new = random_ARR_3_new * (random.random() + 0.5)
                
# ACCETTO random_ARR_x_new e lo uso per aggiornare random_ARR_x_new stesso 
                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0]
                print(APPORTO_TOTALE_SOSTANZA_SECCA)

# aggiorno l'apporto di SS
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new
                DELTA_new = SOMMA_new - F_arr
                
# aggiorno SOMMA_new e DELTA_new                
                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                quantità_alimento_3 = random_ARR_2_new / ARR[2]
                quantità_alimento_4 = random_ARR_3_new / ARR[3]
                
                if round(APPORTO_TOTALE_SOSTANZA_SECCA) == round(F_arr[0]):
                
                    break
                
                print(i)    
                print("SUCCESSO! L'APPORTO DI SOSTANZA SECCA CORRISPONDE AL FABBISOGNO.")

                    	                
            else:
                    
                random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
                random_ARR_2_new = random_ARR_2_old * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
                random_ARR_3_new = random_ARR_3_old * (random.random() + 0.5)
                
# RIFIUTO random_ARR_x_new e lo ricalcolo a partire da random_ARR_x_old 
                
                print('FALLIMENTO')
                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0]
                print(APPORTO_TOTALE_SOSTANZA_SECCA)
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new
                DELTA_new = SOMMA_new - F_arr
                                                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                quantità_alimento_3 = random_ARR_2_new / ARR[2]
                quantità_alimento_4 = random_ARR_3_new / ARR[3]
                
        
        if QM:
        
            QUANTITÀ_TOTALE_TAL_QUALE = QM + Q + quantità_alimento_1[0] + quantità_alimento_2[0] + quantità_alimento_3[0] + quantità_alimento_4[0]
            APPORTO_DEFINITIVO_SOSTANZA_SECCA = app_MAISGRA[0] + app_MAIS[0] + random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] 
            APPORTO_TOTALE_PROTEINA_GREZZA = app_MAISGRA[1] + app_MAIS[1] + random_ARR_0_new[1] + random_ARR_1_new[1] + random_ARR_2_new[1] + random_ARR_3_new[1]
            APPORTO_TOTALE_PROTEINA_DEGRADABILE = app_MAISGRA[2] + app_MAIS[2] + random_ARR_0_new[2] + random_ARR_1_new[2] + random_ARR_2_new[2] + random_ARR_3_new[2]
            APPORTO_TOTALE_PROTEINA_INDEGRADABILE = app_MAISGRA[3] + app_MAIS[3] + random_ARR_0_new[3] + random_ARR_1_new[3] + random_ARR_2_new[3] + random_ARR_3_new[3]
            APPORTO_TOTALE_FIBRA_GREZZA = app_MAISGRA[4] + app_MAIS[4] + random_ARR_0_new[4] + random_ARR_1_new[4] + random_ARR_2_new[4] + random_ARR_3_new[4]
            APPORTO_TOTALE_NDF = app_MAISGRA[5] + app_MAIS[5] + random_ARR_0_new[5] + random_ARR_1_new[5] + random_ARR_2_new[5] + random_ARR_3_new[5]
            APPORTO_TOTALE_ADF = app_MAISGRA[6] + app_MAIS[6] + random_ARR_0_new[6] + random_ARR_1_new[6] + random_ARR_2_new[6] + random_ARR_3_new[6]
            APPORTO_TOTALE_GRASSO = app_MAISGRA[7] + app_MAIS[7] + random_ARR_0_new[7] + random_ARR_1_new[7] + random_ARR_2_new[7] + random_ARR_3_new[7]
            APPORTO_TOTALE_AMIDO = app_MAISGRA[8] + app_MAIS[8] + random_ARR_0_new[8] + random_ARR_1_new[8] + random_ARR_2_new[8] + random_ARR_3_new[8]
            APPORTO_TOTALE_ZUCCHERI = app_MAISGRA[9] + app_MAIS[9] + random_ARR_0_new[9] + random_ARR_1_new[9] + random_ARR_2_new[9] + random_ARR_3_new[9]
            APPORTO_TOTALE_Ca = app_MAISGRA[10] + app_MAIS[10] + random_ARR_0_new[10] + random_ARR_1_new[10] + random_ARR_2_new[10] + random_ARR_3_new[10]
            APPORTO_TOTALE_P = app_MAISGRA[11] + app_MAIS[11] + random_ARR_0_new[11] + random_ARR_1_new[11] + random_ARR_2_new[11] + random_ARR_3_new[11]
            APPORTO_TOTALE_UFL = app_MAISGRA[12] + app_MAIS[12] + random_ARR_0_new[12] + random_ARR_1_new[12] + random_ARR_2_new[12] + random_ARR_3_new[12]

                        
        else:

            QUANTITÀ_TOTALE_TAL_QUALE = Q + quantità_alimento_1[0] + quantità_alimento_2[0] + quantità_alimento_3[0] + quantità_alimento_4[0]
            APPORTO_DEFINITIVO_SOSTANZA_SECCA = app_MAIS[0] + random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] 
            APPORTO_TOTALE_PROTEINA_GREZZA = app_MAIS[1] + random_ARR_0_new[1] + random_ARR_1_new[1] + random_ARR_2_new[1] + random_ARR_3_new[1]
            APPORTO_TOTALE_PROTEINA_DEGRADABILE = app_MAIS[2] + random_ARR_0_new[2] + random_ARR_1_new[2] + random_ARR_2_new[2] + random_ARR_3_new[2]
            APPORTO_TOTALE_PROTEINA_INDEGRADABILE = app_MAIS[3] + random_ARR_0_new[3] + random_ARR_1_new[3] + random_ARR_2_new[3] + random_ARR_3_new[3]
            APPORTO_TOTALE_FIBRA_GREZZA = app_MAIS[4] + random_ARR_0_new[4] + random_ARR_1_new[4] + random_ARR_2_new[4] + random_ARR_3_new[4]
            APPORTO_TOTALE_NDF = app_MAIS[5] + random_ARR_0_new[5] + random_ARR_1_new[5] + random_ARR_2_new[5] + random_ARR_3_new[5]
            APPORTO_TOTALE_ADF = app_MAIS[6] + random_ARR_0_new[6] + random_ARR_1_new[6] + random_ARR_2_new[6] + random_ARR_3_new[6]
            APPORTO_TOTALE_GRASSO = app_MAIS[7] + random_ARR_0_new[7] + random_ARR_1_new[7] + random_ARR_2_new[7] + random_ARR_3_new[7]
            APPORTO_TOTALE_AMIDO = app_MAIS[8] + random_ARR_0_new[8] + random_ARR_1_new[8] + random_ARR_2_new[8] + random_ARR_3_new[8]
            APPORTO_TOTALE_ZUCCHERI = app_MAIS[9] + random_ARR_0_new[9] + random_ARR_1_new[9] + random_ARR_2_new[9] + random_ARR_3_new[9]
            APPORTO_TOTALE_Ca = app_MAIS[10] + random_ARR_0_new[10] + random_ARR_1_new[10] + random_ARR_2_new[10] + random_ARR_3_new[10]
            APPORTO_TOTALE_P = app_MAIS[11] + random_ARR_0_new[11] + random_ARR_1_new[11] + random_ARR_2_new[11] + random_ARR_3_new[11]
            APPORTO_TOTALE_UFL = app_MAIS[12] + random_ARR_0_new[12] + random_ARR_1_new[12] + random_ARR_2_new[12] + random_ARR_3_new[12]
        
        DELTA_SOSTANZA_SECCA = APPORTO_DEFINITIVO_SOSTANZA_SECCA - F[0]
        DELTA_PROTEINA_GREZZA = APPORTO_TOTALE_PROTEINA_GREZZA - F[1]
        DELTA_PROTEINA_DEGRADABILE = APPORTO_TOTALE_PROTEINA_DEGRADABILE - F[2]
        DELTA_PROTEINA_INDEGRADABILE = APPORTO_TOTALE_PROTEINA_INDEGRADABILE - F[3]
        DELTA_FIBRA_GREZZA = APPORTO_TOTALE_FIBRA_GREZZA - F[4]
        DELTA_NDF = APPORTO_TOTALE_NDF - F[5]
        DELTA_ADF = APPORTO_TOTALE_ADF - F[6]
        DELTA_GRASSO = APPORTO_TOTALE_GRASSO - F[7]
        DELTA_AMIDO = APPORTO_TOTALE_AMIDO - F[8]
        DELTA_ZUCCHERI = APPORTO_TOTALE_ZUCCHERI - F[9]
        DELTA_Ca = APPORTO_TOTALE_Ca - F[10]
        DELTA_P = APPORTO_TOTALE_P - F[11]
        DELTA_UFL = APPORTO_TOTALE_UFL - F[12]

                
        original = sys.stdout
        sys.stdout = open('NUOVA_RAZIONE.txt', 'w')
        
        
        if day == 'Monday': 
            print('RAZIONE di %s, creata lunedì %s, %s' % (user, data, current_time))
        if day == 'Tuesday': 
            print('RAZIONE di %s, creata martedì %s, %s' % (user, data, current_time))
        if day == 'Wednesday': 
            print('RAZIONE di %s, creata mercoledì %s, %s' % (user, data, current_time))
        if day == 'Thursday': 
            print('RAZIONE di %s, creata giovedì %s, %s' % (user, data, current_time))
        if day == 'Friday': 
            print('RAZIONE di %s, creata venerdì %s, %s' % (user, data, current_time))
        if day == 'Saturday': 
            print('RAZIONE di %s, creata sabato %s, %s' % (user, data, current_time))
        if day == 'Sunday': 
            print('RAZIONE di %s, creata domenica %s, %s' % (user, data, current_time))
        
        
        print('')
#       print('This is your redirected text:')
        print('')
        if i == 999:
            print('Il calcolo della razione non ha avuto successo; per favore chiudi il programma e riprova.')
        else:
            print('Il calcolo della razione è stato effettuato con successo alla %d^esima replica' % i)        
#       print(i)
        print('')
        print('Il fabbisogno di SOSTANZA SECCA è di %f' %  F_arr[0])
        print('')
        print("L'apporto totale di SOSTANZA SECCA è di %f" % APPORTO_TOTALE_SOSTANZA_SECCA)
        print('')
        print('out of loop')
        print('')        
        print('LEGENDA')
        print('')
        print("DMI => Dry Matter Intake (Capacità d'ingestione di Sostanza Secca)")
        print("CPI => Crude Protein Intake (Apporto di Proteina Grezza)")
        print("RDPI => Rumen Degradable Protein Intake (Apporto di Proteina Degradabile)")
        print("RUPI => Rumen Undegradable Protein Intake (Apporto di Proteina Indegradabile)")
        print("FG => Fibra Grezza (apporto di Fibra Grezza)")
        print("NDF => Neutral Detergent Fiber (apporto di Fibra resistente al Detergente Neutro)")
        print("ADF => Acid Detergent Fiber (apporto di Fibra resistente al Detergente Acido)")
        print("FAT => Fat (apporto di Grasso)")
        print("AM => Amido (apporto di Amido)")
        print("ZUC => Zuccheri (apporto di Zuccheri)")
        print("Ca => Calcio (apporto di Calcio)")
        print("P => Fosforo (apporto di Fosforo)")
        print("UFL => Unità Foraggere Latte (apporto di Energia Netta)")
        print('DMI', 'CPI', 'RDPI', 'RUPI', 'FG', 'NDF', 'ADF', 'FAT', 'AM', 'ZUC', 'Ca', 'P', 'UFL')
        
        if MG:
        
            print('apporti di %s: \n' % M)
            print(app_MAIS)
            print('apporti di %s: \n' % MG)
            print(app_MAISGRA)                        
            print('apporti di %s: \n' % S[0])
            print(random_ARR_0_new)
            print('apporti di %s: \n' % S[1])
            print(random_ARR_1_new)
            print('apporti di %s: \n' % S[2])
            print(random_ARR_2_new)
            print('apporti di %s: \n' % S[3])
            print(random_ARR_3_new)
            
        else:
        
            print('apporti di %s: \n' % M)
            print(app_MAIS)
            print('apporti di %s: \n' % S[0])
            print(random_ARR_0_new)
            print('apporti di %s: \n' % S[1])
            print(random_ARR_1_new)
            print('apporti di %s: \n' % S[2])
            print(random_ARR_2_new)
            print('apporti di %s: \n' % S[3])
            print(random_ARR_3_new)
                                 

        if M == 'insilato di mais':
            print('La razione fornisce %f kg di %s' % (Q_INSIMA, M))
            
            
        elif M == 'pastone mais integrale':
            print('La razione fornisce %f kg di %s\n' % (Q_PASTOMAISINT, M))
            
            
        elif M == 'pastone mais granella':
            print('La razione fornisce %f kg di %s\n' % (Q_PASTOMAISGRA, M))
            


        if Q_MAISGRA:
            print('La razione fornisce %f kg di %s\n' % (QM, MG))
            print('%f kg %s' % (QM, MG))                                         
            print('%f kg %s' % (Q, M))                        
            print('%f kg %s' % (quantità_alimento_1[0], S[0]))
            print('%f kg %s' % (quantità_alimento_2[0], S[1]))
            print('%f kg %s' % (quantità_alimento_3[0], S[2]))
            print('%f kg %s' % (quantità_alimento_4[0], S[3]))
            
        else:
            print('%f kg %s' % (Q, M))                        
            print('%f kg %s' % (quantità_alimento_1[0], S[0]))
            print('%f kg %s' % (quantità_alimento_2[0], S[1]))
            print('%f kg %s' % (quantità_alimento_3[0], S[2]))
            print('%f kg %s' % (quantità_alimento_4[0], S[3]))

                        
        print('La razione fornisce %f kg di alimento tal quale' % QUANTITÀ_TOTALE_TAL_QUALE)
        print('La razione fornisce %f kg di sostanza secca' % APPORTO_DEFINITIVO_SOSTANZA_SECCA)
        
        print("SOSTANZA SECCA: la differenza fra l'apporto totale => %f kg e la capacità d'ingestione => %f kg è: %f kg" % (APPORTO_DEFINITIVO_SOSTANZA_SECCA, F[0], DELTA_SOSTANZA_SECCA))
        print("PROTEINA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_GREZZA, F[1], DELTA_PROTEINA_GREZZA)) 
        print("PROTEINA DEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_DEGRADABILE, F[2], DELTA_PROTEINA_DEGRADABILE))
        print("PROTEINA INDEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_INDEGRADABILE, F[3], DELTA_PROTEINA_INDEGRADABILE))
        print("FIBRA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_FIBRA_GREZZA, F[4], DELTA_FIBRA_GREZZA))
        print("NDF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_NDF, F[5], DELTA_NDF))
        print("ADF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ADF, F[6], DELTA_ADF))
        print("GRASSO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_GRASSO, F[7], DELTA_GRASSO)) 
        print("AMIDO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_AMIDO, F[8], DELTA_AMIDO))
        print("ZUCCHERI: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ZUCCHERI, F[9], DELTA_ZUCCHERI))
        print("Ca: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_Ca, F[10], DELTA_Ca))
        print("P: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_P, F[11], DELTA_P))
        print("UFL: la differenza fra l'apporto totale => %f UFL e il fabbisogno => %f UFL è: %f UFL" % (APPORTO_TOTALE_UFL, F[12], DELTA_UFL))
        
        sys.stdout = original
        print('This string goes to stdout, NOT the file!')

        
                                        

    elif len(S) == 5: 
        print(S[0])
        print(S[1])
        print(S[2])
        print(S[3])
        print(S[4])
        print(ARR[0])
        print(ARR[1])
        print(ARR[2])
        print(ARR[3])
        print(ARR[4])
        
        print('Hai inserito 5 alimenti \n')
        
#       print("QUESTA È LA VERSIONE CORRETTA DELL'ALGORITMO")
        
        random_ARR_0_old = ARR[0] * random.random() * 10
        random_ARR_1_old = ARR[1] * random.random() * 10
        random_ARR_2_old = ARR[2] * random.random() * 10
        random_ARR_3_old = ARR[3] * random.random() * 10
        random_ARR_4_old = ARR[4] * random.random() * 10
        
# ogni alimento scelto dall'utente viene moltiplicato per un numero casuale compreso fra 0 e 10 (kg) 
# dichiaro random_ARR_x_old

        
        random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
        random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
        random_ARR_2_new = random_ARR_2_old * (random.random() + 0.5)
        random_ARR_3_new = random_ARR_3_old * (random.random() + 0.5)
        random_ARR_4_new = random_ARR_4_old * (random.random() + 0.5)
        
# dichiaro random_ARR_x_new
        
        SOMMA_old = random_ARR_0_old + random_ARR_1_old + random_ARR_2_old + random_ARR_3_old + random_ARR_4_old

###########################################################################################################################################        
        
        print(SOMMA_old)
        print(F_arr)
        print('Il vettore <F_arr> è vuoto!!!')
        print('Sono arrivato fin qui!')
        print('Riga 3529')
        
        DELTA_old = SOMMA_old - F_arr
        print('La somma iniziale è...')
        print(SOMMA_old)

# dichiaro SOMMA_old e DELTA_old

        SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new
        DELTA_new = SOMMA_new - F_arr
        print('La nuova somma è...')
        print(SOMMA_new)
        print('La nuova differenza è...')
        print(DELTA_new)

# dichiaro SOMMA_new e DELTA_new
        
        quantità_alimento_1 = random_ARR_0_new / ARR[0]
        quantità_alimento_2 = random_ARR_1_new / ARR[1]
        quantità_alimento_3 = random_ARR_2_new / ARR[2]
        quantità_alimento_4 = random_ARR_3_new / ARR[3]
        quantità_alimento_5 = random_ARR_4_new / ARR[4]
        
# dichiaro gli apporti dei singoli alimenti

# dichiaro gli apporti dei singoli alimenti

        i = 0

# inizializzo il contatore i        
        
        for i in range(N_repl):
        
            rules = [abs(DELTA_new[0]) < abs(DELTA_old[0]), abs(DELTA_new[1]) < abs(DELTA_old[1]), abs(DELTA_new[2]) < abs(DELTA_old[2])]

# dichiaro le regole da rispettare
                                    
            if all(rules):
            
                print('ESTRAGGO DALLA PROPOSAL DISTRIBUTION')
                i += 1
                print(i)
                                                         	               	        
                random_ARR_0_new = random_ARR_0_new * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_new * (random.random() + 0.5)
                random_ARR_2_new = random_ARR_2_new * (random.random() + 0.5)
                random_ARR_3_new = random_ARR_3_new * (random.random() + 0.5)
                random_ARR_4_new = random_ARR_4_new * (random.random() + 0.5)
                
# ACCETTO random_ARR_x_new e lo uso per aggiornare random_ARR_x_new stesso 
                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0]
                print(APPORTO_TOTALE_SOSTANZA_SECCA)

# aggiorno l'apporto di SS
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new
                DELTA_new = SOMMA_new - F_arr
                
# aggiorno SOMMA_new e DELTA_new                
                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                quantità_alimento_3 = random_ARR_2_new / ARR[2]
                quantità_alimento_4 = random_ARR_3_new / ARR[3]
                quantità_alimento_5 = random_ARR_4_new / ARR[4]
                
                if round(APPORTO_TOTALE_SOSTANZA_SECCA) == round(F_arr[0]):
                
                    break
                
                print('Sono arrivato alla %desima replica' % i)
                print('')                
                print("SUCCESSO! L'APPORTO DI SOSTANZA SECCA CORRISPONDE AL FABBISOGNO.")

                    	                
            else:
                    
                random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
                random_ARR_2_new = random_ARR_2_old * (random.random() + 0.5)
                random_ARR_3_new = random_ARR_3_old * (random.random() + 0.5)
                random_ARR_4_new = random_ARR_4_old * (random.random() + 0.5)
                
# RIFIUTO random_ARR_x_new e lo ricalcolo a partire da random_ARR_x_old 
                
                print('FALLIMENTO')
                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0]
                print('')
                print("L'APPORTO TOTALE DI SOSTANZA SECCA è %f" % APPORTO_TOTALE_SOSTANZA_SECCA)
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new
                DELTA_new = SOMMA_new - F_arr
                                                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                quantità_alimento_3 = random_ARR_2_new / ARR[2]
                quantità_alimento_4 = random_ARR_3_new / ARR[3]
                quantità_alimento_5 = random_ARR_4_new / ARR[4]
                
        
        if QM:                                        
                
            QUANTITÀ_TOTALE_TAL_QUALE = QM + Q + quantità_alimento_1[0] + quantità_alimento_2[0] + quantità_alimento_3[0] + quantità_alimento_4[0] + quantità_alimento_5[0]
            APPORTO_DEFINITIVO_SOSTANZA_SECCA = app_MAISGRA[0] + app_MAIS[0] + random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] 
            APPORTO_TOTALE_PROTEINA_GREZZA = app_MAISGRA[1] + app_MAIS[1] + random_ARR_0_new[1] + random_ARR_1_new[1] + random_ARR_2_new[1] + random_ARR_3_new[1] + random_ARR_4_new[1]
            APPORTO_TOTALE_PROTEINA_DEGRADABILE = app_MAISGRA[2] + app_MAIS[2] + random_ARR_0_new[2] + random_ARR_1_new[2] + random_ARR_2_new[2] + random_ARR_3_new[2] + random_ARR_4_new[2]
            APPORTO_TOTALE_PROTEINA_INDEGRADABILE = app_MAISGRA[3] + app_MAIS[3] + random_ARR_0_new[3] + random_ARR_1_new[3] + random_ARR_2_new[3] + random_ARR_3_new[3] + random_ARR_4_new[3]
            APPORTO_TOTALE_FIBRA_GREZZA = app_MAISGRA[4] + app_MAIS[4] + random_ARR_0_new[4] + random_ARR_1_new[4] + random_ARR_2_new[4] + random_ARR_3_new[4] + random_ARR_4_new[4]
            APPORTO_TOTALE_NDF = app_MAISGRA[5] + app_MAIS[5] + random_ARR_0_new[5] + random_ARR_1_new[5] + random_ARR_2_new[5] + random_ARR_3_new[5] + random_ARR_4_new[5]
            APPORTO_TOTALE_ADF = app_MAISGRA[6] + app_MAIS[6] + random_ARR_0_new[6] + random_ARR_1_new[6] + random_ARR_2_new[6] + random_ARR_3_new[6] + random_ARR_4_new[6]
            APPORTO_TOTALE_GRASSO = app_MAISGRA[7] + app_MAIS[7] + random_ARR_0_new[7] + random_ARR_1_new[7] + random_ARR_2_new[7] + random_ARR_3_new[7] + random_ARR_4_new[7]
            APPORTO_TOTALE_AMIDO = app_MAISGRA[8] + app_MAIS[8] + random_ARR_0_new[8] + random_ARR_1_new[8] + random_ARR_2_new[8] + random_ARR_3_new[8] + random_ARR_4_new[8]
            APPORTO_TOTALE_ZUCCHERI = app_MAISGRA[9] + app_MAIS[9] + random_ARR_0_new[9] + random_ARR_1_new[9] + random_ARR_2_new[9] + random_ARR_3_new[9] + random_ARR_4_new[9]
            APPORTO_TOTALE_Ca = app_MAISGRA[10] + app_MAIS[10] + random_ARR_0_new[10] + random_ARR_1_new[10] + random_ARR_2_new[10] + random_ARR_3_new[10] + random_ARR_4_new[10]
            APPORTO_TOTALE_P = app_MAISGRA[11] + app_MAIS[11] + random_ARR_0_new[11] + random_ARR_1_new[11] + random_ARR_2_new[11] + random_ARR_3_new[11] + random_ARR_4_new[11]
            APPORTO_TOTALE_UFL = app_MAISGRA[12] + app_MAIS[12] + random_ARR_0_new[12] + random_ARR_1_new[12] + random_ARR_2_new[12] + random_ARR_3_new[12] + random_ARR_4_new[12]


        else:

            QUANTITÀ_TOTALE_TAL_QUALE = Q + quantità_alimento_1[0] + quantità_alimento_2[0] + quantità_alimento_3[0] + quantità_alimento_4[0] + quantità_alimento_5[0]
            APPORTO_DEFINITIVO_SOSTANZA_SECCA = app_MAIS[0] + random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] 
            APPORTO_TOTALE_PROTEINA_GREZZA = app_MAIS[1] + random_ARR_0_new[1] + random_ARR_1_new[1] + random_ARR_2_new[1] + random_ARR_3_new[1] + random_ARR_4_new[1]
            APPORTO_TOTALE_PROTEINA_DEGRADABILE = app_MAIS[2] + random_ARR_0_new[2] + random_ARR_1_new[2] + random_ARR_2_new[2] + random_ARR_3_new[2] + random_ARR_4_new[2]
            APPORTO_TOTALE_PROTEINA_INDEGRADABILE = app_MAIS[3] + random_ARR_0_new[3] + random_ARR_1_new[3] + random_ARR_2_new[3] + random_ARR_3_new[3] + random_ARR_4_new[3]
            APPORTO_TOTALE_FIBRA_GREZZA = app_MAIS[4] + random_ARR_0_new[4] + random_ARR_1_new[4] + random_ARR_2_new[4] + random_ARR_3_new[4] + random_ARR_4_new[4]
            APPORTO_TOTALE_NDF = app_MAIS[5] + random_ARR_0_new[5] + random_ARR_1_new[5] + random_ARR_2_new[5] + random_ARR_3_new[5] + random_ARR_4_new[5]
            APPORTO_TOTALE_ADF = app_MAIS[6] + random_ARR_0_new[6] + random_ARR_1_new[6] + random_ARR_2_new[6] + random_ARR_3_new[6] + random_ARR_4_new[6]
            APPORTO_TOTALE_GRASSO = app_MAIS[7] + random_ARR_0_new[7] + random_ARR_1_new[7] + random_ARR_2_new[7] + random_ARR_3_new[7] + random_ARR_4_new[7]
            APPORTO_TOTALE_AMIDO = app_MAIS[8] + random_ARR_0_new[8] + random_ARR_1_new[8] + random_ARR_2_new[8] + random_ARR_3_new[8] + random_ARR_4_new[8]
            APPORTO_TOTALE_ZUCCHERI = app_MAIS[9] + random_ARR_0_new[9] + random_ARR_1_new[9] + random_ARR_2_new[9] + random_ARR_3_new[9] + random_ARR_4_new[9]
            APPORTO_TOTALE_Ca = app_MAIS[10] + random_ARR_0_new[10] + random_ARR_1_new[10] + random_ARR_2_new[10] + random_ARR_3_new[10] + random_ARR_4_new[10]
            APPORTO_TOTALE_P = app_MAIS[11] + random_ARR_0_new[11] + random_ARR_1_new[11] + random_ARR_2_new[11] + random_ARR_3_new[11] + random_ARR_4_new[11]
            APPORTO_TOTALE_UFL = app_MAIS[12] + random_ARR_0_new[12] + random_ARR_1_new[12] + random_ARR_2_new[12] + random_ARR_3_new[12] + random_ARR_4_new[12]


        
        DELTA_SOSTANZA_SECCA = APPORTO_DEFINITIVO_SOSTANZA_SECCA - F[0]
        DELTA_PROTEINA_GREZZA = APPORTO_TOTALE_PROTEINA_GREZZA - F[1]
        DELTA_PROTEINA_DEGRADABILE = APPORTO_TOTALE_PROTEINA_DEGRADABILE - F[2]
        DELTA_PROTEINA_INDEGRADABILE = APPORTO_TOTALE_PROTEINA_INDEGRADABILE - F[3]
        DELTA_FIBRA_GREZZA = APPORTO_TOTALE_FIBRA_GREZZA - F[4]
        DELTA_NDF = APPORTO_TOTALE_NDF - F[5]
        DELTA_ADF = APPORTO_TOTALE_ADF - F[6]
        DELTA_GRASSO = APPORTO_TOTALE_GRASSO - F[7]
        DELTA_AMIDO = APPORTO_TOTALE_AMIDO - F[8]
        DELTA_ZUCCHERI = APPORTO_TOTALE_ZUCCHERI - F[9]
        DELTA_Ca = APPORTO_TOTALE_Ca - F[10]
        DELTA_P = APPORTO_TOTALE_P - F[11]
        DELTA_UFL = APPORTO_TOTALE_UFL - F[12]
        
                

                
        original = sys.stdout
        sys.stdout = open('NUOVA_RAZIONE.txt', 'w')
        
        if day == 'Monday': 
            print('RAZIONE di %s, creata lunedì %s, %s' % (user, data, current_time))
        if day == 'Tuesday': 
            print('RAZIONE di %s, creata martedì %s, %s' % (user, data, current_time))
        if day == 'Wednesday': 
            print('RAZIONE di %s, creata mercoledì %s, %s' % (user, data, current_time))
        if day == 'Thursday': 
            print('RAZIONE di %s, creata giovedì %s, %s' % (user, data, current_time))
        if day == 'Friday': 
            print('RAZIONE di %s, creata venerdì %s, %s' % (user, data, current_time))
        if day == 'Saturday': 
            print('RAZIONE di %s, creata sabato %s, %s' % (user, data, current_time))
        if day == 'Sunday': 
            print('RAZIONE di %s, creata domenica %s, %s' % (user, data, current_time))
        
        
        print('')
#       print('This is your redirected text:')
        print('')
        if i == 999:
            print('Il calcolo della razione non ha avuto successo; per favore chiudi il programma e riprova.')
        else:
            print('Il calcolo della razione è stato effettuato con successo alla %d^esima replica' % i)        
#       print(i)
        print('')
        print('Il fabbisogno di SOSTANZA SECCA è di %f' %  F_arr[0])
        print('')
        print("L'apporto totale di SOSTANZA SECCA è di %f" % APPORTO_TOTALE_SOSTANZA_SECCA)
        print('')
        print('out of loop')
        print('')        
        print('LEGENDA')
        print('')
        print("DMI => Dry Matter Intake (Capacità d'ingestione di Sostanza Secca)")
        print("CPI => Crude Protein Intake (Apporto di Proteina Grezza)")
        print("RDPI => Rumen Degradable Protein Intake (Apporto di Proteina Degradabile)")
        print("RUPI => Rumen Undegradable Protein Intake (Apporto di Proteina Indegradabile)")
        print("FG => Fibra Grezza (apporto di Fibra Grezza)")
        print("NDF => Neutral Detergent Fiber (apporto di Fibra resistente al Detergente Neutro)")
        print("ADF => Acid Detergent Fiber (apporto di Fibra resistente al Detergente Acido)")
        print("FAT => Fat (apporto di Grasso)")
        print("AM => Amido (apporto di Amido)")
        print("ZUC => Zuccheri (apporto di Zuccheri)")
        print("Ca => Calcio (apporto di Calcio)")
        print("P => Fosforo (apporto di Fosforo)")
        print("UFL => Unità Foraggere Latte (apporto di Energia Netta)")
        print('DMI', 'CPI', 'RDPI', 'RUPI', 'FG', 'NDF', 'ADF', 'FAT', 'AM', 'ZUC', 'Ca', 'P', 'UFL')                	                
        
        if MG:
            print('')
            print('apporti di %s: \n' % M)
            print('')
            print(app_MAIS)
            print('')
            print('apporti di %s: \n' % MG)
            print('')
            print(app_MAISGRA)
            print('')            
            print('apporti di %s: \n' % S[0])
            print('')
            print(random_ARR_0_new)
            print('')
            print('apporti di %s: \n' % S[1])
            print('')
            print(random_ARR_1_new)
            print('')
            print('apporti di %s: \n' % S[2])
            print('')
            print(random_ARR_2_new)
            print('')
            print('apporti di %s: \n' % S[3])
            print('')
            print(random_ARR_3_new)
            print('')
            print('apporti di %s: \n' % S[4])
            print('')
            print(random_ARR_4_new)
            print('')
            
        else:
            print('')
            print('apporti di %s: \n' % M)
            print('')
            print(app_MAIS)
            print('')
            print('apporti di %s: \n' % S[0])
            print('')
            print(random_ARR_0_new)
            print('')
            print('apporti di %s: \n' % S[1])
            print('')
            print(random_ARR_1_new)
            print('')
            print('apporti di %s: \n' % S[2])
            print('')
            print(random_ARR_2_new)
            print('')
            print('apporti di %s: \n' % S[3])
            print('')
            print(random_ARR_3_new)
            print('')
            print('apporti di %s: \n' % S[4])
            print('')
            print(random_ARR_4_new)
            print('')

                                        
        if M == 'insilato di mais':
            print('La razione fornisce %f kg di %s' % (Q_INSIMA, M))
            from crea_db_PREZZI_Alessandria_w import prezzo_MAIS_INSILATO
            if type(prezzo_MAIS_INSILATO) == float:
                costo_insilato_mais = Q_INSIMA * prezzo_MAIS_INSILATO / 1000
                COSTO_RAZIONE.append(costo_insilato_mais)
                print("Prezzo dell'INSILATO DI MAIS => %f EURO/ton" % prezzo_MAIS_INSILATO)
            else:
                print('%s' % prezzo_MAIS_INSILATO)
            
            
        elif M == 'pastone mais integrale':
            print('La razione fornisce %f kg di %s\n' % (Q_PASTOMAISINT, M))
            from crea_db_PREZZI_clal_w import prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR
            if type(prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR) == float:
                costo_pastone_mais_integrale = Q_PASTOMAISINT * prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR / 1000
                COSTO_RAZIONE.append(costo_pastone_mais_integrale)
                print("Prezzo del PASTONE DI MAIS INTEGRALE => %f EURO/ton" % prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR)
            else:
                print('%s' % prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR)

            
        elif M == 'pastone mais granella':
            print('La razione fornisce %f kg di %s\n' % (Q_PASTOMAISGRA, M))
            from crea_db_PREZZI_clal_w import prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR
            if type(prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR) == float:
                costo_pastone_mais_granella = Q * prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR / 1000
                COSTO_RAZIONE.append(costo_pastone_mais_granella)
                print("Prezzo del PASTONE DI MAIS GRANELLA => %f EURO/ton" % prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR)
            else:
                print('%s' % prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR)
            

        if Q_MAISGRA:
            print('La razione fornisce %f kg di %s\n' % (QM, MG))
            from crea_db_PREZZI_Milano_w import prezzo_MAIS
            if type(prezzo_MAIS) == float:
                costo_mais = QM * prezzo_MAIS / 1000
                COSTO_RAZIONE.append(costo_mais)
                print("Prezzo del MAIS => %f EURO/ton" % prezzo_MAIS)
            else:
                print('%s' % prezzo_MAIS)
            
            print('')
            print('COMPOSIZIONE DELLA RAZIONE:')
            print('')
            print('%f kg %s' % (QM, MG))                                         
            print('%f kg %s' % (Q, M))                        
            print('%f kg %s' % (quantità_alimento_1[0], S[0]))
            print('%f kg %s' % (quantità_alimento_2[0], S[1]))
            print('%f kg %s' % (quantità_alimento_3[0], S[2]))
            print('%f kg %s' % (quantità_alimento_4[0], S[3]))
            print('%f kg %s' % (quantità_alimento_5[0], S[4]))
            
        else:
            print('%f kg %s' % (Q, M))                        
            print('%f kg %s' % (quantità_alimento_1[0], S[0]))
            print('%f kg %s' % (quantità_alimento_2[0], S[1]))
            print('%f kg %s' % (quantità_alimento_3[0], S[2]))
            print('%f kg %s' % (quantità_alimento_4[0], S[3]))
            print('%f kg %s' % (quantità_alimento_5[0], S[4]))


        costo_alimento_1 = quantità_alimento_1[0] * PREZZI[0] / 1000
        costo_alimento_2 = quantità_alimento_2[0] * PREZZI[1] / 1000
        costo_alimento_3 = quantità_alimento_3[0] * PREZZI[2] / 1000
        costo_alimento_4 = quantità_alimento_4[0] * PREZZI[3] / 1000
        costo_alimento_5 = quantità_alimento_5[0] * PREZZI[4] / 1000
        
        COSTO_RAZIONE.append(costo_alimento_1)
        COSTO_RAZIONE.append(costo_alimento_2)
        COSTO_RAZIONE.append(costo_alimento_3)
        COSTO_RAZIONE.append(costo_alimento_4)
        COSTO_RAZIONE.append(costo_alimento_5)
        COSTO_TOTALE = sum(COSTO_RAZIONE)
        print('')
        print('Il costo della razione è %f EURO' % COSTO_TOTALE)
        print('')        


        
        print('La razione fornisce %f kg di alimento tal quale' % QUANTITÀ_TOTALE_TAL_QUALE)
        print('La razione fornisce %f kg di sostanza secca' % APPORTO_DEFINITIVO_SOSTANZA_SECCA)
        
        print("SOSTANZA SECCA: la differenza fra l'apporto totale => %f kg e la capacità d'ingestione => %f kg è: %f kg" % (APPORTO_DEFINITIVO_SOSTANZA_SECCA, F[0], DELTA_SOSTANZA_SECCA))
        print("PROTEINA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_GREZZA, F[1], DELTA_PROTEINA_GREZZA)) 
        print("PROTEINA DEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_DEGRADABILE, F[2], DELTA_PROTEINA_DEGRADABILE))
        print("PROTEINA INDEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_INDEGRADABILE, F[3], DELTA_PROTEINA_INDEGRADABILE))
        print("FIBRA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_FIBRA_GREZZA, F[4], DELTA_FIBRA_GREZZA))
        print("NDF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_NDF, F[5], DELTA_NDF))
        print("ADF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ADF, F[6], DELTA_ADF))
        print("GRASSO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_GRASSO, F[7], DELTA_GRASSO)) 
        print("AMIDO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_AMIDO, F[8], DELTA_AMIDO))
        print("ZUCCHERI: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ZUCCHERI, F[9], DELTA_ZUCCHERI))
        print("Ca: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_Ca, F[10], DELTA_Ca))
        print("P: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_P, F[11], DELTA_P))
        print("UFL: la differenza fra l'apporto totale => %f UFL e il fabbisogno => %f UFL è: %f UFL" % (APPORTO_TOTALE_UFL, F[12], DELTA_UFL))
        
        sys.stdout = original
        print('This string goes to stdout, NOT the file!')

        

                    
    elif len(S) == 6: 
        print(S[0])
        print(S[1])
        print(S[2])
        print(S[3])
        print(S[4])
        print(S[5])
        print(ARR[0])
        print(ARR[1])
        print(ARR[2])
        print(ARR[3])
        print(ARR[4])
        print(ARR[5])
        
        print('Hai inserito 6 alimenti \n')
        
#       print("QUESTA È LA VERSIONE CORRETTA DELL'ALGORITMO")
        
        random_ARR_0_old = ARR[0] * random.random() * 10
        random_ARR_1_old = ARR[1] * random.random() * 10
        random_ARR_2_old = ARR[2] * random.random() * 10
        random_ARR_3_old = ARR[3] * random.random() * 10
        random_ARR_4_old = ARR[4] * random.random() * 10
        random_ARR_5_old = ARR[5] * random.random() * 10
        

# ogni alimento scelto dall'utente viene moltiplicato per un numero casuale compreso fra 0 e 10 (kg) 
# dichiaro random_ARR_x_old

        
        random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
        random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
        random_ARR_2_new = random_ARR_2_old * (random.random() + 0.5)
        random_ARR_3_new = random_ARR_3_old * (random.random() + 0.5)
        random_ARR_4_new = random_ARR_4_old * (random.random() + 0.5)
        random_ARR_5_new = random_ARR_5_old * (random.random() + 0.5)
        

# dichiaro random_ARR_x_new
        
        SOMMA_old = random_ARR_0_old + random_ARR_1_old + random_ARR_2_old + random_ARR_3_old + random_ARR_4_old + random_ARR_5_old
        DELTA_old = SOMMA_old - F_arr
        print('La somma iniziale è...')
        print(SOMMA_old)

# dichiaro SOMMA_old e DELTA_old

        SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new + random_ARR_5_new
        DELTA_new = SOMMA_new - F_arr
        print('La nuova somma è...')
        print(SOMMA_new)
        print('La nuova differenza è...')
        print(DELTA_new)

# dichiaro SOMMA_new e DELTA_new
        
        quantità_alimento_1 = random_ARR_0_new / ARR[0]
        quantità_alimento_2 = random_ARR_1_new / ARR[1]
        quantità_alimento_3 = random_ARR_2_new / ARR[2]
        quantità_alimento_4 = random_ARR_3_new / ARR[3]
        quantità_alimento_5 = random_ARR_4_new / ARR[4]
        quantità_alimento_6 = random_ARR_5_new / ARR[5]
        

# dichiaro gli apporti dei singoli alimenti

        i = 0

# inizializzo il contatore i        
        
        for i in range(N_repl):
        
            rules = [abs(DELTA_new[0]) < abs(DELTA_old[0]), abs(DELTA_new[1]) < abs(DELTA_old[1]), abs(DELTA_new[2]) < abs(DELTA_old[2])]

# dichiaro le regole da rispettare
                                    
            if all(rules):
            
                print('ESTRAGGO DALLA PROPOSAL DISTRIBUTION')
                i += 1
                print(i)
                                                         	               	        
                random_ARR_0_new = random_ARR_0_new * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_new * (random.random() + 0.5)
                random_ARR_2_new = random_ARR_2_new * (random.random() + 0.5)
                random_ARR_3_new = random_ARR_3_new * (random.random() + 0.5)
                random_ARR_4_new = random_ARR_4_new * (random.random() + 0.5)
                random_ARR_5_new = random_ARR_5_new * (random.random() + 0.5)
                

# ACCETTO random_ARR_x_new e lo uso per aggiornare random_ARR_x_new stesso 
                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0]
                print(APPORTO_TOTALE_SOSTANZA_SECCA)

# aggiorno l'apporto di SS
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new + random_ARR_5_new
                DELTA_new = SOMMA_new - F_arr
                
# aggiorno SOMMA_new e DELTA_new                
                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                quantità_alimento_3 = random_ARR_2_new / ARR[2]
                quantità_alimento_4 = random_ARR_3_new / ARR[3]
                quantità_alimento_5 = random_ARR_4_new / ARR[4]
                quantità_alimento_6 = random_ARR_5_new / ARR[5]

                
                if round(APPORTO_TOTALE_SOSTANZA_SECCA) == round(F_arr[0]):
                
                    break
                
                print(i)    
                print("SUCCESSO! L'APPORTO DI SOSTANZA SECCA CORRISPONDE AL FABBISOGNO.")

                    
                    	                
            else:
                    
                random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
                random_ARR_2_new = random_ARR_2_old * (random.random() + 0.5)
                random_ARR_3_new = random_ARR_3_old * (random.random() + 0.5)
                random_ARR_4_new = random_ARR_4_old * (random.random() + 0.5)
                random_ARR_5_new = random_ARR_5_old * (random.random() + 0.5)
                

# RIFIUTO random_ARR_x_new e lo ricalcolo a partire da random_ARR_x_old 
                
                print('FALLIMENTO')
                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0]
                print(APPORTO_TOTALE_SOSTANZA_SECCA)
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new + random_ARR_5_new
                DELTA_new = SOMMA_new - F_arr
                                                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                quantità_alimento_3 = random_ARR_2_new / ARR[2]
                quantità_alimento_4 = random_ARR_3_new / ARR[3]
                quantità_alimento_5 = random_ARR_4_new / ARR[4]
                quantità_alimento_6 = random_ARR_5_new / ARR[5]
                

        if QM:

            QUANTITÀ_TOTALE_TAL_QUALE = QM + Q + quantità_alimento_1[0] + quantità_alimento_2[0] + quantità_alimento_3[0] + quantità_alimento_4[0] + quantità_alimento_5[0] + quantità_alimento_6[0]
            APPORTO_DEFINITIVO_SOSTANZA_SECCA = app_MAISGRA[0] + app_MAIS[0] + random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0] 
            APPORTO_TOTALE_PROTEINA_GREZZA = app_MAISGRA[1] + app_MAIS[1] + random_ARR_0_new[1] + random_ARR_1_new[1] + random_ARR_2_new[1] + random_ARR_3_new[1] + random_ARR_4_new[1] + random_ARR_5_new[1]
            APPORTO_TOTALE_PROTEINA_DEGRADABILE = app_MAISGRA[2] + app_MAIS[2] + random_ARR_0_new[2] + random_ARR_1_new[2] + random_ARR_2_new[2] + random_ARR_3_new[2] + random_ARR_4_new[2] + random_ARR_5_new[2]
            APPORTO_TOTALE_PROTEINA_INDEGRADABILE = app_MAISGRA[3] + app_MAIS[3] + random_ARR_0_new[3] + random_ARR_1_new[3] + random_ARR_2_new[3] + random_ARR_3_new[3] + random_ARR_4_new[3] + random_ARR_5_new[3]
            APPORTO_TOTALE_FIBRA_GREZZA = app_MAISGRA[4] + app_MAIS[4] + random_ARR_0_new[4] + random_ARR_1_new[4] + random_ARR_2_new[4] + random_ARR_3_new[4] + random_ARR_4_new[4] + random_ARR_5_new[4]
            APPORTO_TOTALE_NDF = app_MAISGRA[5] + app_MAIS[5] + random_ARR_0_new[5] + random_ARR_1_new[5] + random_ARR_2_new[5] + random_ARR_3_new[5] + random_ARR_4_new[5] + random_ARR_5_new[5]
            APPORTO_TOTALE_ADF = app_MAISGRA[6] + app_MAIS[6] + random_ARR_0_new[6] + random_ARR_1_new[6] + random_ARR_2_new[6] + random_ARR_3_new[6] + random_ARR_4_new[6] + random_ARR_5_new[6]
            APPORTO_TOTALE_GRASSO = app_MAISGRA[7] + app_MAIS[7] + random_ARR_0_new[7] + random_ARR_1_new[7] + random_ARR_2_new[7] + random_ARR_3_new[7] + random_ARR_4_new[7] + random_ARR_5_new[7]
            APPORTO_TOTALE_AMIDO = app_MAISGRA[8] + app_MAIS[8] + random_ARR_0_new[8] + random_ARR_1_new[8] + random_ARR_2_new[8] + random_ARR_3_new[8] + random_ARR_4_new[8] + random_ARR_5_new[8]
            APPORTO_TOTALE_ZUCCHERI = app_MAISGRA[9] + app_MAIS[9] + random_ARR_0_new[9] + random_ARR_1_new[9] + random_ARR_2_new[9] + random_ARR_3_new[9] + random_ARR_4_new[9] + random_ARR_5_new[9]
            APPORTO_TOTALE_Ca = app_MAISGRA[10] + app_MAIS[10] + random_ARR_0_new[10] + random_ARR_1_new[10] + random_ARR_2_new[10] + random_ARR_3_new[10] + random_ARR_4_new[10] + random_ARR_5_new[10]
            APPORTO_TOTALE_P = app_MAISGRA[11] + app_MAIS[11] + random_ARR_0_new[11] + random_ARR_1_new[11] + random_ARR_2_new[11] + random_ARR_3_new[11] + random_ARR_4_new[11] + random_ARR_5_new[11]
            APPORTO_TOTALE_UFL = app_MAISGRA[12] + app_MAIS[12] + random_ARR_0_new[12] + random_ARR_1_new[12] + random_ARR_2_new[12] + random_ARR_3_new[12] + random_ARR_4_new[12] + random_ARR_5_new[12]


        else:
                
            QUANTITÀ_TOTALE_TAL_QUALE = Q + quantità_alimento_1[0] + quantità_alimento_2[0] + quantità_alimento_3[0] + quantità_alimento_4[0] + quantità_alimento_5[0] + quantità_alimento_6[0]
            APPORTO_DEFINITIVO_SOSTANZA_SECCA = app_MAIS[0] + random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0] 
            APPORTO_TOTALE_PROTEINA_GREZZA = app_MAIS[1] + random_ARR_0_new[1] + random_ARR_1_new[1] + random_ARR_2_new[1] + random_ARR_3_new[1] + random_ARR_4_new[1] + random_ARR_5_new[1]
            APPORTO_TOTALE_PROTEINA_DEGRADABILE = app_MAIS[2] + random_ARR_0_new[2] + random_ARR_1_new[2] + random_ARR_2_new[2] + random_ARR_3_new[2] + random_ARR_4_new[2] + random_ARR_5_new[2]
            APPORTO_TOTALE_PROTEINA_INDEGRADABILE = app_MAIS[3] + random_ARR_0_new[3] + random_ARR_1_new[3] + random_ARR_2_new[3] + random_ARR_3_new[3] + random_ARR_4_new[3] + random_ARR_5_new[3]
            APPORTO_TOTALE_FIBRA_GREZZA = app_MAIS[4] + random_ARR_0_new[4] + random_ARR_1_new[4] + random_ARR_2_new[4] + random_ARR_3_new[4] + random_ARR_4_new[4] + random_ARR_5_new[4]
            APPORTO_TOTALE_NDF = app_MAIS[5] + random_ARR_0_new[5] + random_ARR_1_new[5] + random_ARR_2_new[5] + random_ARR_3_new[5] + random_ARR_4_new[5] + random_ARR_5_new[5]
            APPORTO_TOTALE_ADF = app_MAIS[6] + random_ARR_0_new[6] + random_ARR_1_new[6] + random_ARR_2_new[6] + random_ARR_3_new[6] + random_ARR_4_new[6] + random_ARR_5_new[6]
            APPORTO_TOTALE_GRASSO = app_MAIS[7] + random_ARR_0_new[7] + random_ARR_1_new[7] + random_ARR_2_new[7] + random_ARR_3_new[7] + random_ARR_4_new[7] + random_ARR_5_new[7]
            APPORTO_TOTALE_AMIDO = app_MAIS[8] + random_ARR_0_new[8] + random_ARR_1_new[8] + random_ARR_2_new[8] + random_ARR_3_new[8] + random_ARR_4_new[8] + random_ARR_5_new[8]
            APPORTO_TOTALE_ZUCCHERI = app_MAIS[9] + random_ARR_0_new[9] + random_ARR_1_new[9] + random_ARR_2_new[9] + random_ARR_3_new[9] + random_ARR_4_new[9] + random_ARR_5_new[9]
            APPORTO_TOTALE_Ca = app_MAIS[10] + random_ARR_0_new[10] + random_ARR_1_new[10] + random_ARR_2_new[10] + random_ARR_3_new[10] + random_ARR_4_new[10] + random_ARR_5_new[10]
            APPORTO_TOTALE_P = app_MAIS[11] + random_ARR_0_new[11] + random_ARR_1_new[11] + random_ARR_2_new[11] + random_ARR_3_new[11] + random_ARR_4_new[11] + random_ARR_5_new[11]
            APPORTO_TOTALE_UFL = app_MAIS[12] + random_ARR_0_new[12] + random_ARR_1_new[12] + random_ARR_2_new[12] + random_ARR_3_new[12] + random_ARR_4_new[12] + random_ARR_5_new[12]
        
        DELTA_SOSTANZA_SECCA = APPORTO_DEFINITIVO_SOSTANZA_SECCA - F[0]
        DELTA_PROTEINA_GREZZA = APPORTO_TOTALE_PROTEINA_GREZZA - F[1]
        DELTA_PROTEINA_DEGRADABILE = APPORTO_TOTALE_PROTEINA_DEGRADABILE - F[2]
        DELTA_PROTEINA_INDEGRADABILE = APPORTO_TOTALE_PROTEINA_INDEGRADABILE - F[3]
        DELTA_FIBRA_GREZZA = APPORTO_TOTALE_FIBRA_GREZZA - F[4]
        DELTA_NDF = APPORTO_TOTALE_NDF - F[5]
        DELTA_ADF = APPORTO_TOTALE_ADF - F[6]
        DELTA_GRASSO = APPORTO_TOTALE_GRASSO - F[7]
        DELTA_AMIDO = APPORTO_TOTALE_AMIDO - F[8]
        DELTA_ZUCCHERI = APPORTO_TOTALE_ZUCCHERI - F[9]
        DELTA_Ca = APPORTO_TOTALE_Ca - F[10]
        DELTA_P = APPORTO_TOTALE_P - F[11]
        DELTA_UFL = APPORTO_TOTALE_UFL - F[12]

                
        original = sys.stdout
        sys.stdout = open('NUOVA_RAZIONE.txt', 'w')
        
        
        if day == 'Monday': 
            print('RAZIONE di %s, creata lunedì %s, %s' % (user, data, current_time))
        if day == 'Tuesday': 
            print('RAZIONE di %s, creata martedì %s, %s' % (user, data, current_time))
        if day == 'Wednesday': 
            print('RAZIONE di %s, creata mercoledì %s, %s' % (user, data, current_time))
        if day == 'Thursday': 
            print('RAZIONE di %s, creata giovedì %s, %s' % (user, data, current_time))
        if day == 'Friday': 
            print('RAZIONE di %s, creata venerdì %s, %s' % (user, data, current_time))
        if day == 'Saturday': 
            print('RAZIONE di %s, creata sabato %s, %s' % (user, data, current_time))
        if day == 'Sunday': 
            print('RAZIONE di %s, creata domenica %s, %s' % (user, data, current_time))
        
        
        print('')
#       print('This is your redirected text:')
        print('')
        if i == 999:
            print('Il calcolo della razione non ha avuto successo; per favore chiudi il programma e riprova.')
        else:
            print('Il calcolo della razione è stato effettuato con successo alla %d^esima replica' % i)        
#       print(i)
        print('')
        print('Il fabbisogno di SOSTANZA SECCA è di %f' %  F_arr[0])
        print('')
        print("L'apporto totale di SOSTANZA SECCA è di %f" % APPORTO_TOTALE_SOSTANZA_SECCA)
        print('')
        print('out of loop')
        print('')        
        print('LEGENDA')
        print('')
        print("DMI => Dry Matter Intake (Capacità d'ingestione di Sostanza Secca)")
        print("CPI => Crude Protein Intake (Apporto di Proteina Grezza)")
        print("RDPI => Rumen Degradable Protein Intake (Apporto di Proteina Degradabile)")
        print("RUPI => Rumen Undegradable Protein Intake (Apporto di Proteina Indegradabile)")
        print("FG => Fibra Grezza (apporto di Fibra Grezza)")
        print("NDF => Neutral Detergent Fiber (apporto di Fibra resistente al Detergente Neutro)")
        print("ADF => Acid Detergent Fiber (apporto di Fibra resistente al Detergente Acido)")
        print("FAT => Fat (apporto di Grasso)")
        print("AM => Amido (apporto di Amido)")
        print("ZUC => Zuccheri (apporto di Zuccheri)")
        print("Ca => Calcio (apporto di Calcio)")
        print("P => Fosforo (apporto di Fosforo)")
        print("UFL => Unità Foraggere Latte (apporto di Energia Netta)")
        print('DMI', 'CPI', 'RDPI', 'RUPI', 'FG', 'NDF', 'ADF', 'FAT', 'AM', 'ZUC', 'Ca', 'P', 'UFL')                	                
        
        if MG:
        
            print('apporti di %s: \n' % M)
            print(app_MAIS)
            print('apporti di %s: \n' % MG)
            print(app_MAISGRA)                        
            print('apporti di %s: \n' % S[0])
            print(random_ARR_0_new)
            print('apporti di %s: \n' % S[1])
            print(random_ARR_1_new)
            print('apporti di %s: \n' % S[2])
            print(random_ARR_2_new)
            print('apporti di %s: \n' % S[3])
            print(random_ARR_3_new)
            print('apporti di %s: \n' % S[4])
            print(random_ARR_4_new)
            print('apporti di %s: \n' % S[5])
            print(random_ARR_5_new)
            
        else:
        
            print('apporti di %s: \n' % M)
            print(app_MAIS)
            print('apporti di %s: \n' % S[0])
            print(random_ARR_0_new)
            print('apporti di %s: \n' % S[1])
            print(random_ARR_1_new)
            print('apporti di %s: \n' % S[2])
            print(random_ARR_2_new)
            print('apporti di %s: \n' % S[3])
            print(random_ARR_3_new)
            print('apporti di %s: \n' % S[4])
            print(random_ARR_4_new)
            print('apporti di %s: \n' % S[5])
            print(random_ARR_5_new)
        

        if M == 'insilato di mais':
            print('La razione fornisce %f kg di %s' % (Q_INSIMA, M))
            
            
        elif M == 'pastone mais integrale':
            print('La razione fornisce %f kg di %s\n' % (Q_PASTOMAISINT, M))
            
            
        elif M == 'pastone mais granella':
            print('La razione fornisce %f kg di %s\n' % (Q_PASTOMAISGRA, M))
            

        if Q_MAISGRA:
            print('La razione fornisce %f kg di %s\n' % (QM, MG))
            print('%f kg %s' % (QM, MG))                                         
            print('%f kg %s' % (Q, M))                        
            print('%f kg %s' % (quantità_alimento_1[0], S[0]))
            print('%f kg %s' % (quantità_alimento_2[0], S[1]))
            print('%f kg %s' % (quantità_alimento_3[0], S[2]))
            print('%f kg %s' % (quantità_alimento_4[0], S[3]))
            print('%f kg %s' % (quantità_alimento_5[0], S[4]))
            print('%f kg %s' % (quantità_alimento_6[0], S[5]))
            
        else:
            print('%f kg %s' % (Q, M))                        
            print('%f kg %s' % (quantità_alimento_1[0], S[0]))
            print('%f kg %s' % (quantità_alimento_2[0], S[1]))
            print('%f kg %s' % (quantità_alimento_3[0], S[2]))
            print('%f kg %s' % (quantità_alimento_4[0], S[3]))
            print('%f kg %s' % (quantità_alimento_5[0], S[4]))
            print('%f kg %s' % (quantità_alimento_6[0], S[5]))
                                
                
        print('La razione fornisce %f kg di alimento tal quale' % QUANTITÀ_TOTALE_TAL_QUALE)
        print('La razione fornisce %f kg di sostanza secca' % APPORTO_DEFINITIVO_SOSTANZA_SECCA)

        
        print("SOSTANZA SECCA: la differenza fra l'apporto totale => %f kg e la capacità d'ingestione => %f kg è: %f kg" % (APPORTO_DEFINITIVO_SOSTANZA_SECCA, F[0], DELTA_SOSTANZA_SECCA))
        print("PROTEINA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_GREZZA, F[1], DELTA_PROTEINA_GREZZA)) 
        print("PROTEINA DEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_DEGRADABILE, F[2], DELTA_PROTEINA_DEGRADABILE))
        print("PROTEINA INDEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_INDEGRADABILE, F[3], DELTA_PROTEINA_INDEGRADABILE))
        print("FIBRA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_FIBRA_GREZZA, F[4], DELTA_FIBRA_GREZZA))
        print("NDF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_NDF, F[5], DELTA_NDF))
        print("ADF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ADF, F[6], DELTA_ADF))
        print("GRASSO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_GRASSO, F[7], DELTA_GRASSO)) 
        print("AMIDO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_AMIDO, F[8], DELTA_AMIDO))
        print("ZUCCHERI: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ZUCCHERI, F[9], DELTA_ZUCCHERI))
        print("Ca: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_Ca, F[10], DELTA_Ca))
        print("P: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_P, F[11], DELTA_P))
        print("UFL: la differenza fra l'apporto totale => %f UFL e il fabbisogno => %f UFL è: %f UFL" % (APPORTO_TOTALE_UFL, F[12], DELTA_UFL))
        
        sys.stdout = original
        print('This string goes to stdout, NOT the file!')

        

        
    elif len(S) == 7: 
        print(S[0])
        print(S[1])
        print(S[2])
        print(S[3])
        print(S[4])
        print(S[5])
        print(S[6])
        print(ARR[0])
        print(ARR[1])
        print(ARR[2])
        print(ARR[3])
        print(ARR[4])
        print(ARR[5])
        print(ARR[6])
        
        print('Hai inserito 7 alimenti \n')
#       print("QUESTA È LA VERSIONE CORRETTA DELL'ALGORITMO")
        
        random_ARR_0_old = ARR[0] * random.random() * 10
        random_ARR_1_old = ARR[1] * random.random() * 10
        random_ARR_2_old = ARR[2] * random.random() * 10
        random_ARR_3_old = ARR[3] * random.random() * 10
        random_ARR_4_old = ARR[4] * random.random() * 10
        random_ARR_5_old = ARR[5] * random.random() * 10
        random_ARR_6_old = ARR[6] * random.random() * 10

# ogni alimento scelto dall'utente viene moltiplicato per un numero casuale compreso fra 0 e 10 (kg) 
# dichiaro random_ARR_x_old

        
        random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
        random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
        random_ARR_2_new = random_ARR_2_old * (random.random() + 0.5)
        random_ARR_3_new = random_ARR_3_old * (random.random() + 0.5)
        random_ARR_4_new = random_ARR_4_old * (random.random() + 0.5)
        random_ARR_5_new = random_ARR_5_old * (random.random() + 0.5)
        random_ARR_6_new = random_ARR_6_old * (random.random() + 0.5)

# dichiaro random_ARR_x_new
        
        APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0] + random_ARR_6_new[0]

# dichiaro APPORTO_TOTALE_SOSTANZA_SECCA

        
        SOMMA_old = random_ARR_0_old + random_ARR_1_old + random_ARR_2_old + random_ARR_3_old + random_ARR_4_old + random_ARR_5_old + random_ARR_6_old
        DELTA_old = SOMMA_old - F_arr
        print('La somma iniziale è...')
        print(SOMMA_old)

# dichiaro SOMMA_old e DELTA_old

        SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new + random_ARR_5_new + random_ARR_6_new
        DELTA_new = SOMMA_new - F_arr
        print('La nuova somma è...')
        print(SOMMA_new)
        print('La nuova differenza è...')
        print(DELTA_new)

# dichiaro SOMMA_new e DELTA_new
        
        quantità_alimento_1 = random_ARR_0_new / ARR[0]
        quantità_alimento_2 = random_ARR_1_new / ARR[1]
        quantità_alimento_3 = random_ARR_2_new / ARR[2]
        quantità_alimento_4 = random_ARR_3_new / ARR[3]
        quantità_alimento_5 = random_ARR_4_new / ARR[4]
        quantità_alimento_6 = random_ARR_5_new / ARR[5]
        quantità_alimento_7 = random_ARR_6_new / ARR[6]

# dichiaro gli apporti dei singoli alimenti

        i = 0

# inizializzo il contatore i        
        
        for i in range(N_repl):
        
            rules = [abs(DELTA_new[0]) < abs(DELTA_old[0]), abs(DELTA_new[1]) < abs(DELTA_old[1]), abs(DELTA_new[2]) < abs(DELTA_old[2])]

# dichiaro le regole da rispettare
                                    
            if all(rules):
            
                print('ESTRAGGO DALLA PROPOSAL DISTRIBUTION')
                i += 1
                print(i)
                                                                                                             	            
                random_ARR_0_new = random_ARR_0_new * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_new * (random.random() + 0.5)
                random_ARR_2_new = random_ARR_2_new * (random.random() + 0.5)
                random_ARR_3_new = random_ARR_3_new * (random.random() + 0.5)
                random_ARR_4_new = random_ARR_4_new * (random.random() + 0.5)
                random_ARR_5_new = random_ARR_5_new * (random.random() + 0.5)
                random_ARR_6_new = random_ARR_6_new * (random.random() + 0.5)

# ACCETTO random_ARR_x_new e lo uso per aggiornare random_ARR_x_new stesso 
                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0] + random_ARR_6_new[0]

# aggiorno l'apporto di SS
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new + random_ARR_5_new + random_ARR_6_new
                DELTA_new = SOMMA_new - F_arr
                
# aggiorno SOMMA_new e DELTA_new                
                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                quantità_alimento_3 = random_ARR_2_new / ARR[2]
                quantità_alimento_4 = random_ARR_3_new / ARR[3]
                quantità_alimento_5 = random_ARR_4_new / ARR[4]
                quantità_alimento_6 = random_ARR_5_new / ARR[5]
                quantità_alimento_7 = random_ARR_6_new / ARR[6]
                
                if round(APPORTO_TOTALE_SOSTANZA_SECCA) == round(F_arr[0]):
                
                    break
                
                print(i)    
                print("SUCCESSO! L'APPORTO DI SOSTANZA SECCA CORRISPONDE AL FABBISOGNO.")


            else:
            
                random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
                random_ARR_2_new = random_ARR_2_old * (random.random() + 0.5)
                random_ARR_3_new = random_ARR_3_old * (random.random() + 0.5)
                random_ARR_4_new = random_ARR_4_old * (random.random() + 0.5)
                random_ARR_5_new = random_ARR_5_old * (random.random() + 0.5)
                random_ARR_6_new = random_ARR_6_old * (random.random() + 0.5)

# RIFIUTO random_ARR_x_new e lo ricalcolo a partire da random_ARR_x_old 
                
                print('FALLIMENTO')
                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0] + random_ARR_6_new[0]
                print(APPORTO_TOTALE_SOSTANZA_SECCA)
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new + random_ARR_5_new + random_ARR_6_new
                DELTA_new = SOMMA_new - F_arr
                                                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                quantità_alimento_3 = random_ARR_2_new / ARR[2]
                quantità_alimento_4 = random_ARR_3_new / ARR[3]
                quantità_alimento_5 = random_ARR_4_new / ARR[4]
                quantità_alimento_6 = random_ARR_5_new / ARR[5]
                quantità_alimento_7 = random_ARR_6_new / ARR[6]

        
        if QM:
        
            QUANTITÀ_TOTALE_TAL_QUALE = QM + Q + quantità_alimento_1[0] + quantità_alimento_2[0] + quantità_alimento_3[0] + quantità_alimento_4[0] + quantità_alimento_5[0] + quantità_alimento_6[0] + quantità_alimento_7[0]
            APPORTO_DEFINITIVO_SOSTANZA_SECCA = app_MAISGRA[0] + app_MAIS[0] + random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0] + random_ARR_6_new[0] 
            APPORTO_TOTALE_PROTEINA_GREZZA = app_MAISGRA[1] + app_MAIS[1] + random_ARR_0_new[1] + random_ARR_1_new[1] + random_ARR_2_new[1] + random_ARR_3_new[1] + random_ARR_4_new[1] + random_ARR_5_new[1] + random_ARR_6_new[1]
            APPORTO_TOTALE_PROTEINA_DEGRADABILE = app_MAISGRA[2] + app_MAIS[2] + random_ARR_0_new[2] + random_ARR_1_new[2] + random_ARR_2_new[2] + random_ARR_3_new[2] + random_ARR_4_new[2] + random_ARR_5_new[2] + random_ARR_6_new[2]
            APPORTO_TOTALE_PROTEINA_INDEGRADABILE = app_MAISGRA[3] + app_MAIS[3] + random_ARR_0_new[3] + random_ARR_1_new[3] + random_ARR_2_new[3] + random_ARR_3_new[3] + random_ARR_4_new[3] + random_ARR_5_new[3] + random_ARR_6_new[3]
            APPORTO_TOTALE_FIBRA_GREZZA = app_MAISGRA[4] + app_MAIS[4] + random_ARR_0_new[4] + random_ARR_1_new[4] + random_ARR_2_new[4] + random_ARR_3_new[4] + random_ARR_4_new[4] + random_ARR_5_new[4] + random_ARR_6_new[4]
            APPORTO_TOTALE_NDF = app_MAISGRA[5] + app_MAIS[5] + random_ARR_0_new[5] + random_ARR_1_new[5] + random_ARR_2_new[5] + random_ARR_3_new[5] + random_ARR_4_new[5] + random_ARR_5_new[5] + random_ARR_6_new[5]
            APPORTO_TOTALE_ADF = app_MAISGRA[6] + app_MAIS[6] + random_ARR_0_new[6] + random_ARR_1_new[6] + random_ARR_2_new[6] + random_ARR_3_new[6] + random_ARR_4_new[6] + random_ARR_5_new[6] + random_ARR_6_new[6]
            APPORTO_TOTALE_GRASSO = app_MAISGRA[7] + app_MAIS[7] + random_ARR_0_new[7] + random_ARR_1_new[7] + random_ARR_2_new[7] + random_ARR_3_new[7] + random_ARR_4_new[7] + random_ARR_5_new[7] + random_ARR_6_new[7]
            APPORTO_TOTALE_AMIDO = app_MAISGRA[8] + app_MAIS[8] + random_ARR_0_new[8] + random_ARR_1_new[8] + random_ARR_2_new[8] + random_ARR_3_new[8] + random_ARR_4_new[8] + random_ARR_5_new[8] + random_ARR_6_new[8]
            APPORTO_TOTALE_ZUCCHERI = app_MAISGRA[9] + app_MAIS[9] + random_ARR_0_new[9] + random_ARR_1_new[9] + random_ARR_2_new[9] + random_ARR_3_new[9] + random_ARR_4_new[9] + random_ARR_5_new[9] + random_ARR_6_new[9]
            APPORTO_TOTALE_Ca = app_MAISGRA[10] + app_MAIS[10] + random_ARR_0_new[10] + random_ARR_1_new[10] + random_ARR_2_new[10] + random_ARR_3_new[10] + random_ARR_4_new[10] + random_ARR_5_new[10] + random_ARR_6_new[10]
            APPORTO_TOTALE_P = app_MAISGRA[11] + app_MAIS[11] + random_ARR_0_new[11] + random_ARR_1_new[11] + random_ARR_2_new[11] + random_ARR_3_new[11] + random_ARR_4_new[11] + random_ARR_5_new[11] + random_ARR_6_new[11]
            APPORTO_TOTALE_UFL = app_MAISGRA[12] + app_MAIS[12] + random_ARR_0_new[12] + random_ARR_1_new[12] + random_ARR_2_new[12] + random_ARR_3_new[12] + random_ARR_4_new[12] + random_ARR_5_new[12] + random_ARR_6_new[12]
        

        else:        
            QUANTITÀ_TOTALE_TAL_QUALE = Q + quantità_alimento_1[0] + quantità_alimento_2[0] + quantità_alimento_3[0] + quantità_alimento_4[0] + quantità_alimento_5[0] + quantità_alimento_6[0] + quantità_alimento_7[0]
            APPORTO_DEFINITIVO_SOSTANZA_SECCA = app_MAIS[0] + random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0] + random_ARR_6_new[0] 
            APPORTO_TOTALE_PROTEINA_GREZZA = app_MAIS[1] + random_ARR_0_new[1] + random_ARR_1_new[1] + random_ARR_2_new[1] + random_ARR_3_new[1] + random_ARR_4_new[1] + random_ARR_5_new[1] + random_ARR_6_new[1]
            APPORTO_TOTALE_PROTEINA_DEGRADABILE = app_MAIS[2] + random_ARR_0_new[2] + random_ARR_1_new[2] + random_ARR_2_new[2] + random_ARR_3_new[2] + random_ARR_4_new[2] + random_ARR_5_new[2] + random_ARR_6_new[2]
            APPORTO_TOTALE_PROTEINA_INDEGRADABILE = app_MAIS[3] + random_ARR_0_new[3] + random_ARR_1_new[3] + random_ARR_2_new[3] + random_ARR_3_new[3] + random_ARR_4_new[3] + random_ARR_5_new[3] + random_ARR_6_new[3]
            APPORTO_TOTALE_FIBRA_GREZZA = app_MAIS[4] + random_ARR_0_new[4] + random_ARR_1_new[4] + random_ARR_2_new[4] + random_ARR_3_new[4] + random_ARR_4_new[4] + random_ARR_5_new[4] + random_ARR_6_new[4]
            APPORTO_TOTALE_NDF = app_MAIS[5] + random_ARR_0_new[5] + random_ARR_1_new[5] + random_ARR_2_new[5] + random_ARR_3_new[5] + random_ARR_4_new[5] + random_ARR_5_new[5] + random_ARR_6_new[5]
            APPORTO_TOTALE_ADF = app_MAIS[6] + random_ARR_0_new[6] + random_ARR_1_new[6] + random_ARR_2_new[6] + random_ARR_3_new[6] + random_ARR_4_new[6] + random_ARR_5_new[6] + random_ARR_6_new[6]
            APPORTO_TOTALE_GRASSO = app_MAIS[7] + random_ARR_0_new[7] + random_ARR_1_new[7] + random_ARR_2_new[7] + random_ARR_3_new[7] + random_ARR_4_new[7] + random_ARR_5_new[7] + random_ARR_6_new[7]
            APPORTO_TOTALE_AMIDO = app_MAIS[8] + random_ARR_0_new[8] + random_ARR_1_new[8] + random_ARR_2_new[8] + random_ARR_3_new[8] + random_ARR_4_new[8] + random_ARR_5_new[8] + random_ARR_6_new[8]
            APPORTO_TOTALE_ZUCCHERI = app_MAIS[9] + random_ARR_0_new[9] + random_ARR_1_new[9] + random_ARR_2_new[9] + random_ARR_3_new[9] + random_ARR_4_new[9] + random_ARR_5_new[9] + random_ARR_6_new[9]
            APPORTO_TOTALE_Ca = app_MAIS[10] + random_ARR_0_new[10] + random_ARR_1_new[10] + random_ARR_2_new[10] + random_ARR_3_new[10] + random_ARR_4_new[10] + random_ARR_5_new[10] + random_ARR_6_new[10]
            APPORTO_TOTALE_P = app_MAIS[11] + random_ARR_0_new[11] + random_ARR_1_new[11] + random_ARR_2_new[11] + random_ARR_3_new[11] + random_ARR_4_new[11] + random_ARR_5_new[11] + random_ARR_6_new[11]
            APPORTO_TOTALE_UFL = app_MAIS[12] + random_ARR_0_new[12] + random_ARR_1_new[12] + random_ARR_2_new[12] + random_ARR_3_new[12] + random_ARR_4_new[12] + random_ARR_5_new[12] + random_ARR_6_new[12]

        
        DELTA_SOSTANZA_SECCA = APPORTO_DEFINITIVO_SOSTANZA_SECCA - F[0]
        DELTA_PROTEINA_GREZZA = APPORTO_TOTALE_PROTEINA_GREZZA - F[1]
        DELTA_PROTEINA_DEGRADABILE = APPORTO_TOTALE_PROTEINA_DEGRADABILE - F[2]
        DELTA_PROTEINA_INDEGRADABILE = APPORTO_TOTALE_PROTEINA_INDEGRADABILE - F[3]
        DELTA_FIBRA_GREZZA = APPORTO_TOTALE_FIBRA_GREZZA - F[4]
        DELTA_NDF = APPORTO_TOTALE_NDF - F[5]
        DELTA_ADF = APPORTO_TOTALE_ADF - F[6]
        DELTA_GRASSO = APPORTO_TOTALE_GRASSO - F[7]
        DELTA_AMIDO = APPORTO_TOTALE_AMIDO - F[8]
        DELTA_ZUCCHERI = APPORTO_TOTALE_ZUCCHERI - F[9]
        DELTA_Ca = APPORTO_TOTALE_Ca - F[10]
        DELTA_P = APPORTO_TOTALE_P - F[11]
        DELTA_UFL = APPORTO_TOTALE_UFL - F[12]
        
        original = sys.stdout
        sys.stdout = open('NUOVA_RAZIONE.txt', 'w')
        
        
        if day == 'Monday': 
            print('RAZIONE di %s, creata lunedì %s, %s' % (user, data, current_time))
        if day == 'Tuesday': 
            print('RAZIONE di %s, creata martedì %s, %s' % (user, data, current_time))
        if day == 'Wednesday': 
            print('RAZIONE di %s, creata mercoledì %s, %s' % (user, data, current_time))
        if day == 'Thursday': 
            print('RAZIONE di %s, creata giovedì %s, %s' % (user, data, current_time))
        if day == 'Friday': 
            print('RAZIONE di %s, creata venerdì %s, %s' % (user, data, current_time))
        if day == 'Saturday': 
            print('RAZIONE di %s, creata sabato %s, %s' % (user, data, current_time))
        if day == 'Sunday': 
            print('RAZIONE di %s, creata domenica %s, %s' % (user, data, current_time))
        
        
        print('')
#       print('This is your redirected text:')
        print('')
        if i == 999:
            print('Il calcolo della razione non ha avuto successo; per favore chiudi il programma e riprova.')
        else:
            print('Il calcolo della razione è stato effettuato con successo alla %d^esima replica' % i)        
#       print(i)
        print('')
        print('Il fabbisogno di SOSTANZA SECCA è di %f' %  F_arr[0])
        print('')
        print("L'apporto totale di SOSTANZA SECCA è di %f" % APPORTO_TOTALE_SOSTANZA_SECCA)
        print('')
        print('out of loop')
        print('')        
        print('LEGENDA')
        print('')
        print("DMI => Dry Matter Intake (Capacità d'ingestione di Sostanza Secca)")
        print("CPI => Crude Protein Intake (Apporto di Proteina Grezza)")
        print("RDPI => Rumen Degradable Protein Intake (Apporto di Proteina Degradabile)")
        print("RUPI => Rumen Undegradable Protein Intake (Apporto di Proteina Indegradabile)")
        print("FG => Fibra Grezza (apporto di Fibra Grezza)")
        print("NDF => Neutral Detergent Fiber (apporto di Fibra resistente al Detergente Neutro)")
        print("ADF => Acid Detergent Fiber (apporto di Fibra resistente al Detergente Acido)")
        print("FAT => Fat (apporto di Grasso)")
        print("AM => Amido (apporto di Amido)")
        print("ZUC => Zuccheri (apporto di Zuccheri)")
        print("Ca => Calcio (apporto di Calcio)")
        print("P => Fosforo (apporto di Fosforo)")
        print("UFL => Unità Foraggere Latte (apporto di Energia Netta)")
        print('DMI', 'CPI', 'RDPI', 'RUPI', 'FG', 'NDF', 'ADF', 'FAT', 'AM', 'ZUC', 'Ca', 'P', 'UFL')                	                
        
        if MG:
        
            print('apporti di %s: \n' % M)
            print(app_MAIS)
            print('apporti di %s: \n' % MG)
            print(app_MAISGRA)                        
            print('apporti di %s: \n' % S[0])
            print(random_ARR_0_new)
            print('apporti di %s: \n' % S[1])
            print(random_ARR_1_new)
            print('apporti di %s: \n' % S[2])
            print(random_ARR_2_new)
            print('apporti di %s: \n' % S[3])
            print(random_ARR_3_new)
            print('apporti di %s: \n' % S[4])
            print(random_ARR_4_new)
            print('apporti di %s: \n' % S[5])
            print(random_ARR_5_new)
            print('apporti di %s: \n' % S[6])
            print(random_ARR_6_new)
            
        else:
        
            print('apporti di %s: \n' % M)
            print(app_MAIS)
            print('apporti di %s: \n' % S[0])
            print(random_ARR_0_new)
            print('apporti di %s: \n' % S[1])
            print(random_ARR_1_new)
            print('apporti di %s: \n' % S[2])
            print(random_ARR_2_new)
            print('apporti di %s: \n' % S[3])
            print(random_ARR_3_new)
            print('apporti di %s: \n' % S[4])
            print(random_ARR_4_new)
            print('apporti di %s: \n' % S[5])
            print(random_ARR_5_new)
            print('apporti di %s: \n' % S[6])
            print(random_ARR_6_new)

                                        
        if M == 'insilato di mais':
            print('La razione fornisce %f kg di %s' % (Q_INSIMA, M))
            
            
        elif M == 'pastone mais integrale':
            print('La razione fornisce %f kg di %s\n' % (Q_PASTOMAISINT, M))
            
            
        elif M == 'pastone mais granella':
            print('La razione fornisce %f kg di %s\n' % (Q_PASTOMAISGRA, M))
            


        if Q_MAISGRA:
            print('La razione fornisce %f kg di %s\n' % (QM, MG))
            print('%f kg %s' % (QM, MG))                                         
            print('%f kg %s' % (Q, M))                        
            print('%f kg %s' % (quantità_alimento_1[0], S[0]))
            print('%f kg %s' % (quantità_alimento_2[0], S[1]))
            print('%f kg %s' % (quantità_alimento_3[0], S[2]))
            print('%f kg %s' % (quantità_alimento_4[0], S[3]))
            print('%f kg %s' % (quantità_alimento_5[0], S[4]))
            print('%f kg %s' % (quantità_alimento_6[0], S[5]))
            print('%f kg %s' % (quantità_alimento_7[0], S[6]))
            
        else:
            print('%f kg %s' % (Q, M))                        
            print('%f kg %s' % (quantità_alimento_1[0], S[0]))
            print('%f kg %s' % (quantità_alimento_2[0], S[1]))
            print('%f kg %s' % (quantità_alimento_3[0], S[2]))
            print('%f kg %s' % (quantità_alimento_4[0], S[3]))
            print('%f kg %s' % (quantità_alimento_5[0], S[4]))
            print('%f kg %s' % (quantità_alimento_6[0], S[5]))
            print('%f kg %s' % (quantità_alimento_7[0], S[6]))

                                                
        print('La razione fornisce %f kg di alimento tal quale' % QUANTITÀ_TOTALE_TAL_QUALE)
        print('La razione fornisce %f kg di sostanza secca' % APPORTO_DEFINITIVO_SOSTANZA_SECCA)
        
        print("SOSTANZA SECCA: la differenza fra l'apporto totale => %f kg e la capacità d'ingestione => %f kg è: %f kg" % (APPORTO_DEFINITIVO_SOSTANZA_SECCA, F[0], DELTA_SOSTANZA_SECCA))
        print("PROTEINA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_GREZZA, F[1], DELTA_PROTEINA_GREZZA)) 
        print("PROTEINA DEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_DEGRADABILE, F[2], DELTA_PROTEINA_DEGRADABILE))
        print("PROTEINA INDEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_INDEGRADABILE, F[3], DELTA_PROTEINA_INDEGRADABILE))
        print("FIBRA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_FIBRA_GREZZA, F[4], DELTA_FIBRA_GREZZA))
        print("NDF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_NDF, F[5], DELTA_NDF))
        print("ADF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ADF, F[6], DELTA_ADF))
        print("GRASSO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_GRASSO, F[7], DELTA_GRASSO)) 
        print("AMIDO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_AMIDO, F[8], DELTA_AMIDO))
        print("ZUCCHERI: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ZUCCHERI, F[9], DELTA_ZUCCHERI))
        print("Ca: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_Ca, F[10], DELTA_Ca))
        print("P: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_P, F[11], DELTA_P))
        print("UFL: la differenza fra l'apporto totale => %f UFL e il fabbisogno => %f UFL è: %f UFL" % (APPORTO_TOTALE_UFL, F[12], DELTA_UFL))
        
        sys.stdout = original
        print('This string goes to stdout, NOT the file!')

                        
        

        
    elif len(S) == 8: 
        print(S[0])
        print(S[1])
        print(S[2])
        print(S[3])
        print(S[4])
        print(S[5])
        print(S[6])
        print(S[7])
        print(ARR[0])
        print(ARR[1])
        print(ARR[2])
        print(ARR[3])
        print(ARR[4])
        print(ARR[5])
        print(ARR[6])
        print(ARR[7])
        
        print('Hai inserito 8 alimenti \n')
        
#       print("QUESTA È LA VERSIONE CORRETTA DELL'ALGORITMO")
        
        random_ARR_0_old = ARR[0] * random.random() * 10
        random_ARR_1_old = ARR[1] * random.random() * 10
        random_ARR_2_old = ARR[2] * random.random() * 10
        random_ARR_3_old = ARR[3] * random.random() * 10
        random_ARR_4_old = ARR[4] * random.random() * 10
        random_ARR_5_old = ARR[5] * random.random() * 10
        random_ARR_6_old = ARR[6] * random.random() * 10
        random_ARR_7_old = ARR[7] * random.random() * 10

# ogni alimento scelto dall'utente viene moltiplicato per un numero casuale compreso fra 0 e 10 (kg) 
# dichiaro random_ARR_x_old

        
        random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
        random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
        random_ARR_2_new = random_ARR_2_old * (random.random() + 0.5)
        random_ARR_3_new = random_ARR_3_old * (random.random() + 0.5)
        random_ARR_4_new = random_ARR_4_old * (random.random() + 0.5)
        random_ARR_5_new = random_ARR_5_old * (random.random() + 0.5)
        random_ARR_6_new = random_ARR_6_old * (random.random() + 0.5)
        random_ARR_7_new = random_ARR_7_old * (random.random() + 0.5)

# dichiaro random_ARR_x_new
        
        SOMMA_old = random_ARR_0_old + random_ARR_1_old + random_ARR_2_old + random_ARR_3_old + random_ARR_4_old + random_ARR_5_old + random_ARR_6_old + random_ARR_7_old
        DELTA_old = SOMMA_old - F_arr
        print('La somma iniziale è...')
        print(SOMMA_old)

# dichiaro SOMMA_old e DELTA_old

        SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new + random_ARR_5_new + random_ARR_6_new + random_ARR_7_new
        DELTA_new = SOMMA_new - F_arr
        print('La nuova somma è...')
        print(SOMMA_new)
        print('La nuova differenza è...')
        print(DELTA_new)

# dichiaro SOMMA_new e DELTA_new
        
        quantità_alimento_1 = random_ARR_0_new / ARR[0]
        quantità_alimento_2 = random_ARR_1_new / ARR[1]
        quantità_alimento_3 = random_ARR_2_new / ARR[2]
        quantità_alimento_4 = random_ARR_3_new / ARR[3]
        quantità_alimento_5 = random_ARR_4_new / ARR[4]
        quantità_alimento_6 = random_ARR_5_new / ARR[5]
        quantità_alimento_7 = random_ARR_6_new / ARR[6]
        quantità_alimento_8 = random_ARR_7_new / ARR[7]

# dichiaro gli apporti dei singoli alimenti

# dichiaro gli apporti dei singoli alimenti

        i = 0

# inizializzo il contatore i        
        
        for i in range(N_repl):
        
            rules = [abs(DELTA_new[0]) < abs(DELTA_old[0]), abs(DELTA_new[1]) < abs(DELTA_old[1]), abs(DELTA_new[2]) < abs(DELTA_old[2])]

# dichiaro le regole da rispettare
                                    
            if all(rules):
            
                print('ESTRAGGO DALLA PROPOSAL DISTRIBUTION')
                i += 1
                print(i)
                                                         	               	        
                random_ARR_0_new = random_ARR_0_new * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_new * (random.random() + 0.5)
                random_ARR_2_new = random_ARR_2_new * (random.random() + 0.5)
                random_ARR_3_new = random_ARR_3_new * (random.random() + 0.5)
                random_ARR_4_new = random_ARR_4_new * (random.random() + 0.5)
                random_ARR_5_new = random_ARR_5_new * (random.random() + 0.5)
                random_ARR_6_new = random_ARR_6_new * (random.random() + 0.5)
                random_ARR_7_new = random_ARR_7_new * (random.random() + 0.5)

# ACCETTO random_ARR_x_new e lo uso per aggiornare random_ARR_x_new stesso 
                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0] + random_ARR_6_new[0] + random_ARR_7_new[0]
                print(APPORTO_TOTALE_SOSTANZA_SECCA)

# aggiorno l'apporto di SS
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new + random_ARR_5_new + random_ARR_6_new + random_ARR_7_new
                DELTA_new = SOMMA_new - F_arr
                
# aggiorno SOMMA_new e DELTA_new                
                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                quantità_alimento_3 = random_ARR_2_new / ARR[2]
                quantità_alimento_4 = random_ARR_3_new / ARR[3]
                quantità_alimento_5 = random_ARR_4_new / ARR[4]
                quantità_alimento_6 = random_ARR_5_new / ARR[5]
                quantità_alimento_7 = random_ARR_6_new / ARR[6]
                quantità_alimento_8 = random_ARR_7_new / ARR[7]
                
                if round(APPORTO_TOTALE_SOSTANZA_SECCA) == round(F_arr[0]):
                
                    break
                
                print(i)    
                print("SUCCESSO! L'APPORTO DI SOSTANZA SECCA CORRISPONDE AL FABBISOGNO.")

                                       	                
            else:
                    
                random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
                random_ARR_2_new = random_ARR_2_old * (random.random() + 0.5)
                random_ARR_3_new = random_ARR_3_old * (random.random() + 0.5)
                random_ARR_4_new = random_ARR_4_old * (random.random() + 0.5)
                random_ARR_5_new = random_ARR_5_old * (random.random() + 0.5)
                random_ARR_6_new = random_ARR_6_old * (random.random() + 0.5)
                random_ARR_7_new = random_ARR_7_old * (random.random() + 0.5)

# RIFIUTO random_ARR_x_new e lo ricalcolo a partire da random_ARR_x_old 
                
                print('FALLIMENTO')
                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0] + random_ARR_6_new[0] + random_ARR_7_new[0]
                print(APPORTO_TOTALE_SOSTANZA_SECCA)
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new + random_ARR_5_new + random_ARR_6_new + random_ARR_7_new
                DELTA_new = SOMMA_new - F_arr
                                                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                quantità_alimento_3 = random_ARR_2_new / ARR[2]
                quantità_alimento_4 = random_ARR_3_new / ARR[3]
                quantità_alimento_5 = random_ARR_4_new / ARR[4]
                quantità_alimento_6 = random_ARR_5_new / ARR[5]
                quantità_alimento_7 = random_ARR_6_new / ARR[6]
                quantità_alimento_8 = random_ARR_7_new / ARR[7]


        if QM:

            QUANTITÀ_TOTALE_TAL_QUALE = QM + Q + quantità_alimento_1[0] + quantità_alimento_2[0] + quantità_alimento_3[0] + quantità_alimento_4[0] + quantità_alimento_5[0] + quantità_alimento_6[0] + quantità_alimento_7[0] + quantità_alimento_8[0]
            APPORTO_DEFINITIVO_SOSTANZA_SECCA = app_MAISGRA[0] + app_MAIS[0] + random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0] + random_ARR_6_new[0] + random_ARR_7_new[0] 
            APPORTO_TOTALE_PROTEINA_GREZZA = app_MAISGRA[1] + app_MAIS[1] + random_ARR_0_new[1] + random_ARR_1_new[1] + random_ARR_2_new[1] + random_ARR_3_new[1] + random_ARR_4_new[1] + random_ARR_5_new[1] + random_ARR_6_new[1] + random_ARR_7_new[1]
            APPORTO_TOTALE_PROTEINA_DEGRADABILE = app_MAISGRA[2] + app_MAIS[2] + random_ARR_0_new[2] + random_ARR_1_new[2] + random_ARR_2_new[2] + random_ARR_3_new[2] + random_ARR_4_new[2] + random_ARR_5_new[2] + random_ARR_6_new[2] + random_ARR_7_new[2]
            APPORTO_TOTALE_PROTEINA_INDEGRADABILE = app_MAISGRA[3] + app_MAIS[3] + random_ARR_0_new[3] + random_ARR_1_new[3] + random_ARR_2_new[3] + random_ARR_3_new[3] + random_ARR_4_new[3] + random_ARR_5_new[3] + random_ARR_6_new[3] + random_ARR_7_new[3]
            APPORTO_TOTALE_FIBRA_GREZZA = app_MAISGRA[4] + app_MAIS[4] + random_ARR_0_new[4] + random_ARR_1_new[4] + random_ARR_2_new[4] + random_ARR_3_new[4] + random_ARR_4_new[4] + random_ARR_5_new[4] + random_ARR_6_new[4] + random_ARR_7_new[4]
            APPORTO_TOTALE_NDF = app_MAISGRA[5] + app_MAIS[5] + random_ARR_0_new[5] + random_ARR_1_new[5] + random_ARR_2_new[5] + random_ARR_3_new[5] + random_ARR_4_new[5] + random_ARR_5_new[5] + random_ARR_6_new[5] + random_ARR_7_new[5]
            APPORTO_TOTALE_ADF = app_MAISGRA[6] + app_MAIS[6] + random_ARR_0_new[6] + random_ARR_1_new[6] + random_ARR_2_new[6] + random_ARR_3_new[6] + random_ARR_4_new[6] + random_ARR_5_new[6] + random_ARR_6_new[6] + random_ARR_7_new[6]
            APPORTO_TOTALE_GRASSO = app_MAISGRA[7] + app_MAIS[7] + random_ARR_0_new[7] + random_ARR_1_new[7] + random_ARR_2_new[7] + random_ARR_3_new[7] + random_ARR_4_new[7] + random_ARR_5_new[7] + random_ARR_6_new[7] + random_ARR_7_new[7]
            APPORTO_TOTALE_AMIDO = app_MAISGRA[8] + app_MAIS[8] + random_ARR_0_new[8] + random_ARR_1_new[8] + random_ARR_2_new[8] + random_ARR_3_new[8] + random_ARR_4_new[8] + random_ARR_5_new[8] + random_ARR_6_new[8] + random_ARR_7_new[8]
            APPORTO_TOTALE_ZUCCHERI = app_MAISGRA[9] + app_MAIS[9] + random_ARR_0_new[9] + random_ARR_1_new[9] + random_ARR_2_new[9] + random_ARR_3_new[9] + random_ARR_4_new[9] + random_ARR_5_new[9] + random_ARR_6_new[9] + random_ARR_7_new[9]
            APPORTO_TOTALE_Ca = app_MAISGRA[10] + app_MAIS[10] + random_ARR_0_new[10] + random_ARR_1_new[10] + random_ARR_2_new[10] + random_ARR_3_new[10] + random_ARR_4_new[10] + random_ARR_5_new[10] + random_ARR_6_new[10] + random_ARR_7_new[10]
            APPORTO_TOTALE_P = app_MAISGRA[11] + app_MAIS[11] + random_ARR_0_new[11] + random_ARR_1_new[11] + random_ARR_2_new[11] + random_ARR_3_new[11] + random_ARR_4_new[11] + random_ARR_5_new[11] + random_ARR_6_new[11] + random_ARR_7_new[11]
            APPORTO_TOTALE_UFL = app_MAISGRA[12] + app_MAIS[12] + random_ARR_0_new[12] + random_ARR_1_new[12] + random_ARR_2_new[12] + random_ARR_3_new[12] + random_ARR_4_new[12] + random_ARR_5_new[12] + random_ARR_6_new[12] + random_ARR_7_new[12]                

        
        else:
        
            QUANTITÀ_TOTALE_TAL_QUALE = Q + quantità_alimento_1[0] + quantità_alimento_2[0] + quantità_alimento_3[0] + quantità_alimento_4[0] + quantità_alimento_5[0] + quantità_alimento_6[0] + quantità_alimento_7[0] + quantità_alimento_8[0]
            APPORTO_DEFINITIVO_SOSTANZA_SECCA = app_MAIS[0] + random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0] + random_ARR_6_new[0] + random_ARR_7_new[0] 
            APPORTO_TOTALE_PROTEINA_GREZZA = app_MAIS[1] + random_ARR_0_new[1] + random_ARR_1_new[1] + random_ARR_2_new[1] + random_ARR_3_new[1] + random_ARR_4_new[1] + random_ARR_5_new[1] + random_ARR_6_new[1] + random_ARR_7_new[1]
            APPORTO_TOTALE_PROTEINA_DEGRADABILE = app_MAIS[2] + random_ARR_0_new[2] + random_ARR_1_new[2] + random_ARR_2_new[2] + random_ARR_3_new[2] + random_ARR_4_new[2] + random_ARR_5_new[2] + random_ARR_6_new[2] + random_ARR_7_new[2]
            APPORTO_TOTALE_PROTEINA_INDEGRADABILE = app_MAIS[3] + random_ARR_0_new[3] + random_ARR_1_new[3] + random_ARR_2_new[3] + random_ARR_3_new[3] + random_ARR_4_new[3] + random_ARR_5_new[3] + random_ARR_6_new[3] + random_ARR_7_new[3]
            APPORTO_TOTALE_FIBRA_GREZZA = app_MAIS[4] + random_ARR_0_new[4] + random_ARR_1_new[4] + random_ARR_2_new[4] + random_ARR_3_new[4] + random_ARR_4_new[4] + random_ARR_5_new[4] + random_ARR_6_new[4] + random_ARR_7_new[4]
            APPORTO_TOTALE_NDF = app_MAIS[5] + random_ARR_0_new[5] + random_ARR_1_new[5] + random_ARR_2_new[5] + random_ARR_3_new[5] + random_ARR_4_new[5] + random_ARR_5_new[5] + random_ARR_6_new[5] + random_ARR_7_new[5]
            APPORTO_TOTALE_ADF = app_MAIS[6] + random_ARR_0_new[6] + random_ARR_1_new[6] + random_ARR_2_new[6] + random_ARR_3_new[6] + random_ARR_4_new[6] + random_ARR_5_new[6] + random_ARR_6_new[6] + random_ARR_7_new[6]
            APPORTO_TOTALE_GRASSO = app_MAIS[7] + random_ARR_0_new[7] + random_ARR_1_new[7] + random_ARR_2_new[7] + random_ARR_3_new[7] + random_ARR_4_new[7] + random_ARR_5_new[7] + random_ARR_6_new[7] + random_ARR_7_new[7]
            APPORTO_TOTALE_AMIDO = app_MAIS[8] + random_ARR_0_new[8] + random_ARR_1_new[8] + random_ARR_2_new[8] + random_ARR_3_new[8] + random_ARR_4_new[8] + random_ARR_5_new[8] + random_ARR_6_new[8] + random_ARR_7_new[8]
            APPORTO_TOTALE_ZUCCHERI = app_MAIS[9] + random_ARR_0_new[9] + random_ARR_1_new[9] + random_ARR_2_new[9] + random_ARR_3_new[9] + random_ARR_4_new[9] + random_ARR_5_new[9] + random_ARR_6_new[9] + random_ARR_7_new[9]
            APPORTO_TOTALE_Ca = app_MAIS[10] + random_ARR_0_new[10] + random_ARR_1_new[10] + random_ARR_2_new[10] + random_ARR_3_new[10] + random_ARR_4_new[10] + random_ARR_5_new[10] + random_ARR_6_new[10] + random_ARR_7_new[10]
            APPORTO_TOTALE_P = app_MAIS[11] + random_ARR_0_new[11] + random_ARR_1_new[11] + random_ARR_2_new[11] + random_ARR_3_new[11] + random_ARR_4_new[11] + random_ARR_5_new[11] + random_ARR_6_new[11] + random_ARR_7_new[11]
            APPORTO_TOTALE_UFL = app_MAIS[12] + random_ARR_0_new[12] + random_ARR_1_new[12] + random_ARR_2_new[12] + random_ARR_3_new[12] + random_ARR_4_new[12] + random_ARR_5_new[12] + random_ARR_6_new[12] + random_ARR_7_new[12]                

        
        DELTA_SOSTANZA_SECCA = APPORTO_DEFINITIVO_SOSTANZA_SECCA - F[0]
        DELTA_PROTEINA_GREZZA = APPORTO_TOTALE_PROTEINA_GREZZA - F[1]
        DELTA_PROTEINA_DEGRADABILE = APPORTO_TOTALE_PROTEINA_DEGRADABILE - F[2]
        DELTA_PROTEINA_INDEGRADABILE = APPORTO_TOTALE_PROTEINA_INDEGRADABILE - F[3]
        DELTA_FIBRA_GREZZA = APPORTO_TOTALE_FIBRA_GREZZA - F[4]
        DELTA_NDF = APPORTO_TOTALE_NDF - F[5]
        DELTA_ADF = APPORTO_TOTALE_ADF - F[6]
        DELTA_GRASSO = APPORTO_TOTALE_GRASSO - F[7]
        DELTA_AMIDO = APPORTO_TOTALE_AMIDO - F[8]
        DELTA_ZUCCHERI = APPORTO_TOTALE_ZUCCHERI - F[9]
        DELTA_Ca = APPORTO_TOTALE_Ca - F[10]
        DELTA_P = APPORTO_TOTALE_P - F[11]
        DELTA_UFL = APPORTO_TOTALE_UFL - F[12]

        original = sys.stdout
        sys.stdout = open('NUOVA_RAZIONE.txt', 'w')
        
        
        if day == 'Monday': 
            print('RAZIONE di %s, creata lunedì %s, %s' % (user, data, current_time))
        if day == 'Tuesday': 
            print('RAZIONE di %s, creata martedì %s, %s' % (user, data, current_time))
        if day == 'Wednesday': 
            print('RAZIONE di %s, creata mercoledì %s, %s' % (user, data, current_time))
        if day == 'Thursday': 
            print('RAZIONE di %s, creata giovedì %s, %s' % (user, data, current_time))
        if day == 'Friday': 
            print('RAZIONE di %s, creata venerdì %s, %s' % (user, data, current_time))
        if day == 'Saturday': 
            print('RAZIONE di %s, creata sabato %s, %s' % (user, data, current_time))
        if day == 'Sunday': 
            print('RAZIONE di %s, creata domenica %s, %s' % (user, data, current_time))
        
        
        print('')
#       print('This is your redirected text:')
        print('')
        if i == 999:
            print('Il calcolo della razione non ha avuto successo; per favore chiudi il programma e riprova.')
        else:
            print('Il calcolo della razione è stato effettuato con successo alla %d^esima replica' % i)        
#       print(i)
        print('')
        print('Il fabbisogno di SOSTANZA SECCA è di %f' %  F_arr[0])
        print('')
        print("L'apporto totale di SOSTANZA SECCA è di %f" % APPORTO_TOTALE_SOSTANZA_SECCA)
        print('')
        print('out of loop')
        print('')        
        print('LEGENDA')
        print('')
        print("DMI => Dry Matter Intake (Capacità d'ingestione di Sostanza Secca)")
        print("CPI => Crude Protein Intake (Apporto di Proteina Grezza)")
        print("RDPI => Rumen Degradable Protein Intake (Apporto di Proteina Degradabile)")
        print("RUPI => Rumen Undegradable Protein Intake (Apporto di Proteina Indegradabile)")
        print("FG => Fibra Grezza (apporto di Fibra Grezza)")
        print("NDF => Neutral Detergent Fiber (apporto di Fibra resistente al Detergente Neutro)")
        print("ADF => Acid Detergent Fiber (apporto di Fibra resistente al Detergente Acido)")
        print("FAT => Fat (apporto di Grasso)")
        print("AM => Amido (apporto di Amido)")
        print("ZUC => Zuccheri (apporto di Zuccheri)")
        print("Ca => Calcio (apporto di Calcio)")
        print("P => Fosforo (apporto di Fosforo)")
        print("UFL => Unità Foraggere Latte (apporto di Energia Netta)")
        print('DMI', 'CPI', 'RDPI', 'RUPI', 'FG', 'NDF', 'ADF', 'FAT', 'AM', 'ZUC', 'Ca', 'P', 'UFL')                	                
        if MG:
        
            print('apporti di %s: \n' % M)
            print(app_MAIS)
            print('apporti di %s: \n' % MG)
            print(app_MAISGRA)                        
            print('apporti di %s: \n' % S[0])
            print(random_ARR_0_new)
            print('apporti di %s: \n' % S[1])
            print(random_ARR_1_new)
            print('apporti di %s: \n' % S[2])
            print(random_ARR_2_new)
            print('apporti di %s: \n' % S[3])
            print(random_ARR_3_new)
            print('apporti di %s: \n' % S[4])
            print(random_ARR_4_new)
            print('apporti di %s: \n' % S[5])
            print(random_ARR_5_new)
            print('apporti di %s: \n' % S[6])
            print(random_ARR_6_new)
            print('apporti di %s: \n' % S[7])
            print(random_ARR_7_new)
            
        else:
        
            print('apporti di %s: \n' % M)
            print(app_MAIS)
            print('apporti di %s: \n' % S[0])
            print(random_ARR_0_new)
            print('apporti di %s: \n' % S[1])
            print(random_ARR_1_new)
            print('apporti di %s: \n' % S[2])
            print(random_ARR_2_new)
            print('apporti di %s: \n' % S[3])
            print(random_ARR_3_new)
            print('apporti di %s: \n' % S[4])
            print(random_ARR_4_new)
            print('apporti di %s: \n' % S[5])
            print(random_ARR_5_new)
            print('apporti di %s: \n' % S[6])
            print(random_ARR_6_new)
            print('apporti di %s: \n' % S[7])
            print(random_ARR_7_new)

                                        
        if M == 'insilato di mais':
            print('La razione fornisce %f kg di %s' % (Q_INSIMA, M))
            
            
        elif M == 'pastone mais integrale':
            print('La razione fornisce %f kg di %s\n' % (Q_PASTOMAISINT, M))
            
            
        elif M == 'pastone mais granella':
            print('La razione fornisce %f kg di %s\n' % (Q_PASTOMAISGRA, M))
            
        

        if Q_MAISGRA:
            print('La razione fornisce %f kg di %s\n' % (QM, MG))
            print('%f kg %s' % (QM, MG))                                         
            print('%f kg %s' % (Q, M))                        
            print('%f kg %s' % (quantità_alimento_1[0], S[0]))
            print('%f kg %s' % (quantità_alimento_2[0], S[1]))
            print('%f kg %s' % (quantità_alimento_3[0], S[2]))
            print('%f kg %s' % (quantità_alimento_4[0], S[3]))
            print('%f kg %s' % (quantità_alimento_5[0], S[4]))
            print('%f kg %s' % (quantità_alimento_6[0], S[5]))
            print('%f kg %s' % (quantità_alimento_7[0], S[6]))
            print('%f kg %s' % (quantità_alimento_8[0], S[7]))
            
        else:
            print('%f kg %s' % (Q, M))                        
            print('%f kg %s' % (quantità_alimento_1[0], S[0]))
            print('%f kg %s' % (quantità_alimento_2[0], S[1]))
            print('%f kg %s' % (quantità_alimento_3[0], S[2]))
            print('%f kg %s' % (quantità_alimento_4[0], S[3]))
            print('%f kg %s' % (quantità_alimento_5[0], S[4]))
            print('%f kg %s' % (quantità_alimento_6[0], S[5]))
            print('%f kg %s' % (quantità_alimento_7[0], S[6]))
            print('%f kg %s' % (quantità_alimento_8[0], S[7]))

                                        
        print('La razione fornisce %f kg di alimento tal quale' % QUANTITÀ_TOTALE_TAL_QUALE)
        print('La razione fornisce %f kg di sostanza secca' % APPORTO_DEFINITIVO_SOSTANZA_SECCA)
        
        print("SOSTANZA SECCA: la differenza fra l'apporto totale => %f kg e la capacità d'ingestione => %f kg è: %f kg" % (APPORTO_DEFINITIVO_SOSTANZA_SECCA, F[0], DELTA_SOSTANZA_SECCA))
        print("PROTEINA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_GREZZA, F[1], DELTA_PROTEINA_GREZZA)) 
        print("PROTEINA DEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_DEGRADABILE, F[2], DELTA_PROTEINA_DEGRADABILE))
        print("PROTEINA INDEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_INDEGRADABILE, F[3], DELTA_PROTEINA_INDEGRADABILE))
        print("FIBRA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_FIBRA_GREZZA, F[4], DELTA_FIBRA_GREZZA))
        print("NDF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_NDF, F[5], DELTA_NDF))
        print("ADF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ADF, F[6], DELTA_ADF))
        print("GRASSO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_GRASSO, F[7], DELTA_GRASSO)) 
        print("AMIDO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_AMIDO, F[8], DELTA_AMIDO))
        print("ZUCCHERI: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ZUCCHERI, F[9], DELTA_ZUCCHERI))
        print("Ca: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_Ca, F[10], DELTA_Ca))
        print("P: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_P, F[11], DELTA_P))
        print("UFL: la differenza fra l'apporto totale => %f UFL e il fabbisogno => %f UFL è: %f UFL" % (APPORTO_TOTALE_UFL, F[12], DELTA_UFL))
        
        sys.stdout = original
        print('This string goes to stdout, NOT the file!')

                        
                
    elif len(S) == 9: 
        print(S[0])
        print(S[1])
        print(S[2])
        print(S[3])
        print(S[4])
        print(S[5])
        print(S[6])
        print(S[7])
        print(S[8])
        print(ARR[0])
        print(ARR[1])
        print(ARR[2])
        print(ARR[3])
        print(ARR[4])
        print(ARR[5])
        print(ARR[6])
        print(ARR[7])
        print(ARR[8])
        
        print('Hai inserito 9 alimenti \n')

#       print("QUESTA È LA VERSIONE CORRETTA DELL'ALGORITMO")
        
        random_ARR_0_old = ARR[0] * random.random() * 10
        random_ARR_1_old = ARR[1] * random.random() * 10
        random_ARR_2_old = ARR[2] * random.random() * 10
        random_ARR_3_old = ARR[3] * random.random() * 10
        random_ARR_4_old = ARR[4] * random.random() * 10
        random_ARR_5_old = ARR[5] * random.random() * 10
        random_ARR_6_old = ARR[6] * random.random() * 10
        random_ARR_7_old = ARR[7] * random.random() * 10
        random_ARR_8_old = ARR[8] * random.random() * 10

# ogni alimento scelto dall'utente viene moltiplicato per un numero casuale compreso fra 0 e 10 (kg) 
# dichiaro random_ARR_x_old

        
        random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
        random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
        random_ARR_2_new = random_ARR_2_old * (random.random() + 0.5)
        random_ARR_3_new = random_ARR_3_old * (random.random() + 0.5)
        random_ARR_4_new = random_ARR_4_old * (random.random() + 0.5)
        random_ARR_5_new = random_ARR_5_old * (random.random() + 0.5)
        random_ARR_6_new = random_ARR_6_old * (random.random() + 0.5)
        random_ARR_7_new = random_ARR_7_old * (random.random() + 0.5)
        random_ARR_8_new = random_ARR_8_old * (random.random() + 0.5)

# dichiaro random_ARR_x_new
        
        SOMMA_old = random_ARR_0_old + random_ARR_1_old + random_ARR_2_old + random_ARR_3_old + random_ARR_4_old + random_ARR_5_old + random_ARR_6_old + random_ARR_7_old + random_ARR_8_old
        DELTA_old = SOMMA_old - F_arr
        print('La somma iniziale è...')
        print(SOMMA_old)

# dichiaro SOMMA_old e DELTA_old

        SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new + random_ARR_5_new + random_ARR_6_new + random_ARR_7_new + random_ARR_8_new
        DELTA_new = SOMMA_new - F_arr
        print('La nuova somma è...')
        print(SOMMA_new)
        print('La nuova differenza è...')
        print(DELTA_new)

# dichiaro SOMMA_new e DELTA_new
        
        quantità_alimento_1 = random_ARR_0_new / ARR[0]
        quantità_alimento_2 = random_ARR_1_new / ARR[1]
        quantità_alimento_3 = random_ARR_2_new / ARR[2]
        quantità_alimento_4 = random_ARR_3_new / ARR[3]
        quantità_alimento_5 = random_ARR_4_new / ARR[4]
        quantità_alimento_6 = random_ARR_5_new / ARR[5]
        quantità_alimento_7 = random_ARR_6_new / ARR[6]
        quantità_alimento_8 = random_ARR_7_new / ARR[7]
        quantità_alimento_9 = random_ARR_8_new / ARR[8]

# dichiaro gli apporti dei singoli alimenti

# dichiaro gli apporti dei singoli alimenti

        i = 0

# inizializzo il contatore i        
        
        for i in range(N_repl):
        
            rules = [abs(DELTA_new[0]) < abs(DELTA_old[0]), abs(DELTA_new[1]) < abs(DELTA_old[1]), abs(DELTA_new[2]) < abs(DELTA_old[2])]

# dichiaro le regole da rispettare
                                    
            if all(rules):
            
                print('ESTRAGGO DALLA PROPOSAL DISTRIBUTION')
                i += 1
                print(i)
                                                         	               	        
                random_ARR_0_new = random_ARR_0_new * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_new * (random.random() + 0.5)
                random_ARR_2_new = random_ARR_2_new * (random.random() + 0.5)
                random_ARR_3_new = random_ARR_3_new * (random.random() + 0.5)
                random_ARR_4_new = random_ARR_4_new * (random.random() + 0.5)
                random_ARR_5_new = random_ARR_5_new * (random.random() + 0.5)
                random_ARR_6_new = random_ARR_6_new * (random.random() + 0.5)
                random_ARR_7_new = random_ARR_7_new * (random.random() + 0.5)
                random_ARR_8_new = random_ARR_8_new * (random.random() + 0.5)

# ACCETTO random_ARR_x_new e lo uso per aggiornare random_ARR_x_new stesso 
                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0] + random_ARR_6_new[0] + random_ARR_7_new[0] + random_ARR_8_new[0]
                print(APPORTO_TOTALE_SOSTANZA_SECCA)

# aggiorno l'apporto di SS
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new + random_ARR_5_new + random_ARR_6_new + random_ARR_7_new + random_ARR_8_new
                DELTA_new = SOMMA_new - F_arr
                
# aggiorno SOMMA_new e DELTA_new                
                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                quantità_alimento_3 = random_ARR_2_new / ARR[2]
                quantità_alimento_4 = random_ARR_3_new / ARR[3]
                quantità_alimento_5 = random_ARR_4_new / ARR[4]
                quantità_alimento_6 = random_ARR_5_new / ARR[5]
                quantità_alimento_7 = random_ARR_6_new / ARR[6]
                quantità_alimento_8 = random_ARR_7_new / ARR[7]
                quantità_alimento_9 = random_ARR_8_new / ARR[8]
                
                if round(APPORTO_TOTALE_SOSTANZA_SECCA) == round(F_arr[0]):
                
                    break
                
                print(i)    
                print("SUCCESSO! L'APPORTO DI SOSTANZA SECCA CORRISPONDE AL FABBISOGNO.")

                    	                
            else:
                    
                random_ARR_0_new = random_ARR_0_old * (random.random() + 0.5)
                random_ARR_1_new = random_ARR_1_old * (random.random() + 0.5)
                random_ARR_2_new = random_ARR_2_old * (random.random() + 0.5)
                random_ARR_3_new = random_ARR_3_old * (random.random() + 0.5)
                random_ARR_4_new = random_ARR_4_old * (random.random() + 0.5)
                random_ARR_5_new = random_ARR_5_old * (random.random() + 0.5)
                random_ARR_6_new = random_ARR_6_old * (random.random() + 0.5)
                random_ARR_7_new = random_ARR_7_old * (random.random() + 0.5)
                random_ARR_8_new = random_ARR_8_old * (random.random() + 0.5)

# RIFIUTO random_ARR_x_new e lo ricalcolo a partire da random_ARR_x_old 
                
                print('FALLIMENTO')
                
                APPORTO_TOTALE_SOSTANZA_SECCA = random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0] + random_ARR_6_new[0] + random_ARR_7_new[0] + random_ARR_8_new[0]
                print(APPORTO_TOTALE_SOSTANZA_SECCA)
                                
                SOMMA_new = random_ARR_0_new + random_ARR_1_new + random_ARR_2_new + random_ARR_3_new + random_ARR_4_new + random_ARR_5_new + random_ARR_6_new + random_ARR_7_new + random_ARR_8_new
                DELTA_new = SOMMA_new - F_arr
                                                
                print('La nuova somma è...')
                print(SOMMA_new)
                print('La nuova differenza è...')
                print(DELTA_new)
            
                quantità_alimento_1 = random_ARR_0_new / ARR[0]
                quantità_alimento_2 = random_ARR_1_new / ARR[1]
                quantità_alimento_3 = random_ARR_2_new / ARR[2]
                quantità_alimento_4 = random_ARR_3_new / ARR[3]
                quantità_alimento_5 = random_ARR_4_new / ARR[4]
                quantità_alimento_6 = random_ARR_5_new / ARR[5]
                quantità_alimento_7 = random_ARR_6_new / ARR[6]
                quantità_alimento_8 = random_ARR_7_new / ARR[7]
                quantità_alimento_9 = random_ARR_7_new / ARR[8]


        if QM:

            QUANTITÀ_TOTALE_TAL_QUALE = QM + Q + quantità_alimento_1[0] + quantità_alimento_2[0] + quantità_alimento_3[0] + quantità_alimento_4[0] + quantità_alimento_5[0] + quantità_alimento_6[0] + quantità_alimento_7[0] + quantità_alimento_8[0] + quantità_alimento_9[0]
            APPORTO_DEFINITIVO_SOSTANZA_SECCA = app_MAISGRA[0] + app_MAIS[0] + random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0] + random_ARR_6_new[0] + random_ARR_7_new[0] + random_ARR_8_new[0] 
            APPORTO_TOTALE_PROTEINA_GREZZA = app_MAISGRA[1] + app_MAIS[1] + random_ARR_0_new[1] + random_ARR_1_new[1] + random_ARR_2_new[1] + random_ARR_3_new[1] + random_ARR_4_new[1] + random_ARR_5_new[1] + random_ARR_6_new[1] + random_ARR_7_new[1] + random_ARR_8_new[1]
            APPORTO_TOTALE_PROTEINA_DEGRADABILE = app_MAISGRA[2] + app_MAIS[2] + random_ARR_0_new[2] + random_ARR_1_new[2] + random_ARR_2_new[2] + random_ARR_3_new[2] + random_ARR_4_new[2] + random_ARR_5_new[2] + random_ARR_6_new[2] + random_ARR_7_new[2] + random_ARR_8_new[2]
            APPORTO_TOTALE_PROTEINA_INDEGRADABILE = app_MAISGRA[3] + app_MAIS[3] + random_ARR_0_new[3] + random_ARR_1_new[3] + random_ARR_2_new[3] + random_ARR_3_new[3] + random_ARR_4_new[3] + random_ARR_5_new[3] + random_ARR_6_new[3] + random_ARR_7_new[3] + random_ARR_8_new[3]
            APPORTO_TOTALE_FIBRA_GREZZA = app_MAISGRA[4] + app_MAIS[4] + random_ARR_0_new[4] + random_ARR_1_new[4] + random_ARR_2_new[4] + random_ARR_3_new[4] + random_ARR_4_new[4] + random_ARR_5_new[4] + random_ARR_6_new[4] + random_ARR_7_new[4] + random_ARR_8_new[4]
            APPORTO_TOTALE_NDF = app_MAISGRA[5] + app_MAIS[5] + random_ARR_0_new[5] + random_ARR_1_new[5] + random_ARR_2_new[5] + random_ARR_3_new[5] + random_ARR_4_new[5] + random_ARR_5_new[5] + random_ARR_6_new[5] + random_ARR_7_new[5] + random_ARR_8_new[5]
            APPORTO_TOTALE_ADF = app_MAISGRA[6] + app_MAIS[6] + random_ARR_0_new[6] + random_ARR_1_new[6] + random_ARR_2_new[6] + random_ARR_3_new[6] + random_ARR_4_new[6] + random_ARR_5_new[6] + random_ARR_6_new[6] + random_ARR_7_new[6] + random_ARR_8_new[6]
            APPORTO_TOTALE_GRASSO = app_MAISGRA[7] + app_MAIS[7] + random_ARR_0_new[7] + random_ARR_1_new[7] + random_ARR_2_new[7] + random_ARR_3_new[7] + random_ARR_4_new[7] + random_ARR_5_new[7] + random_ARR_6_new[7] + random_ARR_7_new[7] + random_ARR_8_new[7]
            APPORTO_TOTALE_AMIDO = app_MAISGRA[8] + app_MAIS[8] + random_ARR_0_new[8] + random_ARR_1_new[8] + random_ARR_2_new[8] + random_ARR_3_new[8] + random_ARR_4_new[8] + random_ARR_5_new[8] + random_ARR_6_new[8] + random_ARR_7_new[8] + random_ARR_8_new[8]
            APPORTO_TOTALE_ZUCCHERI = app_MAISGRA[9] + app_MAIS[9] + random_ARR_0_new[9] + random_ARR_1_new[9] + random_ARR_2_new[9] + random_ARR_3_new[9] + random_ARR_4_new[9] + random_ARR_5_new[9] + random_ARR_6_new[9] + random_ARR_7_new[9] + random_ARR_8_new[9]
            APPORTO_TOTALE_Ca = app_MAISGRA[10] + app_MAIS[10] + random_ARR_0_new[10] + random_ARR_1_new[10] + random_ARR_2_new[10] + random_ARR_3_new[10] + random_ARR_4_new[10] + random_ARR_5_new[10] + random_ARR_6_new[10] + random_ARR_7_new[10] + random_ARR_8_new[10]
            APPORTO_TOTALE_P = app_MAISGRA[11] + app_MAIS[11] + random_ARR_0_new[11] + random_ARR_1_new[11] + random_ARR_2_new[11] + random_ARR_3_new[11] + random_ARR_4_new[11] + random_ARR_5_new[11] + random_ARR_6_new[11] + random_ARR_7_new[11] + random_ARR_8_new[11]
            APPORTO_TOTALE_UFL = app_MAISGRA[12] + app_MAIS[12] + random_ARR_0_new[12] + random_ARR_1_new[12] + random_ARR_2_new[12] + random_ARR_3_new[12] + random_ARR_4_new[12] + random_ARR_5_new[12] + random_ARR_6_new[12] + random_ARR_7_new[12] + random_ARR_8_new[12]                


        else:
        
            QUANTITÀ_TOTALE_TAL_QUALE = Q + quantità_alimento_1[0] + quantità_alimento_2[0] + quantità_alimento_3[0] + quantità_alimento_4[0] + quantità_alimento_5[0] + quantità_alimento_6[0] + quantità_alimento_7[0] + quantità_alimento_8[0] + quantità_alimento_9[0]
            APPORTO_DEFINITIVO_SOSTANZA_SECCA = app_MAIS[0] + random_ARR_0_new[0] + random_ARR_1_new[0] + random_ARR_2_new[0] + random_ARR_3_new[0] + random_ARR_4_new[0] + random_ARR_5_new[0] + random_ARR_6_new[0] + random_ARR_7_new[0] + random_ARR_8_new[0] 
            APPORTO_TOTALE_PROTEINA_GREZZA = app_MAIS[1] + random_ARR_0_new[1] + random_ARR_1_new[1] + random_ARR_2_new[1] + random_ARR_3_new[1] + random_ARR_4_new[1] + random_ARR_5_new[1] + random_ARR_6_new[1] + random_ARR_7_new[1] + random_ARR_8_new[1]
            APPORTO_TOTALE_PROTEINA_DEGRADABILE = app_MAIS[2] + random_ARR_0_new[2] + random_ARR_1_new[2] + random_ARR_2_new[2] + random_ARR_3_new[2] + random_ARR_4_new[2] + random_ARR_5_new[2] + random_ARR_6_new[2] + random_ARR_7_new[2] + random_ARR_8_new[2]
            APPORTO_TOTALE_PROTEINA_INDEGRADABILE = app_MAIS[3] + random_ARR_0_new[3] + random_ARR_1_new[3] + random_ARR_2_new[3] + random_ARR_3_new[3] + random_ARR_4_new[3] + random_ARR_5_new[3] + random_ARR_6_new[3] + random_ARR_7_new[3] + random_ARR_8_new[3]
            APPORTO_TOTALE_FIBRA_GREZZA = app_MAIS[4] + random_ARR_0_new[4] + random_ARR_1_new[4] + random_ARR_2_new[4] + random_ARR_3_new[4] + random_ARR_4_new[4] + random_ARR_5_new[4] + random_ARR_6_new[4] + random_ARR_7_new[4] + random_ARR_8_new[4]
            APPORTO_TOTALE_NDF = app_MAIS[5] + random_ARR_0_new[5] + random_ARR_1_new[5] + random_ARR_2_new[5] + random_ARR_3_new[5] + random_ARR_4_new[5] + random_ARR_5_new[5] + random_ARR_6_new[5] + random_ARR_7_new[5] + random_ARR_8_new[5]
            APPORTO_TOTALE_ADF = app_MAIS[6] + random_ARR_0_new[6] + random_ARR_1_new[6] + random_ARR_2_new[6] + random_ARR_3_new[6] + random_ARR_4_new[6] + random_ARR_5_new[6] + random_ARR_6_new[6] + random_ARR_7_new[6] + random_ARR_8_new[6]
            APPORTO_TOTALE_GRASSO = app_MAIS[7] + random_ARR_0_new[7] + random_ARR_1_new[7] + random_ARR_2_new[7] + random_ARR_3_new[7] + random_ARR_4_new[7] + random_ARR_5_new[7] + random_ARR_6_new[7] + random_ARR_7_new[7] + random_ARR_8_new[7]
            APPORTO_TOTALE_AMIDO = app_MAIS[8] + random_ARR_0_new[8] + random_ARR_1_new[8] + random_ARR_2_new[8] + random_ARR_3_new[8] + random_ARR_4_new[8] + random_ARR_5_new[8] + random_ARR_6_new[8] + random_ARR_7_new[8] + random_ARR_8_new[8]
            APPORTO_TOTALE_ZUCCHERI = app_MAIS[9] + random_ARR_0_new[9] + random_ARR_1_new[9] + random_ARR_2_new[9] + random_ARR_3_new[9] + random_ARR_4_new[9] + random_ARR_5_new[9] + random_ARR_6_new[9] + random_ARR_7_new[9] + random_ARR_8_new[9]
            APPORTO_TOTALE_Ca = app_MAIS[10] + random_ARR_0_new[10] + random_ARR_1_new[10] + random_ARR_2_new[10] + random_ARR_3_new[10] + random_ARR_4_new[10] + random_ARR_5_new[10] + random_ARR_6_new[10] + random_ARR_7_new[10] + random_ARR_8_new[10]
            APPORTO_TOTALE_P = app_MAIS[11] + random_ARR_0_new[11] + random_ARR_1_new[11] + random_ARR_2_new[11] + random_ARR_3_new[11] + random_ARR_4_new[11] + random_ARR_5_new[11] + random_ARR_6_new[11] + random_ARR_7_new[11] + random_ARR_8_new[11]
            APPORTO_TOTALE_UFL = app_MAIS[12] + random_ARR_0_new[12] + random_ARR_1_new[12] + random_ARR_2_new[12] + random_ARR_3_new[12] + random_ARR_4_new[12] + random_ARR_5_new[12] + random_ARR_6_new[12] + random_ARR_7_new[12] + random_ARR_8_new[12]                

        
        DELTA_SOSTANZA_SECCA = APPORTO_DEFINITIVO_SOSTANZA_SECCA - F[0]
        DELTA_PROTEINA_GREZZA = APPORTO_TOTALE_PROTEINA_GREZZA - F[1]
        DELTA_PROTEINA_DEGRADABILE = APPORTO_TOTALE_PROTEINA_DEGRADABILE - F[2]
        DELTA_PROTEINA_INDEGRADABILE = APPORTO_TOTALE_PROTEINA_INDEGRADABILE - F[3]
        DELTA_FIBRA_GREZZA = APPORTO_TOTALE_FIBRA_GREZZA - F[4]
        DELTA_NDF = APPORTO_TOTALE_NDF - F[5]
        DELTA_ADF = APPORTO_TOTALE_ADF - F[6]
        DELTA_GRASSO = APPORTO_TOTALE_GRASSO - F[7]
        DELTA_AMIDO = APPORTO_TOTALE_AMIDO - F[8]
        DELTA_ZUCCHERI = APPORTO_TOTALE_ZUCCHERI - F[9]
        DELTA_Ca = APPORTO_TOTALE_Ca - F[10]
        DELTA_P = APPORTO_TOTALE_P - F[11]
        DELTA_UFL = APPORTO_TOTALE_UFL - F[12]

                
        original = sys.stdout
        sys.stdout = open('NUOVA_RAZIONE.txt', 'w')
        
        
        if day == 'Monday': 
            print('RAZIONE di %s, creata lunedì %s, %s' % (user, data, current_time))
        if day == 'Tuesday': 
            print('RAZIONE di %s, creata martedì %s, %s' % (user, data, current_time))
        if day == 'Wednesday': 
            print('RAZIONE di %s, creata mercoledì %s, %s' % (user, data, current_time))
        if day == 'Thursday': 
            print('RAZIONE di %s, creata giovedì %s, %s' % (user, data, current_time))
        if day == 'Friday': 
            print('RAZIONE di %s, creata venerdì %s, %s' % (user, data, current_time))
        if day == 'Saturday': 
            print('RAZIONE di %s, creata sabato %s, %s' % (user, data, current_time))
        if day == 'Sunday': 
            print('RAZIONE di %s, creata domenica %s, %s' % (user, data, current_time))
        
        
        print('')
#       print('This is your redirected text:')
        print('')
        if i == 999:
            print('Il calcolo della razione non ha avuto successo; per favore chiudi il programma e riprova.')
        else:
            print('Il calcolo della razione è stato effettuato con successo alla %d^esima replica' % i)        
#       print(i)
        print('')
        print('Il fabbisogno di SOSTANZA SECCA è di %f' %  F_arr[0])
        print('')
        print("L'apporto totale di SOSTANZA SECCA è di %f" % APPORTO_TOTALE_SOSTANZA_SECCA)
        print('')
        print('out of loop')
        print('')        
        print('LEGENDA')
        print('')
        print("DMI => Dry Matter Intake (Capacità d'ingestione di Sostanza Secca)")
        print("CPI => Crude Protein Intake (Apporto di Proteina Grezza)")
        print("RDPI => Rumen Degradable Protein Intake (Apporto di Proteina Degradabile)")
        print("RUPI => Rumen Undegradable Protein Intake (Apporto di Proteina Indegradabile)")
        print("FG => Fibra Grezza (apporto di Fibra Grezza)")
        print("NDF => Neutral Detergent Fiber (apporto di Fibra resistente al Detergente Neutro)")
        print("ADF => Acid Detergent Fiber (apporto di Fibra resistente al Detergente Acido)")
        print("FAT => Fat (apporto di Grasso)")
        print("AM => Amido (apporto di Amido)")
        print("ZUC => Zuccheri (apporto di Zuccheri)")
        print("Ca => Calcio (apporto di Calcio)")
        print("P => Fosforo (apporto di Fosforo)")
        print("UFL => Unità Foraggere Latte (apporto di Energia Netta)")
        print('DMI', 'CPI', 'RDPI', 'RUPI', 'FG', 'NDF', 'ADF', 'FAT', 'AM', 'ZUC', 'Ca', 'P', 'UFL')
        
        if MG:
        
            print('apporti di %s: \n' % M)
            print(app_MAIS)
            print('apporti di %s: \n' % MG)
            print(app_MAISGRA)                        
            print('apporti di %s: \n' % S[0])
            print(random_ARR_0_new)
            print('apporti di %s: \n' % S[1])
            print(random_ARR_1_new)
            print('apporti di %s: \n' % S[2])
            print(random_ARR_2_new)
            print('apporti di %s: \n' % S[3])
            print(random_ARR_3_new)
            print('apporti di %s: \n' % S[4])
            print(random_ARR_4_new)
            print('apporti di %s: \n' % S[5])
            print(random_ARR_5_new)
            print('apporti di %s: \n' % S[6])
            print(random_ARR_6_new)
            print('apporti di %s: \n' % S[7])
            print(random_ARR_7_new)
            print('apporti di %s: \n' % S[8])
            print(random_ARR_8_new)
            
        else:
        
            print('apporti di %s: \n' % M)
            print(app_MAIS)
            print('apporti di %s: \n' % S[0])
            print(random_ARR_0_new)
            print('apporti di %s: \n' % S[1])
            print(random_ARR_1_new)
            print('apporti di %s: \n' % S[2])
            print(random_ARR_2_new)
            print('apporti di %s: \n' % S[3])
            print(random_ARR_3_new)
            print('apporti di %s: \n' % S[4])
            print(random_ARR_4_new)
            print('apporti di %s: \n' % S[5])
            print(random_ARR_5_new)
            print('apporti di %s: \n' % S[6])
            print(random_ARR_6_new)
            print('apporti di %s: \n' % S[7])
            print(random_ARR_7_new)
            print('apporti di %s: \n' % S[8])
            print(random_ARR_8_new)

                                
        if M == 'insilato di mais':
            print('La razione fornisce %f kg di %s' % (Q_INSIMA, M))
            
            
        elif M == 'pastone mais integrale':
            print('La razione fornisce %f kg di %s\n' % (Q_PASTOMAISINT, M))
            
            
        elif M == 'pastone mais granella':
            print('La razione fornisce %f kg di %s\n' % (Q_PASTOMAISGRA, M))
            
        
        if Q_MAISGRA:
            print('La razione fornisce %f kg di %s\n' % (QM, MG))
            print('%f kg %s' % (QM, MG))                                         
            print('%f kg %s' % (Q, M))                        
            print('%f kg %s' % (quantità_alimento_1[0], S[0]))
            print('%f kg %s' % (quantità_alimento_2[0], S[1]))
            print('%f kg %s' % (quantità_alimento_3[0], S[2]))
            print('%f kg %s' % (quantità_alimento_4[0], S[3]))
            print('%f kg %s' % (quantità_alimento_5[0], S[4]))
            print('%f kg %s' % (quantità_alimento_6[0], S[5]))
            print('%f kg %s' % (quantità_alimento_7[0], S[6]))
            print('%f kg %s' % (quantità_alimento_8[0], S[7]))
            print('%f kg %s' % (quantità_alimento_9[0], S[8]))
            
        else:
            print('%f kg %s' % (Q, M))                        
            print('%f kg %s' % (quantità_alimento_1[0], S[0]))
            print('%f kg %s' % (quantità_alimento_2[0], S[1]))
            print('%f kg %s' % (quantità_alimento_3[0], S[2]))
            print('%f kg %s' % (quantità_alimento_4[0], S[3]))
            print('%f kg %s' % (quantità_alimento_5[0], S[4]))
            print('%f kg %s' % (quantità_alimento_6[0], S[5]))
            print('%f kg %s' % (quantità_alimento_7[0], S[6]))
            print('%f kg %s' % (quantità_alimento_8[0], S[7]))
            print('%f kg %s' % (quantità_alimento_9[0], S[8]))

                                        
                
        print('La razione fornisce %f kg di alimento tal quale' % QUANTITÀ_TOTALE_TAL_QUALE)
        print('La razione fornisce %f kg di sostanza secca' % APPORTO_DEFINITIVO_SOSTANZA_SECCA)
        
        print("SOSTANZA SECCA: la differenza fra l'apporto totale => %f kg e la capacità d'ingestione => %f kg è: %f kg" % (APPORTO_DEFINITIVO_SOSTANZA_SECCA, F[0], DELTA_SOSTANZA_SECCA))
        print("PROTEINA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_GREZZA, F[1], DELTA_PROTEINA_GREZZA)) 
        print("PROTEINA DEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_DEGRADABILE, F[2], DELTA_PROTEINA_DEGRADABILE))
        print("PROTEINA INDEGRADABILE: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_PROTEINA_INDEGRADABILE, F[3], DELTA_PROTEINA_INDEGRADABILE))
        print("FIBRA GREZZA: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_FIBRA_GREZZA, F[4], DELTA_FIBRA_GREZZA))
        print("NDF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_NDF, F[5], DELTA_NDF))
        print("ADF: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ADF, F[6], DELTA_ADF))
        print("GRASSO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_GRASSO, F[7], DELTA_GRASSO)) 
        print("AMIDO: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_AMIDO, F[8], DELTA_AMIDO))
        print("ZUCCHERI: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_ZUCCHERI, F[9], DELTA_ZUCCHERI))
        print("Ca: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_Ca, F[10], DELTA_Ca))
        print("P: la differenza fra l'apporto totale => %f g e il fabbisogno => %f g è: %f g" % (APPORTO_TOTALE_P, F[11], DELTA_P))
        print("UFL: la differenza fra l'apporto totale => %f UFL e il fabbisogno => %f UFL è: %f UFL" % (APPORTO_TOTALE_UFL, F[12], DELTA_UFL))
        
        sys.stdout = original
        print('This string goes to stdout, NOT the file!')


    else:
        print('ERRORE! Hai inserito un numero di alimenti non previsto. \n')

    
    with open('alimenti.txt', 'w') as external_file:
        print(S, file=external_file)
    external_file.close()
    
    with open('vettori.txt', 'w') as external_file:
        print(ARR, file=external_file)
    external_file.close()
    
    with open('fabbisogni.txt', 'w') as external_file:
        print(F, file=external_file)
    external_file.close()
    


###############################################################################################################################        
###############################################################################################################################


def stampa_razione():
# http://timgolden.me.uk/python/win32_how_do_i/print.html#shellexecute

    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib.units import inch
    import cgi, html, os, tempfile, win32api

    os.chdir('C:/Users/piero/PYTHON')
    source_file_name = "NUOVA_RAZIONE.txt"
    pdf_file_name = tempfile.mktemp(".pdf")
    styles = getSampleStyleSheet()
    h1 = styles["h1"]
    normal = styles["Normal"]
    doc = SimpleDocTemplate(pdf_file_name)
    text=html.escape(open(source_file_name).read()).splitlines()
    story = [Paragraph (text[0], h1)]

    for line in text[1:]:
        story.append (Paragraph (line, normal))
        story.append (Spacer (1, 0.2 * inch))

    doc.build(story)
    win32api.ShellExecute(0, "print", pdf_file_name, None, ".", 0)

###############################################################################################################################


def importa_erba_loietto():
    global ERLO_arr
    from importa_MySQLdb_erba_loietto import ERLO_arr
    prezzo_ERBA_LOIETTO = 50.0
    S.append('erba loietto')
    ARR.append(ERLO_arr)
    PREZZI.append(prezzo_ERBA_LOIETTO)
    print('Alimento <ERBA DI LOIETTO> inserito con successo!')
    print("Costo di produzione stimato dell'ERBA DI LOIETTO => 50 EURO/ton") 

def importa_erba_medica_II_taglio():
    global ERME2TA_arr
    from importa_MySQLdb_erba_medica_II_taglio import ERME2TA_arr
    prezzo_ERBA_MEDICA_II_TA = 50.0
    S.append('ERBA MEDICA DI II TAGLIO')
    ARR.append(ERME2TA_arr)
    PREZZI.append(prezzo_ERBA_MEDICA_II_TA)
    print('Alimento <ERBA MEDICA DI II TAGLIO> inserito con successo!')
    print("Costo di produzione stimato dell'ERBA MEDICA DI II TAGLIO => 50 EURO/ton")

def importa_erba_medica_disidratata_15_per_100():
    global ERMEDIS15_arr
    from importa_MySQLdb_erba_medica_disidratata_15_per_100 import ERMEDIS15_arr
    from crea_db_PREZZI_Milano_w import prezzo_ERBA_MEDICA_DIS_1_QUAL
    S.append('ERBA MEDICA DISIDRATATA 15x100')
    ARR.append(ERMEDIS15_arr)
    print('Alimento <ERBA MEDICA DISIDRATATA 15x100> inserito con successo!')
    if type(prezzo_ERBA_MEDICA_DIS_1_QUAL) == float:
        PREZZI.append(prezzo_ERBA_MEDICA_DIS_1_QUAL)
        print("Prezzo dell'ERBA MEDICA DISIDRATATA 15per100 => %f EURO/ton" % prezzo_ERBA_MEDICA_DIS_1_QUAL)
    else:
        print('%s' % prezzo_ERBA_MEDICA_DIS_1_QUAL)

def importa_erba_medica_disidratata_17_per_100():
    global ERMEDIS17_arr
    from importa_MySQLdb_erba_medica_disidratata_17_per_100 import ERMEDIS17_arr
    from crea_db_PREZZI_Milano_w import prezzo_ERBA_MEDICA_DIS_EXTRA
    S.append('ERBA MEDICA DISIDRATATA 17x100')
    ARR.append(ERMEDIS17_arr)
    print('Alimento <ERBA MEDICA DISIDRATATA 17x100> inserito con successo!')
    if type(prezzo_ERBA_MEDICA_DIS_EXTRA) == float:
        PREZZI.append(prezzo_ERBA_MEDICA_DIS_EXTRA)
        print("Prezzo dell'ERBA MEDICA DISIDRATATA 17x100 => %f EURO/ton" % prezzo_ERBA_MEDICA_DIS_EXTRA)
    else:
        print('%s' % prezzo_ERBA_MEDICA_DIS_EXTRA)

def importa_erba_prato_stabile():
    global ERPRASTA_arr
    from importa_MySQLdb_erba_prato_stabile import ERPRASTA_arr
    prezzo_ERBA_PRATO_STABILE = 50.0
    S.append('erba prato stabile')
    ARR.append(ERPRASTA_arr)
    PREZZI.append(prezzo_ERBA_PRATO_STABILE)
    print('Alimento <ERBA PRATO STABILE> inserito con successo!')
    print("Costo di produzione stimato dell'ERBA DI PRATO STABILE => 50 EURO/ton")

def importa_insilato_loietto():
    global INSILO_arr
    from importa_MySQLdb_insilato_loietto import INSILO_arr
    from crea_db_PREZZI_Alessandria_w import prezzo_LOIETTO_INSILATO
    S.append('insilato di loietto')
    ARR.append(INSILO_arr)
    print('Alimento <INSILATO DI LOIETTO> inserito con successo!')
    if type(prezzo_LOIETTO_INSILATO) == float:
        PREZZI.append(prezzo_LOIETTO_INSILATO)
        print("Prezzo dell'INSILATO DI LOIETTO => %f EURO/ton" % prezzo_LOIETTO_INSILATO)
    else:
        print('%s' % prezzo_LOIETTO_INSILATO)

def importa_insilato_mais():
    global INSIMA_arr
    from importa_MySQLdb_insilato_mais import INSIMA_arr
    from crea_db_PREZZI_Alessandria_w import prezzo_MAIS_INSILATO
    S.append('insilato di mais')
    ARR.append(INSIMA_arr)
    print('Alimento <INSILATO DI MAIS> inserito con successo!')
    if type(prezzo_MAIS_INSILATO) == float:
        PREZZI.append(prezzo_MAIS_INSILATO)
        print("Prezzo dell'INSILATO DI MAIS => %f EURO/ton" % prezzo_MAIS_INSILATO)
    else:
        print('%s' % prezzo_MAIS_INSILATO)

def importa_pastone_mais_granella():
    global PASTOMAISGRA_arr
    from importa_MySQLdb_pastone_mais_granella import PASTOMAISGRA_arr
    from crea_db_PREZZI_clal_w import prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR
    S.append('pastone di mais granella')
    ARR.append(PASTOMAISGRA_arr)
    print('Alimento <PASTONE DI MAIS GRANELLA> inserito con successo!')
    if type(prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR) == float:
        PREZZI.append(prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR)
        print("Prezzo del PASTONE DI MAIS GRANELLA => %f EURO/ton" % prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR)
    else:
        print('%s' % prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR)

def importa_pastone_mais_integrale():
    global PASTOMAISINT_arr
    from importa_MySQLdb_pastone_mais_integrale import PASTOMAISINT_arr
    from crea_db_PREZZI_clal_w import prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR
    S.append('pastone di mais integrale')
    ARR.append(PASTOMAISINT_arr)
    print('Alimento <PASTONE DI MAIS INTEGRALE> inserito con successo!')
    if type(prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR) == float:
        PREZZI.append(prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR)
        print("Prezzo del PASTONE DI MAIS INTEGRALE => %f EURO/ton" % prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR)
    else:
        print('%s' % prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR)

def importa_fieno_loietto():
    global FIELO_arr
    from importa_MySQLdb_fieno_loietto import FIELO_arr
    from crea_db_PREZZI_Milano_w import prezzo_FIENO_MAGGENGO
    S.append('fieno di loietto')
    ARR.append(FIELO_arr)
    print('Alimento <FIENO DI LOIETTO> inserito con successo!')
    if type(prezzo_FIENO_MAGGENGO) == float:
        PREZZI.append(prezzo_FIENO_MAGGENGO)
        print("Prezzo del FIENO DI LOIETTO => %f EURO/ton" % prezzo_FIENO_MAGGENGO)
    else:
        print('%s' % prezzo_FIENO_MAGGENGO)


def importa_fieno_medica_I_taglio():
    global FIEME1TA_arr
    from importa_MySQLdb_fieno_medica_I_taglio import FIEME1TA_arr
    from crea_db_PREZZI_Bologna_w import prezzo_FIENO_MEDICA_17_1_TAGLIO_ROTBAL_B
    S.append('fieno di medica di I taglio')
    ARR.append(FIEME1TA_arr)
    print('Alimento <FIENO DI MEDICA DI I TAGLIO IN ROTOBALLE> inserito con successo!')
    if type(prezzo_FIENO_MEDICA_17_1_TAGLIO_ROTBAL_B) == float:
        PREZZI.append(prezzo_FIENO_MEDICA_17_1_TAGLIO_ROTBAL_B)
        print("Prezzo del FIENO DI MEDICA DI I TAGLIO IN ROTOBALLE => %f EURO/ton" % prezzo_FIENO_MEDICA_17_1_TAGLIO_ROTBAL_B)
    else:
        print('%s' % prezzo_FIENO_MEDICA_17_1_TAGLIO_ROTBAL_B)

def importa_fieno_medica_II_taglio():
    global FIEME2TA_arr
    from importa_MySQLdb_fieno_medica_II_taglio import FIEME2TA_arr
    from crea_db_PREZZI_Bologna_w import prezzo_FIENO_MEDICA_17_2_TAGLIO_ROTBAL_B
    S.append('fieno di medica di II taglio')
    ARR.append(FIEME2TA_arr)
    print('Alimento <FIENO DI MEDICA DI II TAGLIO IN ROTOBALLE> inserito con successo!')
    if type(prezzo_FIENO_MEDICA_17_2_TAGLIO_ROTBAL_B) == float:
        PREZZI.append(prezzo_FIENO_MEDICA_17_2_TAGLIO_ROTBAL_B)
        print("Prezzo del FIENO DI MEDICA DI II TAGLIO IN ROTOBALLE => %f EURO/ton" % prezzo_FIENO_MEDICA_17_2_TAGLIO_ROTBAL_B)
    else:
        print('%s' % prezzo_FIENO_MEDICA_17_2_TAGLIO_ROTBAL_B)

def importa_fieno_silos_medica():
    global FIESIME_arr
    from importa_MySQLdb_fieno_silos_medica import FIESIME_arr
    prezzo_FIENO_SILOS_MEDICA = 50.0
    S.append('fieno silos di erba medica')
    ARR.append(FIESIME_arr)
    PREZZI.append(prezzo_FIENO_SILOS_MEDICA)
    print('Alimento <FIENO SILOS DI ERBA MEDICA inserito con successo!')
    print("Costo di produzione stimato del FIENO SILOS DI ERBA MEDICA => 50 EURO/ton")

def importa_fieno_prato_stabile_I_taglio():
    global FIEPRASTA1TA_arr
    from importa_MySQLdb_fieno_prato_stabile_I_taglio import FIEPRASTA1TA_arr
    from crea_db_PREZZI_Milano_w import prezzo_FIENO_MAGGENGO
    S.append('fieno prato stabile di I taglio')
    ARR.append(FIEPRASTA1TA_arr)
    print('Alimento <FIENO DI PRATO STABILE DI I TAGLIO> inserito con successo!')
    if type(prezzo_FIENO_MAGGENGO) == float:
        PREZZI.append(prezzo_FIENO_MAGGENGO)
        print("Prezzo del FIENO DI PRATO STABILE DI I TAGLIO => %f EURO/ton" % prezzo_FIENO_MAGGENGO)
    else:
        print('%s' % prezzo_FIENO_MAGGENGO)

def importa_fieno_prato_stabile_II_taglio():
    global FIEPRASTA2TA_arr
    from importa_MySQLdb_fieno_prato_stabile_II_taglio import FIEPRASTA2TA_arr
    from crea_db_PREZZI_Milano_w import prezzo_FIENO_AGOSTANO
    S.append('fieno prato stabile di II taglio')
    ARR.append(FIEPRASTA2TA_arr)
    print('Alimento <FIENO DI PRATO STABILE DI II TAGLIO> inserito con successo!')
    if type(prezzo_FIENO_AGOSTANO) == float:
        PREZZI.append(prezzo_FIENO_AGOSTANO)
        print("Prezzo del FIENO DI PRATO STABILE DI II TAGLIO => %f EURO/ton" % prezzo_FIENO_AGOSTANO)
    else:
        print('%s' % prezzo_FIENO_AGOSTANO)

def importa_paglia_frumento():
    global PAFRU_arr
    from importa_MySQLdb_paglia_frumento import PAFRU_arr
    from crea_db_PREZZI_Milano_w import prezzo_PAGLIA
    S.append('paglia di frumento')
    ARR.append(PAFRU_arr)
    print('Alimento <PAGLIA DI FRUMENTO> inserito con successo!')
    if type(prezzo_PAGLIA) == float:
        PREZZI.append(prezzo_PAGLIA)
        print("Prezzo della PAGLIA DI FRUMENTO => %f EURO/ton" % prezzo_PAGLIA)
    else:
        print('%s' % prezzo_PAGLIA)

def importa_avena():
    global AV_arr
    from importa_MySQLdb_avena import AV_arr
    from crea_db_PREZZI_Milano_w import prezzo_AVENA
    S.append('avena')
    ARR.append(AV_arr)
    print('Alimento <AVENA> inserito con successo!')
    if type(prezzo_AVENA) == float:
        PREZZI.append(prezzo_AVENA)
        print("Prezzo dell'AVENA => %f EURO/ton" % prezzo_AVENA)
    else:
        print('%s' % prezzo_AVENA)

def importa_frumento_tenero():
    global FRUTE_arr
    from importa_MySQLdb_frumento_tenero import FRUTE_arr
    from crea_db_PREZZI_Bologna_w import prezzo_FRUMENTO_B
    S.append('frumento tenero')
    ARR.append(FRUTE_arr)
    print('Alimento <FRUMENTO TENERO> inserito con successo!')
    if type(prezzo_FRUMENTO_B) == float:
        PREZZI.append(prezzo_FRUMENTO_B)
        print("Prezzo del FRUMENTO TENERO => %f EURO/ton" % prezzo_FRUMENTO_B)
    else:
        print('%s' % prezzo_FRUMENTO_B)

def importa_mais_granella():
    global MAISGRA_arr
    from importa_MySQLdb_mais_granella import MAISGRA_arr
    from crea_db_PREZZI_Milano_w import prezzo_MAIS
    S.append('mais granella')
    ARR.append(MAISGRA_arr)
    print('Alimento <MAIS GRANELLA> inserito con successo!')
    if type(prezzo_MAIS) == float:
        PREZZI.append(prezzo_MAIS)
        print("Prezzo del MAIS GRANELLA => %f EURO/ton" % prezzo_MAIS)
    else:
        print('%s' % prezzo_MAIS)

def importa_sorgo():
    global SORGO_arr
    from importa_MySQLdb_sorgo import SORGO_arr
    from crea_db_PREZZI_Milano_w import prezzo_SORGO
    S.append('sorgo')
    ARR.append(SORGO_arr)
    print('Alimento <SORGO> inserito con successo!')
    if type(prezzo_SORGO) == float:
        PREZZI.append(prezzo_SORGO)
        print("Prezzo del SORGO => %f EURO/ton" % prezzo_SORGO)
    else:
        print('%s' % prezzo_SORGO)
    
def importa_orzo():
    global ORZO_arr
    from importa_MySQLdb_orzo import ORZO_arr
    from crea_db_PREZZI_Milano_w import prezzo_ORZO
    S.append('orzo')
    ARR.append(ORZO_arr)
    print('Alimento <ORZO> inserito con successo!')
    if type(prezzo_ORZO) == float:
        PREZZI.append(prezzo_ORZO)
        print("Prezzo dell'ORZO => %f EURO/ton" % prezzo_ORZO)
    else:
        print('%s' % prezzo_ORZO)

def importa_triticale():
    global TRIT_arr
    from importa_MySQLdb_triticale import TRIT_arr
    from crea_db_PREZZI_Milano_w import prezzo_TRITICALE
    S.append('triticale')
    ARR.append(TRIT_arr)
    print('Alimento <TRITICALE> inserito con successo!')
    if type(prezzo_TRITICALE) == float:
        PREZZI.append(prezzo_TRITICALE)
        print("Prezzo del TRITICALE => %f EURO/ton" % prezzo_TRITICALE)
    else:
        print('%s' % prezzo_TRITICALE)

def importa_soia_integrale():
    global SOIAIN_arr
    from importa_MySQLdb_soia_integrale import SOIAIN_arr
    from crea_db_PREZZI_Milano_w import prezzo_SOIA
    S.append('soia integrale')
    ARR.append(SOIAIN_arr)
    print('Alimento <SOIA INTEGRALE> inserito con successo!')
    if type(prezzo_SOIA) == float:
        PREZZI.append(prezzo_SOIA)
        print("Prezzo della SOIA INTEGRALE => %f EURO/ton" % prezzo_SOIA)
    else:
        print('%s' % prezzo_SOIA)

def importa_pisello():
    global PISELLO_arr
    from importa_MySQLdb_pisello import PISELLO_arr
    from crea_db_PREZZI_Milano_w import prezzo_PISELLO
    S.append('pisello')
    ARR.append(PISELLO_arr)
    print('Alimento <PISELLO> inserito con successo!')
    if type(prezzo_PISELLO) == float:
        PREZZI.append(prezzo_PISELLO)
        print("Prezzo del PISELLO => %f EURO/ton" % prezzo_PISELLO)
    else:
        print('%s' % prezzo_PISELLO)

def importa_favino():
    global FAVINO_arr
    from importa_MySQLdb_favino import FAVINO_arr
    from crea_db_PREZZI_Bologna_w import prezzo_FAVINO_B
    S.append('favino')
    ARR.append(FAVINO_arr)
    print('Alimento <FAVINO> inserito con successo!')
    if type(prezzo_FAVINO_B) == float:
        PREZZI.append(prezzo_FAVINO_B)
        print("Prezzo del FAVINO => %f EURO/ton" % prezzo_FAVINO_B)
    else:
        print('%s' % prezzo_FAVINO_B) 
    
def importa_lupino():
    global LU_arr
    from importa_MySQLdb_lupino import LU_arr
    from crea_db_PREZZI_Alessandria_w import prezzo_LUPINO
    prezzo_LUPINO = float(prezzo_LUPINO)
    S.append('lupino')
    ARR.append(LU_arr)
    print('Alimento <LUPINO> inserito con successo!')
    if type(prezzo_LUPINO) == float:
        PREZZI.append(prezzo_LUPINO)
        print("Prezzo del LUPINO => %f EURO/ton" % prezzo_LUPINO)
    else:
        print('%s' % prezzo_LUPINO)

def importa_frumento_tritello():
    global FRUTRI_arr
    from importa_MySQLdb_frumento_tritello import FRUTRI_arr
    from crea_db_PREZZI_Milano_w import prezzo_FRUMENTO_TENERO_TRITELLO
    S.append('tritello di frumento')
    ARR.append(FRUTRI_arr)
    print('Alimento <FRUMENTO TRITELLO> inserito con successo!')
    if type(prezzo_FRUMENTO_TENERO_TRITELLO) == float:
        PREZZI.append(prezzo_FRUMENTO_TENERO_TRITELLO)
        print("Prezzo del FRUMENTO TRITELLO => %f EURO/ton" % prezzo_FRUMENTO_TENERO_TRITELLO)
    else:
        print('%s' % prezzo_FRUMENTO_TENERO_TRITELLO)

def importa_frumento_tenero_farinaccio():
    global FRUTEFA_arr
    from importa_MySQLdb_frumento_tenero_farinaccio import FRUTEFA_arr
    from crea_db_PREZZI_Milano_w import prezzo_FRUMENTO_TENERO_FARINACCIO
    S.append('farinaccio di frumento tenero')
    ARR.append(FRUTEFA_arr)
    print('Alimento <FRUMENTO TENERO FARINACCIO> inserito con successo!')
    if type(prezzo_FRUMENTO_TENERO_FARINACCIO) == float:
        PREZZI.append(prezzo_FRUMENTO_TENERO_FARINACCIO)
        print("Prezzo del FRUMENTO FARINACCIO => %f EURO/ton" % prezzo_FRUMENTO_TENERO_FARINACCIO)
    else:
        print('%s' % prezzo_FRUMENTO_TENERO_FARINACCIO)

def importa_frumento_duro_farinaccio():
    global FRUDUFA_arr
    from importa_MySQLdb_frumento_duro_farinaccio import FRUDUFA_arr
    from crea_db_PREZZI_Milano_w import prezzo_FRUMENTO_DURO_FARINACCIO
    S.append('farinaccio di frumento duro')
    ARR.append(FRUDUFA_arr)
    print('Alimento <FRUMENTO DURO FARINACCIO> inserito con successo!')
    if type(prezzo_FRUMENTO_DURO_FARINACCIO) == float:
        PREZZI.append(prezzo_FRUMENTO_DURO_FARINACCIO)
        print("Prezzo del FRUMENTO FARINACCIO => %f EURO/ton" % prezzo_FRUMENTO_DURO_FARINACCIO)
    else:
        print('%s' % prezzo_FRUMENTO_DURO_FARINACCIO)

def importa_frumento_tenero_germe():
    global FRUTEGE_arr
    from importa_MySQLdb_frumento_tenero_germe import FRUTEGE_arr
    from crea_db_PREZZI_Milano_w import prezzo_FRUMENTO_TENERO_GERME
    S.append('germe di frumento tenero')
    ARR.append(FRUTEGE_arr)
    print('Alimento <FRUMENTO TENERO GERME> inserito con successo!')
    if type(prezzo_FRUMENTO_TENERO_GERME) == float:
        PREZZI.append(prezzo_FRUMENTO_TENERO_GERME)
        print("Prezzo del FRUMENTO TENERO GERME => %f EURO/ton" % prezzo_FRUMENTO_TENERO_GERME)
    else:
        print('%s' % prezzo_FRUMENTO_TENERO_GERME)

def importa_mais_glutine():
    global MAISGLU_arr
    from importa_MySQLdb_mais_glutine import MAISGLU_arr
    from crea_db_PREZZI_Milano_w import prezzo_GLUTINE
    S.append('glutine di mais')
    ARR.append(MAISGLU_arr)
    print('Alimento <GLUTINE DI MAIS> inserito con successo!')
    if type(prezzo_GLUTINE) == float:
        PREZZI.append(prezzo_GLUTINE)
        print("Prezzo del GLUTINE DI MAIS => %f EURO/ton" % prezzo_GLUTINE)
    else:
        print('%s' % prezzo_GLUTINE)

def importa_mais_semola_glutinata():
    global MAISSEGLU_arr
    from importa_MySQLdb_mais_semola_glutinata import MAISSEGLU_arr
    from crea_db_PREZZI_Milano_w import prezzo_MAIS_SEMOLA_GLUTINATA
    S.append('semola glutinata di mais')
    ARR.append(MAISSEGLU_arr)
    print('Alimento <SEMOLA GLUTINATA DI MAIS> inserito con successo!')
    if type(prezzo_MAIS_SEMOLA_GLUTINATA) == float:
        PREZZI.append(prezzo_MAIS_SEMOLA_GLUTINATA)
        print("Prezzo della SEMOLA GLUTINATA DI MAIS => %f EURO/ton" % prezzo_MAIS_SEMOLA_GLUTINATA)
    else:
        print('%s' % prezzo_MAIS_SEMOLA_GLUTINATA)

def importa_riso_farinaccio():
    global RIFARINACCIO_arr
    from importa_MySQLdb_riso_farinaccio import RIFARINACCIO_arr
    from crea_db_PREZZI_Milano_w import prezzo_RISO_FARINACCIO
    S.append('farinaccio di riso')
    ARR.append(RIFARINACCIO_arr)
    print('Alimento <FARINACCIO DI RISO> inserito con successo!')
    if type(prezzo_RISO_FARINACCIO) == float:
        PREZZI.append(prezzo_RISO_FARINACCIO)
        print("Prezzo del FARINACCIO DI RISO => %f EURO/ton" % prezzo_RISO_FARINACCIO)
    else:
        print('%s' % prezzo_RISO_FARINACCIO)

def importa_riso_gemma():
    global RIGEMMA_arr
    from importa_MySQLdb_riso_gemma import RIGEMMA_arr
    S.append('gemma di riso')
    prezzo_RISO_GEMMA = 400.0
    ARR.append(RIGEMMA_arr)
    PREZZI.append(prezzo_RISO_GEMMA)
    print('Alimento <GEMMA DI RISO> inserito con successo!')
    print('Prezzo stimato della GEMMA DI RISO => 400 EURO/ton')

def importa_riso_grana_verde():
    global RIGRVER_arr
    from importa_MySQLdb_riso_grana_verde import RIGRVER_arr
    from crea_db_PREZZI_Milano_w import prezzo_RISO_GRANA_VERDE
    S.append('grana verde di riso')
    ARR.append(RIGRVER_arr)
    print('Alimento <GRANA VERDE DI RISO> inserito con successo!')
    if type(prezzo_RISO_GRANA_VERDE) == float:
        PREZZI.append(prezzo_RISO_GRANA_VERDE)
        print("Prezzo della GRANA VERDE DI RISO => %f EURO/ton" % prezzo_RISO_GRANA_VERDE)
    else:
        print('%s' % prezzo_RISO_GRANA_VERDE)

def importa_riso_rottura():
    global RIROTTU_arr
    from importa_MySQLdb_riso_rottura import RIROTTU_arr
    from crea_db_PREZZI_Milano_w import prezzo_RISO_GRANA_VERDE
    S.append('rottura di riso')
    ARR.append(RIROTTU_arr)
    print('Alimento <ROTTURA DI RISO> inserito con successo!')
    if type(prezzo_RISO_GRANA_VERDE) == float:
        PREZZI.append(prezzo_RISO_GRANA_VERDE)
        print("Prezzo della ROTTURA DI RISO => %f EURO/ton" % prezzo_RISO_GRANA_VERDE)
    else:
        print('%s' % prezzo_RISO_GRANA_VERDE)
    
def importa_bietola_polpe_surpressate():
    global BIEPOLSURPR_arr
    from importa_MySQLdb_bietola_polpe_surpressate import BIEPOLSURPR_arr
    from crea_db_PREZZI_Milano_w import prezzo_BIETOLA_POLPE_SECCHE
    S.append('polpe surpressate di bietola')
    ARR.append(BIEPOLSURPR_arr)
    print('Alimento <POLPE SURPRESSATE DI BIETOLA> inserito con successo!')
    if type(prezzo_BIETOLA_POLPE_SECCHE) == float:
        PREZZI.append(prezzo_BIETOLA_POLPE_SECCHE)
        print("Prezzo delle POLPE SURPRESSATE DI BIETOLA => %f EURO/ton" % prezzo_BIETOLA_POLPE_SECCHE)
    else:
        print('%s' % prezzo_BIETOLA_POLPE_SECCHE)

def importa_bietola_polpe_secche():
    global BIEPOLPSE_arr
    from importa_MySQLdb_bietola_polpe_secche import BIEPOLPSE_arr
    from crea_db_PREZZI_Milano_w import prezzo_BIETOLA_POLPE_SECCHE
    S.append('polpe secche di bietola')
    ARR.append(BIEPOLPSE_arr)
    print('Alimento <POLPE SECCHE DI BIETOLA> inserito con successo!')
    if type(prezzo_BIETOLA_POLPE_SECCHE) == float:
        PREZZI.append(prezzo_BIETOLA_POLPE_SECCHE)
        print("Prezzo delle POLPE SECCHE DI BIETOLA => %f EURO/ton" % prezzo_BIETOLA_POLPE_SECCHE)
    else:
        print('%s' % prezzo_BIETOLA_POLPE_SECCHE)

def importa_manioca():
    global MANIO_arr
    from importa_MySQLdb_manioca import MANIO_arr
    S.append('manioca')
    ARR.append(MANIO_arr)
    print('Alimento <MANIOCA> inserito con successo!')
    prezzo_MANIOCA = ''
    if type(prezzo_MANIOCA) == float:
        PREZZI.append(prezzo_MANIOCA)
        print("Prezzo della MANIOCA => %f EURO/ton" % prezzo_BIETOLA_POLPE_SECCHE)
    else:
        print('Prezzo della MANIOCA non disponibile')
    
def importa_melasso_barbabietola():
    global MEBARBA_arr
    from importa_MySQLdb_melasso_barbabietola import MEBARBA_arr
    from crea_db_PREZZI_Milano_w import prezzo_MELASSO
    S.append('melasso di barbabietola')
    ARR.append(MEBARBA_arr)
    print('Alimento <MELASSO DI BARBABIETOLA> inserito con successo!')
    if type(prezzo_MELASSO) == float:
        PREZZI.append(prezzo_MELASSO)
        print("Prezzo del MELASSO DI BARBABIETOLA => %f EURO/ton" % prezzo_MELASSO)
    else:
        print('%s' % prezzo_MELASSO)    

def importa_melasso_canna():
    global MECANNA_arr
    from importa_MySQLdb_melasso_canna import MECANNA_arr
    from crea_db_PREZZI_Milano_w import prezzo_MELASSO
    S.append('melasso di canna')
    ARR.append(MECANNA_arr)
    print('Alimento <MELASSO DI CANNA> inserito con successo!')
    if type(prezzo_MELASSO) == float:
        PREZZI.append(prezzo_MELASSO)
        print("Prezzo del MELASSO DI CANNA => %f EURO/ton" % prezzo_MELASSO)
    else:
        print('%s' % prezzo_MELASSO)    

def importa_patate_essiccate():
    global PAESSI_arr
    from importa_MySQLdb_patate_essiccate import PAESSI_arr
    S.append('patate essiccate')
    ARR.append(PAESSI_arr)
    print('Alimento <PATATE ESSICCATE> inserito con successo!')
    prezzo_PATATE_ESSICCATE = ''
    if type(prezzo_PATATE_ESSICCATE) == float:
        PREZZI.append(prezzo_PATATE_ESSICCATE)
        print("Prezzo delle PATATE ESSICCATE => %f EURO/ton" % prezzo_PATATE_ESSICCATE)
    else:
        print('Prezzo delle PATATE ESSICCATE non disponibile')    

def importa_proteina_patata():
    global PROPA_arr
    from importa_MySQLdb_proteina_patata import PROPA_arr
    S.append('patate essiccate')
    ARR.append(PROPA_arr) 
    print('Alimento <PROTEINA DI PATATA> inserito con successo!')
    prezzo_PROTEINA_PATATA = ''
    if type(prezzo_PROTEINA_PATATA) == float:
        PREZZI.append(prezzo_PROTEINA_PATATA)
        print("Prezzo della PROTEINA DI PATATA => %f EURO/ton" % prezzo_PROTEINA_PATATA)
    else:
        print('Prezzo della PROTEINA DI PATATA non disponibile')
        
def importa_carruba_polpa_denocciolata():
    global CARRPOLDEN_arr
    from importa_MySQLdb_carruba_polpa_denocciolata import CARRPOLDEN_arr
    from crea_db_PREZZI_Milano_w import prezzo_CARRUBE_FRANTUMATE
    S.append('polpa denocciolata di carruba')
    ARR.append(CARRPOLDEN_arr)
    print('Alimento <POLPA DENOCCIOLATA DI CARRUBA> inserito con successo!')
    if type(prezzo_CARRUBE_FRANTUMATE) == float:
        PREZZI.append(prezzo_CARRUBE_FRANTUMATE)
        print("Prezzo del MELASSO DI CANNA => %f EURO/ton" % prezzo_CARRUBE_FRANTUMATE)
    else:
        print('%s' % prezzo_CARRUBE_FRANTUMATE)  

def importa_birra_lievito():
    global BILIE_arr
    from importa_MySQLdb_birra_lievito import BILIE_arr
    S.append('lievito di birra')
    ARR.append(BILIE_arr)
    print('Alimento <LIEVITO DI BIRRA> inserito con successo!')
    prezzo_LIEVITO_BIRRA = ''
    if type(prezzo_LIEVITO_BIRRA) == float:
        PREZZI.append(prezzo_LIEVITO_BIRRA)
        print("Prezzo del LIEVITO DI BIRRA => %f EURO/ton" % prezzo_LIEVITO_BIRRA)
    else:
        print('Prezzo del LIEVITO DI BIRRA non disponibile')
    
def importa_agrumi_pastazzo_secco():
    global AGRPASE_arr
    from importa_MySQLdb_agrumi_pastazzo_secco import AGRPASE_arr
    S.append('pastazzo secco di agrumi')
    ARR.append(AGRPASE_arr)
    print('Alimento <PASTAZZO SECCO DI AGRUMI> inserito con successo!')
    prezzo_AGRUMI_PASTAZZO_SECCO = ''
    if type(prezzo_AGRUMI_PASTAZZO_SECCO) == float:
        PREZZI.append(prezzo_AGRUMI_PASTAZZO_SECCO)
        print("Prezzo del PASTAZZO SECCO DI AGRUMI => %f EURO/ton" % prezzo_AGRUMI_PASTAZZO_SECCO)
    else:
        print('Prezzo del PASTAZZO SECCO DI AGRUMI non disponibile')    

def importa_calcio_saponi():
    global CASAP_arr
    from importa_MySQLdb_calcio_saponi import CASAP_arr
    S.append('saponi di calcio')
    ARR.append(CASAP_arr)  
    print('Alimento <SAPONI DI CALCIO> inserito con successo!')
    prezzo_SAPONI_CALCIO = ''
    if type(prezzo_SAPONI_CALCIO) == float:
        PREZZI.append(prezzo_SAPONI_CALCIO)
        print("Prezzo dei SAPONI DI CALCIO => %f EURO/ton" % prezzo_SAPONI_CALCIO)
    else:
        print('Prezzo dei SAPONI DI CALCIO non disponibile') 

def importa_latte_magro_polvere():
    global LATMAPOL_arr
    from importa_MySQLdb_latte_magro_polvere import LATMAPOL_arr
    S.append('latte magro in polvere')
    ARR.append(LATMAPOL_arr)
    print('Alimento <LATTE MAGRO IN POLVERE> inserito con successo!')
    prezzo_LATTE_MAGRO_POLVERE = ''
    if type(prezzo_LATTE_MAGRO_POLVERE) == float:
        PREZZI.append(prezzo_LATTE_MAGRO_POLVERE)
        print("Prezzo del LATTE MAGRO IN POLVERE => %f EURO/ton" % prezzo_LATTE_MAGRO_POLVERE)
    else:
        print('Prezzo del LATTE MAGRO IN POLVERE non disponibile')     

def importa_latte_siero():
    global LATSIE_arr
    from importa_MySQLdb_latte_siero import LATSIE_arr
    S.append('siero di latte')
    ARR.append(LATSIE_arr)
    print('Alimento <SIERO DI LATTE> inserito con successo!')
    prezzo_LATTE_SIERO = ''
    if type(prezzo_LATTE_SIERO) == float:
        PREZZI.append(prezzo_LATTE_MAGRO_POLVERE)
        print("Prezzo del SIERO DI LATTE => %f EURO/ton" % prezzo_LATTE_SIERO)
    else:
        print('Prezzo del SIERO DI LATTE non disponibile')    

def importa_crusca_frumento_tenero():
    global CRUFRUTE_arr
    from importa_MySQLdb_crusca_frumento_tenero import CRUFRUTE_arr
    from crea_db_PREZZI_Milano_w import prezzo_FRUMENTO_TENERO_CRUSCA
    S.append('crusca frumento tenero')
    ARR.append(CRUFRUTE_arr)
    print('Alimento <CRUSCA DI FRUMENTO TENERO> inserito con successo!')
    if type(prezzo_FRUMENTO_TENERO_CRUSCA) == float:
        PREZZI.append(prezzo_FRUMENTO_TENERO_CRUSCA)
        print("Prezzo della CRUSCA DI FRUMENTO TENERO => %f EURO/ton" % prezzo_FRUMENTO_TENERO_CRUSCA)
    else:
        print('%s' % prezzo_FRUMENTO_TENERO_CRUSCA)    

def importa_crusca_frumento_duro():
    global CRUFRUDU_arr
    from importa_MySQLdb_crusca_frumento_duro import CRUFRUDU_arr
    from crea_db_PREZZI_Bologna_w import prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B
    prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B = float(prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B)
    S.append('crusca frumento duro')
    ARR.append(CRUFRUDU_arr)
    PREZZI.append(prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B)
    print('Alimento <CRUSCA DI FRUMENTO DURO> inserito con successo!')
    if type(prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B) == float:
        PREZZI.append(prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B)
        print("Prezzo della CRUSCA DI FRUMENTO DURO => %f EURO/ton" % prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B)
    else:
        print('%s' % prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B)    

def importa_cruschello_frumento_tenero():
    global CRUSCHFRUTE_arr
    from importa_MySQLdb_cruschello_frumento_tenero import CRUSCHFRUTE_arr
    from crea_db_PREZZI_Milano_w import prezzo_FRUMENTO_TENERO_CRUSCHELLO
    S.append('cruschello di frumento tenero')
    ARR.append(CRUSCHFRUTE_arr)
    print('Alimento <CRUSCHELLO DI FRUMENTO TENERO> inserito con successo!')
    if type(prezzo_FRUMENTO_TENERO_CRUSCHELLO) == float:
        PREZZI.append(prezzo_FRUMENTO_TENERO_CRUSCHELLO)
        print("Prezzo della CRUSCHELLO DI FRUMENTO TENERO => %f EURO/ton" % prezzo_FRUMENTO_TENERO_CRUSCHELLO)
    else:
        print('%s' % prezzo_FRUMENTO_TENERO_CRUSCHELLO)  

def importa_cruschello_frumento_duro():
    global CRUSCHFRUDU_arr
    from importa_MySQLdb_cruschello_frumento_duro import CRUSCHFRUDU_arr
    from crea_db_PREZZI_Bologna_w import prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B
    prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B = float(prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B)
    S.append('cruschello di frumento duro')
    ARR.append(CRUSCHFRUDU_arr)
    print('Alimento <CRUSCHELLO DI FRUMENTO DURO> inserito con successo!')
    if type(prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B) == float:
        PREZZI.append(prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B)
        print("Prezzo della CRUSCHELLO DI FRUMENTO DURO => %f EURO/ton" % prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B)
    else:
        print('%s' % prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B)

def importa_pula_commerciale():
    global RISPUCOM_arr
    from importa_MySQLdb_riso_pula_commerciale import RISPUCOM_arr
    S.append('pula commerciale')
    ARR.append(RISPUCOM_arr)
    print('Alimento <PULA COMMERCIALE> inserito con successo!')
    prezzo_PULA_COMMERCIALE = ''
    if type(prezzo_PULA_COMMERCIALE) == float:
        PREZZI.append(prezzo_PULA_COMMERCIALE)
        print("Prezzo della PULA COMMERCIALE => %f EURO/ton" % prezzo_PULA_COMMERCIALE)
    else:
        print('Prezzo della PULA COMMERCIALE non disponibile')     

def importa_pula_vergine():
    global RISPUVER_arr
    from importa_MySQLdb_riso_pula_vergine import RISPUVER_arr
    from crea_db_PREZZI_Milano_w import prezzo_RISO_PULA_VERGINE
    S.append('pula vergine')
    ARR.append(RISPUVER_arr)
    print('Alimento <PULA VERGINE> inserito con successo!')
    prezzo_PULA_VERGINE = ''
    if type(prezzo_PULA_VERGINE) == float:
        PREZZI.append(prezzo_PULA_VERGINE)
        print("Prezzo della PULA VERGINE => %f EURO/ton" % prezzo_PULA_VERGINE)
    else:
        print('Prezzo della PULA VERGINE non disponibile')  

def importa_soia_buccette():
    global SOIABUCC_arr
    from importa_MySQLdb_soia_buccette import SOIABUCC_arr
    from crea_db_PREZZI_Milano_w import prezzo_SOIA_BUCCETTE
    S.append('buccette di soia')
    ARR.append(SOIABUCC_arr)
    print('Alimento <BUCCETTE DI SOIA> inserito con successo!')
    prezzo_BUCCETTE_SOIA = ''
    if type(prezzo_BUCCETTE_SOIA) == float:
        PREZZI.append(prezzo_BUCCETTE_SOIA)
        print("Prezzo delle BUCCETTE DI SOIA => %f EURO/ton" % prezzo_BUCCETTE_SOIA)
    else:
        print('Prezzo delle BUCCETTE DI SOIA non disponibile') 

def importa_residui_distilleria():
    global MAISDIST_arr
    from importa_MySQLdb_mais_residui_distilleria import MAISDIST_arr
    S.append('mais residui di distilleria')
    ARR.append(MAISDIST_arr)
    print('Alimento <RESIDUI DI DISTILLERIA> inserito con successo!')
    prezzo_RESIDUI_DISTILLERIA = ''
    if type(prezzo_RESIDUI_DISTILLERIA) == float:
        PREZZI.append(prezzo_RESIDUI_DISTILLERIA)
        print("Prezzo dei RESIDUI DI DISTILLERIA => %f EURO/ton" % prezzo_RESIDUI_DISTILLERIA)
    else:
        print('Prezzo dei RESIDUI DI DISTILLERIA non disponibile')    

def importa_orzo_radichette_malto():
    global ORRADMAL_arr
    from importa_MySQLdb_orzo_radichette_malto import ORRADMAL_arr
    S.append("radichette di malto d'orzo")
    ARR.append(ORRADMAL_arr) 
    print('Alimento <RADICHETTE DI MALTO> inserito con successo!')
    prezzo_RADICHETTE_MALTO = ''
    if type(prezzo_RADICHETTE_MALTO) == float:
        PREZZI.append(prezzo_RADICHETTE_MALTO)
        print("Prezzo delle RADICHETTE DI MALTO => %f EURO/ton" % prezzo_RADICHETTE_MALTO)
    else:
        print('Prezzo delle RADICHETTE DI MALTO non disponibile')

def importa_orzo_trebbie_birra():
    global ORTREBIR_arr
    from importa_MySQLdb_orzo_trebbie_birra import ORTREBIR_arr
    S.append("trebbie di birra d'orzo")
    ARR.append(ORTREBIR_arr)
    print("Alimento <TREBBIE DI BIRRA D'ORZO> inserito con successo!")
    prezzo_TREBBIE_BIRRA = ''
    if type(prezzo_TREBBIE_BIRRA) == float:
        PREZZI.append(prezzo_TREBBIE_BIRRA)
        print("Prezzo delle TREBBIE DI BIRRA D'ORZO => %f EURO/ton" % prezzo_TREBBIE_BIRRA)
    else:
        print("Prezzo delle TREBBIE DI BIRRA D'ORZO non disponibile")    

def importa_cocco_pannello():
    global COCPANN_arr
    from importa_MySQLdb_cocco_pannello import COCPANN_arr
    S.append('pannello di cocco')
    ARR.append(COCPANN_arr)
    print("Alimento <PANNELLO DI COCCO> inserito con successo!")
    prezzo_PANNELLO_COCCO = ''
    if type(prezzo_PANNELLO_COCCO) == float:
        PREZZI.append(prezzo_PANNELLO_COCCO)
        print("Prezzo del PANNELLO DI COCCO => %f EURO/ton" % prezzo_PANNELLO_COCCO)
    else:
        print('Prezzo del PANNELLO DI COCCO non disponibile')    
    

def importa_arachide_farina_estrazione():
    global ARAFAESTR_arr
    from importa_MySQLdb_arachide_farina_estrazione import ARAFAESTR_arr
    S.append('farina di estrazione di arachide')
    ARR.append(ARAFAESTR_arr)
    print("Alimento <FARINA DI ESTRAZIONE DI ARACHIDE> inserito con successo!")
    prezzo_FARINA_ESTRAZIONE_ARACHIDE = ''
    if type(prezzo_FARINA_ESTRAZIONE_ARACHIDE) == float:
        PREZZI.append(prezzo_FARINA_ESTRAZIONE_ARACHIDE)
        print("Prezzo della FARINA DI ESTRAZIONE DI ARACHIDE => %f EURO/ton" % prezzo_FARINA_ESTRAZIONE_ARACHIDE)
    else:
        print('Prezzo della FARINA DI ESTRAZIONE DI ARACHIDE non disponibile')
        
def importa_lino_farina_estrazione():
    global LIFAESTR_arr
    from importa_MySQLdb_lino_farina_estrazione import LIFAESTR_arr
    S.append('farina di estrazione di lino')
    ARR.append(LIFAESTR_arr)
    print("Alimento <FARINA DI ESTRAZIONE DI LINO> inserito con successo!")
    prezzo_FARINA_ESTRAZIONE_LINO = ''
    if type(prezzo_FARINA_ESTRAZIONE_LINO) == float:
        PREZZI.append(prezzo_FARINA_ESTRAZIONE_LINO)
        print("Prezzo della FARINA DI ESTRAZIONE DI LINO => %f EURO/ton" % prezzo_FARINA_ESTRAZIONE_LINO)
    else:
        print('Prezzo della FARINA DI ESTRAZIONE DI LINO non disponibile')    

def importa_soia_farina_estrazione_45_per_100():
    global SOFAESTR45_arr
    from importa_MySQLdb_soia_farina_estrazione_45_per_100 import SOFAESTR45_arr
    from crea_db_PREZZI_Milano_w import prezzo_SOIA_FE 
    S.append('farina di estrazione di soia 45%')
    ARR.append(SOFAESTR45_arr)
    print('Alimento <FARINA DI ESTRAZIONE DI SOIA 45x100> inserito con successo!')
    if type(prezzo_SOIA_FE) == float:
        PREZZI.append(prezzo_SOIA_FE)
        print("Prezzo della FARINA DI ESTRAZIONE DI SOIA 45x100 => %f EURO/ton" % prezzo_SOIA_FE)
    else:
        print('%s' % prezzo_SOIA_FE)

def importa_soia_farina_estrazione_50_per_100():
    global SOFAESTR50_arr
    from importa_MySQLdb_soia_farina_estrazione_50_per_100 import SOFAESTR50_arr
    from crea_db_PREZZI_Milano_w import prezzo_SOIA_FE
    S.append('farina di estrazione di soia 50%')
    ARR.append(SOFAESTR50_arr)
    print('Alimento <FARINA DI ESTRAZIONE DI SOIA 50x100> inserito con successo!')
    if type(prezzo_SOIA_FE) == float:
        PREZZI.append(prezzo_SOIA_FE)
        print("Prezzo della FARINA DI ESTRAZIONE DI SOIA 50x100 => %f EURO/ton" % prezzo_SOIA_FE)
    else:
        print('%s' % prezzo_SOIA_FE)

def importa_colza_farina_estrazione():
    global COLFAESTR_arr
    from importa_MySQLdb_colza_farina_estrazione import COLFAESTR_arr
    from crea_db_PREZZI_Milano_w import prezzo_COLZA_FE
    S.append('farina di estrazione di colza')
    ARR.append(COLFAESTR_arr)
    print('Alimento <FARINA DI ESTRAZIONE DI COLZA> inserito con successo!')
    if type(prezzo_COLZA_FE) == float:
        PREZZI.append(prezzo_COLZA_FE)
        print("Prezzo della FARINA DI ESTRAZIONE DI COLZA => %f EURO/ton" % prezzo_COLZA_FE)
    else:
        print('%s' % prezzo_COLZA_FE) 

def importa_cotone_farina_estrazione():
    global COTFAESTR_arr
    from importa_MySQLdb_cotone_farina_estrazione import COTFAESTR_arr
    S.append('farina di estrazione di cotone')
    ARR.append(COTFAESTR_arr)
    print('Alimento <FARINA DI ESTRAZIONE DI COTONE> inserito con successo!')
    prezzo_FARINA_ESTRAZIONE_COTONE = ''
    if type(prezzo_FARINA_ESTRAZIONE_COTONE) == float:
        PREZZI.append(prezzo_FARINA_ESTRAZIONE_COTONE)
        print("Prezzo della FARINA DI ESTRAZIONE DI COTONE => %f EURO/ton" % prezzo_FARINA_ESTRAZIONE_COTONE)
    else:
        print('Prezzo della FARINA DI ESTRAZIONE DI COTONE non disponibile')  

def importa_cotone_semi():
    global COTSEMI_arr
    from importa_MySQLdb_cotone_semi import COTSEMI_arr
    from crea_db_PREZZI_Bologna_w import prezzo_COTONE_B
    prezzo_COTONE_B = float(prezzo_COTONE_B)
    S.append('semi di cotone')
    ARR.append(COTSEMI_arr)
    print('Alimento <SEMI DI COTONE> inserito con successo!')
    if type(prezzo_COTONE_B) == float:
        PREZZI.append(prezzo_COTONE_B)
        print("Prezzo dei SEMI DI COTONE => %f EURO/ton" % prezzo_COTONE_B)
    else:
        print('%s' % prezzo_COTONE_B) 

def importa_girasole_farina_estrazione_24_per_100():
    global GIRFAESTR24_arr
    from importa_MySQLdb_girasole_farina_estrazione_24_per_100 import GIRFAESTR24_arr
    from crea_db_PREZZI_Milano_w import prezzo_GIRASOLE_DECORTICATO_FE
    S.append('farina di estrazione di girasole 24%')
    ARR.append(GIRFAESTR24_arr)
    print('Alimento <FARINA DI ESTRAZIONE DI GIRASOLE 24x100> inserito con successo!')
    if type(prezzo_GIRASOLE_DECORTICATO_FE) == float:
        PREZZI.append(prezzo_GIRASOLE_DECORTICATO_FE)
        print("Prezzo della FARINA DI ESTRAZIONE DI GIRASOLE 24x100 => %f EURO/ton" % prezzo_GIRASOLE_DECORTICATO_FE)
    else:
        print('%s' % prezzo_GIRASOLE_DECORTICATO_FE)

def importa_girasole_farina_estrazione_34_per_100():
    global GIRFAESTR34_arr
    from importa_MySQLdb_girasole_farina_estrazione_34_per_100 import GIRFAESTR34_arr
    from crea_db_PREZZI_Milano_w import prezzo_GIRASOLE_DECORTICATO_FE
    S.append('farina di estrazione di girasole 34%')
    ARR.append(GIRFAESTR34_arr)
    print('Alimento <FARINA DI ESTRAZIONE DI GIRASOLE 34x100> inserito con successo!')
    if type(prezzo_GIRASOLE_DECORTICATO_FE) == float:
        PREZZI.append(prezzo_GIRASOLE_DECORTICATO_FE)
        print("Prezzo della FARINA DI ESTRAZIONE DI GIRASOLE 34x100 => %f EURO/ton" % prezzo_GIRASOLE_DECORTICATO_FE)
    else:
        print('%s' % prezzo_GIRASOLE_DECORTICATO_FE)


def stampa_aiuto_inserisci_alimenti():
    print('Inserisci un numero di alimenti compreso fra 3 e 10. \n')

def stampa_alimenti_scelti():
    print(S)
    print(ARR)

def stampa_aiuto_comandi():
    print('scrivi il nome del comando seguito da <.aiuto>')
    
def notdone():
    showerror('Not implemented', 'Not yet available')

def info_sistema_operativo():
    import platform
    print(platform.uname())

def metodo_americano():
    os.chdir('~/PYTHON_PROGRAMS/PROGRAMMI_CHE_FUNZIONANO/')
    os.system('python scrolledtext.py Descrizione_metodo_americano.txt')

def esegui_Notepad():
    os.system('Notepad') 
    
def esegui_firefox_mais():
    os.system('start firefox https://teseo.clal.it/?section=granoturco_secco_Bologna_w#tabella_g_n_zootecnico1')
    
def stampa_prezzi():
    os.system('python stampa_PREZZI_w.py')     

def crea_listino_prezzi_alessandria():
    os.system('python scrape_tables_Alessandria_w.py')
    
def crea_listino_prezzi_bologna():    
    os.system('python esegui_esegui_scrape_tables_Bologna_w.py')
    
def crea_listino_prezzi_clal():    
    os.system('python scrape_tables_clal_w.py')
    
def crea_listino_prezzi_foggia():
    os.system('python scrape_tables_Foggia_w.py')
    
def crea_listino_prezzi_milano():    
    os.system('python scrape_tables_Milano_w.py')
    
def popup_milano():
    import os, requests, ssl, urllib.request
    import pandas as pd										
    from html.parser import HTMLParser
    from html_table_parser.parser import HTMLTableParser		
    from datetime import date, datetime, timedelta				
    from contextlib import redirect_stdout

    ssl._create_default_https_context = ssl._create_unverified_context

    user = os.getlogin()
    os.chdir('C:/Users/%s/PYTHON' % user)

    pd.set_option('display.max_rows', 200)
    pd.options.display.width=None

    data = datetime.today().strftime('%d.%m.%Y')
    today = date.today()

    import datetime

    idx = (today.weekday() + 6) % 7
    Tuesday = (today - datetime.timedelta(idx)).strftime('%Y-%m-%d')
    last_Tuesday = (today - datetime.timedelta(idx+7)).strftime('%Y-%m-%d')
    last_last_Tuesday = (today - datetime.timedelta(idx+14)).strftime('%Y-%m-%d')

    urls = ['https://www.granariamilano.it/listino-%s/' % Tuesday, 'https://www.granariamilano.it/listino-%s/' % last_Tuesday, 'https://www.granariamilano.it/listino-%s/' % last_last_Tuesday]

    def check_url_exists(url):
        for i in range(len(urls)):
            return requests.head(urls[i], allow_redirects=True).status_code == 200

    if check_url_exists(urls[0]) == True:
        url = urls[0]
    elif check_url_exists(urls[1]) == True:
        url = urls[1]
    elif check_url_exists(urls[2]) == True:
        url = urls[2]
    else:
	    print('Listino prezzi BORSA MERCI di Milano non disponibile')

    def url_get_contents(url):					 
        req = urllib.request.Request(url)			
        f = urllib.request.urlopen(req)
        return f.read()						

    xhtml = url_get_contents(url).decode('utf-8')
    p = HTMLTableParser()						
    p.feed(xhtml)							
    granaria_milano = pd.DataFrame(p.tables[1])
    print(granaria_milano)
    

def crea_listino_milano():
    import os, requests, ssl, urllib.request
    import pandas as pd								
    from html.parser import HTMLParser
    from html_table_parser.parser import HTMLTableParser		
    from datetime import date, datetime, timedelta				
    from contextlib import redirect_stdout

    ssl._create_default_https_context = ssl._create_unverified_context

# user = os.getlogin()
# os.chdir('C:/Users/%s/PYTHON' % user)

    pd.set_option('display.max_rows', 200)
    pd.options.display.width=None

    data = datetime.today().strftime('%d.%m.%Y')
    today = date.today()

    import datetime

    idx = (today.weekday() + 6) % 7
    Tuesday = (today - datetime.timedelta(idx)).strftime('%Y-%m-%d')
    last_Tuesday = (today - datetime.timedelta(idx+7)).strftime('%Y-%m-%d')
    last_last_Tuesday = (today - datetime.timedelta(idx+14)).strftime('%Y-%m-%d')

    urls = ['https://www.granariamilano.it/listino-%s/' % Tuesday, 'https://www.granariamilano.it/listino-%s/' % last_Tuesday, 'https://www.granariamilano.it/listino-%s/' % last_last_Tuesday]

    def check_url_exists(url):
        for i in range(len(urls)):
            return requests.head(urls[i], allow_redirects=True).status_code == 200

    if check_url_exists(urls[0]) == True:
        url = urls[0]
    elif check_url_exists(urls[1]) == True:
        url = urls[1]
    elif check_url_exists(urls[2]) == True:
        url = urls[2]
    else:
	    print('Listino prezzi BORSA MERCI di Milano non disponibile')


    def url_get_contents(url):					 
        req = urllib.request.Request(url)			
        f = urllib.request.urlopen(req)
        return f.read()						

    xhtml = url_get_contents(url).decode('utf-8')
    p = HTMLTableParser()						
    p.feed(xhtml)							
    granaria_milano = pd.DataFrame(p.tables[1])
    print("BORSA MERCI DI Milano - %s" % url) 
    print(granaria_milano)
    
    with open('listino_prezzi_Milano.txt', 'w', encoding = "utf-8") as f:
        with redirect_stdout(f):
            print("BORSA MERCI Milano - %s" % url) 
            print(granaria_milano)

 
 
def esegui_Firefox_cornell():
    os.system('start firefox https://cals.cornell.edu/animal-science/outreach-extension/publications-resources-software/cornell-net-carbohydrate-and-protein-system')

 
IMAGE_PATH = 'logo.png'
WIDTH, HEIGHT = 550, 550

# root window
root = tk.Tk()
root.geometry('{}x{}'.format(WIDTH, HEIGHT))
root.configure(bg='black')
root.title('PyR')


canvas = tk.Canvas(root, width=WIDTH, height=HEIGHT)
canvas.pack()

img = ImageTk.PhotoImage(Image.open(IMAGE_PATH).resize((WIDTH, HEIGHT), Image.ANTIALIAS))
canvas.background = img  # Keep a reference in case this code is put in a function.
bg = canvas.create_image(0, 0, anchor=tk.NW, image=img)

size = (60, 60)

toolbar = tk.Frame(root, cursor='hand2', relief=SUNKEN, bd=2, width=size[0], height=size[1])
toolbar.pack(side=BOTTOM, fill=X)
# https://stackoverflow.com/questions/71257355/tkinter-toolbar-menu-button-open-drop-down-menu-gif

photo1 = ImageTk.PhotoImage(Image.open('Start.png').resize(size, Image.ANTIALIAS))
photo2 = ImageTk.PhotoImage(Image.open('win.png').resize(size, Image.ANTIALIAS))
photo3 = ImageTk.PhotoImage(Image.open('cornell.png').resize(size, Image.ANTIALIAS))
photo4 = ImageTk.PhotoImage(Image.open('classificatori.png').resize(size, Image.ANTIALIAS))
photo5 = ImageTk.PhotoImage(Image.open('logo.png').resize(size, Image.ANTIALIAS))
photo6 = ImageTk.PhotoImage(Image.open('bilancia.png').resize(size, Image.ANTIALIAS))
photo7 = ImageTk.PhotoImage(Image.open('granaria_milano.png').resize(size, Image.ANTIALIAS))
photo8 = ImageTk.PhotoImage(Image.open('teseo.png').resize(size, Image.ANTIALIAS))
photo9 = ImageTk.PhotoImage(Image.open('mais.png').resize(size, Image.ANTIALIAS))
photo10 = ImageTk.PhotoImage(Image.open('silos.png').resize(size, Image.ANTIALIAS))
photo11 = ImageTk.PhotoImage(Image.open('pastone_integrale.png').resize(size, Image.ANTIALIAS))
photo12 = ImageTk.PhotoImage(Image.open('pastone_granella.png').resize(size, Image.ANTIALIAS))
photo13 = ImageTk.PhotoImage(Image.open('granella.png').resize(size, Image.ANTIALIAS))
photo14 = ImageTk.PhotoImage(Image.open('blue-power.png').resize(size, Image.ANTIALIAS))
photo15 = ImageTk.PhotoImage(Image.open('stampa.png').resize(size, Image.ANTIALIAS))
photo16 = ImageTk.PhotoImage(Image.open('money.png').resize(size, Image.ANTIALIAS))
photo17 = ImageTk.PhotoImage(Image.open('carro.png').resize(size, Image.ANTIALIAS))
photo18 = ImageTk.PhotoImage(Image.open('info.png').resize(size, Image.ANTIALIAS))
photo19 = ImageTk.PhotoImage(Image.open('cow.png').resize(size, Image.ANTIALIAS))
  
btn1 = tk.Menubutton(toolbar, image=photo1)     # START
btn1.config(relief=RAISED, bd=2)
btn1.config(width=size[0], height=size[1])
btn1.pack(side=LEFT)

menu = tk.Menu(btn1, tearoff=0)
btn1.config(menu=menu)


menu.insert_command(0, label='teseo')
menu.insert_command(0, label='Granaria Milano')
menu.insert_command(0, label='Listino prezzi')
menu.insert_command(0, label='Fabbisogni')
menu.insert_command(0, label='cornell')
menu.insert_command(0, label='Sistema')
menu.insert_command(0, label='PyR')

# def apri_con_gedit():
#    subprocess.run('gedit PROVA.txt')

def info_PyR():
    print("BENVENUTO NEL PROGRAMMA PyR!")
    print('')
    print("PyR è un programma informatico per la formulazione della razione alimentare delle bovine da latte, destinato ai Tecnici Agrari, agli Agronomi ed ai Veterinari che operano nel settore.")
    print("Per la sua semplicità d'uso, PyR può rappresentare uno strumento utile per tutti gli allevatori che desiderino assumere il pieno controllo della razione alimentare da somministrare alle proprie bovine, senza doversi avvalere necessariamente della consulenza di un professionista.")
    print('')
    print('')
    print("DESCRIZIONE")
    print('')
    print("<PyR> è un software scritto da Piero Rivoira nel linguaggio python (https://www.python.it/). Il calcolo dei fabbisogni nutritivi degli animali si basa sul sistema <CNCPS> (Cornell Net Carbohydrate and Protein System), sviluppato dalla Cornell University. Per bilanciare la razione in funzione dei fabbisogni PyR applica un algoritmo molto efficiente (di tipo accetta-rifiuta) il quale, costruendo una catena di Markov (https://it.wikipedia.org/wiki/Catena_di_Markov_Monte_Carlo) che ha come distribuzione stazionaria il vettore dei fabbisogni, calcola la quantità in cui ogni singolo alimento, scelto dall'utente, concorre a formare la razione finale.")
    print("Per valorizzare le produzioni aziendali l'utente ha, inoltre, la possibilità di scegliere la quantità di insilato (o di pastone) e/o di granella di mais che desidera inserire nella razione.")
    print('')
    print('')
    print("REQUISITI DI SISTEMA")
    print('')
    print("Microsoft Windows 10 (o superiore)")
    print("Apple macOS (Mac OS X)")
    print("GNU/Linux")
    print("Android/Linux")
    print('')
    print('                                            *	*	*') 

     

menu.insert_cascade(1, image=photo8, command=lambda: redirectedGuiFunc(stampa_prezzi_teseo))
menu.insert_cascade(1, image=photo7, command=lambda: redirectedGuiFunc(crea_listino_milano))
menu.insert_cascade(1, image=photo6, command=lambda: redirectedGuiShellCmd('python stampa_PREZZI_w.py'))
menu.insert_cascade(1, image=photo19, command=lambda: redirectedGuiFunc(calcola_fabbisogni))
menu.insert_cascade(1, image=photo3, command=esegui_Firefox_cornell)                                    # cornell
menu.insert_cascade(1, image=photo2, command=lambda: redirectedGuiFunc(info_sistema_operativo))         # windows
menu.insert_cascade(1, image=photo18, command=lambda: redirectedGuiFunc(info_PyR))



btn2 = tk.Menubutton(toolbar, image=photo9)     # START MAIS
btn2.config(relief=RAISED, bd=2)
btn2.config(width=size[0], height=size[1])
btn2.pack(side=LEFT)

menu = tk.Menu(btn2, tearoff=0)
btn2.config(menu=menu)


menu.insert_command(0, label='Granella')
menu.insert_command(0, label='Pastone granella')
menu.insert_command(0, label='Pastone integrale')
menu.insert_command(0, label='Insilato')


menu.insert_cascade(1, image=photo13, command=lambda: redirectedGuiFunc(apporto_mais_granella))
menu.insert_cascade(1, image=photo12, command=lambda: redirectedGuiFunc(apporto_pastone_mais_granella))
menu.insert_cascade(1, image=photo11, command=lambda: redirectedGuiFunc(apporto_pastone_mais_integrale))
menu.insert_cascade(1, image=photo10, command=lambda: redirectedGuiFunc(apporto_insilato_mais))


btn3 = tk.Menubutton(toolbar, image=photo15)
btn3.config(relief=RAISED, bd=2)
btn3.config(width=size[0], height=size[1])
btn3.pack(side=LEFT)

menu = tk.Menu(btn3, tearoff=0)
btn3.config(menu=menu)

def stampa_prezzi_PDF():
# https://www.geeksforgeeks.org/convert-text-and-text-file-to-pdf-using-python/
    os.system('python stampa_PREZZI_w.py > tabella_PREZZI.txt')
    from fpdf import FPDF
    pdf = FPDF()
    pdf.add_page('L')
    pdf.set_font('Courier', size = 12)
    pdf.set_margins(20.0, 3.0)
    f = open('tabella_PREZZI.txt', 'r')
    for x in f:
        pdf.cell(250, 10, txt = x, ln = 1, align = 'C')
    pdf.output('tabella_PREZZI.pdf')
    print('Tabella riassuntiva prezzi in formato pdf creata correttamente!')


def stampa_razione_PDF():
    print('Non ancora implementata')
    

menu.insert_command(0, label='Prezzi')
menu.insert_command(0, label='Razione')


menu.insert_cascade(1, image=photo16, command=lambda: redirectedGuiFunc(stampa_prezzi_PDF))
menu.insert_cascade(1, image=photo17, command=stampa_razione_PDF)


btn4 = tk.Menubutton(toolbar, image=photo4)
btn4.config(relief=RAISED, bd=2)
btn4.config(width=size[0], height=size[1])
btn4.pack(side=LEFT)

menu = tk.Menu(btn4, tearoff=0)
btn4.config(menu=menu)



def quit(root):
    if askyesno('Verify quit', 'Sei sicuro di voler uscire dal programma?'):
        Frame.quit(root)


Button(toolbar, text='', image=photo14, command=root.quit).pack(side=RIGHT, fill=Y)


# create a menubar; la barra <menubar> viene assegnata all'opzione <menu> della finestra <root>
menubar = Menu(root, background='black', fg='white')
root.config(menu=menubar)


# create a menu
file_menu = Menu(menubar)

# add a menu item to the menu

file_menu.add_command(label="Sistema", command=lambda: redirectedGuiFunc(info_sistema_operativo))
# file_menu.add_command(label="Apri", command=askopenfilename)
# file_menu.add_command(label="Apri l'ultima razione", command=apri_ultima_razione)
file_menu.add_command(label="Apri la tabella dei prezzi", command=lambda: redirectedGuiShellCmd('python stampa_PREZZI_w.py'))
file_menu.add_command(label='Esci', command=root.destroy)

menubar.add_cascade(label="File", menu=file_menu)           # add the File menu to the menubar

prezzi_menu = Menu(menubar)
prezzi_menu.add_command(label='Crea il listino della Borsa di Alessandria', command=lambda: redirectedGuiShellCmd('python scrape_tables_Alessandria_w.py'))
prezzi_menu.add_command(label='Crea il listino della Borsa di Bologna (il programma non risponderà ai comandi per 2-3 minuti)', command=lambda: redirectedGuiShellCmd('python esegui_esegui_scrape_tables_Bologna_w.py'))
prezzi_menu.add_command(label='Crea il listino clal (https://teseo.clal.it/)', command=lambda: redirectedGuiShellCmd('python scrape_tables_clal_w.py'))
prezzi_menu.add_command(label='Crea il listino della Borsa di Foggia', command=lambda: redirectedGuiShellCmd('python scrape_tables_Foggia_w.py'))
prezzi_menu.add_command(label='Crea il listino della Borsa di Milano', command=lambda:redirectedGuiFunc(crea_listino_milano), underline=0)

menubar.add_cascade(label="Prezzi", menu=prezzi_menu)


calcolo_menu = Menu(menubar)
calcolo_menu.add_command(label="Metodo americano", command=esegui_Firefox_cornell)
submenu = Menu(calcolo_menu, tearoff=True)
submenu.add_command(label='specie animale', command=specie_animale, underline=0)
submenu.add_command(label='attitudine produttiva', command=attitudine_produttiva, underline=0)
submenu.add_command(label='fase produttiva', command=fase_produttiva, underline=0)
submenu.add_command(label='peso', command=peso, underline=0)
submenu.add_command(label='settimana di lattazione', command=WOL, underline=0)
submenu.add_command(label='livello produttivo giornaliero medio', command=latte_prodotto, underline=0)
submenu.add_command(label='% di grasso del latte di massa', command=grasso, underline=0)
submenu.add_command(label='% di proteina del latte di massa', command=proteina, underline=0)
submenu.add_command(label='% di lattosio del latte di massa (se non disponibile => 4.85)', command=lattosio, underline=0)
submenu.add_command(label='numero di repliche', command=numero_di_repliche, underline=0)

calcolo_menu.add_cascade(label='Inserisci i parametri', menu=submenu, underline=0)
calcolo_menu.add_command(label='Salva i parametri su file', command=stampa_parametri_su_file)
calcolo_menu.add_command(label='Visualizza i parametri', command=lambda:redirectedGuiFunc(stampa_parametri), underline=0)
calcolo_menu.add_command(label='Calcola i fabbisogni', command=lambda:redirectedGuiFunc(calcola_fabbisogni), underline=0)
calcolo_menu.add_command(label='Visualizza i fabbisogni', command=lambda:redirectedGuiFunc(stampa_fabbisogni), underline=0)
calcolo_menu.add_command(label='Calcola la razione', command=lambda:redirectedGuiFunc(calcola_razione), underline=0)
calcolo_menu.add_command(label='Stampa la razione', command=stampa_razione, underline=0)

menubar.add_cascade(label="Calcolo", menu=calcolo_menu)


# alimenti_menu = Menu(menubar)
# alimenti_menu.add_command(label='Stampa gli alimenti scelti', command=lambda:redirectedGuiFunc(stampa_alimenti_scelti), underline=0)
        
# menubar.add_cascade(label='Alimenti', underline=0, menu=alimenti_menu)


foraggi_menu = Menu(menubar)

foraggi_menu.add_command(label='Erba loietto', command=lambda: redirectedGuiFunc(importa_erba_loietto), underline=0)
foraggi_menu.add_command(label='Erba medica di II taglio', command=lambda: redirectedGuiFunc(importa_erba_medica_II_taglio), underline=0)
foraggi_menu.add_command(label='Erba medica disidratata al 15%', command=lambda: redirectedGuiFunc(importa_erba_medica_disidratata_15_per_100), underline=0)
foraggi_menu.add_command(label='Erba medica disidratata al 17%', command=lambda: redirectedGuiFunc(importa_erba_medica_disidratata_17_per_100), underline=0)
foraggi_menu.add_command(label='Erba prato stabile', command=lambda: redirectedGuiFunc(importa_erba_prato_stabile), underline=0)
foraggi_menu.add_command(label='Insilato di loietto', command=lambda: redirectedGuiFunc(importa_insilato_loietto), underline=0)
foraggi_menu.add_command(label='Insilato di mais', command=lambda: redirectedGuiFunc(importa_insilato_mais), underline=0)
foraggi_menu.add_command(label='Pastone di mais granella', command=lambda: redirectedGuiFunc(importa_pastone_mais_granella), underline=0)
foraggi_menu.add_command(label='Pastone di mais integrale', command=lambda: redirectedGuiFunc(importa_pastone_mais_integrale), underline=0)
foraggi_menu.add_command(label='Fieno di loietto', command=lambda: redirectedGuiFunc(importa_fieno_loietto), underline=0)
foraggi_menu.add_command(label='Fieno di medica di I taglio', command=lambda: redirectedGuiFunc(importa_fieno_medica_I_taglio), underline=0)
foraggi_menu.add_command(label='Fieno di medica di II taglio', command=lambda: redirectedGuiFunc(importa_fieno_medica_II_taglio), underline=0)
foraggi_menu.add_command(label='Fieno silos di erba medica', command=lambda: redirectedGuiFunc(importa_fieno_silos_medica), underline=0)
foraggi_menu.add_command(label='Fieno di prato stabile di I taglio', command=lambda: redirectedGuiFunc(importa_fieno_prato_stabile_I_taglio), underline=0)
foraggi_menu.add_command(label='Fieno di prato stabile di II taglio', command=lambda: redirectedGuiFunc(importa_fieno_prato_stabile_II_taglio), underline=0)
foraggi_menu.add_command(label='Paglia di frumento', command=lambda: redirectedGuiFunc(importa_paglia_frumento), underline=0)

menubar.add_cascade(label='Foraggi', underline=0, menu=foraggi_menu)


mais_menu = Menu(menubar) 
mais_menu.add_command(label='Insilato', command=lambda: redirectedGuiFunc(apporto_insilato_mais), underline=0)
mais_menu.add_command(label='Pastone integrale', command=lambda: redirectedGuiFunc(apporto_pastone_mais_integrale), underline=0)
mais_menu.add_command(label='Pastone granella', command=lambda: redirectedGuiFunc(apporto_pastone_mais_granella), underline=0)
mais_menu.add_command(label='Granella', command=lambda: redirectedGuiFunc(apporto_mais_granella), underline=0)
mais_menu.add_command(label='Aggiungi alimenti selezionati e calcola la razione', command=lambda: redirectedGuiFunc(ricalcola_razione), underline=0)

menubar.add_cascade(label='Mais', underline=0, menu=mais_menu)


cereali_menu = Menu(menubar)
cereali_menu.add_command(label='Avena', command=lambda: redirectedGuiFunc(importa_avena), underline=0)
cereali_menu.add_command(label='Frumento tenero', command=lambda: redirectedGuiFunc(importa_frumento_tenero), underline=0)
cereali_menu.add_command(label='Mais granella', command=lambda: redirectedGuiFunc(importa_mais_granella), underline=0)
cereali_menu.add_command(label='Sorgo', command=lambda: redirectedGuiFunc(importa_sorgo), underline=0)
cereali_menu.add_command(label='Orzo', command=lambda: redirectedGuiFunc(importa_orzo), underline=0)
cereali_menu.add_command(label='Triticale', command=lambda: redirectedGuiFunc(importa_triticale), underline=0)

menubar.add_cascade(label='Cereali', underline=0, menu=cereali_menu)


leguminose_menu = Menu(menubar)
leguminose_menu.add_command(label='Soia integrale', command=lambda: redirectedGuiFunc(importa_soia_integrale), underline=0)
leguminose_menu.add_command(label='Pisello', command=lambda: redirectedGuiFunc(importa_pisello), underline=0)
leguminose_menu.add_command(label='Favino', command=lambda: redirectedGuiFunc(importa_favino), underline=0)
leguminose_menu.add_command(label='Lupino', command=lambda: redirectedGuiFunc(importa_lupino), underline=0)

menubar.add_cascade(label='Leguminose', underline=0, menu=leguminose_menu)


sottoprodottivari_menu = Menu(menubar)
sottoprodottivari_menu.add_command(label='Germe di frumento tenero', command=lambda: redirectedGuiFunc(importa_frumento_tenero_germe), underline=0)
sottoprodottivari_menu.add_command(label='Gemma di riso', command=lambda: redirectedGuiFunc(importa_riso_gemma), underline=0)
sottoprodottivari_menu.add_command(label='Grana verde di riso', command=lambda: redirectedGuiFunc(importa_riso_grana_verde), underline=0)
sottoprodottivari_menu.add_command(label='Rottura di riso', command=lambda: redirectedGuiFunc(importa_riso_rottura), underline=0)
sottoprodottivari_menu.add_command(label='Manioca', command=lambda: redirectedGuiFunc(importa_manioca), underline=0)
sottoprodottivari_menu.add_command(label='Melasso di barbabietola', command=lambda: redirectedGuiFunc(importa_melasso_barbabietola), underline=0)
sottoprodottivari_menu.add_command(label='Melasso di canna', command=lambda: redirectedGuiFunc(importa_melasso_canna), underline=0)
sottoprodottivari_menu.add_command(label='Patate essiccate', command=lambda: redirectedGuiFunc(importa_patate_essiccate), underline=0)
sottoprodottivari_menu.add_command(label='Proteina di patata', command=lambda: redirectedGuiFunc(importa_proteina_patata), underline=0)
sottoprodottivari_menu.add_command(label='Lievito di birra', command=lambda: redirectedGuiFunc(importa_birra_lievito), underline=0)
sottoprodottivari_menu.add_command(label='Pastazzo secco di agrumi', command=lambda: redirectedGuiFunc(importa_agrumi_pastazzo_secco), underline=0)
sottoprodottivari_menu.add_command(label='Saponi di calcio', command=lambda: redirectedGuiFunc(importa_calcio_saponi), underline=0)
sottoprodottivari_menu.add_command(label='Latte magro in polvere', command=lambda: redirectedGuiFunc(importa_latte_magro_polvere), underline=0)
sottoprodottivari_menu.add_command(label='Siero di latte', command=lambda: redirectedGuiFunc(importa_latte_siero), underline=0)
sottoprodottivari_menu.add_command(label='Pula commerciale', command=lambda: redirectedGuiFunc(importa_pula_commerciale), underline=0)
sottoprodottivari_menu.add_command(label='Pula vergine', command=lambda: redirectedGuiFunc(importa_pula_vergine), underline=0)
sottoprodottivari_menu.add_command(label='Pannello di cocco', command=lambda: redirectedGuiFunc(importa_cocco_pannello), underline=0)

menubar.add_cascade(label='Sottoprodotti vari', underline=0, menu=sottoprodottivari_menu)


fontidifibradigeribile_menu = Menu(menubar)
fontidifibradigeribile_menu.add_command(label='Tritello di frumento', command=lambda: redirectedGuiFunc(importa_frumento_tritello), underline=0)
fontidifibradigeribile_menu.add_command(label='Farinaccio di frumento tenero', command=lambda: redirectedGuiFunc(importa_frumento_tenero_farinaccio), underline=0)
fontidifibradigeribile_menu.add_command(label='Farinaccio di frumento duro', command=lambda: redirectedGuiFunc(importa_frumento_duro_farinaccio), underline=0)
fontidifibradigeribile_menu.add_command(label='Glutine di mais', command=lambda: redirectedGuiFunc(importa_mais_glutine), underline=0)
fontidifibradigeribile_menu.add_command(label='Semola glutinata di mais', command=lambda: redirectedGuiFunc(importa_mais_semola_glutinata), underline=0)
fontidifibradigeribile_menu.add_command(label='Farinaccio di riso', command=lambda: redirectedGuiFunc(importa_riso_farinaccio), underline=0)
fontidifibradigeribile_menu.add_command(label='Polpe surpressate di bietola', command=lambda: redirectedGuiFunc(importa_bietola_polpe_surpressate), underline=0)
fontidifibradigeribile_menu.add_command(label='Polpe secche di bietola', command=lambda: redirectedGuiFunc(importa_bietola_polpe_secche), underline=0)
fontidifibradigeribile_menu.add_command(label='Polpa denocciolata di carruba', command=lambda: redirectedGuiFunc(importa_carruba_polpa_denocciolata), underline=0)
fontidifibradigeribile_menu.add_command(label='Crusca di frumento tenero', command=lambda: redirectedGuiFunc(importa_crusca_frumento_tenero), underline=0)
fontidifibradigeribile_menu.add_command(label='Crusca di frumento duro', command=lambda: redirectedGuiFunc(importa_crusca_frumento_duro), underline=0)
fontidifibradigeribile_menu.add_command(label='Cruschello di frumento tenero', command=lambda: redirectedGuiFunc(importa_cruschello_frumento_tenero), underline=0)
fontidifibradigeribile_menu.add_command(label='Cruschello di frumento duro', command=lambda: redirectedGuiFunc(importa_cruschello_frumento_duro), underline=0)
fontidifibradigeribile_menu.add_command(label='Buccette di soia', command=lambda: redirectedGuiFunc(importa_soia_buccette), underline=0)
fontidifibradigeribile_menu.add_command(label='Mais residui di distilleria', command=lambda: redirectedGuiFunc(importa_residui_distilleria), underline=0)
fontidifibradigeribile_menu.add_command(label="Radichette di malto d'orzo", command=lambda: redirectedGuiFunc(importa_orzo_radichette_malto), underline=0)
fontidifibradigeribile_menu.add_command(label="Trebbie di birra d'orzo", command=lambda: redirectedGuiFunc(importa_orzo_trebbie_birra), underline=0)
fontidifibradigeribile_menu.add_command(label="Semi di cotone", command=lambda: redirectedGuiFunc(importa_cotone_semi), underline=0)

menubar.add_cascade(label='Fonti di fibra digeribile', underline=0, menu=fontidifibradigeribile_menu)


farinediestrazione_menu = Menu(menubar)
farinediestrazione_menu.add_command(label='Farina di estrazione di arachide', command=lambda: redirectedGuiFunc(importa_arachide_farina_estrazione), underline=0)
farinediestrazione_menu.add_command(label='Farina di estrazione di lino', command=lambda: redirectedGuiFunc(importa_lino_farina_estrazione), underline=0)
farinediestrazione_menu.add_command(label='Farina di estrazione di soia 45%', command=lambda: redirectedGuiFunc(importa_soia_farina_estrazione_45_per_100), underline=0)
farinediestrazione_menu.add_command(label='Farina di estrazione di soia 50%', command=lambda: redirectedGuiFunc(importa_soia_farina_estrazione_50_per_100), underline=0)
farinediestrazione_menu.add_command(label='Farina di estrazione di colza', command=lambda: redirectedGuiFunc(importa_colza_farina_estrazione), underline=0)
farinediestrazione_menu.add_command(label='Farina di estrazione di cotone', command=lambda: redirectedGuiFunc(importa_cotone_farina_estrazione), underline=0)
farinediestrazione_menu.add_command(label='Farina di estrazione di girasole 24%', command=lambda: redirectedGuiFunc(importa_girasole_farina_estrazione_24_per_100), underline=0)
farinediestrazione_menu.add_command(label='Farina di estrazione di girasole 34%', command=lambda: redirectedGuiFunc(importa_girasole_farina_estrazione_34_per_100), underline=0)
 
menubar.add_cascade(label='Farine di estrazione', underline=0, menu=farinediestrazione_menu)

root.configure(background='light sea green')
root.mainloop()


