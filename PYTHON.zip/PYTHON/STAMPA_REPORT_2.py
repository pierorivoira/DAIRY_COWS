# STAMPA_REPORT_2.py
# https://stackoverflow.com/questions/51740145/how-can-i-write-text-to-pdf-file

from reportlab.platypus import SimpleDocTemplate, Paragraph
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.lib.pagesizes import letter


styles = getSampleStyleSheet()
styleN = styles['Normal']
styleH = styles['Heading1']
story = []

pdf_name = 'REPORT.pdf'
doc = SimpleDocTemplate(
    pdf_name,
    pagesize=letter,
    bottomMargin=.4 * inch,
    topMargin=.6 * inch,
    rightMargin=.8 * inch,
    leftMargin=.8 * inch)

with open("/home/piero/PYTHON/LINUX/RAZIONE_PyR_0013.txt", "r") as txt_file:
    text_content = txt_file.read()

P = Paragraph(text_content, styleN)
story.append(P)

doc.build(
    story,
)
