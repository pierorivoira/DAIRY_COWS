def apporto_insilato_mais():
    try:    
        from crea_db_PREZZI_Alessandria_L import prezzo_MAIS_INSILATO
    except ImportError:
        print('Non ho trovato il LISTINO PREZZI <BORSA MERCI di Alessandria> nella CARTELLA <%s>!' % cartella)
        print('')
        print("Devi prima crearlo, selezionando l'opzione <Crea il listino della Borsa di Alessandria> nel menù <Prezzi>")        
    try:
        global M, Q, app_MAIS, app_INSIMA, Q_INSIMA, INSIMA_arr, F_arr_ric, prezzo_FORAGGIO_MANUALE
        prezzo_FORAGGIO_MANUALE = prezzo_MAIS_INSILATO   
        Q_INSIMA = askfloat('Entry', 'Inserisci la quantità di <INSILATO DI MAIS> (in kg)')
        Q = Q_INSIMA
        os.system('python3 crea_db_FABBISOGNI_L.py')
        from crea_db_FABBISOGNI_L import F    
        if metodo == '_CNCPS_':   
            from importa_MySQLdb_insilato_mais import INSIMA_arr
        else:
            from importa_MySQLdb_insilato_mais_LYS_MET import INSIMA_arr, PDIE_INSIMA, LysDI_INSIMA, MetDI_INSIMA
        M = 'insilato di mais'
        app_INSIMA = Q_INSIMA * INSIMA_arr
        app_MAIS = app_INSIMA
        F_arr = np.array(F)
        F_arr_ric = F_arr - app_INSIMA     
        print('Hai inserito %f kg di <INSILATO DI MAIS>' % Q_INSIMA)
        print("Prezzo dell'INSILATO DI MAIS => %f EURO/ton" % prezzo_MAIS_INSILATO)
    except NameError:
        print('Non ho trovato alcun METODO DI CALCOLO della razione! Per favore scegline uno ed inserisci i PARAMETRI richiesti')
        print('')
        print('Hai a disposizione i seguenti metodi:')
        print('')
        print('1) <cornell _CNCPS_>')
        print('')
        print('2) <INRA LYS_MET>')
        print('')
        print('In alternativa, puoi importare i PARAMETRI inseriti precedentemente usando il bottone <importa i parametri>')

