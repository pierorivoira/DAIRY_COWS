# crea_db_PARAMETRI_LLYS_MET.py


### LINUX ###


import os, re
import numpy as np
# import scipy.io as sio

global giorno_di_inserimento, data_di_inserimento, ora_di_inserimento, metodo, LW, WOL, MY, FAT_milk, CP_milk, LAC_milk, N_repl  

user = os.getlogin()
os.chdir('/home/%s/PYTHON/LINUX' % user)



TESTO = open('PARAMETRI.txt').read()
Parametri_decimali = re.findall('[\d]*[.][\d]+', open('PARAMETRI.txt').read())
Parametri_interi = re.findall('\d+', open('PARAMETRI.txt').read())


if TESTO[20:27] == '_CNCPS_':
    metodo = '_CNCPS_'
else:
    metodo = 'LYS_MET'

if TESTO[30:33] == 'Mon':
    giorno_di_inserimento = 'Lunedì'
elif TESTO[30:33] == 'Tue':
    giorno_di_inserimento = 'Martedì'
elif TESTO[30:33] == 'Wed':
    giorno_di_inserimento = 'Mercoledì'
elif TESTO[30:33] == 'Thu':
    giorno_di_inserimento = 'Giovedì'
elif TESTO[30:33] == 'Fri':
    giorno_di_inserimento = 'Venerdì'
elif TESTO[30:33] == 'Sat':
    giorno_di_inserimento = 'Sabato'
elif TESTO[30:33] == 'Sun':
    giorno_di_inserimento = 'Domenica'
        
data_di_inserimento = TESTO[0:10]
ora_di_inserimento = TESTO[11:19]
gruppo = TESTO[28]

calf_weight = float(Parametri_decimali[0])
LW = float(Parametri_decimali[1])
cow_age = int(Parametri_interi[10])
WOL = int(Parametri_interi[11])
WOP = int(Parametri_interi[12])
MY = float(Parametri_decimali[2])
FAT_milk = float(Parametri_decimali[3])
CP_milk = float(Parametri_decimali[4])
LAC_milk = float(Parametri_decimali[5])
PREZZO_MAX = float(Parametri_decimali[6])
N_repl = int(Parametri_interi[23])
