# crea_db_PREZZI_Foggia_w.py

### WINDOWS ### 

import os


user = os.getlogin()
os.chdir('C:/Users/%s/PYTHON' % user)


with open('listino_prezzi_Foggia.txt', 'r') as file:
	righe = file.readlines()

for i in range(len(righe)):
	righe[i] = righe[i].replace('\n', '')
	if righe[i] != 'NQ':
		righe[i] = float(righe[i])
	else:
		righe[i] = 'alimento non quotato'


prezzo_FAVINO_FORAGGIO_F = righe[0]
