# importa_MySQLdb_agrumi_pastazzo_secco.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    agrumi_pastazzo_secco = []

    for i in parametri:
        i = "SELECT %s FROM Sottoprodotto WHERE nome = 'agrumi_pastazzo_secco'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        agrumi_pastazzo_secco.append(float(i[0]))
#   print(AGRPASE)

    AGRPASE = list(np.float_(agrumi_pastazzo_secco))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <agrumi_pastazzo_secco> dal modulo <Sottoprodotto>') 
    from Sottoprodotto import agrumi_pastazzo_secco
    print('<agrumi_pastazzo_secco> importato con successo dal modulo <Sottoprodotto>!')

    AGRPASE = list(np.float_(agrumi_pastazzo_secco))

    del AGRPASE[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del AGRPASE[10]
# elimino 'ceneri'

    del AGRPASE[13:15]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <AGRPASE> => %d' % len(AGRPASE))

    for i in range(len(AGRPASE)):
        AGRPASE[i] = AGRPASE[i]*10

    AGRPASE[0] = AGRPASE[0]/1000
    AGRPASE[12] = AGRPASE[12]/10

    AGRPASE_arr = np.array(AGRPASE)

    for i in range(len(AGRPASE)):
        AGRPASE[i] = float(AGRPASE[i])

print("COMPOSIZIONE CHIMICA dell'alimento <PASTAZZO SECCO DI AGRUMI>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % AGRPASE_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % AGRPASE_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % AGRPASE_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % AGRPASE_arr[3])
print("Fibra Grezza (FG) => %f g" % AGRPASE_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % AGRPASE_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % AGRPASE_arr[6])
print("FAT (Grasso) => %f g" % AGRPASE_arr[7])
print("AM (Amido) => %f g" % AGRPASE_arr[8])
print("ZUC (Zuccheri) => %f g" % AGRPASE_arr[9])
print("Ca (Calcio) => %f g" % AGRPASE_arr[10])
print("P (Fosforo) => %f g" % AGRPASE_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % AGRPASE_arr[12])
print('')

# sio.sAGRPASEemat('AGRPASE.mat', {'vect':AGRPASE})
