# importa_MySQLdb_calcio_saponi.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    calcio_saponi = []

    for i in parametri:
        i = "SELECT %s FROM Sottoprodotto WHERE nome = 'calcio_saponi'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        calcio_saponi.append(float(i[0]))
#   print(CASAP)

    CASAP = list(np.float_(calcio_saponi))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <calcio_saponi> dal modulo <Sottoprodotto>') 
    from Sottoprodotto import calcio_saponi
    print('<calcio_saponi> importato con successo dal modulo <Sottoprodotto>!')

    CASAP = list(np.float_(calcio_saponi))

    del CASAP[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del CASAP[10]
# elimino 'ceneri'

    del CASAP[13:15]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <CASAP> => %d' % len(CASAP))

    for i in range(len(CASAP)):
        CASAP[i] = CASAP[i]*10

    CASAP[0] = CASAP[0]/1000
    CASAP[12] = CASAP[12]/10

    CASAP_arr = np.array(CASAP)

    for i in range(len(CASAP)):
        CASAP[i] = float(CASAP[i])

print("COMPOSIZIONE CHIMICA dell'alimento <SAPONI DI CALCIO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % CASAP_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % CASAP_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % CASAP_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % CASAP_arr[3])
print("Fibra Grezza (FG) => %f g" % CASAP_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % CASAP_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % CASAP_arr[6])
print("FAT (Grasso) => %f g" % CASAP_arr[7])
print("AM (Amido) => %f g" % CASAP_arr[8])
print("ZUC (Zuccheri) => %f g" % CASAP_arr[9])
print("Ca (Calcio) => %f g" % CASAP_arr[10])
print("P (Fosforo) => %f g" % CASAP_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % CASAP_arr[12])
print('')

# sio.sCASAPemat('CASAP.mat', {'vect':CASAP})
