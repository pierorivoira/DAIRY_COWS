# importa_MySQLdb_carruba_polpa_denocciolata_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
    carruba_polpa_denocciolata = []

    for i in parametri:
        i = "SELECT %s FROM Fonte_di_fibra_Lys_Met WHERE nome = 'carruba_polpa_denocciolata'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        carruba_polpa_denocciolata.append(float(i[0]))
#   print(carruba_polpa_denocciolata)

    CARRPOLDEN = list(np.float_(carruba_polpa_denocciolata))

except mysql.connector.Error as err:
  print("Server non raggiungibile: {}".format(err))
  print('Provo ad importare <carruba_polpa_denocciolata> dal modulo <fonte_di_fibra_LYS_MET>') 
  from fonte_di_fibra_LYS_MET import carruba_polpa_denocciolata
  print('<carruba_polpa_denocciolata> importato con successo dal modulo <fonte_di_fibra_LYS_MET>!')

CARRPOLDEN = list(np.float_(carruba_polpa_denocciolata))

del CARRPOLDEN[10]
del CARRPOLDEN[12:16]
del CARRPOLDEN[12]
del CARRPOLDEN[13]

CARRPOLDEN[0] = CARRPOLDEN[0]/100

for i in list(range(1, 12)):
	CARRPOLDEN[i] = CARRPOLDEN[i]*10

CARRPOLDEN[16] = CARRPOLDEN[16]*CARRPOLDEN[15]/100
CARRPOLDEN[17] = CARRPOLDEN[17]*CARRPOLDEN[15]/100

del CARRPOLDEN[13]
# elimina Mj

del CARRPOLDEN[2:4]
# elimina RDP ed RUP

PDIE_CARRPOLDEN = CARRPOLDEN[12]
LysDI_CARRPOLDEN = CARRPOLDEN[13]
MetDI_CARRPOLDEN = CARRPOLDEN[14]

LysDI_MetDI_ratio = LysDI_CARRPOLDEN/MetDI_CARRPOLDEN

CARRPOLDEN_mod = CARRPOLDEN[0:12]
CARRPOLDEN_arr = np.array(CARRPOLDEN_mod)

for i in range(len(CARRPOLDEN_mod)):
    CARRPOLDEN_mod[i] = float(CARRPOLDEN_mod[i])

print('')
print("COMPOSIZIONE CHIMICA dell'alimento <POLPA DENOCCIOLATA DI CARRUBA>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % CARRPOLDEN_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % CARRPOLDEN_arr[1])
print("Fibra Grezza (FG) => %f g" % CARRPOLDEN_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % CARRPOLDEN_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % CARRPOLDEN_arr[4])
print("FAT (Grasso) => %f g" % CARRPOLDEN_arr[5])
print("AM (Amido) => %f g" % CARRPOLDEN_arr[6])
print("ZUC (Zuccheri) => %f g" % CARRPOLDEN_arr[7])
print("Ca (Calcio) => %f g" % CARRPOLDEN_arr[8])
print("P (Fosforo) => %f g" % CARRPOLDEN_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % CARRPOLDEN_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % CARRPOLDEN_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.sCARRPOLDENemat('CARRPOLDEN.mat', {'vect':CARRPOLDEN})
