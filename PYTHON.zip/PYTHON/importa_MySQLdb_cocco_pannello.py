# importa_MySQLdb_cocco_pannello.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    cocco_pannello = []

    for i in parametri:
        i = "SELECT %s FROM Sottoprodotto WHERE nome = 'cocco_pannello'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        cocco_pannello.append(float(i[0]))
#   print(COCPANN)

    COCPANN = list(np.float_(cocco_pannello))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <cocco_pannello> dal modulo <Sottoprodotto>') 
    from Sottoprodotto import cocco_pannello
    print('<cocco_pannello> importato con successo dal modulo <Sottoprodotto>!')

    COCPANN = list(np.float_(cocco_pannello))

    del COCPANN[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del COCPANN[10]
# elimino 'ceneri'

    del COCPANN[13:15]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <COCPANN> => %d' % len(COCPANN))

    for i in range(len(COCPANN)):
        COCPANN[i] = COCPANN[i]*10

    COCPANN[0] = COCPANN[0]/1000
    COCPANN[12] = COCPANN[12]/10

    COCPANN_arr = np.array(COCPANN)

    for i in range(len(COCPANN)):
        COCPANN[i] = float(COCPANN[i])

print("COMPOSIZIONE CHIMICA dell'alimento <PANNELLO DI COCCO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % COCPANN_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % COCPANN_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % COCPANN_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % COCPANN_arr[3])
print("Fibra Grezza (FG) => %f g" % COCPANN_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % COCPANN_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % COCPANN_arr[6])
print("FAT (Grasso) => %f g" % COCPANN_arr[7])
print("AM (Amido) => %f g" % COCPANN_arr[8])
print("ZUC (Zuccheri) => %f g" % COCPANN_arr[9])
print("Ca (Calcio) => %f g" % COCPANN_arr[10])
print("P (Fosforo) => %f g" % COCPANN_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % COCPANN_arr[12])
print('')

# sio.sCOCPANNemat('COCPANN.mat', {'vect':COCPANN})
