# importa_MySQLdb_colza_farina_estrazione_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
    colza_farina_estrazione = []

    for i in parametri:
        i = "SELECT %s FROM Farina_di_estrazione_Lys_Met WHERE nome = 'colza_farina_estrazione'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        colza_farina_estrazione.append(float(i[0]))
#   print(colza_farina_estrazione)

    COLFAESTR = list(np.float_(colza_farina_estrazione))

except mysql.connector.Error as err:
  print("Server non raggiungibile: {}".format(err))
  print('Provo ad importare <colza_farina_estrazione> dal modulo <farina_di_estrazione_LYS_MET>') 
  from farina_di_estrazione_LYS_MET import colza_farina_estrazione
  print('<colza_farina_estrazione> importato con successo dal modulo <farina_di_estrazione_LYS_MET>!')

COLFAESTR = list(np.float_(colza_farina_estrazione))

del COLFAESTR[10]
del COLFAESTR[12:16]
del COLFAESTR[12]
del COLFAESTR[13]

COLFAESTR[0] = COLFAESTR[0]/100

for i in list(range(1, 12)):
	COLFAESTR[i] = COLFAESTR[i]*10

COLFAESTR[16] = COLFAESTR[16]*COLFAESTR[15]/100
COLFAESTR[17] = COLFAESTR[17]*COLFAESTR[15]/100

del COLFAESTR[13]
# elimina Mj

del COLFAESTR[2:4]
# elimina RDP ed RUP

PDIE_COLFAESTR = COLFAESTR[12]
LysDI_COLFAESTR = COLFAESTR[13]
MetDI_COLFAESTR = COLFAESTR[14]

LysDI_MetDI_ratio = LysDI_COLFAESTR/MetDI_COLFAESTR

COLFAESTR_mod = COLFAESTR[0:12]
COLFAESTR_arr = np.array(COLFAESTR_mod)

for i in range(len(COLFAESTR_mod)):
    COLFAESTR_mod[i] = float(COLFAESTR_mod[i])

print('')
print("COMPOSIZIONE CHIMICA dell'alimento <COLZA FARINA DI ESTRAZIONE>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % COLFAESTR_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % COLFAESTR_arr[1])
print("Fibra Grezza (FG) => %f g" % COLFAESTR_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % COLFAESTR_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % COLFAESTR_arr[4])
print("FAT (Grasso) => %f g" % COLFAESTR_arr[5])
print("AM (Amido) => %f g" % COLFAESTR_arr[6])
print("ZUC (Zuccheri) => %f g" % COLFAESTR_arr[7])
print("Ca (Calcio) => %f g" % COLFAESTR_arr[8])
print("P (Fosforo) => %f g" % COLFAESTR_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % COLFAESTR_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % COLFAESTR_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.sCOLFAESTRemat('COLFAESTR.mat', {'vect':COLFAESTR})
