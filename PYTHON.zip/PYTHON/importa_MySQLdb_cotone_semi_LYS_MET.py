# importa_MySQLdb_cotone_semi_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
    cotone_semi = []

    for i in parametri:
        i = "SELECT %s FROM Fonte_di_fibra_Lys_Met WHERE nome = 'cotone_semi'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        cotone_semi.append(float(i[0]))
#   print(cotone_semi)

    COTSEMI = list(np.float_(cotone_semi))

except mysql.connector.Error as err:
  print("Server non raggiungibile: {}".format(err))
  print('Provo ad importare <cotone_semi> dal modulo <fonte_di_fibra_LYS_MET>') 
  from fonte_di_fibra_LYS_MET import cotone_semi
  print('<cotone_semi> importato con successo dal modulo <fonte_di_fibra_LYS_MET>!')

COTSEMI = list(np.float_(cotone_semi))

del COTSEMI[10]
del COTSEMI[12:16]
del COTSEMI[12]
del COTSEMI[13]

COTSEMI[0] = COTSEMI[0]/100

for i in list(range(1, 12)):
	COTSEMI[i] = COTSEMI[i]*10

COTSEMI[16] = COTSEMI[16]*COTSEMI[15]/100
COTSEMI[17] = COTSEMI[17]*COTSEMI[15]/100

del COTSEMI[13]
# elimina Mj

del COTSEMI[2:4]
# elimina RDP ed RUP

PDIE_COTSEMI = COTSEMI[12]
LysDI_COTSEMI = COTSEMI[13]
MetDI_COTSEMI = COTSEMI[14]

LysDI_MetDI_ratio = LysDI_COTSEMI/MetDI_COTSEMI

COTSEMI_mod = COTSEMI[0:12]
COTSEMI_arr = np.array(COTSEMI_mod)

for i in range(len(COTSEMI_mod)):
    COTSEMI_mod[i] = float(COTSEMI_mod[i])

print('')
print("COMPOSIZIONE CHIMICA dell'alimento <COTONE SEMI>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % COTSEMI_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % COTSEMI_arr[1])
print("Fibra Grezza (FG) => %f g" % COTSEMI_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % COTSEMI_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % COTSEMI_arr[4])
print("FAT (Grasso) => %f g" % COTSEMI_arr[5])
print("AM (Amido) => %f g" % COTSEMI_arr[6])
print("ZUC (Zuccheri) => %f g" % COTSEMI_arr[7])
print("Ca (Calcio) => %f g" % COTSEMI_arr[8])
print("P (Fosforo) => %f g" % COTSEMI_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % COTSEMI_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % COTSEMI_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.sCOTSEMIemat('COTSEMI.mat', {'vect':COTSEMI})
