# importa_MySQLdb_crusca_frumento_tenero.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    crusca_frumento_tenero = []

    for i in parametri:
        i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'crusca_frumento_tenero'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        crusca_frumento_tenero.append(float(i[0]))
#   print(CRUFRUTE)

    CRUFRUTE = list(np.float_(crusca_frumento_tenero))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <crusca_frumento_tenero> dal modulo <Fonte_di_fibra>') 
    from Fonte_di_fibra import crusca_frumento_tenero
    print('<crusca_frumento_tenero> importato con successo dal modulo <Fonte_di_fibra>!')

    CRUFRUTE = list(np.float_(crusca_frumento_tenero))

    del CRUFRUTE[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del CRUFRUTE[10]
# elimino 'ceneri'

    del CRUFRUTE[13:15]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <CRUFRUTE> => %d' % len(CRUFRUTE))

    for i in range(len(CRUFRUTE)):
        CRUFRUTE[i] = CRUFRUTE[i]*10

    CRUFRUTE[0] = CRUFRUTE[0]/1000
    CRUFRUTE[12] = CRUFRUTE[12]/10

    CRUFRUTE_arr = np.array(CRUFRUTE)

    for i in range(len(CRUFRUTE)):
        CRUFRUTE[i] = float(CRUFRUTE[i])

print("COMPOSIZIONE CHIMICA dell'alimento <CRUSCA DI FRUMENTO TENERO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % CRUFRUTE_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % CRUFRUTE_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % CRUFRUTE_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % CRUFRUTE_arr[3])
print("Fibra Grezza (FG) => %f g" % CRUFRUTE_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % CRUFRUTE_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % CRUFRUTE_arr[6])
print("FAT (Grasso) => %f g" % CRUFRUTE_arr[7])
print("AM (Amido) => %f g" % CRUFRUTE_arr[8])
print("ZUC (Zuccheri) => %f g" % CRUFRUTE_arr[9])
print("Ca (Calcio) => %f g" % CRUFRUTE_arr[10])
print("P (Fosforo) => %f g" % CRUFRUTE_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % CRUFRUTE_arr[12])
print('')

# sio.sCRUFRUTEemat('CRUFRUTE.mat', {'vect':CRUFRUTE})
