# importa_MySQLdb_erba_medica_disidratata_15x100.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    erba_medica_disidratata_15x100 = []

    for i in parametri:
        i = "SELECT %s FROM Foraggio WHERE nome = 'erba_medica_disidratata_15x100'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        erba_medica_disidratata_15x100.append(float(i[0]))
#   print(ERMEDIS15)

    ERMEDIS15 = list(np.float_(erba_medica_disidratata_15x100))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <erba_medica_disidratata_15x100> dal modulo <Foraggio>') 
    from Foraggio import erba_medica_disidratata_15x100
    print('<erba_medica_disidratata_15x100> importato con successo dal modulo <Foraggio>!')

    ERMEDIS15 = list(np.float_(erba_medica_disidratata_15x100))

    del ERMEDIS15[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del ERMEDIS15[10]
# elimino 'ceneri'

    del ERMEDIS15[13:15]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <ERMEDIS15> => %d' % len(ERMEDIS15))

    for i in range(len(ERMEDIS15)):
        ERMEDIS15[i] = ERMEDIS15[i]*10

    ERMEDIS15[0] = ERMEDIS15[0]/1000
    ERMEDIS15[12] = ERMEDIS15[12]/10

    ERMEDIS15_arr = np.array(ERMEDIS15)

    for i in range(len(ERMEDIS15)):
        ERMEDIS15[i] = float(ERMEDIS15[i])

print("COMPOSIZIONE CHIMICA dell'alimento <ERBA MEDICA DISIDRATATA 15%>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % ERMEDIS15_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % ERMEDIS15_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % ERMEDIS15_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % ERMEDIS15_arr[3])
print("Fibra Grezza (FG) => %f g" % ERMEDIS15_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % ERMEDIS15_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % ERMEDIS15_arr[6])
print("FAT (Grasso) => %f g" % ERMEDIS15_arr[7])
print("AM (Amido) => %f g" % ERMEDIS15_arr[8])
print("ZUC (Zuccheri) => %f g" % ERMEDIS15_arr[9])
print("Ca (Calcio) => %f g" % ERMEDIS15_arr[10])
print("P (Fosforo) => %f g" % ERMEDIS15_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % ERMEDIS15_arr[12])
print('')

# sio.sERMEDIS15emat('ERMEDIS15.mat', {'vect':ERMEDIS15})
