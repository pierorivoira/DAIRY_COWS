# importa_MySQLdb_favino.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    favino = []

    for i in parametri:
        i = "SELECT %s FROM Leguminosa WHERE nome = 'favino'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        favino.append(float(i[0]))
#   print(FAVINO)

    FAVINO = list(np.float_(favino))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <favino> dal modulo <Leguminosa>') 
    from Leguminosa import favino
    print('<favino> importato con successo dal modulo <Leguminosa>!')

    FAVINO = list(np.float_(favino))

    del FAVINO[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del FAVINO[10]
# elimino 'ceneri'

    del FAVINO[13:17]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <FAVINO> => %d' % len(FAVINO))

    for i in range(len(FAVINO)):
        FAVINO[i] = FAVINO[i]*10

    FAVINO[0] = FAVINO[0]/1000
    FAVINO[12] = FAVINO[12]/10

    FAVINO_arr = np.array(FAVINO)

    for i in range(len(FAVINO)):
        FAVINO[i] = float(FAVINO[i])

print("COMPOSIZIONE CHIMICA dell'alimento <FAVINO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % FAVINO_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % FAVINO_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % FAVINO_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % FAVINO_arr[3])
print("Fibra Grezza (FG) => %f g" % FAVINO_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % FAVINO_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % FAVINO_arr[6])
print("FAT (Grasso) => %f g" % FAVINO_arr[7])
print("AM (Amido) => %f g" % FAVINO_arr[8])
print("ZUC (Zuccheri) => %f g" % FAVINO_arr[9])
print("Ca (Calcio) => %f g" % FAVINO_arr[10])
print("P (Fosforo) => %f g" % FAVINO_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % FAVINO_arr[12])
print('')

# sio.sFAVINOemat('FAVINO.mat', {'vect':FAVINO})
