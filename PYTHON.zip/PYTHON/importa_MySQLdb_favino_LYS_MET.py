# importa_MySQLdb_favino_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
    favino = []

    for i in parametri:
        i = "SELECT %s FROM Leguminosa_Lys_Met WHERE nome = 'favino'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        favino.append(float(i[0]))

    FAVINO = list(np.float_(favino))

except mysql.connector.Error as err:
  print("Server non raggiungibile: {}".format(err))
  print('Provo ad importare <favino> dal modulo <leguminosa_LYS_MET>') 
  from leguminosa_LYS_MET import favino
  print('<favino> importato con successo dal modulo <leguminosa_LYS_MET>!')

FAVINO = list(np.float_(favino))

del FAVINO[10]
del FAVINO[12:16]
del FAVINO[12]
del FAVINO[13]

FAVINO[0] = FAVINO[0]/100

for i in list(range(1, 12)):
	FAVINO[i] = FAVINO[i]*10

FAVINO[16] = FAVINO[16]*FAVINO[15]/100
FAVINO[17] = FAVINO[17]*FAVINO[15]/100

del FAVINO[13]
# elimina i Mj

del FAVINO[2:4]
# elimina RDP ed RUP

PDIE_FAVINO = FAVINO[12]
LysDI_FAVINO = FAVINO[13]
MetDI_FAVINO = FAVINO[14]

LysDI_MetDI_ratio = LysDI_FAVINO/MetDI_FAVINO

FAVINO_mod = FAVINO[0:12]
FAVINO_arr = np.array(FAVINO_mod)

for i in range(len(FAVINO_mod)):
    FAVINO_mod[i] = float(FAVINO_mod[i])

print('')
print("COMPOSIZIONE CHIMICA dell'alimento <FAVINO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % FAVINO_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % FAVINO_arr[1])
print("Fibra Grezza (FG) => %f g" % FAVINO_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % FAVINO_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % FAVINO_arr[4])
print("FAT (Grasso) => %f g" % FAVINO_arr[5])
print("AM (Amido) => %f g" % FAVINO_arr[6])
print("ZUC (Zuccheri) => %f g" % FAVINO_arr[7])
print("Ca (Calcio) => %f g" % FAVINO_arr[8])
print("P (Fosforo) => %f g" % FAVINO_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % FAVINO_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % FAVINO_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.sFAVINOemat('FAVINO.mat', {'vect':FAVINO})
