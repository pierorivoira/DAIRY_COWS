# importa_MySQLdb_fieno_medica_II_taglio.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    fieno_medica_II_taglio = []

    for i in parametri:
        i = "SELECT %s FROM Foraggio WHERE nome = 'fieno_medica_II_taglio'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        fieno_medica_II_taglio.append(float(i[0]))
#   print(FIEME2TA)

    FIEME2TA = list(np.float_(fieno_medica_II_taglio))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <fieno_medica_II_taglio> dal modulo <Foraggio>') 
    from Foraggio import fieno_medica_II_taglio
    print('<fieno_medica_II_taglio> importato con successo dal modulo <Foraggio>!')

    FIEME2TA = list(np.float_(fieno_medica_II_taglio))

    del FIEME2TA[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del FIEME2TA[10]
# elimino 'ceneri'

    del FIEME2TA[13:17]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <FIEME2TA> => %d' % len(FIEME2TA))

    for i in range(len(FIEME2TA)):
        FIEME2TA[i] = FIEME2TA[i]*10

    FIEME2TA[0] = FIEME2TA[0]/1000
    FIEME2TA[12] = FIEME2TA[12]/10

    FIEME2TA_arr = np.array(FIEME2TA)

    for i in range(len(FIEME2TA)):
        FIEME2TA[i] = float(FIEME2TA[i])

print("COMPOSIZIONE CHIMICA dell'alimento <FIENO MEDICA II TAGLIO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % FIEME2TA_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % FIEME2TA_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % FIEME2TA_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % FIEME2TA_arr[3])
print("Fibra Grezza (FG) => %f g" % FIEME2TA_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % FIEME2TA_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % FIEME2TA_arr[6])
print("FAT (Grasso) => %f g" % FIEME2TA_arr[7])
print("AM (Amido) => %f g" % FIEME2TA_arr[8])
print("ZUC (Zuccheri) => %f g" % FIEME2TA_arr[9])
print("Ca (Calcio) => %f g" % FIEME2TA_arr[10])
print("P (Fosforo) => %f g" % FIEME2TA_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % FIEME2TA_arr[12])
print('')

# sio.sFIEME2TAemat('FIEME2TA.mat', {'vect':FIEME2TA})
