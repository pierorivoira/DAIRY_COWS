# importa_MySQLdb_fieno_medica_I_taglio.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    fieno_medica_I_taglio = []

    for i in parametri:
        i = "SELECT %s FROM Foraggio WHERE nome = 'fieno_medica_I_taglio'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        fieno_medica_I_taglio.append(float(i[0]))
#   print(FIEME1TA)

    FIEME1TA = list(np.float_(fieno_medica_I_taglio))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <fieno_medica_I_taglio> dal modulo <Foraggio>') 
    from Foraggio import fieno_medica_I_taglio
    print('<fieno_medica_I_taglio> importato con successo dal modulo <Foraggio>!')

    FIEME1TA = list(np.float_(fieno_medica_I_taglio))

    del FIEME1TA[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del FIEME1TA[10]
# elimino 'ceneri'

    del FIEME1TA[13:17]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <FIEME1TA> => %d' % len(FIEME1TA))

    for i in range(len(FIEME1TA)):
        FIEME1TA[i] = FIEME1TA[i]*10

    FIEME1TA[0] = FIEME1TA[0]/1000
    FIEME1TA[12] = FIEME1TA[12]/10

    FIEME1TA_arr = np.array(FIEME1TA)

    for i in range(len(FIEME1TA)):
        FIEME1TA[i] = float(FIEME1TA[i])

print("COMPOSIZIONE CHIMICA dell'alimento <FIENO MEDICA I TAGLIO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % FIEME1TA_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % FIEME1TA_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % FIEME1TA_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % FIEME1TA_arr[3])
print("Fibra Grezza (FG) => %f g" % FIEME1TA_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % FIEME1TA_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % FIEME1TA_arr[6])
print("FAT (Grasso) => %f g" % FIEME1TA_arr[7])
print("AM (Amido) => %f g" % FIEME1TA_arr[8])
print("ZUC (Zuccheri) => %f g" % FIEME1TA_arr[9])
print("Ca (Calcio) => %f g" % FIEME1TA_arr[10])
print("P (Fosforo) => %f g" % FIEME1TA_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % FIEME1TA_arr[12])
print('')

# sio.sFIEME1TAemat('FIEME1TA.mat', {'vect':FIEME1TA})
