# importa_MySQLdb_fieno_prato_stabile_II_taglio.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    fieno_prato_stabile_II_taglio = []

    for i in parametri:
        i = "SELECT %s FROM Foraggio WHERE nome = 'fieno_prato_stabile_II_taglio'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        fieno_prato_stabile_II_taglio.append(float(i[0]))
#   print(FIEPRASTA2TA)

    FIEPRASTA2TA = list(np.float_(fieno_prato_stabile_II_taglio))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <fieno_prato_stabile_II_taglio> dal modulo <Foraggio>') 
    from Foraggio import fieno_prato_stabile_II_taglio
    print('<fieno_prato_stabile_II_taglio> importato con successo dal modulo <Foraggio>!')

    FIEPRASTA2TA = list(np.float_(fieno_prato_stabile_II_taglio))

    del FIEPRASTA2TA[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del FIEPRASTA2TA[10]
# elimino 'ceneri'

    del FIEPRASTA2TA[13:17]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <FIEPRASTA2TA> => %d' % len(FIEPRASTA2TA))

    for i in range(len(FIEPRASTA2TA)):
        FIEPRASTA2TA[i] = FIEPRASTA2TA[i]*10

    FIEPRASTA2TA[0] = FIEPRASTA2TA[0]/1000
    FIEPRASTA2TA[12] = FIEPRASTA2TA[12]/10

    FIEPRASTA2TA_arr = np.array(FIEPRASTA2TA)

    for i in range(len(FIEPRASTA2TA)):
        FIEPRASTA2TA[i] = float(FIEPRASTA2TA[i])

print("COMPOSIZIONE CHIMICA dell'alimento <FIENO PRATO STABILE II TAGLIO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % FIEPRASTA2TA_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % FIEPRASTA2TA_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % FIEPRASTA2TA_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % FIEPRASTA2TA_arr[3])
print("Fibra Grezza (FG) => %f g" % FIEPRASTA2TA_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % FIEPRASTA2TA_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % FIEPRASTA2TA_arr[6])
print("FAT (Grasso) => %f g" % FIEPRASTA2TA_arr[7])
print("AM (Amido) => %f g" % FIEPRASTA2TA_arr[8])
print("ZUC (Zuccheri) => %f g" % FIEPRASTA2TA_arr[9])
print("Ca (Calcio) => %f g" % FIEPRASTA2TA_arr[10])
print("P (Fosforo) => %f g" % FIEPRASTA2TA_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % FIEPRASTA2TA_arr[12])
print('')

# sio.sFIEPRASTA2TAemat('FIEPRASTA2TA.mat', {'vect':FIEPRASTA2TA})
