# importa_MySQLdb_girasole_farina_estrazione_34x100.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    girasole_farina_estrazione_34x100 = []

    for i in parametri:
        i = "SELECT %s FROM Farina_di_estrazione WHERE nome = 'girasole_farina_estrazione_34x100'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        girasole_farina_estrazione_34x100.append(float(i[0]))
#   print(GIRFAESTR34)

    GIRFAESTR34 = list(np.float_(girasole_farina_estrazione_34x100))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <girasole_farina_estrazione_34x100> dal modulo <Farina_di_estrazione>') 
    from Farina_di_estrazione import girasole_farina_estrazione_34x100
    print('<girasole_farina_estrazione_34x100> importato con successo dal modulo <Farina_di_estrazione>!')

    GIRFAESTR34 = list(np.float_(girasole_farina_estrazione_34x100))

    del GIRFAESTR34[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del GIRFAESTR34[10]
# elimino 'ceneri'

    del GIRFAESTR34[13:17]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <GIRFAESTR34> => %d' % len(GIRFAESTR34))

    for i in range(len(GIRFAESTR34)):
        GIRFAESTR34[i] = GIRFAESTR34[i]*10

    GIRFAESTR34[0] = GIRFAESTR34[0]/1000
    GIRFAESTR34[12] = GIRFAESTR34[12]/10

    GIRFAESTR34_arr = np.array(GIRFAESTR34)

    for i in range(len(GIRFAESTR34)):
        GIRFAESTR34[i] = float(GIRFAESTR34[i])

print("COMPOSIZIONE CHIMICA dell'alimento <FARINA DI ESTRAZIONE DI GIRASOLE 34%>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % GIRFAESTR34_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % GIRFAESTR34_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % GIRFAESTR34_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % GIRFAESTR34_arr[3])
print("Fibra Grezza (FG) => %f g" % GIRFAESTR34_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % GIRFAESTR34_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % GIRFAESTR34_arr[6])
print("FAT (Grasso) => %f g" % GIRFAESTR34_arr[7])
print("AM (Amido) => %f g" % GIRFAESTR34_arr[8])
print("ZUC (Zuccheri) => %f g" % GIRFAESTR34_arr[9])
print("Ca (Calcio) => %f g" % GIRFAESTR34_arr[10])
print("P (Fosforo) => %f g" % GIRFAESTR34_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % GIRFAESTR34_arr[12])
print('')

# sio.sGIRFAESTR34emat('GIRFAESTR34.mat', {'vect':GIRFAESTR34})
