# importa_MySQLdb_girasole_farina_estrazione_34x100_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
    girasole_farina_estrazione_34x100 = []

    for i in parametri:
        i = "SELECT %s FROM Farina_di_estrazione_Lys_Met WHERE nome = 'girasole_farina_estrazione_34x100'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        girasole_farina_estrazione_34x100.append(float(i[0]))
#   print(girasole_farina_estrazione_34x100)

    GIRFAESTR34 = list(np.float_(girasole_farina_estrazione_34x100))

except mysql.connector.Error as err:
  print("Server non raggiungibile: {}".format(err))
  print('Provo ad importare <girasole_farina_estrazione_34x100> dal modulo <farina_di_estrazione_LYS_MET>') 
  from farina_di_estrazione_LYS_MET import girasole_farina_estrazione_34x100
  print('<girasole_farina_estrazione_34x100> importato con successo dal modulo <farina_di_estrazione_LYS_MET>!')

GIRFAESTR34 = list(np.float_(girasole_farina_estrazione_34x100))

del GIRFAESTR34[10]
del GIRFAESTR34[12:16]
del GIRFAESTR34[12]
del GIRFAESTR34[13]

GIRFAESTR34[0] = GIRFAESTR34[0]/100

for i in list(range(1, 12)):
	GIRFAESTR34[i] = GIRFAESTR34[i]*10

GIRFAESTR34[16] = GIRFAESTR34[16]*GIRFAESTR34[15]/100
GIRFAESTR34[17] = GIRFAESTR34[17]*GIRFAESTR34[15]/100

del GIRFAESTR34[13]
# elimina Mj

del GIRFAESTR34[2:4]
# elimina RDP e RUP

PDIE_GIRFAESTR34 = GIRFAESTR34[12]
LysDI_GIRFAESTR34 = GIRFAESTR34[13]
MetDI_GIRFAESTR34 = GIRFAESTR34[14]

LysDI_MetDI_ratio = LysDI_GIRFAESTR34/MetDI_GIRFAESTR34

GIRFAESTR34_mod = GIRFAESTR34[0:12]
GIRFAESTR34_arr = np.array(GIRFAESTR34_mod)

for i in range(len(GIRFAESTR34_mod)):
    GIRFAESTR34_mod[i] = float(GIRFAESTR34_mod[i])

print('')
print("COMPOSIZIONE CHIMICA dell'alimento <GIRASOLE FARINA DI ESTRAZIONE 34x100>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % GIRFAESTR34_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % GIRFAESTR34_arr[1])
print("Fibra Grezza (FG) => %f g" % GIRFAESTR34_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % GIRFAESTR34_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % GIRFAESTR34_arr[4])
print("FAT (Grasso) => %f g" % GIRFAESTR34_arr[5])
print("AM (Amido) => %f g" % GIRFAESTR34_arr[6])
print("ZUC (Zuccheri) => %f g" % GIRFAESTR34_arr[7])
print("Ca (Calcio) => %f g" % GIRFAESTR34_arr[8])
print("P (Fosforo) => %f g" % GIRFAESTR34_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % GIRFAESTR34_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % GIRFAESTR34_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.sGIRFAESTR34emat('GIRFAESTR34.mat', {'vect':GIRFAESTR34})
