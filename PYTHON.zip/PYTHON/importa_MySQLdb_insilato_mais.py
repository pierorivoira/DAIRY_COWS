# importa_MySQLdb_insilato_mais.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    insilato_mais = []

    for i in parametri:
        i = "SELECT %s FROM Foraggio WHERE nome = 'insilato_mais'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        insilato_mais.append(float(i[0]))
#   print(INSIMA)

    INSIMA = list(np.float_(insilato_mais))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <insilato_mais> dal modulo <Foraggio>') 
    from Foraggio import insilato_mais
    print('<insilato_mais> importato con successo dal modulo <Foraggio>!')

    INSIMA = list(np.float_(insilato_mais))

    del INSIMA[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del INSIMA[10]
# elimino 'ceneri'

    del INSIMA[13:17]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <INSIMA> => %d' % len(INSIMA))

    for i in range(len(INSIMA)):
        INSIMA[i] = INSIMA[i]*10

    INSIMA[0] = INSIMA[0]/1000
    INSIMA[12] = INSIMA[12]/10

    INSIMA_arr = np.array(INSIMA)

    for i in range(len(INSIMA)):
        INSIMA[i] = float(INSIMA[i])

print("COMPOSIZIONE CHIMICA dell'alimento <INSILATO DI MAIS>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % INSIMA_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % INSIMA_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % INSIMA_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % INSIMA_arr[3])
print("Fibra Grezza (FG) => %f g" % INSIMA_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % INSIMA_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % INSIMA_arr[6])
print("FAT (Grasso) => %f g" % INSIMA_arr[7])
print("AM (Amido) => %f g" % INSIMA_arr[8])
print("ZUC (Zuccheri) => %f g" % INSIMA_arr[9])
print("Ca (Calcio) => %f g" % INSIMA_arr[10])
print("P (Fosforo) => %f g" % INSIMA_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % INSIMA_arr[12])
print('')

# sio.sINSIMAemat('INSIMA.mat', {'vect':INSIMA})
