# importa_MySQLdb_latte_siero.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    latte_siero = []

    for i in parametri:
        i = "SELECT %s FROM Sottoprodotto WHERE nome = 'latte_siero'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        latte_siero.append(float(i[0]))
#   print(LATSIE)

    LATSIE = list(np.float_(latte_siero))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <latte_siero> dal modulo <Sottoprodotto>') 
    from Sottoprodotto import latte_siero
    print('<latte_siero> importato con successo dal modulo <Sottoprodotto>!')

    LATSIE = list(np.float_(latte_siero))

    del LATSIE[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del LATSIE[10]
# elimino 'ceneri'

    del LATSIE[13:17]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <LATSIE> => %d' % len(LATSIE))

    for i in range(len(LATSIE)):
        LATSIE[i] = LATSIE[i]*10

    LATSIE[0] = LATSIE[0]/1000
    LATSIE[12] = LATSIE[12]/10

    LATSIE_arr = np.array(LATSIE)

    for i in range(len(LATSIE)):
        LATSIE[i] = float(LATSIE[i])

print("COMPOSIZIONE CHIMICA dell'alimento <SIERO DI LATTE>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % LATSIE_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % LATSIE_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % LATSIE_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % LATSIE_arr[3])
print("Fibra Grezza (FG) => %f g" % LATSIE_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % LATSIE_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % LATSIE_arr[6])
print("FAT (Grasso) => %f g" % LATSIE_arr[7])
print("AM (Amido) => %f g" % LATSIE_arr[8])
print("ZUC (Zuccheri) => %f g" % LATSIE_arr[9])
print("Ca (Calcio) => %f g" % LATSIE_arr[10])
print("P (Fosforo) => %f g" % LATSIE_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % LATSIE_arr[12])
print('')

# sio.sLATSIEemat('LATSIE.mat', {'vect':LATSIE})
