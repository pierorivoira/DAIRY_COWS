# importa_MySQLdb_lupino_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
    lupino = []

    for i in parametri:
        i = "SELECT %s FROM Leguminosa_Lys_Met WHERE nome = 'lupino'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        lupino.append(float(i[0]))
#   print(lupino)

    LU = list(np.float_(lupino))

except mysql.connector.Error as err:
  print("Server non raggiungibile: {}".format(err))
  print('Provo ad importare <lupino> dal modulo <leguminosa_LYS_MET>') 
  from leguminosa_LYS_MET import lupino
  print('<lupino> importato con successo dal modulo <leguminosa_LYS_MET>!')

LU = list(np.float_(lupino))

del LU[10]
del LU[12:16]
del LU[12]
del LU[13]
LU[0] = LU[0]/100

for i in list(range(1, 12)):
	LU[i] = LU[i]*10

LU[16] = LU[16]*LU[15]/100
LU[17] = LU[17]*LU[15]/100

del LU[13]
# elimina Mj

del LU[2:4]
# elimina RDP e RUP

PDIE_LU = LU[12]
LysDI_LU = LU[13]
MetDI_LU = LU[14]

LysDI_MetDI_ratio = LysDI_LU/MetDI_LU

LU_mod = LU[0:12]
LU_arr = np.array(LU_mod)

for i in range(len(LU_mod)):
    LU_mod[i] = float(LU_mod[i])

print('')
print("COMPOSIZIONE CHIMICA dell'alimento <LUPINO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % LU_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % LU_arr[1])
print("Fibra Grezza (FG) => %f g" % LU_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % LU_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % LU_arr[4])
print("FAT (Grasso) => %f g" % LU_arr[5])
print("AM (Amido) => %f g" % LU_arr[6])
print("ZUC (Zuccheri) => %f g" % LU_arr[7])
print("Ca (Calcio) => %f g" % LU_arr[8])
print("P (Fosforo) => %f g" % LU_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % LU_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % LU_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.sLUemat('LU.mat', {'vect':LU})
