# importa_MySQLdb_mais_granella.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    mais_granella = []

    for i in parametri:
        i = "SELECT %s FROM Cereale WHERE nome = 'mais_granella'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        mais_granella.append(float(i[0]))
#   print(MAISGRA)

    MAISGRA = list(np.float_(mais_granella))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <mais_granella> dal modulo <Cereale>') 
    from Cereale import mais_granella
    print('<mais_granella> importato con successo dal modulo <Cereale>!')

    MAISGRA = list(np.float_(mais_granella))

    del MAISGRA[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del MAISGRA[10]
# elimino 'ceneri'

    del MAISGRA[13:17]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <MAISGRA> => %d' % len(MAISGRA))

    for i in range(len(MAISGRA)):
        MAISGRA[i] = MAISGRA[i]*10

    MAISGRA[0] = MAISGRA[0]/1000
    MAISGRA[12] = MAISGRA[12]/10

    MAISGRA_arr = np.array(MAISGRA)

    for i in range(len(MAISGRA)):
        MAISGRA[i] = float(MAISGRA[i])

print("COMPOSIZIONE CHIMICA dell'alimento <MAIS GRANELLA>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % MAISGRA_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % MAISGRA_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % MAISGRA_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % MAISGRA_arr[3])
print("Fibra Grezza (FG) => %f g" % MAISGRA_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % MAISGRA_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % MAISGRA_arr[6])
print("FAT (Grasso) => %f g" % MAISGRA_arr[7])
print("AM (Amido) => %f g" % MAISGRA_arr[8])
print("ZUC (Zuccheri) => %f g" % MAISGRA_arr[9])
print("Ca (Calcio) => %f g" % MAISGRA_arr[10])
print("P (Fosforo) => %f g" % MAISGRA_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % MAISGRA_arr[12])
print('')

# sio.sMAISGRAemat('MAISGRA.mat', {'vect':MAISGRA})
