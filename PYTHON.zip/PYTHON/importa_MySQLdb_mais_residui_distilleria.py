# importa_MySQLdb_mais_residui_distilleria.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    mais_residui_distilleria = []

    for i in parametri:
        i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'mais_residui_distilleria'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        mais_residui_distilleria.append(float(i[0]))
#   print(MAISDIST)

    MAISDIST = list(np.float_(mais_residui_distilleria))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <mais_residui_distilleria> dal modulo <Fonte_di_fibra>') 
    from Fonte_di_fibra import mais_residui_distilleria
    print('<mais_residui_distilleria> importato con successo dal modulo <Fonte_di_fibra>!')

    MAISDIST = list(np.float_(mais_residui_distilleria))

    del MAISDIST[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del MAISDIST[10]
# elimino 'ceneri'

    del MAISDIST[13:17]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <MAISDIST> => %d' % len(MAISDIST))

    for i in range(len(MAISDIST)):
        MAISDIST[i] = MAISDIST[i]*10

    MAISDIST[0] = MAISDIST[0]/1000
    MAISDIST[12] = MAISDIST[12]/10

    MAISDIST_arr = np.array(MAISDIST)

    for i in range(len(MAISDIST)):
        MAISDIST[i] = float(MAISDIST[i])

print("COMPOSIZIONE CHIMICA dell'alimento <MAIS RESIDUI DI DISTILLERIA>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % MAISDIST_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % MAISDIST_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % MAISDIST_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % MAISDIST_arr[3])
print("Fibra Grezza (FG) => %f g" % MAISDIST_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % MAISDIST_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % MAISDIST_arr[6])
print("FAT (Grasso) => %f g" % MAISDIST_arr[7])
print("AM (Amido) => %f g" % MAISDIST_arr[8])
print("ZUC (Zuccheri) => %f g" % MAISDIST_arr[9])
print("Ca (Calcio) => %f g" % MAISDIST_arr[10])
print("P (Fosforo) => %f g" % MAISDIST_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % MAISDIST_arr[12])
print('')

# sio.sMAISDISTemat('MAISDIST.mat', {'vect':MAISDIST})
