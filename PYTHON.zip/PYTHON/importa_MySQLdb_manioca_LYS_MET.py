# importa_MySQLdb_manioca_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
    manioca = []

    for i in parametri:
        i = "SELECT %s FROM Sottoprodotto_Lys_Met WHERE nome = 'manioca'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        manioca.append(float(i[0]))
#   print(manioca)

    MANIO = list(np.float_(manioca))

except mysql.connector.Error as err:
  print("Server non raggiungibile: {}".format(err))
  print('Provo ad importare <manioca> dal modulo <sottoprodotto_LYS_MET>') 
  from sottoprodotto_LYS_MET import manioca
  print('<manioca> importato con successo dal modulo <sottoprodotto_LYS_MET>!')

MANIO = list(np.float_(manioca))

del MANIO[10]
del MANIO[12:16]
del MANIO[12]
del MANIO[13]

MANIO[0] = MANIO[0]/100

for i in list(range(1, 12)):
	MANIO[i] = MANIO[i]*10

MANIO[16] = MANIO[16]*MANIO[15]/100
MANIO[17] = MANIO[17]*MANIO[15]/100

del MANIO[13]
# elimina Mj

del MANIO[2:4]
# elimina RDP e RUP

PDIE_MANIO = MANIO[12]
LysDI_MANIO = MANIO[13]
MetDI_MANIO = MANIO[14]

LysDI_MetDI_ratio = LysDI_MANIO/MetDI_MANIO

MANIO_mod = MANIO[0:12]
MANIO_arr = np.array(MANIO_mod)

for i in range(len(MANIO_mod)):
    MANIO_mod[i] = float(MANIO_mod[i])

print('')
print("COMPOSIZIONE CHIMICA dell'alimento <MANIOCA>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % MANIO_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % MANIO_arr[1])
print("Fibra Grezza (FG) => %f g" % MANIO_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % MANIO_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % MANIO_arr[4])
print("FAT (Grasso) => %f g" % MANIO_arr[5])
print("AM (Amido) => %f g" % MANIO_arr[6])
print("ZUC (Zuccheri) => %f g" % MANIO_arr[7])
print("Ca (Calcio) => %f g" % MANIO_arr[8])
print("P (Fosforo) => %f g" % MANIO_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % MANIO_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % MANIO_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.sMANIOemat('MANIO.mat', {'vect':MANIO})
