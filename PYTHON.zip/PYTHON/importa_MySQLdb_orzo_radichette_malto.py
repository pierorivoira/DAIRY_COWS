# importa_MySQLdb_orzo_radichette_malto.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    orzo_radichette_malto = []

    for i in parametri:
        i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'orzo_radichette_malto'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        orzo_radichette_malto.append(float(i[0]))
#   print(ORRADMAL)

    ORRADMAL = list(np.float_(orzo_radichette_malto))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <orzo_radichette_malto> dal modulo <Fonte_di_fibra>') 
    from Fonte_di_fibra import  orzo_radichette_malto
    print('<orzo_radichette_malto> importato con successo dal modulo <Fonte_di_fibra>!')

    ORRADMAL = list(np.float_(orzo_radichette_malto))

    del ORRADMAL[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del ORRADMAL[10]
# elimino 'ceneri'

    del ORRADMAL[13:17]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <ORRADMAL> => %d' % len(ORRADMAL))

    for i in range(len(ORRADMAL)):
        ORRADMAL[i] = ORRADMAL[i]*10

    ORRADMAL[0] = ORRADMAL[0]/1000
    ORRADMAL[12] = ORRADMAL[12]/10

    ORRADMAL_arr = np.array(ORRADMAL)

    for i in range(len(ORRADMAL)):
        ORRADMAL[i] = float(ORRADMAL[i])

print("COMPOSIZIONE CHIMICA dell'alimento <RADICHETTE DI MALTO D'ORZO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % ORRADMAL_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % ORRADMAL_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % ORRADMAL_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % ORRADMAL_arr[3])
print("Fibra Grezza (FG) => %f g" % ORRADMAL_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % ORRADMAL_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % ORRADMAL_arr[6])
print("FAT (Grasso) => %f g" % ORRADMAL_arr[7])
print("AM (Amido) => %f g" % ORRADMAL_arr[8])
print("ZUC (Zuccheri) => %f g" % ORRADMAL_arr[9])
print("Ca (Calcio) => %f g" % ORRADMAL_arr[10])
print("P (Fosforo) => %f g" % ORRADMAL_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % ORRADMAL_arr[12])
print('')

# sio.sORRADMALemat('ORRADMAL.mat', {'vect':ORRADMAL})
