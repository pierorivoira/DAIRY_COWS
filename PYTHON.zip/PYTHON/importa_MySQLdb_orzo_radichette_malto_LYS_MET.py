# importa_MySQLdb_orzo_radichette_malto_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
    orzo_radichette_malto = []

    for i in parametri:
        i = "SELECT %s FROM Fonte_di_fibra_Lys_Met WHERE nome = 'orzo_radichette_malto'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        orzo_radichette_malto.append(float(i[0]))
#   print(orzo_radichette_malto)

    ORRADMAL = list(np.float_(orzo_radichette_malto))

except mysql.connector.Error as err:
  print("Server non raggiungibile: {}".format(err))
  print('Provo ad importare <orzo_radichette_malto> dal modulo <fonte_di_fibra_LYS_MET>') 
  from fonte_di_fibra_LYS_MET import orzo_radichette_malto
  print('<orzo_radichette_malto> importato con successo dal modulo <fonte_di_fibra_LYS_MET>!')

ORRADMAL = list(np.float_(orzo_radichette_malto))

del ORRADMAL[10]
del ORRADMAL[12:16]
del ORRADMAL[12]
del ORRADMAL[13]

ORRADMAL[0] = ORRADMAL[0]/100

for i in list(range(1, 12)):
	ORRADMAL[i] = ORRADMAL[i]*10

ORRADMAL[16] = ORRADMAL[16]*ORRADMAL[15]/100
ORRADMAL[17] = ORRADMAL[17]*ORRADMAL[15]/100

del ORRADMAL[13]
# elimina Mj

del ORRADMAL[2:4]
# elimina RDP e RUP

PDIE_ORRADMAL = ORRADMAL[12]
LysDI_ORRADMAL = ORRADMAL[13]
MetDI_ORRADMAL = ORRADMAL[14]

LysDI_MetDI_ratio = LysDI_ORRADMAL/MetDI_ORRADMAL

ORRADMAL_mod = ORRADMAL[0:12]
ORRADMAL_arr = np.array(ORRADMAL_mod)

for i in range(len(ORRADMAL_mod)):
    ORRADMAL_mod[i] = float(ORRADMAL_mod[i])

print('')
print("COMPOSIZIONE CHIMICA dell'alimento <ORZO RADICHETTE DI MALTO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % ORRADMAL_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % ORRADMAL_arr[1])
print("Fibra Grezza (FG) => %f g" % ORRADMAL_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % ORRADMAL_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % ORRADMAL_arr[4])
print("FAT (Grasso) => %f g" % ORRADMAL_arr[5])
print("AM (Amido) => %f g" % ORRADMAL_arr[6])
print("ZUC (Zuccheri) => %f g" % ORRADMAL_arr[7])
print("Ca (Calcio) => %f g" % ORRADMAL_arr[8])
print("P (Fosforo) => %f g" % ORRADMAL_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % ORRADMAL_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % ORRADMAL_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.sORRADMALemat('ORRADMAL.mat', {'vect':ORRADMAL})
