# importa_MySQLdb_orzo_trebbie_birra_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
    orzo_trebbie_birra = []

    for i in parametri:
        i = "SELECT %s FROM Fonte_di_fibra_Lys_Met WHERE nome = 'orzo_trebbie_birra'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        orzo_trebbie_birra.append(float(i[0]))
#   print(orzo_trebbie_birra)

    ORTREBIR = list(np.float_(orzo_trebbie_birra))

except mysql.connector.Error as err:
  print("Server non raggiungibile: {}".format(err))
  print('Provo ad importare <orzo_trebbie_birra> dal modulo <fonte_di_fibra_LYS_MET>') 
  from fonte_di_fibra_LYS_MET import orzo_trebbie_birra
  print('<orzo_trebbie_birra> importato con successo dal modulo <fonte_di_fibra_LYS_MET>!')

ORTREBIR = list(np.float_(orzo_trebbie_birra))

del ORTREBIR[10]
del ORTREBIR[12:16]
del ORTREBIR[12]
del ORTREBIR[13]

ORTREBIR[0] = ORTREBIR[0]/100

for i in list(range(1, 12)):
	ORTREBIR[i] = ORTREBIR[i]*10

ORTREBIR[16] = ORTREBIR[16]*ORTREBIR[15]/100
ORTREBIR[17] = ORTREBIR[17]*ORTREBIR[15]/100

del ORTREBIR[13]
# elimina Mj

del ORTREBIR[2:4]
# elimina RDP e RUP

PDIE_ORTREBIR = ORTREBIR[12]
LysDI_ORTREBIR = ORTREBIR[13]
MetDI_ORTREBIR = ORTREBIR[14]

LysDI_MetDI_ratio = LysDI_ORTREBIR/MetDI_ORTREBIR

ORTREBIR_mod = ORTREBIR[0:12]
ORTREBIR_arr = np.array(ORTREBIR_mod)

for i in range(len(ORTREBIR_mod)):
    ORTREBIR_mod[i] = float(ORTREBIR_mod[i])

print('')
print("COMPOSIZIONE CHIMICA dell'alimento <ORZO TREBBIE DI BIRRA>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % ORTREBIR_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % ORTREBIR_arr[1])
print("Fibra Grezza (FG) => %f g" % ORTREBIR_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % ORTREBIR_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % ORTREBIR_arr[4])
print("FAT (Grasso) => %f g" % ORTREBIR_arr[5])
print("AM (Amido) => %f g" % ORTREBIR_arr[6])
print("ZUC (Zuccheri) => %f g" % ORTREBIR_arr[7])
print("Ca (Calcio) => %f g" % ORTREBIR_arr[8])
print("P (Fosforo) => %f g" % ORTREBIR_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % ORTREBIR_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % ORTREBIR_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.sORTREBIRemat('ORTREBIR.mat', {'vect':ORTREBIR})
