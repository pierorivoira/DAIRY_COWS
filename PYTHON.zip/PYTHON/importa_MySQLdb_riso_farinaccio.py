# importa_MySQLdb_riso_gemma.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    riso_gemma = []

    for i in parametri:
        i = "SELECT %s FROM Sottoprodotto WHERE nome = 'riso_gemma'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        riso_gemma.append(float(i[0]))
#   print(RIGEMMA)

    RIGEMMA = list(np.float_(riso_gemma))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <riso_gemma> dal modulo <Sottoprodotto>') 
    from Sottoprodotto import  riso_gemma
    print('<riso_gemma> importato con successo dal modulo <Sottoprodotto>!')

    RIGEMMA = list(np.float_(riso_gemma))

    del RIGEMMA[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del RIGEMMA[10]
# elimino 'ceneri'

    del RIGEMMA[13:17]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <RIGEMMA> => %d' % len(RIGEMMA))

    for i in range(len(RIGEMMA)):
        RIGEMMA[i] = RIGEMMA[i]*10

    RIGEMMA[0] = RIGEMMA[0]/1000
    RIGEMMA[12] = RIGEMMA[12]/10

    RIGEMMA_arr = np.array(RIGEMMA)

    for i in range(len(RIGEMMA)):
        RIGEMMA[i] = float(RIGEMMA[i])

print("COMPOSIZIONE CHIMICA dell'alimento <GEMMA DI RISO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % RIGEMMA_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % RIGEMMA_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % RIGEMMA_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % RIGEMMA_arr[3])
print("Fibra Grezza (FG) => %f g" % RIGEMMA_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % RIGEMMA_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % RIGEMMA_arr[6])
print("FAT (Grasso) => %f g" % RIGEMMA_arr[7])
print("AM (Amido) => %f g" % RIGEMMA_arr[8])
print("ZUC (Zuccheri) => %f g" % RIGEMMA_arr[9])
print("Ca (Calcio) => %f g" % RIGEMMA_arr[10])
print("P (Fosforo) => %f g" % RIGEMMA_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % RIGEMMA_arr[12])
print('')

# sio.sRIGEMMAemat('RIGEMMA.mat', {'vect':RIGEMMA})
