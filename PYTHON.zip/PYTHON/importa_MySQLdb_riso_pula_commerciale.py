# importa_MySQLdb_riso_pula_commerciale.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    riso_pula_commerciale = []

    for i in parametri:
        i = "SELECT %s FROM Sottoprodotto WHERE nome = 'riso_pula_commerciale'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        riso_pula_commerciale.append(float(i[0]))
#   print(RISPUCOM)

    RISPUCOM = list(np.float_(riso_pula_commerciale))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <riso_pula_commerciale> dal modulo <Sottoprodotto>') 
    from Sottoprodotto import  riso_pula_commerciale
    print('<riso_pula_commerciale> importato con successo dal modulo <Sottoprodotto>!')

    RISPUCOM = list(np.float_(riso_pula_commerciale))

    del RISPUCOM[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del RISPUCOM[10]
# elimino 'ceneri'

    del RISPUCOM[13:17]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <RISPUCOM> => %d' % len(RISPUCOM))

    for i in range(len(RISPUCOM)):
        RISPUCOM[i] = RISPUCOM[i]*10

    RISPUCOM[0] = RISPUCOM[0]/1000
    RISPUCOM[12] = RISPUCOM[12]/10

    RISPUCOM_arr = np.array(RISPUCOM)

    for i in range(len(RISPUCOM)):
        RISPUCOM[i] = float(RISPUCOM[i])

print("COMPOSIZIONE CHIMICA dell'alimento <PULA COMMERCIALE DI RISO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % RISPUCOM_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % RISPUCOM_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % RISPUCOM_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % RISPUCOM_arr[3])
print("Fibra Grezza (FG) => %f g" % RISPUCOM_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % RISPUCOM_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % RISPUCOM_arr[6])
print("FAT (Grasso) => %f g" % RISPUCOM_arr[7])
print("AM (Amido) => %f g" % RISPUCOM_arr[8])
print("ZUC (Zuccheri) => %f g" % RISPUCOM_arr[9])
print("Ca (Calcio) => %f g" % RISPUCOM_arr[10])
print("P (Fosforo) => %f g" % RISPUCOM_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % RISPUCOM_arr[12])
print('')

# sio.sRISPUCOMemat('RISPUCOM.mat', {'vect':RISPUCOM})
