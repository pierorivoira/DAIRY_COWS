# importa_MySQLdb_riso_pula_commerciale_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
    riso_pula_commerciale = []

    for i in parametri:
        i = "SELECT %s FROM Sottoprodotto_Lys_Met WHERE nome = 'riso_pula_commerciale'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        riso_pula_commerciale.append(float(i[0]))
#   print(riso_pula_commerciale)

    RISPUCOM = list(np.float_(riso_pula_commerciale))

except mysql.connector.Error as err:
  print("Server non raggiungibile: {}".format(err))
  print('Provo ad importare <riso_pula_commerciale> dal modulo <sottoprodotto_LYS_MET>') 
  from sottoprodotto_LYS_MET import riso_pula_commerciale
  print('<riso_pula_commerciale> importato con successo dal modulo <sottoprodotto_LYS_MET>!')

RISPUCOM = list(np.float_(riso_pula_commerciale))

del RISPUCOM[10]
del RISPUCOM[12:16]
del RISPUCOM[12]
del RISPUCOM[13]

RISPUCOM[0] = RISPUCOM[0]/100

for i in list(range(1, 12)):
	RISPUCOM[i] = RISPUCOM[i]*10

RISPUCOM[16] = RISPUCOM[16]*RISPUCOM[15]/100
RISPUCOM[17] = RISPUCOM[17]*RISPUCOM[15]/100

del RISPUCOM[13]
# elimina Mj

del RISPUCOM[2:4]
# elimina RDP e RUP

PDIE_RISPUCOM = RISPUCOM[12]
LysDI_RISPUCOM = RISPUCOM[13]
MetDI_RISPUCOM = RISPUCOM[14]

LysDI_MetDI_ratio = LysDI_RISPUCOM/MetDI_RISPUCOM

RISPUCOM_mod = RISPUCOM[0:12]
RISPUCOM_arr = np.array(RISPUCOM_mod)

for i in range(len(RISPUCOM_mod)):
    RISPUCOM_mod[i] = float(RISPUCOM_mod[i])

print('')
print("COMPOSIZIONE CHIMICA dell'alimento <RISO PULA COMMERCIALE>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % RISPUCOM_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % RISPUCOM_arr[1])
print("Fibra Grezza (FG) => %f g" % RISPUCOM_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % RISPUCOM_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % RISPUCOM_arr[4])
print("FAT (Grasso) => %f g" % RISPUCOM_arr[5])
print("AM (Amido) => %f g" % RISPUCOM_arr[6])
print("ZUC (Zuccheri) => %f g" % RISPUCOM_arr[7])
print("Ca (Calcio) => %f g" % RISPUCOM_arr[8])
print("P (Fosforo) => %f g" % RISPUCOM_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % RISPUCOM_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % RISPUCOM_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.sRISPUCOMemat('RISPUCOM.mat', {'vect':RISPUCOM})
