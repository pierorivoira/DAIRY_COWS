# importa_MySQLdb_riso_pula_vergine_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
    riso_pula_vergine = []

    for i in parametri:
        i = "SELECT %s FROM Sottoprodotto_Lys_Met WHERE nome = 'riso_pula_vergine'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        riso_pula_vergine.append(float(i[0]))
#   print(riso_pula_vergine)

    RISPUVER = list(np.float_(riso_pula_vergine))

except mysql.connector.Error as err:
  print("Server non raggiungibile: {}".format(err))
  print('Provo ad importare <riso_pula_vergine> dal modulo <sottoprodotto_LYS_MET>') 
  from sottoprodotto_LYS_MET import riso_pula_vergine
  print('<riso_pula_vergine> importato con successo dal modulo <sottoprodotto_LYS_MET>!')

RISPUVER = list(np.float_(riso_pula_vergine))

del RISPUVER[10]
del RISPUVER[12:16]
del RISPUVER[12]
del RISPUVER[13]

RISPUVER[0] = RISPUVER[0]/100

for i in list(range(1, 12)):
	RISPUVER[i] = RISPUVER[i]*10

RISPUVER[16] = RISPUVER[16]*RISPUVER[15]/100
RISPUVER[17] = RISPUVER[17]*RISPUVER[15]/100

del RISPUVER[13]
# elimina Mj

del RISPUVER[2:4]
# elimina RDP e RUP

PDIE_RISPUVER = RISPUVER[12]
LysDI_RISPUVER = RISPUVER[13]
MetDI_RISPUVER = RISPUVER[14]

LysDI_MetDI_ratio = LysDI_RISPUVER/MetDI_RISPUVER

RISPUVER_mod = RISPUVER[0:12]
RISPUVER_arr = np.array(RISPUVER_mod)

for i in range(len(RISPUVER_mod)):
    RISPUVER_mod[i] = float(RISPUVER_mod[i])

print('')
print("COMPOSIZIONE CHIMICA dell'alimento <RISO PULA VERGINE>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % RISPUVER_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % RISPUVER_arr[1])
print("Fibra Grezza (FG) => %f g" % RISPUVER_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % RISPUVER_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % RISPUVER_arr[4])
print("FAT (Grasso) => %f g" % RISPUVER_arr[5])
print("AM (Amido) => %f g" % RISPUVER_arr[6])
print("ZUC (Zuccheri) => %f g" % RISPUVER_arr[7])
print("Ca (Calcio) => %f g" % RISPUVER_arr[8])
print("P (Fosforo) => %f g" % RISPUVER_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % RISPUVER_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % RISPUVER_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.sRISPUVERemat('RISPUVER.mat', {'vect':RISPUVER})
