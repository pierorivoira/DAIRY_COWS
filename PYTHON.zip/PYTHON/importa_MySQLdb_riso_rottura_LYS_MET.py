# importa_MySQLdb_riso_rottura_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
    riso_rottura = []

    for i in parametri:
        i = "SELECT %s FROM Sottoprodotto_Lys_Met WHERE nome = 'riso_rottura'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        riso_rottura.append(float(i[0]))
#   print(riso_rottura)
    RIROTTU = list(np.float_(riso_rottura))

except mysql.connector.Error as err:
  print("Server non raggiungibile: {}".format(err))
  print('Provo ad importare <riso_rottura> dal modulo <sottoprodotto_LYS_MET>') 
  from sottoprodotto_LYS_MET import riso_rottura
  print('<riso_rottura> importato con successo dal modulo <sottoprodotto_LYS_MET>!')

RIROTTU = list(np.float_(riso_rottura))

del RIROTTU[10]
del RIROTTU[12:16]
del RIROTTU[12]
del RIROTTU[13]

RIROTTU[0] = RIROTTU[0]/100

for i in list(range(1, 12)):
	RIROTTU[i] = RIROTTU[i]*10

RIROTTU[16] = RIROTTU[16]*RIROTTU[15]/100
RIROTTU[17] = RIROTTU[17]*RIROTTU[15]/100

del RIROTTU[13]
# elimina Mj

del RIROTTU[2:4]
# elimina RDP e RUP

PDIE_RIROTTU = RIROTTU[12]
LysDI_RIROTTU = RIROTTU[13]
MetDI_RIROTTU = RIROTTU[14]

LysDI_MetDI_ratio = LysDI_RIROTTU/MetDI_RIROTTU

RIROTTU_mod = RIROTTU[0:12]
RIROTTU_arr = np.array(RIROTTU_mod)

for i in range(len(RIROTTU_mod)):
    RIROTTU_mod[i] = float(RIROTTU_mod[i])

print('')
print("COMPOSIZIONE CHIMICA dell'alimento <RISO ROTTURA>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % RIROTTU_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % RIROTTU_arr[1])
print("Fibra Grezza (FG) => %f g" % RIROTTU_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % RIROTTU_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % RIROTTU_arr[4])
print("FAT (Grasso) => %f g" % RIROTTU_arr[5])
print("AM (Amido) => %f g" % RIROTTU_arr[6])
print("ZUC (Zuccheri) => %f g" % RIROTTU_arr[7])
print("Ca (Calcio) => %f g" % RIROTTU_arr[8])
print("P (Fosforo) => %f g" % RIROTTU_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % RIROTTU_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % RIROTTU_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.sRIROTTUemat('RIROTTU.mat', {'vect':RIROTTU})
