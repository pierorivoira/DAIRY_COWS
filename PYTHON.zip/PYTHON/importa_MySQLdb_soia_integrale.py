# importa_MySQLdb_soia_integrale.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    soia_integrale = []

    for i in parametri:
        i = "SELECT %s FROM Leguminosa WHERE nome = 'soia_integrale'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        soia_integrale.append(float(i[0]))
#   print(SOIAIN)

    SOIAIN = list(np.float_(soia_integrale))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <soia_integrale> dal modulo <Leguminosa>') 
    from Leguminosa import  soia_integrale
    print('<soia_integrale> importato con successo dal modulo <Leguminosa>!')

    SOIAIN = list(np.float_(soia_integrale))

    del SOIAIN[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del SOIAIN[10]
# elimino 'ceneri'

    del SOIAIN[13:17]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <SOIAIN> => %d' % len(SOIAIN))

    for i in range(len(SOIAIN)):
        SOIAIN[i] = SOIAIN[i]*10

    SOIAIN[0] = SOIAIN[0]/1000
    SOIAIN[12] = SOIAIN[12]/10

    SOIAIN_arr = np.array(SOIAIN)

    for i in range(len(SOIAIN)):
        SOIAIN[i] = float(SOIAIN[i])

print("COMPOSIZIONE CHIMICA dell'alimento <SOIA INTEGRALE>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % SOIAIN_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % SOIAIN_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % SOIAIN_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % SOIAIN_arr[3])
print("Fibra Grezza (FG) => %f g" % SOIAIN_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % SOIAIN_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % SOIAIN_arr[6])
print("FAT (Grasso) => %f g" % SOIAIN_arr[7])
print("AM (Amido) => %f g" % SOIAIN_arr[8])
print("ZUC (Zuccheri) => %f g" % SOIAIN_arr[9])
print("Ca (Calcio) => %f g" % SOIAIN_arr[10])
print("P (Fosforo) => %f g" % SOIAIN_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % SOIAIN_arr[12])
print('')

# sio.sSOIAINemat('SOIAIN.mat', {'vect':SOIAIN})
