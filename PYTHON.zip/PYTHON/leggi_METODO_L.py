# leggi_METODO_L.py



### LINUX ###


import os, re
import numpy as np
from pathlib import Path

# import scipy.io as sio

global giorno_di_inserimento, data_di_inserimento, ora_di_inserimento, metodo, LW, WOL, MY, FAT_milk, CP_milk, LAC_milk, N_repl  

user = os.getlogin()
os.chdir('/home/%s/PYTHON/LINUX' % user)
cartella = os.getcwd()

if Path("%s.txt" % nome_file_parametri).exists():
    TESTO = open('%s.txt' % nome_file_parametri).read()
    if TESTO[20:27] == '_CNCPS_':
        metodo = '_CNCPS_'
    else:
        metodo = 'LYS_MET'
else:
    print('Non sono riuscito a trovare i PARAMETRI nella CARTELLA <%s>!' % cartella)
    print('Sicuro di averli inseriti?')
