# scrape_tables_Alessandria_L.py

# https://stackoverflow.com/questions/60377106/python3-module-tabula-has-no-attribute-read-pdf
# https://www.tutorialspoint.com/convert-pdf-to-csv-using-python
# https://www.codegrepper.com/code-examples/python/remove+first+instance+of+character+from+string+python
# https://towardsdatascience.com/how-to-show-all-columns-rows-of-a-pandas-dataframe-c49d4507fcf


### LINUX ###


import pandas as pd
import datetime, os
import fileinput, io, numpy, os, re, subprocess, sys, tabula
from tabula.io import read_pdf
from tabula import *
from dateutil.relativedelta import relativedelta
from contextlib import redirect_stdout

user = os.getlogin()
os.chdir('/home/%s/PYTHON/LINUX' % user)

last_year = (datetime.datetime.now()-relativedelta(years=1)).strftime('%Y')

os.system('wget http://images.al.camcom.gov.it/f/PriceLists/YA/ListinoAnnuale%s_1.pdf' % last_year)

# http://images.al.camcom.gov.it/f/PriceLists/YA/ListinoAnnuale2021_1.pdf

pd.set_option('display.max_columns', None)

df1 = tabula.io.read_pdf('ListinoAnnuale%s_1.pdf' % last_year, pages='all')[1]
df4 = tabula.io.read_pdf('ListinoAnnuale%s_1.pdf' % last_year, pages='all')[4]

prezzi_1 = df1.to_numpy()
prezzi_4 = df4.to_numpy()

LUPINO = prezzi_1[1]
MAIS_INSILATO = prezzi_4[10]
LOIETTO_INSILATO = prezzi_4[11]


prezzo_LUPINO = LUPINO[2][6:].replace(',','.')
prezzo_MAIS_INSILATO = MAIS_INSILATO[2][5:].replace(',','.')
prezzo_LOIETTO_INSILATO = LOIETTO_INSILATO[2][5:].replace(',','.')

# print("Prezzi medi dell'anno %s" % last_year)

print('Listino prezzi BORSA MERCI Alessandria creato con successo!')

with open('listino_prezzi_Alessandria.txt', 'w', encoding = "utf-8") as f:
    with redirect_stdout(f):
#       print("Prezzi medi riferiti all'anno %s" % last_year)
        print(prezzo_LUPINO)
        print(prezzo_MAIS_INSILATO)
        print(prezzo_LOIETTO_INSILATO) 
