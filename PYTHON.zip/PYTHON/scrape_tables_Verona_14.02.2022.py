# scrape_tables_Verona_14.02.2022.py

# https://stackoverflow.com/questions/60377106/python3-module-tabula-has-no-attribute-read-pdf
# https://www.tutorialspoint.com/convert-pdf-to-csv-using-python


### LINUX ### 


import pandas as pd
import fileinput, io, numpy, os, re, subprocess, sys, tabula
from tabula.io import read_pdf
from tabula import *
from datetime import date, datetime, timedelta


user = os.getlogin()
os.chdir('/home/%s/PYTHON/LINUX' % user)


import pandas as pd
import fileinput, io, numpy, os, re, subprocess, sys, tabula
from tabula.io import read_pdf
from tabula import *
from datetime import date, datetime, timedelta
os.chdir('/home/piero')
today = date.today()
offset = (today.weekday() - 0) % 7

import datetime

if datetime.datetime.today().weekday() == 0:
	last_Monday = today - timedelta(days=7)
	Monday = last_Monday
else:
	Monday = today - timedelta(days=offset)
	
data_aggiornamento_V = Monday.strftime('%d.%m.%Y')

# https://www.portaleprezziverona.it/camcom-verona/it/borsa-merci/rilevazione_borsa-merci_28_02_2022_28_02_2022.pdf
giorno_di_pubblicazione_V = Monday.strftime('%d_%m_%Y')
# url = 'https://www.portaleprezziverona.it/camcom-verona/it/borsa-merci/rilevazione_borsa-merci_%s_%s.pdf' % (giorno_di_pubblicazione_V, giorno_di_pubblicazione_V)
os.system('wget https://www.portaleprezziverona.it/camcom-verona/it/borsa-merci/rilevazione_borsa-merci_%s_%s.pdf' % (giorno_di_pubblicazione_V, giorno_di_pubblicazione_V))

# df22 = tabula.io.read_pdf('rilevazione_borsa-merci_%s_%s.pdf' % (giorno_di_pubblicazione_V, giorno_di_pubblicazione_V), pages='all')[22]
# NON FUNZIONA

df22 = tabula.io.read_pdf('rilevazione_borsa-merci_14_02_2022_14_02_2022.pdf', pages='all')[22]

prezzi_22 = df22.to_numpy()
COTONE = prezzi_22[5]

prezzo_COTONE_V = COTONE[3]



# print('Prezzi della Borsa di Verona aggiornati al %s' % data_aggiornamento_V)

print("BORSA MERCI DI Verona - Listino settimanale dei prezzi all'ingrosso aggiornato al 14.02.2022")

print(prezzo_COTONE_V)

# df22 => prezzo dei semi di cotone


  
