# crea_REPORT.py
# file modificato il 10.12.2022 per gestire l'eccezione della mancata importazione dei prezzi

from datetime import date, datetime
import matplotlib.pyplot as plt
from pathlib import Path
from reportlab.lib.pagesizes import A4, landscape, letter
from reportlab.platypus import Frame, PageTemplate, NextPageTemplate, Image, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
from reportlab.rl_config import defaultPageSize
from reportlab.lib import colors
from reportlab.lib.colors import red
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.pdfgen import canvas
import datetime, io, os, re, reportlab.lib.colors, sys, time
import numpy as np

global prezzi
prezzi = []

user = os.getlogin()
os.chdir('C:/Users/Alby/PYTHON_AL')



formatted_time = time.ctime()

print('Per favore inserisci il nome del FILE DI TESTO in cui hai salvato i PARAMETRI!')
nome_file_parametri = input()
if Path("PARAMETRI_PyR_%s.txt" % nome_file_parametri).exists():
    print("PARAMETRI letti dal file <PARAMETRI_PyR_%s.txt> con successo!" % nome_file_parametri)
    print('Inserisci il nome del FILE DI TESTO in cui hai salvato la RAZIONE')
    nome_file_razione = input()
    if Path("DATI_PyR_%s.py" % nome_file_razione).exists():
        print("DATI letti dal file <DATI_PyR_%s.py> con successo!" % nome_file_razione)
    else:
        print("Non ho trovato il file <DATI_PyR_%s.py>!" % nome_file_razione) 
    if Path("FABBISOGNI_PyR_%s.txt" % nome_file_razione).exists():
        print("FABBISOGNI letti dal file <FABBISOGNI_PyR_%s.txt> con successo!" % nome_file_razione)
    else:
        print("Non ho trovato il file <FABBISOGNI_PyR_%s.txt>!" % nome_file_razione)
    if Path("APPORTI_PyR_%s.txt" % nome_file_razione).exists():
        print("APPORTI letti dal file <APPORTI_PyR_%s.txt> con successo!" % nome_file_razione)
        print('Inserisci il nome del PDF in cui vuoi salvare il REPORT')
        nome_report_pdf = input()
        print("Il REPORT verrà salvato nel file <REPORT_PyR_%s.pdf>" % nome_report_pdf)
    else:
        print("Non ho trovato il file <APPORTI_PyR_%s.txt>!" % nome_file_razione)
        print("Interrompo l'esecuzione del PROGRAMMA!")
        print("Ciao")
        sys.exit(1)
    
    
else:
    print("Non ho trovato il file <PARAMETRI_PyR_%s.py>!" % nome_file_parametri)
    print("Devi prima CREARE UNA NUOVA RAZIONE!") 
    
try:
    src = 'C:/Users/Alby/PYTHON_AL/DATI_PyR_%s.py' % nome_file_razione
    dest = 'C:/Users/Alby/PYTHON_AL/fonte_dati.py'
except NameError:
    print('Non ho trovato alcuna RAZIONE!')
    print("Interrompo l'esecuzione del PROGRAMMA!")
    print("Ciao")
    sys.exit(1)


if Path("fonte_dati.py").exists():
    os.system("del fonte_dati.py") 

os.symlink(src, dest)



if Path("PARAMETRI_PyR_%s.txt" % nome_file_parametri).exists():
    print('PARAMETRI letti dal FILE DI TESTO <PARAMETRI_PyR_%s.txt> con successo!' % nome_file_parametri)
     
    TESTO_P = open('PARAMETRI_PyR_%s.txt' % nome_file_parametri).read()
    metodo = TESTO_P[20:27]
    Parametri_decimali = re.findall('[\d]*[.][\d]+', open('PARAMETRI_PyR_%s.txt' % nome_file_parametri).read())
    Parametri_interi = re.findall('\d+', open('PARAMETRI_PyR_%s.txt' % nome_file_parametri).read())
    data_di_inserimento = TESTO_P[0:10]
    ora_di_inserimento = TESTO_P[11:19]
    gruppo = TESTO_P[28]
    
    PARAMETRI_GENERALI = []
    PARAMETRI_GENERALI.append(metodo)

    
if TESTO_P[20:27] == '_CNCPS_':
    metodo = '_CNCPS_'
    LW = float(Parametri_decimali[0])
    WOL = int(Parametri_interi[8])
    MY = float(Parametri_decimali[1])
    FAT_milk = float(Parametri_decimali[2])
    CP_milk = float(Parametri_decimali[3])
    LAC_milk = float(Parametri_decimali[4])
    PREZZO_MAX = float(Parametri_decimali[5])
    N_repl = int(Parametri_interi[19])  
    
  
elif TESTO_P[20:27] == 'LYS_MET': 
    metodo = 'LYS_MET' 
    calf_weight = float(Parametri_decimali[0])
    LW = float(Parametri_decimali[1])
    cow_age = int(Parametri_interi[10])
    WOL = int(Parametri_interi[11])
    WOP = int(Parametri_interi[12])
    MY = float(Parametri_decimali[2])
    FAT_milk = float(Parametri_decimali[3])
    CP_milk = float(Parametri_decimali[4])
    LAC_milk = float(Parametri_decimali[5])
    PREZZO_MAX = float(Parametri_decimali[6])
    N_repl = int(Parametri_interi[23])
    ora_di_inserimento = TESTO_P[11:19]
    gruppo = TESTO_P[28]


if TESTO_P[30:33] == 'Mon':
    giorno_di_inserimento = 'Lunedì'
elif TESTO_P[30:33] == 'Tue':
    giorno_di_inserimento = 'Martedì'
elif TESTO_P[30:33] == 'Wed':
    giorno_di_inserimento = 'Mercoledì'
elif TESTO_P[30:33] == 'Thu':
    giorno_di_inserimento = 'Giovedì'
elif TESTO_P[30:33] == 'Fri':
    giorno_di_inserimento = 'Venerdì'
elif TESTO_P[30:33] == 'Sat':
    giorno_di_inserimento = 'Sabato'
elif TESTO_P[30:33] == 'Sun':
    giorno_di_inserimento = 'Domenica'



def alternate_orientations():
    doc = SimpleDocTemplate("REPORT_PyR_%s.pdf" % nome_report_pdf,
                            pagesize=A4,
                            rightMargin=36,
                            leftMargin=36,
                            topMargin=36,
                            bottomMargin=36)
    styles = getSampleStyleSheet()
    normal = styles["Normal"]

    margin = 0.5 * inch
    frame = Frame(margin, margin, doc.width, doc.height,
                  id='frame')
    portrait_template = PageTemplate(id='portrait',
                                     frames=[frame],
                                     pagesize=A4)
    landscape_template = PageTemplate(id='landscape',
                                      frames=[frame],
                                      pagesize=landscape(A4))
    doc.addPageTemplates([portrait_template, landscape_template])

    flowables = []
    



# Change back to portrait
#   flowables.append(NextPageTemplate('portrait'))
#   flowables.append(PageBreak())
#   flowables.append(Paragraph("Now we're back in portrait mode again", normal))

#   doc = SimpleDocTemplate("REPORT_PyR_%s.pdf" % nome_report_pdf, pagesize=A4)
    styles = getSampleStyleSheet()       
    
           
#   styles["Normal"].spaceBefore = 10
#   styles["Normal"].spaceAfter = 10
    
    spacer = Spacer(1, 1.0*inch)    
    logo = "carro_sfondo.png"
    im = Image(logo, 3*inch, 1.5*inch)
    
    flowables.append(im)


    text = "Benvenuto nel software <i>Programma Razione Python</i> (PyR) di Piero Rivoira"
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name='Centered', alignment=TA_CENTER))
    styles["Centered"].fontSize = 12
    styles["Centered"].leading = 14
    spacer = Spacer(1, 0.5*inch)
    flowables.append(spacer)
    flowables.append(Paragraph(text, styles["Centered"]))
    flowables.append(spacer)


    title = '<b>RAZIONE %s</b>' % nome_report_pdf
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name='Titolo', alignment=TA_CENTER))
    styles["Titolo"].fontSize = 26
    styles["Titolo"].leading = 14
    spacer = Spacer(1, 0.4*inch)
    flowables.append(Paragraph(title, styles["Titolo"]))
    flowables.append(spacer)

    
    styles["Normal"].fontSize = 16
    styles["Normal"].leading = 20
    
    DATA = formatted_time
    para = Paragraph(formatted_time, style=styles["Normal"])
    flowables.append(para)


    TESTO_P = 'PARAMETRI %s inseriti da %s, %s %s alle ore %s' % (nome_file_parametri, user, giorno_di_inserimento, data_di_inserimento, ora_di_inserimento)  
    para = Paragraph(TESTO_P, style=styles["Normal"])
    flowables.append(para)

   
    def arrotonda(float):
        return(round(float, 2))    



############################################################################################################################################################################
############################################################################# METODO <LYS_MET> #############################################################################
############################################################################################################################################################################



    if metodo == 'LYS_MET':


        testo = '<b>PARAMETRI_PyR_%s</b>' % nome_file_parametri
        styles = getSampleStyleSheet()
        styles.add(ParagraphStyle(name='Parametri', alignment=TA_CENTER))
        styles["Parametri"].fontSize = 18
        styles["Parametri"].leading = 14
        spacer = Spacer(1, 0.4*inch)
        flowables.append(spacer)
        flowables.append(Paragraph(testo, styles["Parametri"]))
        spacer = Spacer(1, 0.5*inch)
        flowables.append(spacer)
        
        styles["Normal"].fontSize = 16
        styles["Normal"].leading = 20

        text = "METODO DI CALCOLO della razione => <font name=helvetica size=16 color=red>%s</font>" % metodo
        para = Paragraph(text, style=styles["Normal"])
        flowables.append(para)

        testo = 'PESO MEDIO ALLA NASCITA => %f kg' % calf_weight
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)    
    
        testo = 'PESO VIVO MEDIO BOVINE IN LATTAZIONE => %f kg' % LW
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)

        testo = 'ETÀ MEDIA BOVINE IN LATTAZIONE => %d mesi' % cow_age
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)

        testo = 'SETTIMANA DI LATTAZIONE media => %d^' % WOL
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)

        testo = 'SETTIMANA DI GRAVIDANZA media => %d^' % WOP
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)

        testo = 'LIVELLO PRODUTTIVO medio => %f kg di latte al giorno' % MY
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)

        testo = 'TENORE DI GRASSO del latte => %fx100' % FAT_milk
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)

        testo = 'TENORE DI PROTEINA del latte => %fx100' % CP_milk
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)

        testo = 'TENORE DI LATTOSIO del latte => %fx100' % LAC_milk
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)

        testo = 'N° DI REPLICHE => %d' % N_repl
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)
        


        if Path("FABBISOGNI_PyR_%s.txt" % nome_file_razione).exists():
              
#       TESTO_F = open('nome_file_fabbisogni.txt').read()
#       nome_file_fabbisogni = TESTO_F[0:(len(TESTO_F)-1)]
            Fabbisogni_decimali = re.findall('[\d]*[.][\d]+', open("FABBISOGNI_PyR_%s.txt" % nome_file_razione).read())

            DMI = float(Fabbisogni_decimali[0])
            CP = float(Fabbisogni_decimali[1])
            FG = float(Fabbisogni_decimali[2])
            NDF = float(Fabbisogni_decimali[3])
            ADF = float(Fabbisogni_decimali[4])
            FAT = float(Fabbisogni_decimali[5])
            AM = float(Fabbisogni_decimali[6])
            ZUC = float(Fabbisogni_decimali[7])
            Ca = float(Fabbisogni_decimali[8])
            P = float(Fabbisogni_decimali[9])
            UFL = float(Fabbisogni_decimali[10])
            PDI = float(Fabbisogni_decimali[11])

            
            DMIr = arrotonda(DMI)
            CPr = arrotonda(CP)
            FGr = arrotonda(FG)
            NDFr = arrotonda(NDF)
            ADFr = arrotonda(ADF)
            FATr = arrotonda(FAT)
            AMr = arrotonda(AM)
            ZUCr = arrotonda(ZUC)
            Car = arrotonda(Ca)
            Pr = arrotonda(P)
            UFLr = arrotonda(UFL)
            PDIr = arrotonda(PDI)

            testo = '**********************************************************************'
            para = Paragraph(testo, style=styles["Normal"])
            spacer = Spacer(1, 0.4*inch)
            flowables.append(spacer)
            flowables.append(para)
            flowables.append(PageBreak())


            testo = '<b>FABBISOGNI_PyR_%s</b>' % nome_file_razione
            styles = getSampleStyleSheet()
            styles.add(ParagraphStyle(name='Parametri', alignment=TA_CENTER))
            styles["Parametri"].fontSize = 18
            styles["Parametri"].leading = 14
            spacer = Spacer(1, 0.4*inch)
            flowables.append(spacer)
            flowables.append(Paragraph(testo, styles["Parametri"]))
            spacer = Spacer(1, 0.5*inch)
            flowables.append(spacer)

            
            styles["Normal"].fontSize = 16
            styles["Normal"].leading = 20


            testo = 'CAPACITÀ DI INGESTIONE => %f kg di SOSTANZA SECCA' % DMI
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'PROTEINA GREZZA => %f g' % CP
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'FIBRA GREZZA => %f g' % FG
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'Fibra resistente al Detergente Neutro (NDF) => %f g' % NDF
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'Fibra resistente al Detergente Acido (ADF) => %f g' % ADF
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'GRASSO GREZZO => %f g' % FAT
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'AMIDO => %f g' % AM
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'ZUCCHERI => %f g' % ZUC
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'CALCIO => %f g' % Ca
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'FOSFORO => %f g' % P
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'ENERGIA NETTA => %f UFL' % UFL
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'Proteina Digeribile Intestinale (PDI) => %f g' % PDI
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)


        if Path("nome_file_apporti.txt").exists():
#       TESTO_A = open('nome_file_apporti.txt').read()
#       nome_file_apporti = TESTO_A[0:(len(TESTO_A)-1)]
            Apporti_decimali = re.findall('[\d]*[.][\d]+', open("APPORTI_PyR_%s.txt" % nome_file_razione).read())

            ADM = float(Apporti_decimali[0])
            ACP = float(Apporti_decimali[1])
            AFG = float(Apporti_decimali[2])
            ANDF = float(Apporti_decimali[3])
            AADF = float(Apporti_decimali[4])
            AFAT = float(Apporti_decimali[5])
            AAM = float(Apporti_decimali[6])
            AZUC = float(Apporti_decimali[7])
            ACa = float(Apporti_decimali[8])
            AP = float(Apporti_decimali[9])
            AUFL = float(Apporti_decimali[10])
            APDI = float(Apporti_decimali[11])

    
            ADMr = arrotonda(ADM)
            ACPr = arrotonda(ACP)
            AFGr = arrotonda(AFG)
            ANDFr = arrotonda(ANDF)
            AADFr = arrotonda(AADF)
            AFATr = arrotonda(AFAT)
            AAMr = arrotonda(AAM)
            AZUCr = arrotonda(AZUC)
            ACar = arrotonda(ACa)
            APr = arrotonda(AP)
            AUFLr = arrotonda(AUFL)
            APDIr = arrotonda(APDI)

            testo = '**********************************************************************'
            para = Paragraph(testo, style=styles["Normal"])
            spacer = Spacer(1, 0.4*inch)
            flowables.append(spacer)
            flowables.append(para)

            testo = '<b>APPORTI_PyR_%s</b>' % nome_file_razione
            styles = getSampleStyleSheet()
            styles.add(ParagraphStyle(name='Parametri', alignment=TA_CENTER))
            styles["Parametri"].fontSize = 18
            styles["Parametri"].leading = 14
            spacer = Spacer(1, 0.4*inch)
            flowables.append(spacer)
            flowables.append(Paragraph(testo, styles["Parametri"]))
            spacer = Spacer(1, 0.5*inch)
            flowables.append(spacer)

            
            styles["Normal"].fontSize = 16
            styles["Normal"].leading = 20

            testo = 'CAPACITÀ DI INGESTIONE => %f kg di SOSTANZA SECCA' % ADM
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'PROTEINA GREZZA => %f g' % ACP
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'FIBRA GREZZA => %f g' % AFG
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'Fibra resistente al Detergente Neutro (NDF) => %f g' % ANDF
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'Fibra resistente al Detergente Acido (ADF) => %f g' % AADF
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'GRASSO GREZZO => %f g' % AFAT
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'AMIDO => %f g' % AAM
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'ZUCCHERI => %f g' % AZUC
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'CALCIO => %f g' % ACa
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'FOSFORO => %f g' % AP
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'ENERGIA NETTA => %f UFL' % AUFL
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'Proteina Digeribile Intestinale (PDI) => %f g' % APDI
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)
    
            testo = '**********************************************************************'
            para = Paragraph(testo, style=styles["Normal"])
            spacer = Spacer(1, 0.4*inch)
            flowables.append(spacer)
            flowables.append(para)
            flowables.append(PageBreak())


            testo = '<b>TABELLA RIASSUNTIVA</b>'
            styles = getSampleStyleSheet()
            styles.add(ParagraphStyle(name='Parametri', alignment=TA_CENTER))
            styles["Parametri"].fontSize = 24
            styles["Parametri"].leading = 14
            spacer = Spacer(1, 1.0*inch)
            flowables.append(Paragraph(testo, styles["Parametri"]))      
            flowables.append(spacer)

            
            styles["Normal"].fontSize = 16
            styles["Normal"].leading = 20


            stile_intestazione_1 = TableStyle([('FONT', (0, 0), (-1, 0), 'Helvetica', 18)])
            tblstyle_1 = TableStyle([('FONT', (0, 1), (-1, 14), 'Helvetica', 16)])
            stile_griglia = TableStyle([('INNERGRID', (0,0), (-1,-1), 0.25, colors.black), ('BOX', (0,0), (-1,-1), 0.5, colors.black)])
            
            stile_intestazione_2 = TableStyle([('FONT', (0, 0), (-1, 0), 'Helvetica', 18)])
            tblstyle_2 = TableStyle([('FONT', (0, 1), (-1, 14), 'Helvetica', 16)])
            stile_griglia = TableStyle([('INNERGRID', (0,0), (-1,-1), 0.25, colors.black), ('BOX', (0,0), (-1,-1), 0.5, colors.black)])

            stile_intestazione_3 = TableStyle([('FONT', (0, 0), (-1, 0), 'Helvetica', 12)])
            tblstyle_3 = TableStyle([('FONT', (0, 1), (-1, 14), 'Helvetica', 10)])
            stile_griglia = TableStyle([('INNERGRID', (0,0), (-1,-1), 0.25, colors.black), ('BOX', (0,0), (-1,-1), 0.5, colors.black)])
                           
            data1 = [['PRINCIPIO NUTR.', 'APPORTO', 'FABBISOGNO', 'Δ'], ['SOSTANZA SECCA (kg)', ADMr, DMIr, (arrotonda(ADM-DMI))], ['PROTEINA GREZZA (g)', ACPr, CPr, (arrotonda(ACP-CP))], ['FIBRA GREZZA (g)', AFGr, FGr, (arrotonda(AFG-FG))], ['NDF (g)', ANDFr, NDFr, (arrotonda(ANDF-NDF))], ['ADF (g)', AADFr, ADFr, (arrotonda(AADF-ADF))], ['FAT (g)', AFATr, FATr, (arrotonda(AFAT-FAT))], ['AMIDO (g)', AAMr, AMr, (arrotonda(AAM-AM))], ['ZUCCHERI (g)', AZUCr, ZUCr, (arrotonda(AZUC-ZUC))], ['CALCIO (g)', ACar, Car, (arrotonda(ACa-Ca))], ['FOSFORO (g)', APr, Pr, (arrotonda(AP-P))], ['ENERGIA NETTA (UFL)', AUFLr, UFLr, (arrotonda(AUFL-UFL))], ['PDI (g)', APDIr, PDIr, (arrotonda(APDI-PDI))]]

    
            tbl1 = Table(data1)
            tbl1.setStyle(stile_intestazione_1)
            tbl1.setStyle(tblstyle_1)
            tbl1.setStyle(stile_griglia)
            flowables.append(tbl1)
            flowables.append(PageBreak())


# eccezione aggiunta il 08.12.2022 per tener conto del caso in cui non sia possibile importare i prezzi
            
            try:    
                from fonte_dati import alimenti, LISINA, METIONINA, PDIE, PDIN, quantita, prezzi
                
                prezzi = np.array(prezzi)
                prezzi = np.divide(prezzi, 1000)
                COSTI = np.round(prezzi * quantita, 4)
                COSTO_TOT = np.round(np.sum(COSTI), 4)
                quantita_TOT = np.round(np.sum(np.array(quantita)), 4)
                
                
                LISINA = np.array(LISINA)
                METIONINA = np.array(METIONINA)
                PDIE = np.array(PDIE)
                PDIN = np.array(PDIN)
                
                LISINA_TOT = np.sum(LISINA*quantita)
                METIONINA_TOT = np.sum(METIONINA*quantita)
                PDIE_TOT = np.sum(PDIE*quantita)
                PDIN_TOT = np.sum(PDIN*quantita)
                
                LYS_MET_ratio = round(LISINA_TOT/METIONINA_TOT, 6)
                LysDI_ratio = round(LISINA_TOT/PDIN_TOT, 6)
                MetDI_ratio = round(METIONINA_TOT/PDIN_TOT, 6)


### AGGIUNGERE IL CASO 6 ALIMENTI!


                if len(alimenti) == 6:
    
                    from fonte_dati import COMPOSIZIONE_ITEM_1, COMPOSIZIONE_ITEM_2, COMPOSIZIONE_ITEM_3, COMPOSIZIONE_ITEM_4, COMPOSIZIONE_ITEM_5, COMPOSIZIONE_ITEM_6, COMPOSIZIONE_ITEM_7
    

                    apporti_1 = np.round(np.array([i * quantita[0] for i in COMPOSIZIONE_ITEM_1]), 2)
                    apporti_2 = np.round(np.array([i * quantita[1] for i in COMPOSIZIONE_ITEM_2]), 2)
                    apporti_3 = np.round(np.array([i * quantita[2] for i in COMPOSIZIONE_ITEM_3]), 2)
                    apporti_4 = np.round(np.array([i * quantita[3] for i in COMPOSIZIONE_ITEM_4]), 2)
                    apporti_5 = np.round(np.array([i * quantita[4] for i in COMPOSIZIONE_ITEM_5]), 2)
                    apporti_6 = np.round(np.array([i * quantita[5] for i in COMPOSIZIONE_ITEM_6]), 2)
                            
                    quantita_TOT = round(sum(quantita[i] for i in range(len(quantita))), 4)   
                    quantita = np.round(quantita, 4)
                
                    data2 = [['ALIMENTO', 'QUANT.', 'PR. (E/kg)', 'COSTO (E)'], [alimenti[0], quantita[0], prezzi[0], COSTI[0]], [alimenti[1], quantita[1], prezzi[1], COSTI[1]], [alimenti[2], quantita[2], prezzi[2], COSTI[2]], [alimenti[3], quantita[3], prezzi[3], COSTI[3]], [alimenti[4], quantita[4], prezzi[4], COSTI[4]], [alimenti[5], quantita[5], prezzi[5], COSTI[5]], ['TOTALE', quantita_TOT, '', COSTO_TOT]]   
          
                    data3 = [['', 'T.Q. (kg)', 'DM (kg)', 'CP (g)', 'FG (g)', 'NDF (g)', 'ADF (g)', 'FAT (g)', 'AM (g)', 'ZUC (g)', 'Ca (g)', 'P (g)', 'UFL', 'PDI (g)'], [alimenti[0], quantita[0], apporti_1[0], apporti_1[1], apporti_1[2], apporti_1[3], apporti_1[4], apporti_1[5], apporti_1[6], apporti_1[7], apporti_1[8], apporti_1[9], apporti_1[10], apporti_1[11]], [alimenti[1], quantita[1], apporti_2[0], apporti_2[1], apporti_2[2], apporti_2[3], apporti_2[4], apporti_2[5], apporti_2[6], apporti_2[7], apporti_2[8], apporti_2[9], apporti_2[10], apporti_2[11]], [alimenti[2], quantita[2], apporti_3[0], apporti_3[1], apporti_3[2], apporti_3[3], apporti_3[4], apporti_3[5], apporti_3[6], apporti_3[7], apporti_3[8], apporti_3[9], apporti_3[10], apporti_3[11]], [alimenti[3], quantita[3], apporti_4[0], apporti_4[1], apporti_4[2], apporti_4[3], apporti_4[4], apporti_4[5], apporti_4[6], apporti_4[7], apporti_4[8], apporti_4[9], apporti_4[10], apporti_4[11]], [alimenti[4], quantita[4], apporti_5[0], apporti_5[1], apporti_5[2], apporti_5[3], apporti_5[4], apporti_5[5], apporti_5[6], apporti_5[7], apporti_5[8], apporti_5[9], apporti_5[10], apporti_5[11]], [alimenti[5], quantita[5], apporti_6[0], apporti_6[1], apporti_6[2], apporti_6[3], apporti_6[4], apporti_6[5], apporti_6[6], apporti_6[7], apporti_6[8], apporti_6[9], apporti_6[10], apporti_6[11]], ['TOTALE', quantita_TOT, ADMr, ACPr, AFGr, ANDFr, AADFr, AFATr, AAMr, AZUCr, ACar, APr, AUFLr, APDIr]]     



                elif len(alimenti) == 7:
    
                    from fonte_dati import COMPOSIZIONE_ITEM_1, COMPOSIZIONE_ITEM_2, COMPOSIZIONE_ITEM_3, COMPOSIZIONE_ITEM_4, COMPOSIZIONE_ITEM_5, COMPOSIZIONE_ITEM_6, COMPOSIZIONE_ITEM_7
    

                    apporti_1 = np.round(np.array([i * quantita[0] for i in COMPOSIZIONE_ITEM_1]), 2)
                    apporti_2 = np.round(np.array([i * quantita[1] for i in COMPOSIZIONE_ITEM_2]), 2)
                    apporti_3 = np.round(np.array([i * quantita[2] for i in COMPOSIZIONE_ITEM_3]), 2)
                    apporti_4 = np.round(np.array([i * quantita[3] for i in COMPOSIZIONE_ITEM_4]), 2)
                    apporti_5 = np.round(np.array([i * quantita[4] for i in COMPOSIZIONE_ITEM_5]), 2)
                    apporti_6 = np.round(np.array([i * quantita[5] for i in COMPOSIZIONE_ITEM_6]), 2)
                    apporti_7 = np.round(np.array([i * quantita[6] for i in COMPOSIZIONE_ITEM_7]), 2)
        
                    quantita_TOT = round(sum(quantita[i] for i in range(len(quantita))), 4)   
                    quantita = np.round(quantita, 4)
                
                    data2 = [['ALIMENTO', 'QUANT.', 'PR. (E/kg)', 'COSTO (E)'], [alimenti[0], quantita[0], prezzi[0], COSTI[0]], [alimenti[1], quantita[1], prezzi[1], COSTI[1]], [alimenti[2], quantita[2], prezzi[2], COSTI[2]], [alimenti[3], quantita[3], prezzi[3], COSTI[3]], [alimenti[4], quantita[4], prezzi[4], COSTI[4]], [alimenti[5], quantita[5], prezzi[5], COSTI[5]],[alimenti[6], quantita[6], prezzi[6], COSTI[6]], ['TOTALE', quantita_TOT, '', COSTO_TOT]]   
          
                    data3 = [['', 'T.Q. (kg)', 'DM (kg)', 'CP (g)', 'FG (g)', 'NDF (g)', 'ADF (g)', 'FAT (g)', 'AM (g)', 'ZUC (g)', 'Ca (g)', 'P (g)', 'UFL', 'PDI (g)'], [alimenti[0], quantita[0], apporti_1[0], apporti_1[1], apporti_1[2], apporti_1[3], apporti_1[4], apporti_1[5], apporti_1[6], apporti_1[7], apporti_1[8], apporti_1[9], apporti_1[10], apporti_1[11]], [alimenti[1], quantita[1], apporti_2[0], apporti_2[1], apporti_2[2], apporti_2[3], apporti_2[4], apporti_2[5], apporti_2[6], apporti_2[7], apporti_2[8], apporti_2[9], apporti_2[10], apporti_2[11]], [alimenti[2], quantita[2], apporti_3[0], apporti_3[1], apporti_3[2], apporti_3[3], apporti_3[4], apporti_3[5], apporti_3[6], apporti_3[7], apporti_3[8], apporti_3[9], apporti_3[10], apporti_3[11]], [alimenti[3], quantita[3], apporti_4[0], apporti_4[1], apporti_4[2], apporti_4[3], apporti_4[4], apporti_4[5], apporti_4[6], apporti_4[7], apporti_4[8], apporti_4[9], apporti_4[10], apporti_4[11]], [alimenti[4], quantita[4], apporti_5[0], apporti_5[1], apporti_5[2], apporti_5[3], apporti_5[4], apporti_5[5], apporti_5[6], apporti_5[7], apporti_5[8], apporti_5[9], apporti_5[10], apporti_5[11]], [alimenti[5], quantita[5], apporti_6[0], apporti_6[1], apporti_6[2], apporti_6[3], apporti_6[4], apporti_6[5], apporti_6[6], apporti_6[7], apporti_6[8], apporti_6[9], apporti_6[10], apporti_6[11]], [alimenti[6], quantita[6], apporti_7[0], apporti_7[1], apporti_7[2], apporti_7[3], apporti_7[4], apporti_7[5], apporti_7[6], apporti_7[7], apporti_7[8], apporti_7[9], apporti_7[10], apporti_7[11]], ['TOTALE', quantita_TOT, ADMr, ACPr, AFGr, ANDFr, AADFr, AFATr, AAMr, AZUCr, ACar, APr, AUFLr, APDIr]]     


    
                elif len(alimenti) == 8:
    
                    from fonte_dati import COMPOSIZIONE_ITEM_1, COMPOSIZIONE_ITEM_2, COMPOSIZIONE_ITEM_3, COMPOSIZIONE_ITEM_4, COMPOSIZIONE_ITEM_5, COMPOSIZIONE_ITEM_6, COMPOSIZIONE_ITEM_7, COMPOSIZIONE_ITEM_8
    


                    apporti_1 = np.round(np.array([i * quantita[0] for i in COMPOSIZIONE_ITEM_1]), 2)
                    apporti_2 = np.round(np.array([i * quantita[1] for i in COMPOSIZIONE_ITEM_2]), 2)
                    apporti_3 = np.round(np.array([i * quantita[2] for i in COMPOSIZIONE_ITEM_3]), 2)
                    apporti_4 = np.round(np.array([i * quantita[3] for i in COMPOSIZIONE_ITEM_4]), 2)
                    apporti_5 = np.round(np.array([i * quantita[4] for i in COMPOSIZIONE_ITEM_5]), 2)
                    apporti_6 = np.round(np.array([i * quantita[5] for i in COMPOSIZIONE_ITEM_6]), 2)
                    apporti_7 = np.round(np.array([i * quantita[6] for i in COMPOSIZIONE_ITEM_7]), 2)
                    apporti_8 = np.round(np.array([i * quantita[7] for i in COMPOSIZIONE_ITEM_8]), 2)
        
                    quantita_TOT = round(sum(quantita[i] for i in range(len(quantita))), 4)      
                    quantita = np.round(quantita, 4)
        
                    data2 = [['ALIMENTO', 'QUANT.', 'PR. (E/kg)', 'COSTO (E)'], [alimenti[0], quantita[0], prezzi[0], COSTI[0]], [alimenti[1], quantita[1], prezzi[1], COSTI[1]], [alimenti[2], quantita[2], prezzi[2], COSTI[2]], [alimenti[3], quantita[3], prezzi[3], COSTI[3]], [alimenti[4], quantita[4], prezzi[4], COSTI[4]], [alimenti[5], quantita[5], prezzi[5], COSTI[5]],[alimenti[6], quantita[6], prezzi[6], COSTI[6]], [alimenti[7], quantita[7], prezzi[7], COSTI[7]], ['TOTALE', quantita_TOT, '', COSTO_TOT]]   
          
                    data3 = [['', 'T.Q. (kg)', 'DM (kg)', 'CP (g)', 'FG (g)', 'NDF (g)', 'ADF (g)', 'FAT (g)', 'AM (g)', 'ZUC (g)', 'Ca (g)', 'P (g)', 'UFL', 'PDI (g)'], [alimenti[0], quantita[0], apporti_1[0], apporti_1[1], apporti_1[2], apporti_1[3], apporti_1[4], apporti_1[5], apporti_1[6], apporti_1[7], apporti_1[8], apporti_1[9], apporti_1[10], apporti_1[11]], [alimenti[1], quantita[1], apporti_2[0], apporti_2[1], apporti_2[2], apporti_2[3], apporti_2[4], apporti_2[5], apporti_2[6], apporti_2[7], apporti_2[8], apporti_2[9], apporti_2[10], apporti_2[11]], [alimenti[2], quantita[2], apporti_3[0], apporti_3[1], apporti_3[2], apporti_3[3], apporti_3[4], apporti_3[5], apporti_3[6], apporti_3[7], apporti_3[8], apporti_3[9], apporti_3[10], apporti_3[11]], [alimenti[3], quantita[3], apporti_4[0], apporti_4[1], apporti_4[2], apporti_4[3], apporti_4[4], apporti_4[5], apporti_4[6], apporti_4[7], apporti_4[8], apporti_4[9], apporti_4[10], apporti_4[11]], [alimenti[4], quantita[4], apporti_5[0], apporti_5[1], apporti_5[2], apporti_5[3], apporti_5[4], apporti_5[5], apporti_5[6], apporti_5[7], apporti_5[8], apporti_5[9], apporti_5[10], apporti_5[11]], [alimenti[5], quantita[5], apporti_6[0], apporti_6[1], apporti_6[2], apporti_6[3], apporti_6[4], apporti_6[5], apporti_6[6], apporti_6[7], apporti_6[8], apporti_6[9], apporti_6[10], apporti_6[11]], [alimenti[6], quantita[6], apporti_7[0], apporti_7[1], apporti_7[2], apporti_7[3], apporti_7[4], apporti_7[5], apporti_7[6], apporti_7[7], apporti_7[8], apporti_7[9], apporti_7[10], apporti_7[11]], [alimenti[7], quantita[7], apporti_8[0], apporti_8[1], apporti_8[2], apporti_8[3], apporti_8[4], apporti_8[5], apporti_8[6], apporti_8[7], apporti_8[8], apporti_8[9], apporti_8[10], apporti_8[11]], ['TOTALE', quantita_TOT, ADMr, ACPr, AFGr, ANDFr, AADFr, AFATr, AAMr, AZUCr, ACar, APr, AUFLr, APDIr]]     



                elif len(alimenti) == 9:
    
                    from fonte_dati import COMPOSIZIONE_ITEM_1, COMPOSIZIONE_ITEM_2, COMPOSIZIONE_ITEM_3, COMPOSIZIONE_ITEM_4, COMPOSIZIONE_ITEM_5, COMPOSIZIONE_ITEM_6, COMPOSIZIONE_ITEM_7, COMPOSIZIONE_ITEM_8, COMPOSIZIONE_ITEM_9
    


                    apporti_1 = np.round(np.array([i * quantita[0] for i in COMPOSIZIONE_ITEM_1]), 2)
                    apporti_2 = np.round(np.array([i * quantita[1] for i in COMPOSIZIONE_ITEM_2]), 2)
                    apporti_3 = np.round(np.array([i * quantita[2] for i in COMPOSIZIONE_ITEM_3]), 2)
                    apporti_4 = np.round(np.array([i * quantita[3] for i in COMPOSIZIONE_ITEM_4]), 2)
                    apporti_5 = np.round(np.array([i * quantita[4] for i in COMPOSIZIONE_ITEM_5]), 2)
                    apporti_6 = np.round(np.array([i * quantita[5] for i in COMPOSIZIONE_ITEM_6]), 2)
                    apporti_7 = np.round(np.array([i * quantita[6] for i in COMPOSIZIONE_ITEM_7]), 2)
                    apporti_8 = np.round(np.array([i * quantita[7] for i in COMPOSIZIONE_ITEM_8]), 2)
                    apporti_9 = np.round(np.array([i * quantita[8] for i in COMPOSIZIONE_ITEM_9]), 2)
        
                    quantita_TOT = round(sum(quantita[i] for i in range(len(quantita))), 4)      
                    quantita = np.round(quantita, 4)
        
                    data2 = [['ALIMENTO', 'QUANT.', 'PR. (E/kg)', 'COSTO (E)'], [alimenti[0], quantita[0], prezzi[0], COSTI[0]], [alimenti[1], quantita[1], prezzi[1], COSTI[1]], [alimenti[2], quantita[2], prezzi[2], COSTI[2]], [alimenti[3], quantita[3], prezzi[3], COSTI[3]], [alimenti[4], quantita[4], prezzi[4], COSTI[4]], [alimenti[5], quantita[5], prezzi[5], COSTI[5]],[alimenti[6], quantita[6], prezzi[6], COSTI[6]], [alimenti[7], quantita[7], prezzi[7], COSTI[7]], [alimenti[8], quantita[8], prezzi[8], COSTI[8]], ['TOTALE', quantita_TOT, '', COSTO_TOT]]   
          
                    data3 = [['', 'T.Q. (kg)', 'DM (kg)', 'CP (g)', 'FG (g)', 'NDF (g)', 'ADF (g)', 'FAT (g)', 'AM (g)', 'ZUC (g)', 'Ca (g)', 'P (g)', 'UFL', 'PDI (g)'], [alimenti[0], quantita[0], apporti_1[0], apporti_1[1], apporti_1[2], apporti_1[3], apporti_1[4], apporti_1[5], apporti_1[6], apporti_1[7], apporti_1[8], apporti_1[9], apporti_1[10], apporti_1[11]], [alimenti[1], quantita[1], apporti_2[0], apporti_2[1], apporti_2[2], apporti_2[3], apporti_2[4], apporti_2[5], apporti_2[6], apporti_2[7], apporti_2[8], apporti_2[9], apporti_2[10], apporti_2[11]], [alimenti[2], quantita[2], apporti_3[0], apporti_3[1], apporti_3[2], apporti_3[3], apporti_3[4], apporti_3[5], apporti_3[6], apporti_3[7], apporti_3[8], apporti_3[9], apporti_3[10], apporti_3[11]], [alimenti[3], quantita[3], apporti_4[0], apporti_4[1], apporti_4[2], apporti_4[3], apporti_4[4], apporti_4[5], apporti_4[6], apporti_4[7], apporti_4[8], apporti_4[9], apporti_4[10], apporti_4[11]], [alimenti[4], quantita[4], apporti_5[0], apporti_5[1], apporti_5[2], apporti_5[3], apporti_5[4], apporti_5[5], apporti_5[6], apporti_5[7], apporti_5[8], apporti_5[9], apporti_5[10], apporti_5[11]], [alimenti[5], quantita[5], apporti_6[0], apporti_6[1], apporti_6[2], apporti_6[3], apporti_6[4], apporti_6[5], apporti_6[6], apporti_6[7], apporti_6[8], apporti_6[9], apporti_6[10], apporti_6[11]], [alimenti[6], quantita[6], apporti_7[0], apporti_7[1], apporti_7[2], apporti_7[3], apporti_7[4], apporti_7[5], apporti_7[6], apporti_7[7], apporti_7[8], apporti_7[9], apporti_7[10], apporti_7[11]], [alimenti[7], quantita[7], apporti_8[0], apporti_8[1], apporti_8[2], apporti_8[3], apporti_8[4], apporti_8[5], apporti_8[6], apporti_8[7], apporti_8[8], apporti_8[9], apporti_8[10], apporti_8[11]], [alimenti[8], quantita[8], apporti_9[0], apporti_9[1], apporti_9[2], apporti_9[3], apporti_9[4], apporti_9[5], apporti_9[6], apporti_9[7], apporti_9[8], apporti_9[9], apporti_9[10], apporti_9[11]], ['TOTALE', quantita_TOT, ADMr, ACPr, AFGr, ANDFr, AADFr, AFATr, AAMr, AZUCr, ACar, APr, AUFLr, APDIr]]



                F = re.findall(r"[+-]?\d+(?:\.\d+)?", open('FABBISOGNI_PyR_%s.txt' % nome_file_razione).read())
                
                for i in range(len(F)):
                    F[i] = float(F[i])
    
                F_SS = F[0]
                F_UFL = F[10]
                for i in range(len(F)):
                    F[i] = F[i]/1000
    
                F[0] = F_SS
                F[10] = F_UFL

                for i in range(len(F)):
                    F[i] = round(F[i], 1)

                A = re.findall(r"[+-]?\d+(?:\.\d+)?", open('APPORTI_PyR_%s.txt' % nome_file_razione).read())
                print(A)

                for i in range(len(A)):
                    A[i] = float(A[i])

                A_SS = A[0]
                A_UFL = A[10]
                for i in range(len(A)):
                    A[i] = A[i]/1000
   
                A[0] = A_SS
                A[10] = A_UFL

                for i in range(len(A)):
                    A[i] = round(A[i], 1)

                labels = ['DM', 'CP', 'FG', 'NDF', 'ADF', 'FAT', 'AM', 'ZUC', 'Ca', 'P', 'UFL', 'PDI']
	
                x = np.arange(len(labels))

                width = 0.35
                fig, ax = plt.subplots()
                rects1 = ax.bar(x - width/2, F, width, label='Fabbisogni')
                rects2 = ax.bar(x + width/2, A, width, label='Apporti')

                ax.set_ylabel('kg (o UFL)')
                ax.set_title('FABBISOGNI vs APPORTI')
                ax.set_xticks(x, labels)
                ax.legend()
                ax.bar_label(rects1, padding=3)
                ax.bar_label(rects2, padding=3)
                fig.tight_layout()
                plt.savefig('BARPLOT_PyR_%s.png' % nome_file_razione, dpi=400)


                barplot = "BARPLOT_PyR_%s.png" % nome_file_razione
                im2 = Image(barplot, 7.8*inch, 4.5*inch)
                flowables.append(spacer)   
                flowables.append(im2)
                flowables.append(spacer)
                flowables.append(PageBreak())


                testo = '<b>TABELLA COSTI</b>'
                styles = getSampleStyleSheet()
                styles.add(ParagraphStyle(name='Parametri', alignment=TA_CENTER))
                styles["Parametri"].fontSize = 24
                styles["Parametri"].leading = 14
                spacer = Spacer(1, 1.0*inch)
                flowables.append(Paragraph(testo, styles["Parametri"]))      
                flowables.append(spacer)                


                tbl2 = Table(data2, hAlign='LEFT')
                tbl2.setStyle(stile_intestazione_2)
                tbl2.setStyle(tblstyle_2)
                tbl2.setStyle(stile_griglia)
                flowables.append(tbl2)
                flowables.append(PageBreak())
#       	flowables.append(Spacer(inch, 0.5*inch))




            
            except ImportError:
            
                from fonte_dati import alimenti, LISINA, METIONINA, PDIE, PDIN, quantita
                LISINA = np.array(LISINA)
                METIONINA = np.array(METIONINA)
                PDIE = np.array(PDIE)
                PDIN = np.array(PDIN)
                
                LISINA_TOT = np.sum(LISINA*quantita)
                METIONINA_TOT = np.sum(METIONINA*quantita)
                PDIE_TOT = np.sum(PDIE*quantita)
                PDIN_TOT = np.sum(PDIN*quantita)
                
                LYS_MET_ratio = round(LISINA_TOT/METIONINA_TOT, 6)
                LysDI_ratio = round(LISINA_TOT/PDIN_TOT, 6)
                MetDI_ratio = round(METIONINA_TOT/PDIN_TOT, 6)
                      
                quantita_TOT = np.round(np.sum(np.array(quantita)), 4)                

                if len(alimenti) == 6:
    
                    from fonte_dati import COMPOSIZIONE_ITEM_1, COMPOSIZIONE_ITEM_2, COMPOSIZIONE_ITEM_3, COMPOSIZIONE_ITEM_4, COMPOSIZIONE_ITEM_5, COMPOSIZIONE_ITEM_6
    

                    apporti_1 = np.round(np.array([i * quantita[0] for i in COMPOSIZIONE_ITEM_1]), 2)
                    apporti_2 = np.round(np.array([i * quantita[1] for i in COMPOSIZIONE_ITEM_2]), 2)
                    apporti_3 = np.round(np.array([i * quantita[2] for i in COMPOSIZIONE_ITEM_3]), 2)
                    apporti_4 = np.round(np.array([i * quantita[3] for i in COMPOSIZIONE_ITEM_4]), 2)
                    apporti_5 = np.round(np.array([i * quantita[4] for i in COMPOSIZIONE_ITEM_5]), 2)
                    apporti_6 = np.round(np.array([i * quantita[5] for i in COMPOSIZIONE_ITEM_6]), 2)
                            
                    quantita_TOT = round(sum(quantita[i] for i in range(len(quantita))), 4)   
                    quantita = np.round(quantita, 4)
                
#                   data2 = [['ALIMENTO', 'QUANT.', 'PR. (E/kg)', 'COSTO (E)'], [alimenti[0], quantita[0], prezzi[0], COSTI[0]], [alimenti[1], quantita[1], prezzi[1], COSTI[1]], [alimenti[2], quantita[2], prezzi[2], COSTI[2]], [alimenti[3], quantita[3], prezzi[3], COSTI[3]], [alimenti[4], quantita[4], prezzi[4], COSTI[4]], [alimenti[5], quantita[5], prezzi[5], COSTI[5]],[alimenti[6], quantita[6], prezzi[6], COSTI[6]], ['TOTALE', quantita_TOT, '', COSTO_TOT]]   
          
                    data3 = [['', 'T.Q. (kg)', 'DM (kg)', 'CP (g)', 'FG (g)', 'NDF (g)', 'ADF (g)', 'FAT (g)', 'AM (g)', 'ZUC (g)', 'Ca (g)', 'P (g)', 'UFL', 'PDI (g)'], [alimenti[0], quantita[0], apporti_1[0], apporti_1[1], apporti_1[2], apporti_1[3], apporti_1[4], apporti_1[5], apporti_1[6], apporti_1[7], apporti_1[8], apporti_1[9], apporti_1[10], apporti_1[11]], [alimenti[1], quantita[1], apporti_2[0], apporti_2[1], apporti_2[2], apporti_2[3], apporti_2[4], apporti_2[5], apporti_2[6], apporti_2[7], apporti_2[8], apporti_2[9], apporti_2[10], apporti_2[11]], [alimenti[2], quantita[2], apporti_3[0], apporti_3[1], apporti_3[2], apporti_3[3], apporti_3[4], apporti_3[5], apporti_3[6], apporti_3[7], apporti_3[8], apporti_3[9], apporti_3[10], apporti_3[11]], [alimenti[3], quantita[3], apporti_4[0], apporti_4[1], apporti_4[2], apporti_4[3], apporti_4[4], apporti_4[5], apporti_4[6], apporti_4[7], apporti_4[8], apporti_4[9], apporti_4[10], apporti_4[11]], [alimenti[4], quantita[4], apporti_5[0], apporti_5[1], apporti_5[2], apporti_5[3], apporti_5[4], apporti_5[5], apporti_5[6], apporti_5[7], apporti_5[8], apporti_5[9], apporti_5[10], apporti_5[11]], [alimenti[5], quantita[5], apporti_6[0], apporti_6[1], apporti_6[2], apporti_6[3], apporti_6[4], apporti_6[5], apporti_6[6], apporti_6[7], apporti_6[8], apporti_6[9], apporti_6[10], apporti_6[11]], ['TOTALE', quantita_TOT, ADMr, ACPr, AFGr, ANDFr, AADFr, AFATr, AAMr, AZUCr, ACar, APr, AUFLr, APDIr]]     



                elif len(alimenti) == 7:
    
                    from fonte_dati import COMPOSIZIONE_ITEM_1, COMPOSIZIONE_ITEM_2, COMPOSIZIONE_ITEM_3, COMPOSIZIONE_ITEM_4, COMPOSIZIONE_ITEM_5, COMPOSIZIONE_ITEM_6, COMPOSIZIONE_ITEM_7
    

                    apporti_1 = np.round(np.array([i * quantita[0] for i in COMPOSIZIONE_ITEM_1]), 2)
                    apporti_2 = np.round(np.array([i * quantita[1] for i in COMPOSIZIONE_ITEM_2]), 2)
                    apporti_3 = np.round(np.array([i * quantita[2] for i in COMPOSIZIONE_ITEM_3]), 2)
                    apporti_4 = np.round(np.array([i * quantita[3] for i in COMPOSIZIONE_ITEM_4]), 2)
                    apporti_5 = np.round(np.array([i * quantita[4] for i in COMPOSIZIONE_ITEM_5]), 2)
                    apporti_6 = np.round(np.array([i * quantita[5] for i in COMPOSIZIONE_ITEM_6]), 2)
                    apporti_7 = np.round(np.array([i * quantita[6] for i in COMPOSIZIONE_ITEM_7]), 2)
        
                    quantita_TOT = round(sum(quantita[i] for i in range(len(quantita))), 4)   
                    quantita = np.round(quantita, 4)
                
#                   data2 = [['ALIMENTO', 'QUANT.', 'PR. (E/kg)', 'COSTO (E)'], [alimenti[0], quantita[0], prezzi[0], COSTI[0]], [alimenti[1], quantita[1], prezzi[1], COSTI[1]], [alimenti[2], quantita[2], prezzi[2], COSTI[2]], [alimenti[3], quantita[3], prezzi[3], COSTI[3]], [alimenti[4], quantita[4], prezzi[4], COSTI[4]], [alimenti[5], quantita[5], prezzi[5], COSTI[5]],[alimenti[6], quantita[6], prezzi[6], COSTI[6]], ['TOTALE', quantita_TOT, '', COSTO_TOT]]   
          
                    data3 = [['', 'T.Q. (kg)', 'DM (kg)', 'CP (g)', 'FG (g)', 'NDF (g)', 'ADF (g)', 'FAT (g)', 'AM (g)', 'ZUC (g)', 'Ca (g)', 'P (g)', 'UFL', 'PDI (g)'], [alimenti[0], quantita[0], apporti_1[0], apporti_1[1], apporti_1[2], apporti_1[3], apporti_1[4], apporti_1[5], apporti_1[6], apporti_1[7], apporti_1[8], apporti_1[9], apporti_1[10], apporti_1[11]], [alimenti[1], quantita[1], apporti_2[0], apporti_2[1], apporti_2[2], apporti_2[3], apporti_2[4], apporti_2[5], apporti_2[6], apporti_2[7], apporti_2[8], apporti_2[9], apporti_2[10], apporti_2[11]], [alimenti[2], quantita[2], apporti_3[0], apporti_3[1], apporti_3[2], apporti_3[3], apporti_3[4], apporti_3[5], apporti_3[6], apporti_3[7], apporti_3[8], apporti_3[9], apporti_3[10], apporti_3[11]], [alimenti[3], quantita[3], apporti_4[0], apporti_4[1], apporti_4[2], apporti_4[3], apporti_4[4], apporti_4[5], apporti_4[6], apporti_4[7], apporti_4[8], apporti_4[9], apporti_4[10], apporti_4[11]], [alimenti[4], quantita[4], apporti_5[0], apporti_5[1], apporti_5[2], apporti_5[3], apporti_5[4], apporti_5[5], apporti_5[6], apporti_5[7], apporti_5[8], apporti_5[9], apporti_5[10], apporti_5[11]], [alimenti[5], quantita[5], apporti_6[0], apporti_6[1], apporti_6[2], apporti_6[3], apporti_6[4], apporti_6[5], apporti_6[6], apporti_6[7], apporti_6[8], apporti_6[9], apporti_6[10], apporti_6[11]], [alimenti[6], quantita[6], apporti_7[0], apporti_7[1], apporti_7[2], apporti_7[3], apporti_7[4], apporti_7[5], apporti_7[6], apporti_7[7], apporti_7[8], apporti_7[9], apporti_7[10], apporti_7[11]], ['TOTALE', quantita_TOT, ADMr, ACPr, AFGr, ANDFr, AADFr, AFATr, AAMr, AZUCr, ACar, APr, AUFLr, APDIr]]     


    
                elif len(alimenti) == 8:
    
                    from fonte_dati import COMPOSIZIONE_ITEM_1, COMPOSIZIONE_ITEM_2, COMPOSIZIONE_ITEM_3, COMPOSIZIONE_ITEM_4, COMPOSIZIONE_ITEM_5, COMPOSIZIONE_ITEM_6, COMPOSIZIONE_ITEM_7, COMPOSIZIONE_ITEM_8
    


                    apporti_1 = np.round(np.array([i * quantita[0] for i in COMPOSIZIONE_ITEM_1]), 2)
                    apporti_2 = np.round(np.array([i * quantita[1] for i in COMPOSIZIONE_ITEM_2]), 2)
                    apporti_3 = np.round(np.array([i * quantita[2] for i in COMPOSIZIONE_ITEM_3]), 2)
                    apporti_4 = np.round(np.array([i * quantita[3] for i in COMPOSIZIONE_ITEM_4]), 2)
                    apporti_5 = np.round(np.array([i * quantita[4] for i in COMPOSIZIONE_ITEM_5]), 2)
                    apporti_6 = np.round(np.array([i * quantita[5] for i in COMPOSIZIONE_ITEM_6]), 2)
                    apporti_7 = np.round(np.array([i * quantita[6] for i in COMPOSIZIONE_ITEM_7]), 2)
                    apporti_8 = np.round(np.array([i * quantita[7] for i in COMPOSIZIONE_ITEM_8]), 2)
        
                    quantita_TOT = round(sum(quantita[i] for i in range(len(quantita))), 4)      
                    quantita = np.round(quantita, 4)
        
#                   data2 = [['ALIMENTO', 'QUANT.', 'PR. (E/kg)', 'COSTO (E)'], [alimenti[0], quantita[0], prezzi[0], COSTI[0]], [alimenti[1], quantita[1], prezzi[1], COSTI[1]], [alimenti[2], quantita[2], prezzi[2], COSTI[2]], [alimenti[3], quantita[3], prezzi[3], COSTI[3]], [alimenti[4], quantita[4], prezzi[4], COSTI[4]], [alimenti[5], quantita[5], prezzi[5], COSTI[5]],[alimenti[6], quantita[6], prezzi[6], COSTI[6]], [alimenti[7], quantita[7], prezzi[7], COSTI[7]], ['TOTALE', quantita_TOT, '', COSTO_TOT]]   
          
                    data3 = [['', 'T.Q. (kg)', 'DM (kg)', 'CP (g)', 'FG (g)', 'NDF (g)', 'ADF (g)', 'FAT (g)', 'AM (g)', 'ZUC (g)', 'Ca (g)', 'P (g)', 'UFL', 'PDI (g)'], [alimenti[0], quantita[0], apporti_1[0], apporti_1[1], apporti_1[2], apporti_1[3], apporti_1[4], apporti_1[5], apporti_1[6], apporti_1[7], apporti_1[8], apporti_1[9], apporti_1[10], apporti_1[11]], [alimenti[1], quantita[1], apporti_2[0], apporti_2[1], apporti_2[2], apporti_2[3], apporti_2[4], apporti_2[5], apporti_2[6], apporti_2[7], apporti_2[8], apporti_2[9], apporti_2[10], apporti_2[11]], [alimenti[2], quantita[2], apporti_3[0], apporti_3[1], apporti_3[2], apporti_3[3], apporti_3[4], apporti_3[5], apporti_3[6], apporti_3[7], apporti_3[8], apporti_3[9], apporti_3[10], apporti_3[11]], [alimenti[3], quantita[3], apporti_4[0], apporti_4[1], apporti_4[2], apporti_4[3], apporti_4[4], apporti_4[5], apporti_4[6], apporti_4[7], apporti_4[8], apporti_4[9], apporti_4[10], apporti_4[11]], [alimenti[4], quantita[4], apporti_5[0], apporti_5[1], apporti_5[2], apporti_5[3], apporti_5[4], apporti_5[5], apporti_5[6], apporti_5[7], apporti_5[8], apporti_5[9], apporti_5[10], apporti_5[11]], [alimenti[5], quantita[5], apporti_6[0], apporti_6[1], apporti_6[2], apporti_6[3], apporti_6[4], apporti_6[5], apporti_6[6], apporti_6[7], apporti_6[8], apporti_6[9], apporti_6[10], apporti_6[11]], [alimenti[6], quantita[6], apporti_7[0], apporti_7[1], apporti_7[2], apporti_7[3], apporti_7[4], apporti_7[5], apporti_7[6], apporti_7[7], apporti_7[8], apporti_7[9], apporti_7[10], apporti_7[11]], [alimenti[7], quantita[7], apporti_8[0], apporti_8[1], apporti_8[2], apporti_8[3], apporti_8[4], apporti_8[5], apporti_8[6], apporti_8[7], apporti_8[8], apporti_8[9], apporti_8[10], apporti_8[11]], ['TOTALE', quantita_TOT, ADMr, ACPr, AFGr, ANDFr, AADFr, AFATr, AAMr, AZUCr, ACar, APr, AUFLr, APDIr]]     



                elif len(alimenti) == 9:
    
                    from fonte_dati import COMPOSIZIONE_ITEM_1, COMPOSIZIONE_ITEM_2, COMPOSIZIONE_ITEM_3, COMPOSIZIONE_ITEM_4, COMPOSIZIONE_ITEM_5, COMPOSIZIONE_ITEM_6, COMPOSIZIONE_ITEM_7, COMPOSIZIONE_ITEM_8, COMPOSIZIONE_ITEM_9
    


                    apporti_1 = np.round(np.array([i * quantita[0] for i in COMPOSIZIONE_ITEM_1]), 2)
                    apporti_2 = np.round(np.array([i * quantita[1] for i in COMPOSIZIONE_ITEM_2]), 2)
                    apporti_3 = np.round(np.array([i * quantita[2] for i in COMPOSIZIONE_ITEM_3]), 2)
                    apporti_4 = np.round(np.array([i * quantita[3] for i in COMPOSIZIONE_ITEM_4]), 2)
                    apporti_5 = np.round(np.array([i * quantita[4] for i in COMPOSIZIONE_ITEM_5]), 2)
                    apporti_6 = np.round(np.array([i * quantita[5] for i in COMPOSIZIONE_ITEM_6]), 2)
                    apporti_7 = np.round(np.array([i * quantita[6] for i in COMPOSIZIONE_ITEM_7]), 2)
                    apporti_8 = np.round(np.array([i * quantita[7] for i in COMPOSIZIONE_ITEM_8]), 2)
                    apporti_9 = np.round(np.array([i * quantita[8] for i in COMPOSIZIONE_ITEM_9]), 2)
        
                    quantita_TOT = round(sum(quantita[i] for i in range(len(quantita))), 4)      
                    quantita = np.round(quantita, 4)
        
#                  data2 = [['ALIMENTO', 'QUANT.', 'PR. (E/kg)', 'COSTO (E)'], [alimenti[0], quantita[0], prezzi[0], COSTI[0]], [alimenti[1], quantita[1], prezzi[1], COSTI[1]], [alimenti[2], quantita[2], prezzi[2], COSTI[2]], [alimenti[3], quantita[3], prezzi[3], COSTI[3]], [alimenti[4], quantita[4], prezzi[4], COSTI[4]], [alimenti[5], quantita[5], prezzi[5], COSTI[5]],[alimenti[6], quantita[6], prezzi[6], COSTI[6]], [alimenti[7], quantita[7], prezzi[7], COSTI[7]], [alimenti[8], quantita[8], prezzi[8], COSTI[8]], ['TOTALE', quantita_TOT, '', COSTO_TOT]]   
          
                    data3 = [['', 'T.Q. (kg)', 'DM (kg)', 'CP (g)', 'FG (g)', 'NDF (g)', 'ADF (g)', 'FAT (g)', 'AM (g)', 'ZUC (g)', 'Ca (g)', 'P (g)', 'UFL', 'PDI (g)'], [alimenti[0], quantita[0], apporti_1[0], apporti_1[1], apporti_1[2], apporti_1[3], apporti_1[4], apporti_1[5], apporti_1[6], apporti_1[7], apporti_1[8], apporti_1[9], apporti_1[10], apporti_1[11]], [alimenti[1], quantita[1], apporti_2[0], apporti_2[1], apporti_2[2], apporti_2[3], apporti_2[4], apporti_2[5], apporti_2[6], apporti_2[7], apporti_2[8], apporti_2[9], apporti_2[10], apporti_2[11]], [alimenti[2], quantita[2], apporti_3[0], apporti_3[1], apporti_3[2], apporti_3[3], apporti_3[4], apporti_3[5], apporti_3[6], apporti_3[7], apporti_3[8], apporti_3[9], apporti_3[10], apporti_3[11]], [alimenti[3], quantita[3], apporti_4[0], apporti_4[1], apporti_4[2], apporti_4[3], apporti_4[4], apporti_4[5], apporti_4[6], apporti_4[7], apporti_4[8], apporti_4[9], apporti_4[10], apporti_4[11]], [alimenti[4], quantita[4], apporti_5[0], apporti_5[1], apporti_5[2], apporti_5[3], apporti_5[4], apporti_5[5], apporti_5[6], apporti_5[7], apporti_5[8], apporti_5[9], apporti_5[10], apporti_5[11]], [alimenti[5], quantita[5], apporti_6[0], apporti_6[1], apporti_6[2], apporti_6[3], apporti_6[4], apporti_6[5], apporti_6[6], apporti_6[7], apporti_6[8], apporti_6[9], apporti_6[10], apporti_6[11]], [alimenti[6], quantita[6], apporti_7[0], apporti_7[1], apporti_7[2], apporti_7[3], apporti_7[4], apporti_7[5], apporti_7[6], apporti_7[7], apporti_7[8], apporti_7[9], apporti_7[10], apporti_7[11]], [alimenti[7], quantita[7], apporti_8[0], apporti_8[1], apporti_8[2], apporti_8[3], apporti_8[4], apporti_8[5], apporti_8[6], apporti_8[7], apporti_8[8], apporti_8[9], apporti_8[10], apporti_8[11]], [alimenti[8], quantita[8], apporti_9[0], apporti_9[1], apporti_9[2], apporti_9[3], apporti_9[4], apporti_9[5], apporti_9[6], apporti_9[7], apporti_9[8], apporti_9[9], apporti_9[10], apporti_9[11]], ['TOTALE', quantita_TOT, ADMr, ACPr, AFGr, ANDFr, AADFr, AFATr, AAMr, AZUCr, ACar, APr, AUFLr, APDIr]]

            

                F = re.findall(r"[+-]?\d+(?:\.\d+)?", open('FABBISOGNI_PyR_%s.txt' % nome_file_razione).read())
                
                for i in range(len(F)):
                    F[i] = float(F[i])
    
                F_SS = F[0]
                F_UFL = F[10]
                for i in range(len(F)):
                    F[i] = F[i]/1000
    
                F[0] = F_SS
                F[10] = F_UFL

                for i in range(len(F)):
                    F[i] = round(F[i], 1)

                A = re.findall(r"[+-]?\d+(?:\.\d+)?", open('APPORTI_PyR_%s.txt' % nome_file_razione).read())
                print(A)

                for i in range(len(A)):
                    A[i] = float(A[i])

                A_SS = A[0]
                A_UFL = A[10]
                for i in range(len(A)):
                    A[i] = A[i]/1000
   
                A[0] = A_SS
                A[10] = A_UFL

                for i in range(len(A)):
                    A[i] = round(A[i], 1)

                labels = ['DM', 'CP', 'FG', 'NDF', 'ADF', 'FAT', 'AM', 'ZUC', 'Ca', 'P', 'UFL', 'PDI']
	
                x = np.arange(len(labels))

                width = 0.35
                fig, ax = plt.subplots()
                rects1 = ax.bar(x - width/2, F, width, label='Fabbisogni')
                rects2 = ax.bar(x + width/2, A, width, label='Apporti')

                ax.set_ylabel('kg (o UFL)')
                ax.set_title('FABBISOGNI vs APPORTI')
                ax.set_xticks(x, labels)
                ax.legend()
                ax.bar_label(rects1, padding=3)
                ax.bar_label(rects2, padding=3)
                fig.tight_layout()
                plt.savefig('BARPLOT_PyR_%s.png' % nome_file_razione, dpi=400)


                barplot = "BARPLOT_PyR_%s.png" % nome_file_razione
                im2 = Image(barplot, 7.8*inch, 4.5*inch)
                flowables.append(spacer)   
                flowables.append(im2)
                flowables.append(spacer)
                flowables.append(PageBreak())


                testo = '<b>TABELLA COSTI</b>'
                styles = getSampleStyleSheet()
                styles.add(ParagraphStyle(name='Parametri', alignment=TA_CENTER))
                styles["Parametri"].fontSize = 24
                styles["Parametri"].leading = 14
                spacer = Spacer(1, 1.0*inch)
                flowables.append(Paragraph(testo, styles["Parametri"]))      
                flowables.append(spacer)                


#               tbl2 = Table(data2, hAlign='LEFT')
#               tbl2.setStyle(stile_intestazione_2)
#               tbl2.setStyle(tblstyle_2)
#               tbl2.setStyle(stile_griglia)
#               flowables.append(tbl2)
#               flowables.append(PageBreak())
#       	flowables.append(Spacer(inch, 0.5*inch))





######################################################## SOSTANZA SECCA ########################################################


        testo = '<b>SOSTANZA SECCA</b>'
        styles = getSampleStyleSheet()
        styles.add(ParagraphStyle(name='Parametri', alignment=TA_CENTER))
        styles["Parametri"].fontSize = 20
        styles["Parametri"].leading = 14
        spacer = Spacer(1, 0.5*inch)
        flowables.append(Paragraph(testo, styles["Parametri"]))      
        flowables.append(spacer)
        
       
        styles["Normal"].fontSize = 16
        styles["Normal"].leading = 20
        spacer = Spacer(1, 0.5*inch)


        testo = 'La razione fornisce %f kg di ALIMENTO TAL QUALE' % quantita_TOT
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)
        
        testo = 'La razione fornisce %f kg di SOSTANZA SECCA' % ADMr
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)
        flowables.append(spacer)
        
        DMI_AS_FED_ratio = round((ADMr/quantita_TOT)*100, 4)

        testo = 'La tua RAZIONE contiene il %fx100 di SOSTANZA SECCA' % DMI_AS_FED_ratio
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)
        flowables.append(spacer)
        
        if DMI_AS_FED_ratio < 66.0:
            testo = "In estate, in caso di COMPETIZIONE ALIMENTARE x un <font name=helvetica size=16 color=red>N° INSUFFICIENTE DI AUTOCATTURANTI</font> (= BOVINE IN PIEDI), se prepari un CARRO MISCELATORE con, per es., un 10% in più di razioni (per es., con 100 BOVINE IN LATTAZIONE metto nel carro 110 RAZIONI), dal momento che la miscelata rimarrà per più tempo in mangiatoia, potrebbe scaldarsi! Prova a RIDURRE UN PO' L'APPORTO COMPLESSIVO DI INSILATO, per aumentare la SS della razione, O DI FIENO (dipende da che tipo di foraggio hai inserito manualmente), per forzare il programma ad AUMENTARE L'APPORTO DELLA FONTE DI FIBRA DIGERIBILE. In questo modo, si dovrebbe attenuare la riduzione dell'ingestione volontaria di fibra scarsamente digeribile (poiché più o meno lignificata), la quale produce molto calore di fermentazione nel rumine, nonché il conseguente CALO DEL TENORE IN GRASSO del latte. Tieni anche conto del fatto che, riducendo l'apporto della cosiddetta «FIBRA FISICAMENTE EFFICACE» (quella dei foraggi, che fa ruminare), <font name=helvetica size=16 color=red>LE BOVINE PRODURRANNO MENO SALIVA</font> (che è il tampone naturale del rumine) e, quindi, dovrai valutare l'inserimento di un TAMPONE ARTIFICIALE, come il <b>bicarbonato di sodio</b> (100-200 g al giorno per capo), nella razione."
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)
            flowables.append(spacer)                
        


################################################## PROTEINA GREZZA #######################################################        


        testo = '<b>PROTEINA GREZZA</b>'
        styles = getSampleStyleSheet()
        styles.add(ParagraphStyle(name='Parametri', alignment=TA_CENTER))
        styles["Parametri"].fontSize = 20
        styles["Parametri"].leading = 14
        spacer = Spacer(1, 0.5*inch)
        flowables.append(Paragraph(testo, styles["Parametri"]))      
        flowables.append(spacer)
        
       
        styles["Normal"].fontSize = 16
        styles["Normal"].leading = 20
        spacer = Spacer(1, 0.5*inch)

        
        CPI_DMI_ratio = round((ACPr/ADMr)/10, 4)
        
        testo = 'Rapporto (PROTEINA GREZZA : SOSTANZA SECCA) => %fx100' % CPI_DMI_ratio
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)
#       flowables.append(spacer)
        
        if CPI_DMI_ratio > 17.5 and CPI_DMI_ratio < 18.5:
            testo = "<font name=helvetica size=16 color=green>Eccellente! (ad inizio lattazione dovrebbe essere ~ 0.18 (18%)</font>"
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)
            flowables.append(spacer) 
        
        elif CPI_DMI_ratio < 17.5 and 'SOIA F.E. 45x100' not in alimenti and 'SOIA F.E. 50x100' not in alimenti:
            testo = "<font name=helvetica size=16 color=red>La quantita di PROTEINA GREZZA fornita dalla razione è INSUFFICIENTE!</font> Prova ad aumentare l'apporto della FONTE PROTEICA principale o a sostituirla con la FARINA DI ESTRAZIONE DI SOIA 50% <font name=helvetica size=16 color=red>(in questo caso, però, l'ECCESSO DI LISINA sarà ancora più accentuato!)</font> Se non basta, sostituisci una parte del foraggio (fieno o insilato), che hai inserito, con il FIENO DI ERBA MEDICA."
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)
            flowables.append(spacer)         

        elif CPI_DMI_ratio < 17.5 and 'SOIA F.E. 45x100' not in alimenti and 'SOIA F.E. 50x100' not in alimenti and 'FIENO MEDICA I TAGLIO' not in alimenti and 'FIENO MEDICA II TAGLIO' not in alimenti:
            testo = "<font name=helvetica size=16 color=red>La quantita di PROTEINA GREZZA fornita dalla razione è INSUFFICIENTE!</font> Prova ad aumentare l'apporto della FONTE PROTEICA principale o a sostituirla con la FARINA DI ESTRAZIONE DI SOIA 50% <font name=helvetica size=16 color=red>(in questo caso, però, l'ECCESSO DI LISINA sarà ancora più accentuato!)</font> Se non basta, sostituisci una parte del foraggio (fieno o insilato), che hai inserito, con il FIENO DI ERBA MEDICA."
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)
            flowables.append(spacer)  

        elif CPI_DMI_ratio > 18.5 and 'SOIA F.E. 45x100' in alimenti or 'SOIA F.E. 50x100' in alimenti:
            testo = "<font name=helvetica size=16 color=red>La quantita di PROTEINA GREZZA fornita dalla razione è ECCESSIVA!</font> Riduci l'apporto di FARINA DI ESTRAZIONE DI SOIA e, se non basta, sostituiscila con una fonte proteica che apporti una quantita di proteina <."
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)
            flowables.append(spacer)        

        elif CPI_DMI_ratio > 18.5 and 'SOIA F.E. 45x100' in alimenti or 'SOIA F.E. 50x100' in alimenti and 'FIENO MEDICA I TAGLIO' in alimenti or 'FIENO MEDICA II TAGLIO' in alimenti:
            testo = "<font name=helvetica size=16 color=red>La quantita di PROTEINA GREZZA fornita dalla razione è ECCESSIVA!</font> Riduci l'apporto di FARINA DI ESTRAZIONE DI SOIA e, se non basta, sostituiscila con una fonte proteica che apporti una quantita di proteina < e/o sostituisci il FIENO DI MEDICA con un foraggio di graminacee."
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)
            flowables.append(spacer)                  

        elif CPI_DMI_ratio > 18.5 and 'SOIA F.E. 45x100' not in alimenti or 'SOIA F.E. 50x100' not in alimenti and 'FIENO MEDICA I TAGLIO' in alimenti or 'FIENO MEDICA II TAGLIO' in alimenti:
            testo = "<font name=helvetica size=16 color=red>La quantita di PROTEINA GREZZA fornita dalla razione è ECCESSIVA!</font> Riduci l'apporto di FARINA DI ESTRAZIONE e, se non basta, sostituiscila con una fonte proteica che apporti una quantita di proteina < e/o sostituisci il FIENO DI MEDICA con un foraggio di graminacee"
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)
            flowables.append(spacer)        
        


################################################## LISINA e METIONINA #######################################################

        testo = '<b>LISINA E METIONINA</b>'
        styles = getSampleStyleSheet()
        styles.add(ParagraphStyle(name='Parametri', alignment=TA_CENTER))
        styles["Parametri"].fontSize = 20
        styles["Parametri"].leading = 14
        spacer = Spacer(1, 0.5*inch)
        flowables.append(Paragraph(testo, styles["Parametri"]))      
        flowables.append(spacer)
        
       
        styles["Normal"].fontSize = 16
        styles["Normal"].leading = 20
        spacer = Spacer(1, 0.5*inch)

        
        testo = "Rapporto (LISINA / PROTEINA DIGERIBILE) => %f" % LysDI_ratio
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)
        flowables.append(spacer)

        testo = "Rapporto (METIONINA / PROTEINA DIGERIBILE) => %f" % MetDI_ratio
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)
        flowables.append(spacer)

        testo = "Rapporto (LISINA / METIONINA) => %f" % LYS_MET_ratio
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)
        flowables.append(spacer)

        testo = "Dovrebbe essere > 2.7 e < 3.0"
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)
        flowables.append(spacer)
        
        if LYS_MET_ratio >= 3.0:
            testo = "<font name=helvetica size=16 color=red>La tua RAZIONE contiene un eccesso di LISINA!</font>"
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)
            flowables.append(spacer)
            testo = "Se hai scelto come FONTE DI PROTEINA un alimento CARENTE DI METIONINA, prova a sostituirlo con la <b>FARINA DI ESTRAZIONE DI GIRASOLE</b>"
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)
            flowables.append(spacer)                      
        else:
            testo = "<font name=helvetica size=16 color=green>ECCELLENTE! Il rapporto LISINA / METIONINA dovrebbe essere < 3.0</font>"
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)
            flowables.append(spacer)        



################################################## PDIN e PDIE #######################################################


        testo = '<b>PDIN E PDIE</b>'
        styles = getSampleStyleSheet()
        styles.add(ParagraphStyle(name='Parametri', alignment=TA_CENTER))
        styles["Parametri"].fontSize = 20
        styles["Parametri"].leading = 14
        spacer = Spacer(1, 0.5*inch)
        flowables.append(Paragraph(testo, styles["Parametri"]))      
        flowables.append(spacer)
        
       
        styles["Normal"].fontSize = 16
        styles["Normal"].leading = 20
        spacer = Spacer(1, 0.5*inch)


        testo = "Per ottenere una sintesi ottimale di proteina microbica ed una soddisfacente digeribilità della razione, la flora microbica deve disporre nello stesso tempo di una quantita minima di energia fermentescibile e di sostanze azotate degradabili nel rumine, vale a dire di un apporto di PDIE uguale a quello di PDIN. Questo obiettivo è difficile da conseguire nella pratica, ma è possibile avvicinarsi ad esso. Perciò, si calcola il rapporto:"
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)
        flowables.append(spacer)

        testo = "<b>Rmic = (PDIN – PDIE)/UFL</b>"
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)
        flowables.append(spacer)
        
        BFR = arrotonda((PDIN_TOT - PDIE_TOT)/AUFL)

        testo = "La RAZIONE fornisce %f g di PDIN" % PDIN_TOT
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)
        flowables.append(spacer)

        testo = "La RAZIONE fornisce %f g di PDIE" % PDIE_TOT
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)
        flowables.append(spacer)

        testo = 'Rmic = %f' % BFR
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)
        flowables.append(spacer)
        
        if BFR >= -17:
            testo = "<font name=helvetica size=16 color=green>La razione è accettabile</font>"
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)
            flowables.append(spacer)
        else:        
            testo = "<font name=helvetica size=16 color=red>La razione non è accettabile</font>"
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)
            flowables.append(spacer)            



################################################## FIBRA GREZZA #######################################################        


        testo = '<b>FIBRA GREZZA</b>'
        styles = getSampleStyleSheet()
        styles.add(ParagraphStyle(name='Parametri', alignment=TA_CENTER))
        styles["Parametri"].fontSize = 20
        styles["Parametri"].leading = 14
        spacer = Spacer(1, 0.5*inch)
        flowables.append(Paragraph(testo, styles["Parametri"]))      
        flowables.append(spacer)
        
       
        styles["Normal"].fontSize = 16
        styles["Normal"].leading = 20
        spacer = Spacer(1, 0.5*inch)
        
        FG_DMI_ratio = arrotonda(AFG/(ADM*1000))

        testo = 'Rapporto (FIBRA GREZZA : Sostanza Secca) => %f' % FG_DMI_ratio
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)
        flowables.append(spacer)
        
        testo = 'Dovrebbe essere ~ 0.17 (17%)'
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)
        flowables.append(spacer)


############################################## TABELLA APPORTI ALIMENTI #######################################################
        
        flowables.append(NextPageTemplate('landscape'))
        flowables.append(PageBreak())       

        

# Change to landscape orientation
#       flowables.append(NextPageTemplate('landscape'))
        flowables.append(Spacer(inch, 3*inch))
        testo = '<b>APPORTI DEI SINGOLI ALIMENTI</b>'
        styles = getSampleStyleSheet()
        styles.add(ParagraphStyle(name='Parametri', alignment=TA_CENTER))
        styles["Parametri"].fontSize = 24
        styles["Parametri"].leading = 14
        spacer = Spacer(1, 0.5*inch)
        flowables.append(Paragraph(testo, styles["Parametri"]))      
        flowables.append(spacer)
        

        
        flowables.append(Spacer(inch, 0.5*inch))
        tbl3 = Table(data3, hAlign='LEFT')
        tbl3.setStyle(stile_intestazione_3)
#       tbl3.setStyle(tblstyle_3)
        tbl3.setStyle(stile_griglia)
        flowables.append(tbl3)
        flowables.append(PageBreak())


############################################################ NOTE ############################################################


        testo = '<b>NOTE</b>'
        styles = getSampleStyleSheet()
        styles.add(ParagraphStyle(name='Parametri', alignment=TA_CENTER))
        styles["Parametri"].fontSize = 20
        styles["Parametri"].leading = 14
        spacer = Spacer(1, 0.5*inch)
        flowables.append(Paragraph(testo, styles["Parametri"]))      
        flowables.append(spacer)
        
       
        styles["Normal"].fontSize = 16
        styles["Normal"].leading = 20
        spacer = Spacer(1, 0.5*inch)

        testo = "STAMP. MAIUSC. => ALIMENTI INSERITI MANUALMENTE (quantita indicate dall'utente)"
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)
        flowables.append(spacer)        

        testo = 'stamp. minusc. => alimenti inseriti automaticamente (quantita calcolate dal programma)'
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)
        flowables.append(spacer)                

        testo = "<font name=helvetica size=16 color=red>N.B. L'apporto di ZUCCHERI è sottostimato per mancanza di dati sulla composizione dei fieni</font>"
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)
        flowables.append(spacer)      
   
        doc.build(flowables)





############################################################################################################################################################################
############################################################################# METODO <_CNCPS_> #############################################################################
############################################################################################################################################################################



    elif metodo == '_CNCPS_':

        F = re.findall(r"[+-]?\d+(?:\.\d+)?", open('FABBISOGNI_PyR_%s.txt' % nome_file_razione).read())
        
        for i in range(len(F)):
            F[i] = float(F[i])
    
        F_SS = F[0]
        F_UFL = F[12]
        for i in range(len(F)):
            F[i] = F[i]/1000
    
        F[0] = F_SS
        F[12] = F_UFL

        for i in range(len(F)):
            F[i] = round(F[i], 1)

        A = re.findall(r"[+-]?\d+(?:\.\d+)?", open('APPORTI_PyR_%s.txt' % nome_file_razione).read())
        print(A)

        for i in range(len(A)):
            A[i] = float(A[i])

        A_SS = A[0]
        A_UFL = A[12]
        for i in range(len(A)):
            A[i] = A[i]/1000
   
        A[0] = A_SS
        A[12] = A_UFL

        for i in range(len(A)):
            A[i] = round(A[i], 1)

        labels = ['DM', 'CP', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'AM', 'ZUC', 'Ca', 'P', 'UFL']
	
        x = np.arange(len(labels))

        width = 0.35
        fig, ax = plt.subplots()
        rects1 = ax.bar(x - width/2, F, width, label='Fabbisogni')
        rects2 = ax.bar(x + width/2, A, width, label='Apporti')

        ax.set_ylabel('kg (o UFL)')
        ax.set_title('FABBISOGNI vs APPORTI')
        ax.set_xticks(x, labels)
        ax.legend()
        ax.bar_label(rects1, padding=3)
        ax.bar_label(rects2, padding=3)
        fig.tight_layout()
        plt.savefig('BARPLOT_PyR_%s.png' % nome_file_razione, dpi=400)
#       plt.show()


# if Path("PARAMETRI_PyR_%s.txt" % nome_file_parametri).exists():
#   print('PARAMETRI letti dal FILE DI TESTO <PARAMETRI_PyR_%s.txt> con successo!' % nome_file_parametri)
     
#   TESTO_P = open('PARAMETRI_PyR_%s.txt' % nome_file_parametri).read()
#   metodo = TESTO_P[20:27]
#   Parametri_decimali = re.findall('[\d]*[.][\d]+', open('PARAMETRI_PyR_%s.txt' % nome_file_parametri).read())
#   Parametri_interi = re.findall('\d+', open('PARAMETRI_PyR_%s.txt' % nome_file_parametri).read())
#   data_di_inserimento = TESTO_P[0:10]
#   ora_di_inserimento = TESTO_P[11:19]
#   gruppo = TESTO_P[28]
    
#   PARAMETRI_GENERALI = []
#   PARAMETRI_GENERALI.append(metodo)

# if TESTO_P[20:27] == '_CNCPS_':
#   metodo = '_CNCPS_'
#   LW = float(Parametri_decimali[0])
#   WOL = int(Parametri_interi[8])
#   MY = float(Parametri_decimali[1])
#   FAT_milk = float(Parametri_decimali[2])
#   CP_milk = float(Parametri_decimali[3])
#   LAC_milk = float(Parametri_decimali[4])
#   PREZZO_MAX = float(Parametri_decimali[5])
#   N_repl = int(Parametri_interi[19])        

        titolo = '<b>PARAMETRI_PyR_%s</b>' % nome_file_parametri
        styles = getSampleStyleSheet()
        styles.add(ParagraphStyle(name='Parametri', alignment=TA_CENTER))
        styles["Parametri"].fontSize = 18
        styles["Parametri"].leading = 14
        spacer = Spacer(1, 0.4*inch)
        flowables.append(spacer)
        flowables.append(Paragraph(titolo, styles["Parametri"]))
        spacer = Spacer(1, 0.5*inch)
        flowables.append(spacer)
        
        styles["Normal"].fontSize = 16
        styles["Normal"].leading = 20

        text = "METODO DI CALCOLO della razione => <font name=helvetica size=16 color=red>%s</font>" % metodo
        para = Paragraph(text, style=styles["Normal"])
        flowables.append(para)  
    
        testo = 'PESO VIVO MEDIO BOVINE IN LATTAZIONE => %f kg' % LW
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)

        testo = 'SETTIMANA DI LATTAZIONE media => %d^' % WOL
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)

        testo = 'LIVELLO PRODUTTIVO medio => %f kg di latte al giorno' % MY
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)

        testo = 'TENORE DI GRASSO del latte => %fx100' % FAT_milk
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)

        testo = 'TENORE DI PROTEINA del latte => %fx100' % CP_milk
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)

        testo = 'TENORE DI LATTOSIO del latte => %fx100' % LAC_milk
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)

        testo = 'N° DI REPLICHE => %d' % N_repl
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)
        

        if Path("FABBISOGNI_PyR_%s.txt" % nome_file_razione).exists():
#       TESTO_F = open('nome_file_fabbisogni.txt').read()
#       nome_file_fabbisogni = TESTO_F[0:(len(TESTO_F)-1)]
            Fabbisogni_decimali = re.findall('[\d]*[.][\d]+', open("FABBISOGNI_PyR_%s.txt" % nome_file_razione).read())

            DMI = float(Fabbisogni_decimali[0])
            CP = float(Fabbisogni_decimali[1])
            RDP = float(Fabbisogni_decimali[2])
            RUP = float(Fabbisogni_decimali[3])
            FG = float(Fabbisogni_decimali[4])
            NDF = float(Fabbisogni_decimali[5])
            ADF = float(Fabbisogni_decimali[6])
            FAT = float(Fabbisogni_decimali[7])
            AM = float(Fabbisogni_decimali[8])
            ZUC = float(Fabbisogni_decimali[9])
            Ca = float(Fabbisogni_decimali[10])
            P = float(Fabbisogni_decimali[11])
            UFL = float(Fabbisogni_decimali[12])

            
            DMIr = arrotonda(DMI)
            CPr = arrotonda(CP)
            RDPr = arrotonda(RDP)
            RUPr = arrotonda(RUP)
            FGr = arrotonda(FG)
            NDFr = arrotonda(NDF)
            ADFr = arrotonda(ADF)
            FATr = arrotonda(FAT)
            AMr = arrotonda(AM)
            ZUCr = arrotonda(ZUC)
            Car = arrotonda(Ca)
            Pr = arrotonda(P)
            UFLr = arrotonda(UFL)
            

            testo = '**********************************************************************'
            para = Paragraph(testo, style=styles["Normal"])
            spacer = Spacer(1, 0.4*inch)
            flowables.append(spacer)
            flowables.append(para)
            flowables.append(PageBreak())


            testo = '<b>FABBISOGNI_PyR_%s</b>' % nome_file_razione
            styles = getSampleStyleSheet()
            styles.add(ParagraphStyle(name='Parametri', alignment=TA_CENTER))
            styles["Parametri"].fontSize = 18
            styles["Parametri"].leading = 14
            spacer = Spacer(1, 0.4*inch)
            flowables.append(spacer)
            flowables.append(Paragraph(testo, styles["Parametri"]))
            spacer = Spacer(1, 0.5*inch)
            flowables.append(spacer)

            
            styles["Normal"].fontSize = 16
            styles["Normal"].leading = 20


            testo = 'CAPACITÀ DI INGESTIONE => %f kg di SOSTANZA SECCA' % DMI
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'PROTEINA GREZZA => %f g' % CP
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'PROTEINA DEGRADABILE => %f g' % RDP
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'PROTEINA INDEGRADABILE => %f g' % RUP
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'FIBRA GREZZA => %f g' % FG
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'Fibra resistente al Detergente Neutro (NDF) => %f g' % NDF
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'Fibra resistente al Detergente Acido (ADF) => %f g' % ADF
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'GRASSO GREZZO => %f g' % FAT
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'AMIDO => %f g' % AM
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'ZUCCHERI => %f g' % ZUC
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'CALCIO => %f g' % Ca
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'FOSFORO => %f g' % P
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'ENERGIA NETTA => %f UFL' % UFL
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)



        if Path("nome_file_apporti.txt").exists():
#       TESTO_A = open('nome_file_apporti.txt').read()
#       nome_file_apporti = TESTO_A[0:(len(TESTO_A)-1)]
            Apporti_decimali = re.findall('[\d]*[.][\d]+', open("APPORTI_PyR_%s.txt" % nome_file_razione).read())

            ADM = float(Apporti_decimali[0])
            ACP = float(Apporti_decimali[1])
            ARDP = float(Apporti_decimali[2])
            ARUP = float(Apporti_decimali[3])
            AFG = float(Apporti_decimali[4])
            ANDF = float(Apporti_decimali[5])
            AADF = float(Apporti_decimali[6])
            AFAT = float(Apporti_decimali[7])
            AAM = float(Apporti_decimali[8])
            AZUC = float(Apporti_decimali[9])
            ACa = float(Apporti_decimali[10])
            AP = float(Apporti_decimali[11])
            AUFL = float(Apporti_decimali[12])           

    
            ADMr = arrotonda(ADM)
            ACPr = arrotonda(ACP)
            ARDPr = arrotonda(ARDP)
            ARUPr = arrotonda(ARUP)
            AFGr = arrotonda(AFG)
            ANDFr = arrotonda(ANDF)
            AADFr = arrotonda(AADF)
            AFATr = arrotonda(AFAT)
            AAMr = arrotonda(AAM)
            AZUCr = arrotonda(AZUC)
            ACar = arrotonda(ACa)
            APr = arrotonda(AP)
            AUFLr = arrotonda(AUFL)
            

            testo = '**********************************************************************'
            para = Paragraph(testo, style=styles["Normal"])
            spacer = Spacer(1, 0.4*inch)
            flowables.append(spacer)
            flowables.append(para)

            testo = '<b>APPORTI_PyR_%s</b>' % nome_file_razione
            styles = getSampleStyleSheet()
            styles.add(ParagraphStyle(name='Parametri', alignment=TA_CENTER))
            styles["Parametri"].fontSize = 18
            styles["Parametri"].leading = 14
            spacer = Spacer(1, 0.4*inch)
            flowables.append(spacer)
            flowables.append(Paragraph(testo, styles["Parametri"]))
            spacer = Spacer(1, 0.5*inch)
            flowables.append(spacer)

            
            styles["Normal"].fontSize = 16
            styles["Normal"].leading = 20

            testo = 'SOSTANZA SECCA => %f kg' % ADM
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'PROTEINA GREZZA => %f g' % ACP
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'PROTEINA DEGRADABILE => %f g' % ARDP
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'PROTEINA INDEGRADABILE => %f g' % ARUP
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'FIBRA GREZZA => %f g' % AFG
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'Fibra resistente al Detergente Neutro (NDF) => %f g' % ANDF
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'Fibra resistente al Detergente Acido (ADF) => %f g' % AADF
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'GRASSO GREZZO => %f g' % AFAT
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'AMIDO => %f g' % AAM
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'ZUCCHERI => %f g' % AZUC
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'CALCIO => %f g' % ACa
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'FOSFORO => %f g' % AP
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

            testo = 'ENERGIA NETTA => %f UFL' % AUFL
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)

    
            testo = '**********************************************************************'
            para = Paragraph(testo, style=styles["Normal"])
            spacer = Spacer(1, 0.4*inch)
            flowables.append(spacer)
            flowables.append(para)
            flowables.append(PageBreak())


            testo = '<b>TABELLA RIASSUNTIVA</b>'
            styles = getSampleStyleSheet()
            styles.add(ParagraphStyle(name='Parametri', alignment=TA_CENTER))
            styles["Parametri"].fontSize = 24
            styles["Parametri"].leading = 14
            spacer = Spacer(1, 1.0*inch)
            flowables.append(Paragraph(testo, styles["Parametri"]))      
            flowables.append(spacer)

            
            styles["Normal"].fontSize = 16
            styles["Normal"].leading = 20


            stile_intestazione_1 = TableStyle([('FONT', (0, 0), (-1, 0), 'Helvetica', 18)])
            tblstyle_1 = TableStyle([('FONT', (0, 1), (-1, 14), 'Helvetica', 16)])
            stile_griglia = TableStyle([('INNERGRID', (0,0), (-1,-1), 0.25, colors.black), ('BOX', (0,0), (-1,-1), 0.5, colors.black)])
            
            stile_intestazione_2 = TableStyle([('FONT', (0, 0), (-1, 0), 'Helvetica', 18)])
            tblstyle_2 = TableStyle([('FONT', (0, 1), (-1, 14), 'Helvetica', 16)])
            stile_griglia = TableStyle([('INNERGRID', (0,0), (-1,-1), 0.25, colors.black), ('BOX', (0,0), (-1,-1), 0.5, colors.black)])

            stile_intestazione_3 = TableStyle([('FONT', (0, 0), (-1, 0), 'Helvetica', 12)])
            tblstyle_3 = TableStyle([('FONT', (0, 1), (-1, 14), 'Helvetica', 10)])
            stile_griglia = TableStyle([('INNERGRID', (0,0), (-1,-1), 0.25, colors.black), ('BOX', (0,0), (-1,-1), 0.5, colors.black)])
                           
            data1 = [['PRINCIPIO NUTR.', 'APPORTO', 'FABBISOGNO', 'Δ'], ['SOSTANZA SECCA (kg)', ADMr, DMIr, (arrotonda(ADM-DMI))], ['PROTEINA GREZZA (g)', ACPr, CPr, (arrotonda(ACP-CP))], ['PROTEINA DEGRADABILE (g)', ARDPr, RDPr, (arrotonda(ARDP-RDP))], ['PROTEINA INDEGRADABILE (g)', ARUPr, RUPr, (arrotonda(ARUP-RUP))], ['FIBRA GREZZA (g)', AFGr, FGr, (arrotonda(AFG-FG))], ['NDF (g)', ANDFr, NDFr, (arrotonda(ANDF-NDF))], ['ADF (g)', AADFr, ADFr, (arrotonda(AADF-ADF))], ['FAT (g)', AFATr, FATr, (arrotonda(AFAT-FAT))], ['AMIDO (g)', AAMr, AMr, (arrotonda(AAM-AM))], ['ZUCCHERI (g)', AZUCr, ZUCr, (arrotonda(AZUC-ZUC))], ['CALCIO (g)', ACar, Car, (arrotonda(ACa-Ca))], ['FOSFORO (g)', APr, Pr, (arrotonda(AP-P))], ['ENERGIA NETTA (UFL)', AUFLr, UFLr, (arrotonda(AUFL-UFL))]]

    
            tbl1 = Table(data1)
            tbl1.setStyle(stile_intestazione_1)
            tbl1.setStyle(tblstyle_1)
            tbl1.setStyle(stile_griglia)
            flowables.append(tbl1)
            flowables.append(PageBreak())


# eccezione aggiunta il 08.12.2022 per tener conto del caso in cui non sia possibile importare i prezzi
            
            try:    
                from fonte_dati import alimenti, quantita, prezzi

                if len(alimenti) == 5:
    
                    from fonte_dati import COMPOSIZIONE_ITEM_1, COMPOSIZIONE_ITEM_2, COMPOSIZIONE_ITEM_3, COMPOSIZIONE_ITEM_4, COMPOSIZIONE_ITEM_5
    

                    apporti_1 = np.round(np.array([i * quantita[0] for i in COMPOSIZIONE_ITEM_1]), 2)
                    apporti_2 = np.round(np.array([i * quantita[1] for i in COMPOSIZIONE_ITEM_2]), 2)
                    apporti_3 = np.round(np.array([i * quantita[2] for i in COMPOSIZIONE_ITEM_3]), 2)
                    apporti_4 = np.round(np.array([i * quantita[3] for i in COMPOSIZIONE_ITEM_4]), 2)
                    apporti_5 = np.round(np.array([i * quantita[4] for i in COMPOSIZIONE_ITEM_5]), 2)
                
            
                    quantita_TOT = round(sum(quantita[i] for i in range(len(quantita))), 4)   
                    quantita = np.round(quantita, 4)
                
                    prezzi = np.array(prezzi)
                    prezzi = np.divide(prezzi, 1000)
                                           
                    COSTI = np.round(prezzi * quantita, 4)
                    quantita_TOT = np.round(np.sum(np.array(quantita)), 4)
                    COSTO_TOT = np.round(np.sum(COSTI), 4)

                       
#               if prezzi.any():
                    data2 = [['ALIMENTO', 'QUANT.', 'PR. (E/kg)', 'COSTO (E)'], [alimenti[0], quantita[0], prezzi[0], COSTI[0]], [alimenti[1], quantita[1], prezzi[1], COSTI[1]], [alimenti[2], quantita[2], prezzi[2], COSTI[2]], [alimenti[3], quantita[3], prezzi[3], COSTI[3]], [alimenti[4], quantita[4], prezzi[4], COSTI[4]], ['TOTALE', quantita_TOT, '', COSTO_TOT]]
#               else:
#                   print('PREZZI degli alimenti non disponibili')   
              
                    data3 = [['', 'T.Q. (kg)', 'DM (kg)', 'CP (g)', 'RDP (g)', 'RUP (g)', 'FG (g)', 'NDF (g)', 'ADF (g)', 'FAT (g)', 'AM (g)', 'ZUC (g)', 'Ca (g)', 'P (g)', 'UFL'], [alimenti[0], quantita[0], apporti_1[0], apporti_1[1], apporti_1[2], apporti_1[3], apporti_1[4], apporti_1[5], apporti_1[6], apporti_1[7], apporti_1[8], apporti_1[9], apporti_1[10], apporti_1[11], apporti_1[12]], [alimenti[1], quantita[1], apporti_2[0], apporti_2[1], apporti_2[2], apporti_2[3], apporti_2[4], apporti_2[5], apporti_2[6], apporti_2[7], apporti_2[8], apporti_2[9], apporti_2[10], apporti_2[11], apporti_2[12]], [alimenti[2], quantita[2], apporti_3[0], apporti_3[1], apporti_3[2], apporti_3[3], apporti_3[4], apporti_3[5], apporti_3[6], apporti_3[7], apporti_3[8], apporti_3[9], apporti_3[10], apporti_3[11], apporti_3[12]], [alimenti[3], quantita[3], apporti_4[0], apporti_4[1], apporti_4[2], apporti_4[3], apporti_4[4], apporti_4[5], apporti_4[6], apporti_4[7], apporti_4[8], apporti_4[9], apporti_4[10], apporti_4[11], apporti_4[12]], [alimenti[4], quantita[4], apporti_5[0], apporti_5[1], apporti_5[2], apporti_5[3], apporti_5[4], apporti_5[5], apporti_5[6], apporti_5[7], apporti_5[8], apporti_5[9], apporti_5[10], apporti_5[11], apporti_5[12]], ['TOTALE', quantita_TOT, ADMr, ACPr, ARDPr, ARUPr, AFGr, ANDFr, AADFr, AFATr, AAMr, AZUCr, ACar, APr, AUFLr]]
                  


                elif len(alimenti) == 6:
    
                    from fonte_dati import COMPOSIZIONE_ITEM_1, COMPOSIZIONE_ITEM_2, COMPOSIZIONE_ITEM_3, COMPOSIZIONE_ITEM_4, COMPOSIZIONE_ITEM_5, COMPOSIZIONE_ITEM_6
    

                    apporti_1 = np.round(np.array([i * quantita[0] for i in COMPOSIZIONE_ITEM_1]), 2)
                    apporti_2 = np.round(np.array([i * quantita[1] for i in COMPOSIZIONE_ITEM_2]), 2)
                    apporti_3 = np.round(np.array([i * quantita[2] for i in COMPOSIZIONE_ITEM_3]), 2)
                    apporti_4 = np.round(np.array([i * quantita[3] for i in COMPOSIZIONE_ITEM_4]), 2)
                    apporti_5 = np.round(np.array([i * quantita[4] for i in COMPOSIZIONE_ITEM_5]), 2)
                    apporti_6 = np.round(np.array([i * quantita[5] for i in COMPOSIZIONE_ITEM_6]), 2)
                
            
                    quantita_TOT = round(sum(quantita[i] for i in range(len(quantita))), 4)   
                    quantita = np.round(quantita, 4)
                
                    prezzi = np.array(prezzi)
                    prezzi = np.divide(prezzi, 1000)
                                           
                    COSTI = np.round(prezzi * quantita, 4)
                    quantita_TOT = np.round(np.sum(np.array(quantita)), 4)
                    COSTO_TOT = np.round(np.sum(COSTI), 4)

                        
#               if prezzi.any():
                    data2 = [['ALIMENTO', 'QUANT.', 'PR. (E/kg)', 'COSTO (E)'], [alimenti[0], quantita[0], prezzi[0], COSTI[0]], [alimenti[1], quantita[1], prezzi[1], COSTI[1]], [alimenti[2], quantita[2], prezzi[2], COSTI[2]], [alimenti[3], quantita[3], prezzi[3], COSTI[3]], [alimenti[4], quantita[4], prezzi[4], COSTI[4]], [alimenti[5], quantita[5], prezzi[5], COSTI[5]], ['TOTALE', quantita_TOT, '', COSTO_TOT]] 
#               else:
#                   print('PREZZI degli alimenti non disponibili')  
              
                    data3 = [['', 'T.Q. (kg)', 'DM (kg)', 'CP (g)', 'RDP (g)', 'RUP (g)', 'FG (g)', 'NDF (g)', 'ADF (g)', 'FAT (g)', 'AM (g)', 'ZUC (g)', 'Ca (g)', 'P (g)', 'UFL'], [alimenti[0], quantita[0], apporti_1[0], apporti_1[1], apporti_1[2], apporti_1[3], apporti_1[4], apporti_1[5], apporti_1[6], apporti_1[7], apporti_1[8], apporti_1[9], apporti_1[10], apporti_1[11], apporti_1[12]], [alimenti[1], quantita[1], apporti_2[0], apporti_2[1], apporti_2[2], apporti_2[3], apporti_2[4], apporti_2[5], apporti_2[6], apporti_2[7], apporti_2[8], apporti_2[9], apporti_2[10], apporti_2[11], apporti_2[12]], [alimenti[2], quantita[2], apporti_3[0], apporti_3[1], apporti_3[2], apporti_3[3], apporti_3[4], apporti_3[5], apporti_3[6], apporti_3[7], apporti_3[8], apporti_3[9], apporti_3[10], apporti_3[11], apporti_3[12]], [alimenti[3], quantita[3], apporti_4[0], apporti_4[1], apporti_4[2], apporti_4[3], apporti_4[4], apporti_4[5], apporti_4[6], apporti_4[7], apporti_4[8], apporti_4[9], apporti_4[10], apporti_4[11], apporti_4[12]], [alimenti[4], quantita[4], apporti_5[0], apporti_5[1], apporti_5[2], apporti_5[3], apporti_5[4], apporti_5[5], apporti_5[6], apporti_5[7], apporti_5[8], apporti_5[9], apporti_5[10], apporti_5[11], apporti_5[12]], [alimenti[5], quantita[5], apporti_6[0], apporti_6[1], apporti_6[2], apporti_6[3], apporti_6[4], apporti_6[5], apporti_6[6], apporti_6[7], apporti_6[8], apporti_6[9], apporti_6[10], apporti_6[11], apporti_6[12]], ['TOTALE', quantita_TOT, ADMr, ACPr, ARDPr, ARUPr, AFGr, ANDFr, AADFr, AFATr, AAMr, AZUCr, ACar, APr, AUFLr]]


                elif len(alimenti) == 7:
    
                    from fonte_dati import COMPOSIZIONE_ITEM_1, COMPOSIZIONE_ITEM_2, COMPOSIZIONE_ITEM_3, COMPOSIZIONE_ITEM_4, COMPOSIZIONE_ITEM_5, COMPOSIZIONE_ITEM_6, COMPOSIZIONE_ITEM_7
    

                    apporti_1 = np.round(np.array([i * quantita[0] for i in COMPOSIZIONE_ITEM_1]), 2)
                    apporti_2 = np.round(np.array([i * quantita[1] for i in COMPOSIZIONE_ITEM_2]), 2)
                    apporti_3 = np.round(np.array([i * quantita[2] for i in COMPOSIZIONE_ITEM_3]), 2)
                    apporti_4 = np.round(np.array([i * quantita[3] for i in COMPOSIZIONE_ITEM_4]), 2)
                    apporti_5 = np.round(np.array([i * quantita[4] for i in COMPOSIZIONE_ITEM_5]), 2)
                    apporti_6 = np.round(np.array([i * quantita[5] for i in COMPOSIZIONE_ITEM_6]), 2)
                    apporti_7 = np.round(np.array([i * quantita[6] for i in COMPOSIZIONE_ITEM_7]), 2)
            
                    quantita_TOT = round(sum(quantita[i] for i in range(len(quantita))), 4)   
                    quantita = np.round(quantita, 4)
                
                    prezzi = np.array(prezzi)
                    prezzi = np.divide(prezzi, 1000)
                                           
                    COSTI = np.round(prezzi * quantita, 4)
                    quantita_TOT = np.round(np.sum(np.array(quantita)), 4)
                    COSTO_TOT = np.round(np.sum(COSTI), 4)

                        
#               if prezzi.any():
                    data2 = [['ALIMENTO', 'QUANT.', 'PR. (E/kg)', 'COSTO (E)'], [alimenti[0], quantita[0], prezzi[0], COSTI[0]], [alimenti[1], quantita[1], prezzi[1], COSTI[1]], [alimenti[2], quantita[2], prezzi[2], COSTI[2]], [alimenti[3], quantita[3], prezzi[3], COSTI[3]], [alimenti[4], quantita[4], prezzi[4], COSTI[4]], [alimenti[5], quantita[5], prezzi[5], COSTI[5]],[alimenti[6], quantita[6], prezzi[6], COSTI[6]], ['TOTALE', quantita_TOT, '', COSTO_TOT]] 
#               else:
#                   print('PREZZI degli alimenti non disponibili')  
              
                    data3 = [['', 'T.Q. (kg)', 'DM (kg)', 'CP (g)', 'RDP (g)', 'RUP (g)', 'FG (g)', 'NDF (g)', 'ADF (g)', 'FAT (g)', 'AM (g)', 'ZUC (g)', 'Ca (g)', 'P (g)', 'UFL'], [alimenti[0], quantita[0], apporti_1[0], apporti_1[1], apporti_1[2], apporti_1[3], apporti_1[4], apporti_1[5], apporti_1[6], apporti_1[7], apporti_1[8], apporti_1[9], apporti_1[10], apporti_1[11], apporti_1[12]], [alimenti[1], quantita[1], apporti_2[0], apporti_2[1], apporti_2[2], apporti_2[3], apporti_2[4], apporti_2[5], apporti_2[6], apporti_2[7], apporti_2[8], apporti_2[9], apporti_2[10], apporti_2[11], apporti_2[12]], [alimenti[2], quantita[2], apporti_3[0], apporti_3[1], apporti_3[2], apporti_3[3], apporti_3[4], apporti_3[5], apporti_3[6], apporti_3[7], apporti_3[8], apporti_3[9], apporti_3[10], apporti_3[11], apporti_3[12]], [alimenti[3], quantita[3], apporti_4[0], apporti_4[1], apporti_4[2], apporti_4[3], apporti_4[4], apporti_4[5], apporti_4[6], apporti_4[7], apporti_4[8], apporti_4[9], apporti_4[10], apporti_4[11], apporti_4[12]], [alimenti[4], quantita[4], apporti_5[0], apporti_5[1], apporti_5[2], apporti_5[3], apporti_5[4], apporti_5[5], apporti_5[6], apporti_5[7], apporti_5[8], apporti_5[9], apporti_5[10], apporti_5[11], apporti_5[12]], [alimenti[5], quantita[5], apporti_6[0], apporti_6[1], apporti_6[2], apporti_6[3], apporti_6[4], apporti_6[5], apporti_6[6], apporti_6[7], apporti_6[8], apporti_6[9], apporti_6[10], apporti_6[11], apporti_6[12]], [alimenti[6], quantita[6], apporti_7[0], apporti_7[1], apporti_7[2], apporti_7[3], apporti_7[4], apporti_7[5], apporti_7[6], apporti_7[7], apporti_7[8], apporti_7[9], apporti_7[10], apporti_7[11], apporti_7[12]], ['TOTALE', quantita_TOT, ADMr, ACPr, ARDPr, ARUPr, AFGr, ANDFr, AADFr, AFATr, AAMr, AZUCr, ACar, APr, AUFLr]]     


    
                elif len(alimenti) == 8:
    
                    from fonte_dati import COMPOSIZIONE_ITEM_1, COMPOSIZIONE_ITEM_2, COMPOSIZIONE_ITEM_3, COMPOSIZIONE_ITEM_4, COMPOSIZIONE_ITEM_5, COMPOSIZIONE_ITEM_6, COMPOSIZIONE_ITEM_7, COMPOSIZIONE_ITEM_8
    


                    apporti_1 = np.round(np.array([i * quantita[0] for i in COMPOSIZIONE_ITEM_1]), 2)
                    apporti_2 = np.round(np.array([i * quantita[1] for i in COMPOSIZIONE_ITEM_2]), 2)
                    apporti_3 = np.round(np.array([i * quantita[2] for i in COMPOSIZIONE_ITEM_3]), 2)
                    apporti_4 = np.round(np.array([i * quantita[3] for i in COMPOSIZIONE_ITEM_4]), 2)
                    apporti_5 = np.round(np.array([i * quantita[4] for i in COMPOSIZIONE_ITEM_5]), 2)
                    apporti_6 = np.round(np.array([i * quantita[5] for i in COMPOSIZIONE_ITEM_6]), 2)
                    apporti_7 = np.round(np.array([i * quantita[6] for i in COMPOSIZIONE_ITEM_7]), 2)
                    apporti_8 = np.round(np.array([i * quantita[7] for i in COMPOSIZIONE_ITEM_8]), 2)
            
                    quantita_TOT = round(sum(quantita[i] for i in range(len(quantita))), 4)   
                    quantita = np.round(quantita, 4)
                
                    prezzi = np.array(prezzi)
                    prezzi = np.divide(prezzi, 1000)
                                           
                    COSTI = np.round(prezzi * quantita, 4)
                    quantita_TOT = np.round(np.sum(np.array(quantita)), 4)
                    COSTO_TOT = np.round(np.sum(COSTI), 4)

            
#                   if prezzi.any():
                    data2 = [['ALIMENTO', 'QUANT.', 'PR. (E/kg)', 'COSTO (E)'], [alimenti[0], quantita[0], prezzi[0], COSTI[0]], [alimenti[1], quantita[1], prezzi[1], COSTI[1]], [alimenti[2], quantita[2], prezzi[2], COSTI[2]], [alimenti[3], quantita[3], prezzi[3], COSTI[3]], [alimenti[4], quantita[4], prezzi[4], COSTI[4]], [alimenti[5], quantita[5], prezzi[5], COSTI[5]],[alimenti[6], quantita[6], prezzi[6], COSTI[6]], [alimenti[7], quantita[7], prezzi[7], COSTI[7]], ['TOTALE', quantita_TOT, '', COSTO_TOT]]   
#               else:
#                   print('PREZZI degli alimenti non disponibili')
              
                    data3 = [['', 'T.Q. (kg)', 'DM (kg)', 'CP (g)', 'RDP (g)', 'RUP (g)', 'FG (g)', 'NDF (g)', 'ADF (g)', 'FAT (g)', 'AM (g)', 'ZUC (g)', 'Ca (g)', 'P (g)', 'UFL'], [alimenti[0], quantita[0], apporti_1[0], apporti_1[1], apporti_1[2], apporti_1[3], apporti_1[4], apporti_1[5], apporti_1[6], apporti_1[7], apporti_1[8], apporti_1[9], apporti_1[10], apporti_1[11], apporti_1[12]], [alimenti[1], quantita[1], apporti_2[0], apporti_2[1], apporti_2[2], apporti_2[3], apporti_2[4], apporti_2[5], apporti_2[6], apporti_2[7], apporti_2[8], apporti_2[9], apporti_2[10], apporti_2[11], apporti_2[12]], [alimenti[2], quantita[2], apporti_3[0], apporti_3[1], apporti_3[2], apporti_3[3], apporti_3[4], apporti_3[5], apporti_3[6], apporti_3[7], apporti_3[8], apporti_3[9], apporti_3[10], apporti_3[11], apporti_3[12]], [alimenti[3], quantita[3], apporti_4[0], apporti_4[1], apporti_4[2], apporti_4[3], apporti_4[4], apporti_4[5], apporti_4[6], apporti_4[7], apporti_4[8], apporti_4[9], apporti_4[10], apporti_4[11], apporti_4[12]], [alimenti[4], quantita[4], apporti_5[0], apporti_5[1], apporti_5[2], apporti_5[3], apporti_5[4], apporti_5[5], apporti_5[6], apporti_5[7], apporti_5[8], apporti_5[9], apporti_5[10], apporti_5[11], apporti_5[12]], [alimenti[5], quantita[5], apporti_6[0], apporti_6[1], apporti_6[2], apporti_6[3], apporti_6[4], apporti_6[5], apporti_6[6], apporti_6[7], apporti_6[8], apporti_6[9], apporti_6[10], apporti_6[11], apporti_6[12]], [alimenti[6], quantita[6], apporti_7[0], apporti_7[1], apporti_7[2], apporti_7[3], apporti_7[4], apporti_7[5], apporti_7[6], apporti_7[7], apporti_7[8], apporti_7[9], apporti_7[10], apporti_7[11], apporti_7[12]], [alimenti[7], quantita[7], apporti_8[0], apporti_8[1], apporti_8[2], apporti_8[3], apporti_8[4], apporti_8[5], apporti_8[6], apporti_8[7], apporti_8[8], apporti_8[9], apporti_8[10], apporti_8[11], apporti_8[12]], ['TOTALE', quantita_TOT, ADMr, ACPr, ARDPr, ARUPr, AFGr, ANDFr, AADFr, AFATr, AAMr, AZUCr, ACar, APr, AUFLr]]     



                elif len(alimenti) == 9:
    
                    from fonte_dati import COMPOSIZIONE_ITEM_1, COMPOSIZIONE_ITEM_2, COMPOSIZIONE_ITEM_3, COMPOSIZIONE_ITEM_4, COMPOSIZIONE_ITEM_5, COMPOSIZIONE_ITEM_6, COMPOSIZIONE_ITEM_7, COMPOSIZIONE_ITEM_8, COMPOSIZIONE_ITEM_9
    


                    apporti_1 = np.round(np.array([i * quantita[0] for i in COMPOSIZIONE_ITEM_1]), 2)
                    apporti_2 = np.round(np.array([i * quantita[1] for i in COMPOSIZIONE_ITEM_2]), 2)
                    apporti_3 = np.round(np.array([i * quantita[2] for i in COMPOSIZIONE_ITEM_3]), 2)
                    apporti_4 = np.round(np.array([i * quantita[3] for i in COMPOSIZIONE_ITEM_4]), 2)
                    apporti_5 = np.round(np.array([i * quantita[4] for i in COMPOSIZIONE_ITEM_5]), 2)
                    apporti_6 = np.round(np.array([i * quantita[5] for i in COMPOSIZIONE_ITEM_6]), 2)
                    apporti_7 = np.round(np.array([i * quantita[6] for i in COMPOSIZIONE_ITEM_7]), 2)
                    apporti_8 = np.round(np.array([i * quantita[7] for i in COMPOSIZIONE_ITEM_8]), 2)
                    apporti_9 = np.round(np.array([i * quantita[8] for i in COMPOSIZIONE_ITEM_9]), 2)
            
                    quantita_TOT = round(sum(quantita[i] for i in range(len(quantita))), 4)   
                    quantita = np.round(quantita, 4)
                
                    prezzi = np.array(prezzi)
                    prezzi = np.divide(prezzi, 1000)
                                           
                    COSTI = np.round(prezzi * quantita, 4)
                    quantita_TOT = np.round(np.sum(np.array(quantita)), 4)
                    COSTO_TOT = np.round(np.sum(COSTI), 4)

            
#               if prezzi.any():
                    data2 = [['ALIMENTO', 'QUANT.', 'PR. (E/kg)', 'COSTO (E)'], [alimenti[0], quantita[0], prezzi[0], COSTI[0]], [alimenti[1], quantita[1], prezzi[1], COSTI[1]], [alimenti[2], quantita[2], prezzi[2], COSTI[2]], [alimenti[3], quantita[3], prezzi[3], COSTI[3]], [alimenti[4], quantita[4], prezzi[4], COSTI[4]], [alimenti[5], quantita[5], prezzi[5], COSTI[5]],[alimenti[6], quantita[6], prezzi[6], COSTI[6]], [alimenti[7], quantita[7], prezzi[7], COSTI[7]], [alimenti[8], quantita[8], prezzi[8], COSTI[8]], ['TOTALE', quantita_TOT, '', COSTO_TOT]] 
#               else:
#                   print('PREZZI degli alimenti non disponibili')  
              
                    data3 = [['', 'T.Q. (kg)', 'DM (kg)', 'CP (g)', 'RDP (g)', 'RUP (g)', 'FG (g)', 'NDF (g)', 'ADF (g)', 'FAT (g)', 'AM (g)', 'ZUC (g)', 'Ca (g)', 'P (g)', 'UFL'], [alimenti[0], quantita[0], apporti_1[0], apporti_1[1], apporti_1[2], apporti_1[3], apporti_1[4], apporti_1[5], apporti_1[6], apporti_1[7], apporti_1[8], apporti_1[9], apporti_1[10], apporti_1[11], apporti_1[12]], [alimenti[1], quantita[1], apporti_2[0], apporti_2[1], apporti_2[2], apporti_2[3], apporti_2[4], apporti_2[5], apporti_2[6], apporti_2[7], apporti_2[8], apporti_2[9], apporti_2[10], apporti_2[11], apporti_2[12]], [alimenti[2], quantita[2], apporti_3[0], apporti_3[1], apporti_3[2], apporti_3[3], apporti_3[4], apporti_3[5], apporti_3[6], apporti_3[7], apporti_3[8], apporti_3[9], apporti_3[10], apporti_3[11], apporti_3[12]], [alimenti[3], quantita[3], apporti_4[0], apporti_4[1], apporti_4[2], apporti_4[3], apporti_4[4], apporti_4[5], apporti_4[6], apporti_4[7], apporti_4[8], apporti_4[9], apporti_4[10], apporti_4[11], apporti_4[12]], [alimenti[4], quantita[4], apporti_5[0], apporti_5[1], apporti_5[2], apporti_5[3], apporti_5[4], apporti_5[5], apporti_5[6], apporti_5[7], apporti_5[8], apporti_5[9], apporti_5[10], apporti_5[11], apporti_5[12]], [alimenti[5], quantita[5], apporti_6[0], apporti_6[1], apporti_6[2], apporti_6[3], apporti_6[4], apporti_6[5], apporti_6[6], apporti_6[7], apporti_6[8], apporti_6[9], apporti_6[10], apporti_6[11], apporti_6[12]], [alimenti[6], quantita[6], apporti_7[0], apporti_7[1], apporti_7[2], apporti_7[3], apporti_7[4], apporti_7[5], apporti_7[6], apporti_7[7], apporti_7[8], apporti_7[9], apporti_7[10], apporti_7[11], apporti_7[12]], [alimenti[7], quantita[7], apporti_8[0], apporti_8[1], apporti_8[2], apporti_8[3], apporti_8[4], apporti_8[5], apporti_8[6], apporti_8[7], apporti_8[8], apporti_8[9], apporti_8[10], apporti_8[11], apporti_8[12]], [alimenti[8], quantita[8], apporti_9[0], apporti_9[1], apporti_9[2], apporti_9[3], apporti_9[4], apporti_9[5], apporti_9[6], apporti_9[7], apporti_9[8], apporti_9[9], apporti_9[10], apporti_9[11], apporti_9[12]], ['TOTALE', quantita_TOT, ADMr, ACPr, ARDPr, ARUPr, AFGr, ANDFr, AADFr, AFATr, AAMr, AZUCr, ACar, APr, AUFLr]]    


            
                barplot = "BARPLOT_PyR_%s.png" % nome_file_razione
                im2 = Image(barplot, 7.8*inch, 4.5*inch)
                flowables.append(spacer)   
                flowables.append(im2)
                flowables.append(spacer)
                flowables.append(PageBreak())
      

                testo = '<b>TABELLA COSTI</b>'
                styles = getSampleStyleSheet()
                styles.add(ParagraphStyle(name='Parametri', alignment=TA_CENTER))
                styles["Parametri"].fontSize = 24
                styles["Parametri"].leading = 14
                spacer = Spacer(1, 1.0*inch)
                flowables.append(Paragraph(testo, styles["Parametri"]))      
                flowables.append(spacer)        


                tbl2 = Table(data2, hAlign='LEFT')
                tbl2.setStyle(stile_intestazione_2)
                tbl2.setStyle(tblstyle_2)
                tbl2.setStyle(stile_griglia)
                flowables.append(tbl2)
                flowables.append(PageBreak())
#               flowables.append(Spacer(inch, 0.5*inch))
                

            except ImportError:
                print('PREZZI degli alimenti non disponibili')

                if len(alimenti) == 5:
    
                    from fonte_dati import COMPOSIZIONE_ITEM_1, COMPOSIZIONE_ITEM_2, COMPOSIZIONE_ITEM_3, COMPOSIZIONE_ITEM_4, COMPOSIZIONE_ITEM_5
    

                    apporti_1 = np.round(np.array([i * quantita[0] for i in COMPOSIZIONE_ITEM_1]), 2)
                    apporti_2 = np.round(np.array([i * quantita[1] for i in COMPOSIZIONE_ITEM_2]), 2)
                    apporti_3 = np.round(np.array([i * quantita[2] for i in COMPOSIZIONE_ITEM_3]), 2)
                    apporti_4 = np.round(np.array([i * quantita[3] for i in COMPOSIZIONE_ITEM_4]), 2)
                    apporti_5 = np.round(np.array([i * quantita[4] for i in COMPOSIZIONE_ITEM_5]), 2)
                
            
                    quantita_TOT = round(sum(quantita[i] for i in range(len(quantita))), 4)   
                    quantita = np.round(quantita, 4)
                        
#               if prezzi.any():
#                   data2 = [['ALIMENTO', 'QUANT.', 'PR. (E/kg)', 'COSTO (E)'], [alimenti[0], quantita[0], prezzi[0], COSTI[0]], [alimenti[1], quantita[1], prezzi[1], COSTI[1]], [alimenti[2], quantita[2], prezzi[2], COSTI[2]], [alimenti[3], quantita[3], prezzi[3], COSTI[3]], [alimenti[4], quantita[4], prezzi[4], COSTI[4]], ['TOTALE', quantita_TOT, '', COSTO_TOT]]
#               else:
#                   print('PREZZI degli alimenti non disponibili')   
              
                    data3 = [['', 'T.Q. (kg)', 'DM (kg)', 'CP (g)', 'RDP (g)', 'RUP (g)', 'FG (g)', 'NDF (g)', 'ADF (g)', 'FAT (g)', 'AM (g)', 'ZUC (g)', 'Ca (g)', 'P (g)', 'UFL'], [alimenti[0], quantita[0], apporti_1[0], apporti_1[1], apporti_1[2], apporti_1[3], apporti_1[4], apporti_1[5], apporti_1[6], apporti_1[7], apporti_1[8], apporti_1[9], apporti_1[10], apporti_1[11], apporti_1[12]], [alimenti[1], quantita[1], apporti_2[0], apporti_2[1], apporti_2[2], apporti_2[3], apporti_2[4], apporti_2[5], apporti_2[6], apporti_2[7], apporti_2[8], apporti_2[9], apporti_2[10], apporti_2[11], apporti_2[12]], [alimenti[2], quantita[2], apporti_3[0], apporti_3[1], apporti_3[2], apporti_3[3], apporti_3[4], apporti_3[5], apporti_3[6], apporti_3[7], apporti_3[8], apporti_3[9], apporti_3[10], apporti_3[11], apporti_3[12]], [alimenti[3], quantita[3], apporti_4[0], apporti_4[1], apporti_4[2], apporti_4[3], apporti_4[4], apporti_4[5], apporti_4[6], apporti_4[7], apporti_4[8], apporti_4[9], apporti_4[10], apporti_4[11], apporti_4[12]], [alimenti[4], quantita[4], apporti_5[0], apporti_5[1], apporti_5[2], apporti_5[3], apporti_5[4], apporti_5[5], apporti_5[6], apporti_5[7], apporti_5[8], apporti_5[9], apporti_5[10], apporti_5[11], apporti_5[12]], ['TOTALE', quantita_TOT, ADMr, ACPr, ARDPr, ARUPr, AFGr, ANDFr, AADFr, AFATr, AAMr, AZUCr, ACar, APr, AUFLr]]
                  


                elif len(alimenti) == 6:
    
                    from fonte_dati import COMPOSIZIONE_ITEM_1, COMPOSIZIONE_ITEM_2, COMPOSIZIONE_ITEM_3, COMPOSIZIONE_ITEM_4, COMPOSIZIONE_ITEM_5, COMPOSIZIONE_ITEM_6
    

                    apporti_1 = np.round(np.array([i * quantita[0] for i in COMPOSIZIONE_ITEM_1]), 2)
                    apporti_2 = np.round(np.array([i * quantita[1] for i in COMPOSIZIONE_ITEM_2]), 2)
                    apporti_3 = np.round(np.array([i * quantita[2] for i in COMPOSIZIONE_ITEM_3]), 2)
                    apporti_4 = np.round(np.array([i * quantita[3] for i in COMPOSIZIONE_ITEM_4]), 2)
                    apporti_5 = np.round(np.array([i * quantita[4] for i in COMPOSIZIONE_ITEM_5]), 2)
                    apporti_6 = np.round(np.array([i * quantita[5] for i in COMPOSIZIONE_ITEM_6]), 2)
                
            
                    quantita_TOT = round(sum(quantita[i] for i in range(len(quantita))), 4)   
                    quantita = np.round(quantita, 4)
                        
#               if prezzi.any():
#                   data2 = [['ALIMENTO', 'QUANT.', 'PR. (E/kg)', 'COSTO (E)'], [alimenti[0], quantita[0], prezzi[0], COSTI[0]], [alimenti[1], quantita[1], prezzi[1], COSTI[1]], [alimenti[2], quantita[2], prezzi[2], COSTI[2]], [alimenti[3], quantita[3], prezzi[3], COSTI[3]], [alimenti[4], quantita[4], prezzi[4], COSTI[4]], [alimenti[5], quantita[5], prezzi[5], COSTI[5]], ['TOTALE', quantita_TOT, '', COSTO_TOT]] 
#               else:
#                   print('PREZZI degli alimenti non disponibili')  
              
                    data3 = [['', 'T.Q. (kg)', 'DM (kg)', 'CP (g)', 'RDP (g)', 'RUP (g)', 'FG (g)', 'NDF (g)', 'ADF (g)', 'FAT (g)', 'AM (g)', 'ZUC (g)', 'Ca (g)', 'P (g)', 'UFL'], [alimenti[0], quantita[0], apporti_1[0], apporti_1[1], apporti_1[2], apporti_1[3], apporti_1[4], apporti_1[5], apporti_1[6], apporti_1[7], apporti_1[8], apporti_1[9], apporti_1[10], apporti_1[11], apporti_1[12]], [alimenti[1], quantita[1], apporti_2[0], apporti_2[1], apporti_2[2], apporti_2[3], apporti_2[4], apporti_2[5], apporti_2[6], apporti_2[7], apporti_2[8], apporti_2[9], apporti_2[10], apporti_2[11], apporti_2[12]], [alimenti[2], quantita[2], apporti_3[0], apporti_3[1], apporti_3[2], apporti_3[3], apporti_3[4], apporti_3[5], apporti_3[6], apporti_3[7], apporti_3[8], apporti_3[9], apporti_3[10], apporti_3[11], apporti_3[12]], [alimenti[3], quantita[3], apporti_4[0], apporti_4[1], apporti_4[2], apporti_4[3], apporti_4[4], apporti_4[5], apporti_4[6], apporti_4[7], apporti_4[8], apporti_4[9], apporti_4[10], apporti_4[11], apporti_4[12]], [alimenti[4], quantita[4], apporti_5[0], apporti_5[1], apporti_5[2], apporti_5[3], apporti_5[4], apporti_5[5], apporti_5[6], apporti_5[7], apporti_5[8], apporti_5[9], apporti_5[10], apporti_5[11], apporti_5[12]], [alimenti[5], quantita[5], apporti_6[0], apporti_6[1], apporti_6[2], apporti_6[3], apporti_6[4], apporti_6[5], apporti_6[6], apporti_6[7], apporti_6[8], apporti_6[9], apporti_6[10], apporti_6[11], apporti_6[12]], ['TOTALE', quantita_TOT, ADMr, ACPr, ARDPr, ARUPr, AFGr, ANDFr, AADFr, AFATr, AAMr, AZUCr, ACar, APr, AUFLr]]


                elif len(alimenti) == 7:
    
                    from fonte_dati import COMPOSIZIONE_ITEM_1, COMPOSIZIONE_ITEM_2, COMPOSIZIONE_ITEM_3, COMPOSIZIONE_ITEM_4, COMPOSIZIONE_ITEM_5, COMPOSIZIONE_ITEM_6, COMPOSIZIONE_ITEM_7
    

                    apporti_1 = np.round(np.array([i * quantita[0] for i in COMPOSIZIONE_ITEM_1]), 2)
                    apporti_2 = np.round(np.array([i * quantita[1] for i in COMPOSIZIONE_ITEM_2]), 2)
                    apporti_3 = np.round(np.array([i * quantita[2] for i in COMPOSIZIONE_ITEM_3]), 2)
                    apporti_4 = np.round(np.array([i * quantita[3] for i in COMPOSIZIONE_ITEM_4]), 2)
                    apporti_5 = np.round(np.array([i * quantita[4] for i in COMPOSIZIONE_ITEM_5]), 2)
                    apporti_6 = np.round(np.array([i * quantita[5] for i in COMPOSIZIONE_ITEM_6]), 2)
                    apporti_7 = np.round(np.array([i * quantita[6] for i in COMPOSIZIONE_ITEM_7]), 2)
            
                    quantita_TOT = round(sum(quantita[i] for i in range(len(quantita))), 4)   
                    quantita = np.round(quantita, 4)
                        
#               if prezzi.any():
#                   data2 = [['ALIMENTO', 'QUANT.', 'PR. (E/kg)', 'COSTO (E)'], [alimenti[0], quantita[0], prezzi[0], COSTI[0]], [alimenti[1], quantita[1], prezzi[1], COSTI[1]], [alimenti[2], quantita[2], prezzi[2], COSTI[2]], [alimenti[3], quantita[3], prezzi[3], COSTI[3]], [alimenti[4], quantita[4], prezzi[4], COSTI[4]], [alimenti[5], quantita[5], prezzi[5], COSTI[5]],[alimenti[6], quantita[6], prezzi[6], COSTI[6]], ['TOTALE', quantita_TOT, '', COSTO_TOT]] 
#               else:
#                   print('PREZZI degli alimenti non disponibili')  
              
                    data3 = [['', 'T.Q. (kg)', 'DM (kg)', 'CP (g)', 'RDP (g)', 'RUP (g)', 'FG (g)', 'NDF (g)', 'ADF (g)', 'FAT (g)', 'AM (g)', 'ZUC (g)', 'Ca (g)', 'P (g)', 'UFL'], [alimenti[0], quantita[0], apporti_1[0], apporti_1[1], apporti_1[2], apporti_1[3], apporti_1[4], apporti_1[5], apporti_1[6], apporti_1[7], apporti_1[8], apporti_1[9], apporti_1[10], apporti_1[11], apporti_1[12]], [alimenti[1], quantita[1], apporti_2[0], apporti_2[1], apporti_2[2], apporti_2[3], apporti_2[4], apporti_2[5], apporti_2[6], apporti_2[7], apporti_2[8], apporti_2[9], apporti_2[10], apporti_2[11], apporti_2[12]], [alimenti[2], quantita[2], apporti_3[0], apporti_3[1], apporti_3[2], apporti_3[3], apporti_3[4], apporti_3[5], apporti_3[6], apporti_3[7], apporti_3[8], apporti_3[9], apporti_3[10], apporti_3[11], apporti_3[12]], [alimenti[3], quantita[3], apporti_4[0], apporti_4[1], apporti_4[2], apporti_4[3], apporti_4[4], apporti_4[5], apporti_4[6], apporti_4[7], apporti_4[8], apporti_4[9], apporti_4[10], apporti_4[11], apporti_4[12]], [alimenti[4], quantita[4], apporti_5[0], apporti_5[1], apporti_5[2], apporti_5[3], apporti_5[4], apporti_5[5], apporti_5[6], apporti_5[7], apporti_5[8], apporti_5[9], apporti_5[10], apporti_5[11], apporti_5[12]], [alimenti[5], quantita[5], apporti_6[0], apporti_6[1], apporti_6[2], apporti_6[3], apporti_6[4], apporti_6[5], apporti_6[6], apporti_6[7], apporti_6[8], apporti_6[9], apporti_6[10], apporti_6[11], apporti_6[12]], [alimenti[6], quantita[6], apporti_7[0], apporti_7[1], apporti_7[2], apporti_7[3], apporti_7[4], apporti_7[5], apporti_7[6], apporti_7[7], apporti_7[8], apporti_7[9], apporti_7[10], apporti_7[11], apporti_7[12]], ['TOTALE', quantita_TOT, ADMr, ACPr, ARDPr, ARUPr, AFGr, ANDFr, AADFr, AFATr, AAMr, AZUCr, ACar, APr, AUFLr]]     


    
                elif len(alimenti) == 8:
    
                    from fonte_dati import COMPOSIZIONE_ITEM_1, COMPOSIZIONE_ITEM_2, COMPOSIZIONE_ITEM_3, COMPOSIZIONE_ITEM_4, COMPOSIZIONE_ITEM_5, COMPOSIZIONE_ITEM_6, COMPOSIZIONE_ITEM_7, COMPOSIZIONE_ITEM_8
    


                    apporti_1 = np.round(np.array([i * quantita[0] for i in COMPOSIZIONE_ITEM_1]), 2)
                    apporti_2 = np.round(np.array([i * quantita[1] for i in COMPOSIZIONE_ITEM_2]), 2)
                    apporti_3 = np.round(np.array([i * quantita[2] for i in COMPOSIZIONE_ITEM_3]), 2)
                    apporti_4 = np.round(np.array([i * quantita[3] for i in COMPOSIZIONE_ITEM_4]), 2)
                    apporti_5 = np.round(np.array([i * quantita[4] for i in COMPOSIZIONE_ITEM_5]), 2)
                    apporti_6 = np.round(np.array([i * quantita[5] for i in COMPOSIZIONE_ITEM_6]), 2)
                    apporti_7 = np.round(np.array([i * quantita[6] for i in COMPOSIZIONE_ITEM_7]), 2)
                    apporti_8 = np.round(np.array([i * quantita[7] for i in COMPOSIZIONE_ITEM_8]), 2)
            
                    quantita_TOT = round(sum(quantita[i] for i in range(len(quantita))), 4)      
                    quantita = np.round(quantita, 4)
            
#                   if prezzi.any():
#                   data2 = [['ALIMENTO', 'QUANT.', 'PR. (E/kg)', 'COSTO (E)'], [alimenti[0], quantita[0], prezzi[0], COSTI[0]], [alimenti[1], quantita[1], prezzi[1], COSTI[1]], [alimenti[2], quantita[2], prezzi[2], COSTI[2]], [alimenti[3], quantita[3], prezzi[3], COSTI[3]], [alimenti[4], quantita[4], prezzi[4], COSTI[4]], [alimenti[5], quantita[5], prezzi[5], COSTI[5]],[alimenti[6], quantita[6], prezzi[6], COSTI[6]], [alimenti[7], quantita[7], prezzi[7], COSTI[7]], ['TOTALE', quantita_TOT, '', COSTO_TOT]]   
#               else:
#                   print('PREZZI degli alimenti non disponibili')
              
                    data3 = [['', 'T.Q. (kg)', 'DM (kg)', 'CP (g)', 'RDP (g)', 'RUP (g)', 'FG (g)', 'NDF (g)', 'ADF (g)', 'FAT (g)', 'AM (g)', 'ZUC (g)', 'Ca (g)', 'P (g)', 'UFL'], [alimenti[0], quantita[0], apporti_1[0], apporti_1[1], apporti_1[2], apporti_1[3], apporti_1[4], apporti_1[5], apporti_1[6], apporti_1[7], apporti_1[8], apporti_1[9], apporti_1[10], apporti_1[11], apporti_1[12]], [alimenti[1], quantita[1], apporti_2[0], apporti_2[1], apporti_2[2], apporti_2[3], apporti_2[4], apporti_2[5], apporti_2[6], apporti_2[7], apporti_2[8], apporti_2[9], apporti_2[10], apporti_2[11], apporti_2[12]], [alimenti[2], quantita[2], apporti_3[0], apporti_3[1], apporti_3[2], apporti_3[3], apporti_3[4], apporti_3[5], apporti_3[6], apporti_3[7], apporti_3[8], apporti_3[9], apporti_3[10], apporti_3[11], apporti_3[12]], [alimenti[3], quantita[3], apporti_4[0], apporti_4[1], apporti_4[2], apporti_4[3], apporti_4[4], apporti_4[5], apporti_4[6], apporti_4[7], apporti_4[8], apporti_4[9], apporti_4[10], apporti_4[11], apporti_4[12]], [alimenti[4], quantita[4], apporti_5[0], apporti_5[1], apporti_5[2], apporti_5[3], apporti_5[4], apporti_5[5], apporti_5[6], apporti_5[7], apporti_5[8], apporti_5[9], apporti_5[10], apporti_5[11], apporti_5[12]], [alimenti[5], quantita[5], apporti_6[0], apporti_6[1], apporti_6[2], apporti_6[3], apporti_6[4], apporti_6[5], apporti_6[6], apporti_6[7], apporti_6[8], apporti_6[9], apporti_6[10], apporti_6[11], apporti_6[12]], [alimenti[6], quantita[6], apporti_7[0], apporti_7[1], apporti_7[2], apporti_7[3], apporti_7[4], apporti_7[5], apporti_7[6], apporti_7[7], apporti_7[8], apporti_7[9], apporti_7[10], apporti_7[11], apporti_7[12]], [alimenti[7], quantita[7], apporti_8[0], apporti_8[1], apporti_8[2], apporti_8[3], apporti_8[4], apporti_8[5], apporti_8[6], apporti_8[7], apporti_8[8], apporti_8[9], apporti_8[10], apporti_8[11], apporti_8[12]], ['TOTALE', quantita_TOT, ADMr, ACPr, ARDPr, ARUPr, AFGr, ANDFr, AADFr, AFATr, AAMr, AZUCr, ACar, APr, AUFLr]]     



                elif len(alimenti) == 9:
    
                    from fonte_dati import COMPOSIZIONE_ITEM_1, COMPOSIZIONE_ITEM_2, COMPOSIZIONE_ITEM_3, COMPOSIZIONE_ITEM_4, COMPOSIZIONE_ITEM_5, COMPOSIZIONE_ITEM_6, COMPOSIZIONE_ITEM_7, COMPOSIZIONE_ITEM_8, COMPOSIZIONE_ITEM_9
    


                    apporti_1 = np.round(np.array([i * quantita[0] for i in COMPOSIZIONE_ITEM_1]), 2)
                    apporti_2 = np.round(np.array([i * quantita[1] for i in COMPOSIZIONE_ITEM_2]), 2)
                    apporti_3 = np.round(np.array([i * quantita[2] for i in COMPOSIZIONE_ITEM_3]), 2)
                    apporti_4 = np.round(np.array([i * quantita[3] for i in COMPOSIZIONE_ITEM_4]), 2)
                    apporti_5 = np.round(np.array([i * quantita[4] for i in COMPOSIZIONE_ITEM_5]), 2)
                    apporti_6 = np.round(np.array([i * quantita[5] for i in COMPOSIZIONE_ITEM_6]), 2)
                    apporti_7 = np.round(np.array([i * quantita[6] for i in COMPOSIZIONE_ITEM_7]), 2)
                    apporti_8 = np.round(np.array([i * quantita[7] for i in COMPOSIZIONE_ITEM_8]), 2)
                    apporti_9 = np.round(np.array([i * quantita[8] for i in COMPOSIZIONE_ITEM_9]), 2)
            
                    quantita_TOT = round(sum(quantita[i] for i in range(len(quantita))), 4)      
                    quantita = np.round(quantita, 4)
            
#               if prezzi.any():
#                  data2 = [['ALIMENTO', 'QUANT.', 'PR. (E/kg)', 'COSTO (E)'], [alimenti[0], quantita[0], prezzi[0], COSTI[0]], [alimenti[1], quantita[1], prezzi[1], COSTI[1]], [alimenti[2], quantita[2], prezzi[2], COSTI[2]], [alimenti[3], quantita[3], prezzi[3], COSTI[3]], [alimenti[4], quantita[4], prezzi[4], COSTI[4]], [alimenti[5], quantita[5], prezzi[5], COSTI[5]],[alimenti[6], quantita[6], prezzi[6], COSTI[6]], [alimenti[7], quantita[7], prezzi[7], COSTI[7]], [alimenti[8], quantita[8], prezzi[8], COSTI[8]], ['TOTALE', quantita_TOT, '', COSTO_TOT]] 
#               else:
#                   print('PREZZI degli alimenti non disponibili')  
              
                    data3 = [['', 'T.Q. (kg)', 'DM (kg)', 'CP (g)', 'RDP (g)', 'RUP (g)', 'FG (g)', 'NDF (g)', 'ADF (g)', 'FAT (g)', 'AM (g)', 'ZUC (g)', 'Ca (g)', 'P (g)', 'UFL'], [alimenti[0], quantita[0], apporti_1[0], apporti_1[1], apporti_1[2], apporti_1[3], apporti_1[4], apporti_1[5], apporti_1[6], apporti_1[7], apporti_1[8], apporti_1[9], apporti_1[10], apporti_1[11], apporti_1[12]], [alimenti[1], quantita[1], apporti_2[0], apporti_2[1], apporti_2[2], apporti_2[3], apporti_2[4], apporti_2[5], apporti_2[6], apporti_2[7], apporti_2[8], apporti_2[9], apporti_2[10], apporti_2[11], apporti_2[12]], [alimenti[2], quantita[2], apporti_3[0], apporti_3[1], apporti_3[2], apporti_3[3], apporti_3[4], apporti_3[5], apporti_3[6], apporti_3[7], apporti_3[8], apporti_3[9], apporti_3[10], apporti_3[11], apporti_3[12]], [alimenti[3], quantita[3], apporti_4[0], apporti_4[1], apporti_4[2], apporti_4[3], apporti_4[4], apporti_4[5], apporti_4[6], apporti_4[7], apporti_4[8], apporti_4[9], apporti_4[10], apporti_4[11], apporti_4[12]], [alimenti[4], quantita[4], apporti_5[0], apporti_5[1], apporti_5[2], apporti_5[3], apporti_5[4], apporti_5[5], apporti_5[6], apporti_5[7], apporti_5[8], apporti_5[9], apporti_5[10], apporti_5[11], apporti_5[12]], [alimenti[5], quantita[5], apporti_6[0], apporti_6[1], apporti_6[2], apporti_6[3], apporti_6[4], apporti_6[5], apporti_6[6], apporti_6[7], apporti_6[8], apporti_6[9], apporti_6[10], apporti_6[11], apporti_6[12]], [alimenti[6], quantita[6], apporti_7[0], apporti_7[1], apporti_7[2], apporti_7[3], apporti_7[4], apporti_7[5], apporti_7[6], apporti_7[7], apporti_7[8], apporti_7[9], apporti_7[10], apporti_7[11], apporti_7[12]], [alimenti[7], quantita[7], apporti_8[0], apporti_8[1], apporti_8[2], apporti_8[3], apporti_8[4], apporti_8[5], apporti_8[6], apporti_8[7], apporti_8[8], apporti_8[9], apporti_8[10], apporti_8[11], apporti_8[12]], [alimenti[8], quantita[8], apporti_9[0], apporti_9[1], apporti_9[2], apporti_9[3], apporti_9[4], apporti_9[5], apporti_9[6], apporti_9[7], apporti_9[8], apporti_9[9], apporti_9[10], apporti_9[11], apporti_9[12]], ['TOTALE', quantita_TOT, ADMr, ACPr, ARDPr, ARUPr, AFGr, ANDFr, AADFr, AFATr, AAMr, AZUCr, ACar, APr, AUFLr]]    

              
              
                barplot = "BARPLOT_PyR_%s.png" % nome_file_razione
                im2 = Image(barplot, 7.8*inch, 4.5*inch)
                flowables.append(spacer)   
                flowables.append(im2)
                flowables.append(spacer)
                flowables.append(PageBreak())
      

                testo = '<b>TABELLA COSTI</b>'
                styles = getSampleStyleSheet()
                styles.add(ParagraphStyle(name='Parametri', alignment=TA_CENTER))
                styles["Parametri"].fontSize = 24
                styles["Parametri"].leading = 14
                spacer = Spacer(1, 1.0*inch)
                flowables.append(Paragraph(testo, styles["Parametri"]))      
                flowables.append(spacer)        


#               tbl2 = Table(data2, hAlign='LEFT')
#               tbl2.setStyle(stile_intestazione_2)
#               tbl2.setStyle(tblstyle_2)
#               tbl2.setStyle(stile_griglia)
#               flowables.append(tbl2)
#               flowables.append(PageBreak())
#               flowables.append(Spacer(inch, 0.5*inch))


######################################################## SOSTANZA SECCA ########################################################


        testo = '<b>SOSTANZA SECCA</b>'
        styles = getSampleStyleSheet()
        styles.add(ParagraphStyle(name='Parametri', alignment=TA_CENTER))
        styles["Parametri"].fontSize = 20
        styles["Parametri"].leading = 14
        spacer = Spacer(1, 0.5*inch)
        flowables.append(Paragraph(testo, styles["Parametri"]))      
        flowables.append(spacer)
        
       
        styles["Normal"].fontSize = 16
        styles["Normal"].leading = 20
        spacer = Spacer(1, 0.5*inch)


        testo = 'La razione fornisce %f kg di ALIMENTO TAL QUALE' % quantita_TOT
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)
        
        testo = 'La razione fornisce %f kg di SOSTANZA SECCA' % ADMr
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)
        flowables.append(spacer)
        
        DMI_AS_FED_ratio = round((ADMr/quantita_TOT)*100, 4)

        testo = 'La tua RAZIONE contiene il %fx100 di SOSTANZA SECCA' % DMI_AS_FED_ratio
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)
        flowables.append(spacer)
        
        if DMI_AS_FED_ratio < 66.0:
            testo = "In estate, in caso di COMPETIZIONE ALIMENTARE x un <font name=helvetica size=16 color=red>N° INSUFFICIENTE DI AUTOCATTURANTI</font> (= BOVINE IN PIEDI), se prepari un CARRO MISCELATORE con, per es., un 10% in più di razioni (per es., con 100 BOVINE IN LATTAZIONE metto nel carro 110 RAZIONI), dal momento che la miscelata rimarrà per più tempo in mangiatoia, potrebbe scaldarsi! Prova a RIDURRE UN PO' L'APPORTO COMPLESSIVO DI INSILATO, per aumentare la SS della razione, O DI FIENO (dipende da che tipo di foraggio hai inserito manualmente), per forzare il programma ad AUMENTARE L'APPORTO DELLA FONTE DI FIBRA DIGERIBILE. In questo modo, si dovrebbe attenuare la riduzione dell'ingestione volontaria di fibra scarsamente digeribile (poiché più o meno lignificata), la quale produce molto calore di fermentazione nel rumine, nonché il conseguente CALO DEL TENORE IN GRASSO del latte. Tieni anche conto del fatto che, riducendo l'apporto della cosiddetta «FIBRA FISICAMENTE EFFICACE» (quella dei foraggi, che fa ruminare), <font name=helvetica size=16 color=red>LE BOVINE PRODURRANNO MENO SALIVA</font> (che è il tampone naturale del rumine) e, quindi, dovrai valutare l'inserimento di un TAMPONE ARTIFICIALE, come il <b>bicarbonato di sodio</b> (100-200 g al giorno per capo), nella razione."
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)
            flowables.append(spacer)                
        


################################################## PROTEINA GREZZA #######################################################        


        testo = '<b>PROTEINA GREZZA</b>'
        styles = getSampleStyleSheet()
        styles.add(ParagraphStyle(name='Parametri', alignment=TA_CENTER))
        styles["Parametri"].fontSize = 20
        styles["Parametri"].leading = 14
        spacer = Spacer(1, 0.5*inch)
        flowables.append(Paragraph(testo, styles["Parametri"]))      
        flowables.append(spacer)
        
       
        styles["Normal"].fontSize = 16
        styles["Normal"].leading = 20
        spacer = Spacer(1, 0.5*inch)

        
        CPI_DMI_ratio = round((ACPr/ADMr)/10, 4)
        
        testo = 'Rapporto (PROTEINA GREZZA : SOSTANZA SECCA) => %fx100' % CPI_DMI_ratio
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)
#       flowables.append(spacer)
        
        if CPI_DMI_ratio > 17.5 and CPI_DMI_ratio < 18.5:
            testo = "<font name=helvetica size=16 color=green>Eccellente! (ad inizio lattazione dovrebbe essere ~ 0.18 (18%)</font>"
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)
            flowables.append(spacer) 
        
        elif CPI_DMI_ratio < 17.5 and 'SOIA F.E. 45x100' not in alimenti and 'SOIA F.E. 50x100' not in alimenti:
            testo = "<font name=helvetica size=16 color=red>La quantita di PROTEINA GREZZA fornita dalla razione è INSUFFICIENTE!</font> Prova ad aumentare l'apporto della FONTE PROTEICA principale o a sostituirla con la FARINA DI ESTRAZIONE DI SOIA 50% <font name=helvetica size=16 color=red>(in questo caso, però, l'ECCESSO DI LISINA sarà ancora più accentuato!)</font> Se non basta, sostituisci una parte del foraggio (fieno o insilato), che hai inserito, con il FIENO DI ERBA MEDICA."
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)
            flowables.append(spacer)         

        elif CPI_DMI_ratio < 17.5 and 'SOIA F.E. 45x100' not in alimenti and 'SOIA F.E. 50x100' not in alimenti and 'FIENO MEDICA I TAGLIO' not in alimenti and 'FIENO MEDICA II TAGLIO' not in alimenti:
            testo = "<font name=helvetica size=16 color=red>La quantita di PROTEINA GREZZA fornita dalla razione è INSUFFICIENTE!</font> Prova ad aumentare l'apporto della FONTE PROTEICA principale o a sostituirla con la FARINA DI ESTRAZIONE DI SOIA 50% <font name=helvetica size=16 color=red>(in questo caso, però, l'ECCESSO DI LISINA sarà ancora più accentuato!)</font> Se non basta, sostituisci una parte del foraggio (fieno o insilato), che hai inserito, con il FIENO DI ERBA MEDICA."
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)
            flowables.append(spacer)  

        elif CPI_DMI_ratio > 18.5 and 'SOIA F.E. 45x100' in alimenti or 'SOIA F.E. 50x100' in alimenti:
            testo = "<font name=helvetica size=16 color=red>La quantita di PROTEINA GREZZA fornita dalla razione è ECCESSIVA!</font> Riduci l'apporto di FARINA DI ESTRAZIONE DI SOIA e, se non basta, sostituiscila con una fonte proteica che apporti una quantita di proteina <."
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)
            flowables.append(spacer)        

        elif CPI_DMI_ratio > 18.5 and 'SOIA F.E. 45x100' in alimenti or 'SOIA F.E. 50x100' in alimenti and 'FIENO MEDICA I TAGLIO' in alimenti or 'FIENO MEDICA II TAGLIO' in alimenti:
            testo = "<font name=helvetica size=16 color=red>La quantita di PROTEINA GREZZA fornita dalla razione è ECCESSIVA!</font> Riduci l'apporto di FARINA DI ESTRAZIONE DI SOIA e, se non basta, sostituiscila con una fonte proteica che apporti una quantita di proteina < e/o sostituisci il FIENO DI MEDICA con un foraggio di graminacee."
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)
            flowables.append(spacer)                  

        elif CPI_DMI_ratio > 18.5 and 'SOIA F.E. 45x100' not in alimenti or 'SOIA F.E. 50x100' not in alimenti and 'FIENO MEDICA I TAGLIO' in alimenti or 'FIENO MEDICA II TAGLIO' in alimenti:
            testo = "<font name=helvetica size=16 color=red>La quantita di PROTEINA GREZZA fornita dalla razione è ECCESSIVA!</font> Riduci l'apporto di FARINA DI ESTRAZIONE e, se non basta, sostituiscila con una fonte proteica che apporti una quantita di proteina < e/o sostituisci il FIENO DI MEDICA con un foraggio di graminacee"
            para = Paragraph(testo, style=styles["Normal"])
            flowables.append(para)
            flowables.append(spacer)        
        




################################################## FIBRA GREZZA #######################################################        


        testo = '<b>FIBRA GREZZA</b>'
        styles = getSampleStyleSheet()
        styles.add(ParagraphStyle(name='Parametri', alignment=TA_CENTER))
        styles["Parametri"].fontSize = 20
        styles["Parametri"].leading = 14
        spacer = Spacer(1, 0.5*inch)
        flowables.append(Paragraph(testo, styles["Parametri"]))      
        flowables.append(spacer)
        
       
        styles["Normal"].fontSize = 16
        styles["Normal"].leading = 20
        spacer = Spacer(1, 0.5*inch)
        
        FG_DMI_ratio = arrotonda(AFG/(ADM*1000))

        testo = 'Rapporto (FIBRA GREZZA : Sostanza Secca) => %f' % FG_DMI_ratio
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)
        flowables.append(spacer)
        
        testo = 'Dovrebbe essere ~ 0.17 (17%)'
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)
        flowables.append(spacer)


############################################## TABELLA APPORTI ALIMENTI #######################################################
        
        flowables.append(NextPageTemplate('landscape'))
        flowables.append(PageBreak())       

        

# Change to landscape orientation
#       flowables.append(NextPageTemplate('landscape'))
        flowables.append(Spacer(inch, 3*inch))
        testo = '<b>APPORTI DEI SINGOLI ALIMENTI</b>'
        styles = getSampleStyleSheet()
        styles.add(ParagraphStyle(name='Parametri', alignment=TA_CENTER))
        styles["Parametri"].fontSize = 24
        styles["Parametri"].leading = 14
        spacer = Spacer(1, 0.5*inch)
        flowables.append(Paragraph(testo, styles["Parametri"]))      
        flowables.append(spacer)
        

        
        flowables.append(Spacer(inch, 0.5*inch))
        tbl3 = Table(data3, hAlign='LEFT')
        tbl3.setStyle(stile_intestazione_3)
#       tbl3.setStyle(tblstyle_3)
        tbl3.setStyle(stile_griglia)
        flowables.append(tbl3)
        flowables.append(PageBreak())


############################################################ NOTE ############################################################


        testo = '<b>NOTE</b>'
        styles = getSampleStyleSheet()
        styles.add(ParagraphStyle(name='Parametri', alignment=TA_CENTER))
        styles["Parametri"].fontSize = 20
        styles["Parametri"].leading = 14
        spacer = Spacer(1, 0.5*inch)
        flowables.append(Paragraph(testo, styles["Parametri"]))      
        flowables.append(spacer)
        
       
        styles["Normal"].fontSize = 16
        styles["Normal"].leading = 20
        spacer = Spacer(1, 0.5*inch)

        testo = "STAMP. MAIUSC. => ALIMENTI INSERITI MANUALMENTE (quantita indicate dall'utente)"
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)
        flowables.append(spacer)        

        testo = 'stamp. minusc. => alimenti inseriti automaticamente (quantita calcolate dal programma)'
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)
        flowables.append(spacer)                

        testo = "<font name=helvetica size=16 color=red>N.B. L'apporto di ZUCCHERI è sottostimato per mancanza di dati sulla composizione dei fieni</font>"
        para = Paragraph(testo, style=styles["Normal"])
        flowables.append(para)
        flowables.append(spacer)      
    
        doc.build(flowables)




if __name__ == '__main__':
        alternate_orientations()

os.system('start "" /max "REPORT_PyR_%s.pdf"' % nome_report_pdf)
os.system('del fonte_dati.py')


