# esegui_parallel_bologna.py

import os
import pandas as pd

user = os.getlogin()
os.chdir('C:/Users/%s/PYTHON' % user)

from parallel_bologna import bologna_parallel

pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', None)

# print(dataframe_bologna)