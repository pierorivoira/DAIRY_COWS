# importa_MySQLdb_avena.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    avena = []

    for i in parametri:
        i = "SELECT %s FROM Cereale WHERE nome = 'avena'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        avena.append(float(i[0]))
#   print(AV)

    AV = list(np.float_(avena))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <avena> dal modulo <Cereale>') 
    from Cereale import avena
    print('<avena> importato con successo dal modulo <Cereale>!')

    AV = list(np.float_(avena))

    del AV[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del AV[10]
# elimino 'ceneri'

    del AV[13:15]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <AV> => %d' % len(AV))

    for i in range(len(AV)):
        AV[i] = AV[i]*10

    AV[0] = AV[0]/1000
    AV[12] = AV[12]/10

    AV_arr = np.array(AV)

    for i in range(len(AV)):
        AV[i] = float(AV[i])

print("COMPOSIZIONE CHIMICA dell'alimento <AVENA>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % AV_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % AV_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % AV_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % AV_arr[3])
print("Fibra Grezza (FG) => %f g" % AV_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % AV_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % AV_arr[6])
print("FAT (Grasso) => %f g" % AV_arr[7])
print("AM (Amido) => %f g" % AV_arr[8])
print("ZUC (Zuccheri) => %f g" % AV_arr[9])
print("Ca (Calcio) => %f g" % AV_arr[10])
print("P (Fosforo) => %f g" % AV_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % AV_arr[12])
print('')

# sio.sAVemat('AV.mat', {'vect':AV})
