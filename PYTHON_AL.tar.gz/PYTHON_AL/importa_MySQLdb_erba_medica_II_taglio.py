# importa_MySQLdb_erba_medica_II_taglio.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    erba_medica_II_taglio = []

    for i in parametri:
        i = "SELECT %s FROM Foraggio WHERE nome = 'erba_medica_II_taglio'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        erba_medica_II_taglio.append(float(i[0]))
#   print(ERME2TA)

    ERME2TA = list(np.float_(erba_medica_II_taglio))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <erba_medica_II_taglio> dal modulo <Foraggio>') 
    from Foraggio import erba_medica_II_taglio
    print('<erba_medica_II_taglio> importato con successo dal modulo <Foraggio>!')

    ERME2TA = list(np.float_(erba_medica_II_taglio))

    del ERME2TA[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del ERME2TA[10]
# elimino 'ceneri'

    del ERME2TA[13:17]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <ERME2TA> => %d' % len(ERME2TA))

    for i in range(len(ERME2TA)):
        ERME2TA[i] = ERME2TA[i]*10

    ERME2TA[0] = ERME2TA[0]/1000
    ERME2TA[12] = ERME2TA[12]/10

    ERME2TA_arr = np.array(ERME2TA)

    for i in range(len(ERME2TA)):
        ERME2TA[i] = float(ERME2TA[i])

print("COMPOSIZIONE CHIMICA dell'alimento <ERBA MEDICA DI II TAGLIO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % ERME2TA_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % ERME2TA_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % ERME2TA_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % ERME2TA_arr[3])
print("Fibra Grezza (FG) => %f g" % ERME2TA_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % ERME2TA_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % ERME2TA_arr[6])
print("FAT (Grasso) => %f g" % ERME2TA_arr[7])
print("AM (Amido) => %f g" % ERME2TA_arr[8])
print("ZUC (Zuccheri) => %f g" % ERME2TA_arr[9])
print("Ca (Calcio) => %f g" % ERME2TA_arr[10])
print("P (Fosforo) => %f g" % ERME2TA_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % ERME2TA_arr[12])
print('')

# sio.sERME2TAemat('ERME2TA.mat', {'vect':ERME2TA})
