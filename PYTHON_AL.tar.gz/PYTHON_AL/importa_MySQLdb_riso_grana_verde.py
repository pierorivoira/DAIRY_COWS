# importa_MySQLdb_riso_grana_verde.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    riso_grana_verde = []

    for i in parametri:
        i = "SELECT %s FROM Sottoprodotto WHERE nome = 'riso_grana_verde'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        riso_grana_verde.append(float(i[0]))
#   print(RIGRVER)

    RIGRVER = list(np.float_(riso_grana_verde))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <riso_grana_verde> dal modulo <Sottoprodotto>') 
    from Sottoprodotto import  riso_grana_verde
    print('<riso_grana_verde> importato con successo dal modulo <Sottoprodotto>!')

    RIGRVER = list(np.float_(riso_grana_verde))

    del RIGRVER[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del RIGRVER[10]
# elimino 'ceneri'

    del RIGRVER[13:17]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <RIGRVER> => %d' % len(RIGRVER))

    for i in range(len(RIGRVER)):
        RIGRVER[i] = RIGRVER[i]*10

    RIGRVER[0] = RIGRVER[0]/1000
    RIGRVER[12] = RIGRVER[12]/10

    RIGRVER_arr = np.array(RIGRVER)

    for i in range(len(RIGRVER)):
        RIGRVER[i] = float(RIGRVER[i])

print("COMPOSIZIONE CHIMICA dell'alimento <GRANA VERDE DI RISO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % RIGRVER_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % RIGRVER_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % RIGRVER_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % RIGRVER_arr[3])
print("Fibra Grezza (FG) => %f g" % RIGRVER_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % RIGRVER_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % RIGRVER_arr[6])
print("FAT (Grasso) => %f g" % RIGRVER_arr[7])
print("AM (Amido) => %f g" % RIGRVER_arr[8])
print("ZUC (Zuccheri) => %f g" % RIGRVER_arr[9])
print("Ca (Calcio) => %f g" % RIGRVER_arr[10])
print("P (Fosforo) => %f g" % RIGRVER_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % RIGRVER_arr[12])
print('')

# sio.sRIGRVERemat('RIGRVER.mat', {'vect':RIGRVER})
