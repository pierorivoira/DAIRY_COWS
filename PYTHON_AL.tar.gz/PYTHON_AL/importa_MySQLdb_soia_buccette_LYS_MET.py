# importa_MySQLdb_soia_buccette_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
    soia_buccette = []

    for i in parametri:
        i = "SELECT %s FROM Fonte_di_fibra_Lys_Met WHERE nome = 'soia_buccette'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        soia_buccette.append(float(i[0]))
#   print(soia_buccette)

    SOIABUCC = list(np.float_(soia_buccette))

except mysql.connector.Error as err:
  print("Server non raggiungibile: {}".format(err))
  print('Provo ad importare <soia_buccette> dal modulo <fonte_di_fibra_LYS_MET>') 
  from fonte_di_fibra_LYS_MET import soia_buccette
  print('<soia_buccette> importato con successo dal modulo <fonte_di_fibra_LYS_MET>!')

SOIABUCC = list(np.float_(soia_buccette))

del SOIABUCC[10]
del SOIABUCC[12:16]
del SOIABUCC[12]
del SOIABUCC[13]

SOIABUCC[0] = SOIABUCC[0]/100

for i in list(range(1, 12)):
	SOIABUCC[i] = SOIABUCC[i]*10

SOIABUCC[16] = SOIABUCC[16]*SOIABUCC[15]/100
SOIABUCC[17] = SOIABUCC[17]*SOIABUCC[15]/100

del SOIABUCC[13]
# elimina Mj

del SOIABUCC[2:4]
# elimina RDP e RUP

PDIE_SOIABUCC = SOIABUCC[12]
LysDI_SOIABUCC = SOIABUCC[13]
MetDI_SOIABUCC = SOIABUCC[14]

LysDI_MetDI_ratio = LysDI_SOIABUCC/MetDI_SOIABUCC

SOIABUCC_mod = SOIABUCC[0:12]
SOIABUCC_arr = np.array(SOIABUCC_mod)

for i in range(len(SOIABUCC_mod)):
    SOIABUCC_mod[i] = float(SOIABUCC_mod[i])

print('')
print("COMPOSIZIONE CHIMICA dell'alimento <SOIA BUCCETTE>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % SOIABUCC_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % SOIABUCC_arr[1])
print("Fibra Grezza (FG) => %f g" % SOIABUCC_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % SOIABUCC_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % SOIABUCC_arr[4])
print("FAT (Grasso) => %f g" % SOIABUCC_arr[5])
print("AM (Amido) => %f g" % SOIABUCC_arr[6])
print("ZUC (Zuccheri) => %f g" % SOIABUCC_arr[7])
print("Ca (Calcio) => %f g" % SOIABUCC_arr[8])
print("P (Fosforo) => %f g" % SOIABUCC_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % SOIABUCC_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % SOIABUCC_arr[11])   
print('')
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.sSOIABUCCemat('SOIABUCC.mat', {'vect':SOIABUCC})
