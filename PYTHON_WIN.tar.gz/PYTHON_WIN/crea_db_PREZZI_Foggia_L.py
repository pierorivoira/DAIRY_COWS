# crea_db_PREZZI_Foggia_L.py

### LINUX ### 

import os
from pathlib import Path


user = os.getlogin()
os.chdir('/home/%s/PYR/LINUX' % user)
cartella = os.getcwd()

if Path("listino_prezzi_Bologna.txt").exists():
    with open('listino_prezzi_Foggia.txt', 'r') as file:
        righe = file.readlines()
    for i in range(len(righe)):
        righe[i] = righe[i].replace('\n', '')
            if righe[i] != 'NQ':
                righe[i] = float(righe[i])
            else:
                righe[i] = 'alimento non quotato'
    prezzo_FAVINO_FORAGGIO_F = righe[0]

else:
    print('Non ho trovato il LISTINO PREZZI <BORSA MERCI di Bologna> nella CARTELLA <%s>!' % cartella)
    print('')
    print("Devi prima crearlo, selezionando l'opzione <Crea il listino della Borsa di Bologna> nel menù <Prezzi>")
    print('')
