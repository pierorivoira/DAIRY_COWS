# importa_MySQLdb_arachide_farina_estrazione_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
    arachide_farina_estrazione = []

    for i in parametri:
        i = "SELECT %s FROM Farina_di_estrazione_Lys_Met WHERE nome = 'arachide_farina_estrazione'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        arachide_farina_estrazione.append(float(i[0]))
#   print(arachide_farina_estrazione)

    ARAFAESTR = list(np.float_(arachide_farina_estrazione))

except mysql.connector.Error as err:
  print("Server non raggiungibile: {}".format(err))
  print('Provo ad importare <arachide_farina_estrazione> dal modulo <farina_di_estrazione_LYS_MET>') 
  from farina_di_estrazione_LYS_MET import arachide_farina_estrazione
  print('<arachide_farina_estrazione> importato con successo dal modulo <farina_di_estrazione_LYS_MET>!')

ARAFAESTR = list(np.float_(arachide_farina_estrazione))

del ARAFAESTR[10]
del ARAFAESTR[12:16]
del ARAFAESTR[12]
del ARAFAESTR[13]

ARAFAESTR[0] = ARAFAESTR[0]/100

for i in list(range(1, 12)):
	ARAFAESTR[i] = ARAFAESTR[i]*10

ARAFAESTR[16] = ARAFAESTR[16]*ARAFAESTR[15]/100
ARAFAESTR[17] = ARAFAESTR[17]*ARAFAESTR[15]/100

del ARAFAESTR[13]
# elimina i Mj

del ARAFAESTR[2:4]
# elimina RDP ed RUP

PDIE_ARAFAESTR = ARAFAESTR[12]
LysDI_ARAFAESTR = ARAFAESTR[13]
MetDI_ARAFAESTR = ARAFAESTR[14]

LysDI_MetDI_ratio = LysDI_ARAFAESTR/MetDI_ARAFAESTR

ARAFAESTR_mod = ARAFAESTR[0:12]
ARAFAESTR_arr = np.array(ARAFAESTR_mod)

for i in range(len(ARAFAESTR_mod)):
    ARAFAESTR_mod[i] = float(ARAFAESTR_mod[i])

print('')
print("COMPOSIZIONE CHIMICA dell'alimento <ARACHIDE FARINA DI ESTRAZIONE>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % ARAFAESTR_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % ARAFAESTR_arr[1])
print("Fibra Grezza (FG) => %f g" % ARAFAESTR_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % ARAFAESTR_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % ARAFAESTR_arr[4])
print("FAT (Grasso) => %f g" % ARAFAESTR_arr[5])
print("AM (Amido) => %f g" % ARAFAESTR_arr[6])
print("ZUC (Zuccheri) => %f g" % ARAFAESTR_arr[7])
print("Ca (Calcio) => %f g" % ARAFAESTR_arr[8])
print("P (Fosforo) => %f g" % ARAFAESTR_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % ARAFAESTR_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % ARAFAESTR_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.sARAFAESTRemat('ARAFAESTR.mat', {'vect':ARAFAESTR})
