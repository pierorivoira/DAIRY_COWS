# importa_MySQLdb_bietola_polpe_secche.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    bietola_polpe_secche = []

    for i in parametri:
        i = "SELECT %s FROM Fonte_di_fibra WHERE nome = 'bietola_polpe_secche'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        bietola_polpe_secche.append(float(i[0]))
#   print(BIEPOLPSE)

    BIEPOLPSE = list(np.float_(bietola_polpe_secche))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <bietola_polpe_secche> dal modulo <Fonte_di_fibra>') 
    from Fonte_di_fibra import bietola_polpe_secche
    print('<bietola_polpe_secche> importato con successo dal modulo <Fonte_di_fibra>!')

    BIEPOLPSE = list(np.float_(bietola_polpe_secche))

    del BIEPOLPSE[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del BIEPOLPSE[10]
# elimino 'ceneri'

    del BIEPOLPSE[13:15]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <BIEPOLPSE> => %d' % len(BIEPOLPSE))

    for i in range(len(BIEPOLPSE)):
        BIEPOLPSE[i] = BIEPOLPSE[i]*10

    BIEPOLPSE[0] = BIEPOLPSE[0]/1000
    BIEPOLPSE[12] = BIEPOLPSE[12]/10

    BIEPOLPSE_arr = np.array(BIEPOLPSE)

    for i in range(len(BIEPOLPSE)):
        BIEPOLPSE[i] = float(BIEPOLPSE[i])

print("COMPOSIZIONE CHIMICA dell'alimento <POLPE SECCHE DI BIETOLA>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % BIEPOLPSE_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % BIEPOLPSE_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % BIEPOLPSE_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % BIEPOLPSE_arr[3])
print("Fibra Grezza (FG) => %f g" % BIEPOLPSE_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % BIEPOLPSE_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % BIEPOLPSE_arr[6])
print("FAT (Grasso) => %f g" % BIEPOLPSE_arr[7])
print("AM (Amido) => %f g" % BIEPOLPSE_arr[8])
print("ZUC (Zuccheri) => %f g" % BIEPOLPSE_arr[9])
print("Ca (Calcio) => %f g" % BIEPOLPSE_arr[10])
print("P (Fosforo) => %f g" % BIEPOLPSE_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % BIEPOLPSE_arr[12])
print('')

# sio.sBIEPOLPSEemat('BIEPOLPSE.mat', {'vect':BIEPOLPSE})
