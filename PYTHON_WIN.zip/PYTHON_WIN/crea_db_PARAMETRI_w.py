# crea_db_PARAMETRI_w.py


### windows ###


import os, re
import numpy as np
import scipy.io as sio


user = os.getlogin()
os.chdir('C:/Users/%s/PYTHON' % user)



TESTO = open('PARAMETRI.txt').read()
Parametri_decimali = re.findall('[\d]*[.][\d]+', open('PARAMETRI.txt').read())
Parametri_interi = re.findall('\d+', open('PARAMETRI.txt').read())

specie = str(TESTO[2:8])
attitudine_produttiva = str(TESTO[12:17])
fase_produttiva = str(TESTO[21:31])
LW = float(Parametri_decimali[0])
WOL = int(Parametri_interi[2])
MY = float(Parametri_decimali[1])
FAT_milk = float(Parametri_decimali[2])
CP_milk = float(Parametri_decimali[3])
LAC_milk = float(Parametri_decimali[4])
N_repl = int(Parametri_interi[11])