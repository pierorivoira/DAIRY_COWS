# importa_MySQLdb_bietola_polpe_surpressate_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
    bietola_polpe_surpressate = []

    for i in parametri:
        i = "SELECT %s FROM Fonte_di_fibra_Lys_Met WHERE nome = 'bietola_polpe_surpressate'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        bietola_polpe_surpressate.append(float(i[0]))
#   print(bietola_polpe_surpressate)

    BIEPOLSURPR = list(np.float_(bietola_polpe_surpressate))

except mysql.connector.Error as err:
  print("Server non raggiungibile: {}".format(err))
  print('Provo ad importare <bietola_polpe_surpressate> dal modulo <fonte_di_fibra_LYS_MET>') 
  from fonte_di_fibra_LYS_MET import bietola_polpe_surpressate
  print('<bietola_polpe_surpressate> importato con successo dal modulo <fonte_di_fibra_LYS_MET>!')

BIEPOLSURPR = list(np.float_(bietola_polpe_surpressate))

del BIEPOLSURPR[10]
del BIEPOLSURPR[12:16]
del BIEPOLSURPR[12]
del BIEPOLSURPR[13]

BIEPOLSURPR[0] = BIEPOLSURPR[0]/100

for i in list(range(1, 12)):
	BIEPOLSURPR[i] = BIEPOLSURPR[i]*10

BIEPOLSURPR[16] = BIEPOLSURPR[16]*BIEPOLSURPR[15]/100
BIEPOLSURPR[17] = BIEPOLSURPR[17]*BIEPOLSURPR[15]/100

del BIEPOLSURPR[13]
# elimina Mj

del BIEPOLSURPR[2:4]
# elimina RDP ed RUP

PDIE_BIEPOLSURPR = BIEPOLSURPR[12]
LysDI_BIEPOLSURPR = BIEPOLSURPR[13]
MetDI_BIEPOLSURPR = BIEPOLSURPR[14]

LysDI_MetDI_ratio = LysDI_BIEPOLSURPR/MetDI_BIEPOLSURPR

BIEPOLSURPR_mod = BIEPOLSURPR[0:12]
BIEPOLSURPR_arr = np.array(BIEPOLSURPR_mod)

for i in range(len(BIEPOLSURPR_mod)):
    BIEPOLSURPR_mod[i] = float(BIEPOLSURPR_mod[i])

print('')
print("COMPOSIZIONE CHIMICA dell'alimento <POLPE SURPRESSATE DI BIETOLA>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % BIEPOLSURPR_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % BIEPOLSURPR_arr[1])
print("Fibra Grezza (FG) => %f g" % BIEPOLSURPR_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % BIEPOLSURPR_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % BIEPOLSURPR_arr[4])
print("FAT (Grasso) => %f g" % BIEPOLSURPR_arr[5])
print("AM (Amido) => %f g" % BIEPOLSURPR_arr[6])
print("ZUC (Zuccheri) => %f g" % BIEPOLSURPR_arr[7])
print("Ca (Calcio) => %f g" % BIEPOLSURPR_arr[8])
print("P (Fosforo) => %f g" % BIEPOLSURPR_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % BIEPOLSURPR_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % BIEPOLSURPR_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.sBIEPOLSURPRemat('BIEPOLSURPR.mat', {'vect':BIEPOLSURPR})
