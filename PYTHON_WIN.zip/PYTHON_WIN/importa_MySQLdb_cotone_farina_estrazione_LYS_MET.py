# importa_MySQLdb_cotone_farina_estrazione_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
    cotone_farina_estrazione = []

    for i in parametri:
        i = "SELECT %s FROM Farina_di_estrazione_Lys_Met WHERE nome = 'cotone_farina_estrazione'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        cotone_farina_estrazione.append(float(i[0]))
#   print(cotone_farina_estrazione)

    COTFAESTR = list(np.float_(cotone_farina_estrazione))

except mysql.connector.Error as err:
  print("Server non raggiungibile: {}".format(err))
  print('Provo ad importare <cotone_farina_estrazione> dal modulo <farina_di_estrazione_LYS_MET>') 
  from farina_di_estrazione_LYS_MET import cotone_farina_estrazione
  print('<cotone_farina_estrazione> importato con successo dal modulo <farina_di_estrazione_LYS_MET>!')

COTFAESTR = list(np.float_(cotone_farina_estrazione))

del COTFAESTR[10]
del COTFAESTR[12:16]
del COTFAESTR[12]
del COTFAESTR[13]

COTFAESTR[0] = COTFAESTR[0]/100

for i in list(range(1, 12)):
	COTFAESTR[i] = COTFAESTR[i]*10

COTFAESTR[16] = COTFAESTR[16]*COTFAESTR[15]/100
COTFAESTR[17] = COTFAESTR[17]*COTFAESTR[15]/100

del COTFAESTR[13]
# elimina Mj

del COTFAESTR[2:4]
# elimina RDP ed RUP

PDIE_COTFAESTR = COTFAESTR[12]
LysDI_COTFAESTR = COTFAESTR[13]
MetDI_COTFAESTR = COTFAESTR[14]

LysDI_MetDI_ratio = LysDI_COTFAESTR/MetDI_COTFAESTR

COTFAESTR_mod = COTFAESTR[0:12]
COTFAESTR_arr = np.array(COTFAESTR_mod)

for i in range(len(COTFAESTR_mod)):
    COTFAESTR_mod[i] = float(COTFAESTR_mod[i])

print('')
print("COMPOSIZIONE CHIMICA dell'alimento <COTONE FARINA DI ESTRAZIONE>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % COTFAESTR_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % COTFAESTR_arr[1])
print("Fibra Grezza (FG) => %f g" % COTFAESTR_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % COTFAESTR_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % COTFAESTR_arr[4])
print("FAT (Grasso) => %f g" % COTFAESTR_arr[5])
print("AM (Amido) => %f g" % COTFAESTR_arr[6])
print("ZUC (Zuccheri) => %f g" % COTFAESTR_arr[7])
print("Ca (Calcio) => %f g" % COTFAESTR_arr[8])
print("P (Fosforo) => %f g" % COTFAESTR_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % COTFAESTR_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % COTFAESTR_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.sCOTFAESTRemat('COTFAESTR.mat', {'vect':COTFAESTR})
