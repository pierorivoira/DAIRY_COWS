# importa_MySQLdb_crusca_frumento_tenero_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
    crusca_frumento_tenero = []

    for i in parametri:
        i = "SELECT %s FROM Fonte_di_fibra_Lys_Met WHERE nome = 'crusca_frumento_tenero'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        crusca_frumento_tenero.append(float(i[0]))
#   print(crusca_frumento_tenero)

    CRUFRUTE = list(np.float_(crusca_frumento_tenero))

except mysql.connector.Error as err:
  print("Server non raggiungibile: {}".format(err))
  print('Provo ad importare <crusca_frumento_tenero> dal modulo <fonte_di_fibra_LYS_MET>') 
  from fonte_di_fibra_LYS_MET import crusca_frumento_tenero
  print('<crusca_frumento_tenero> importato con successo dal modulo <fonte_di_fibra_LYS_MET>!')

CRUFRUTE = list(np.float_(crusca_frumento_tenero))

del CRUFRUTE[10]
del CRUFRUTE[12:16]
del CRUFRUTE[12]
del CRUFRUTE[13]

CRUFRUTE[0] = CRUFRUTE[0]/100

for i in list(range(1, 12)):
	CRUFRUTE[i] = CRUFRUTE[i]*10

CRUFRUTE[16] = CRUFRUTE[16]*CRUFRUTE[15]/100
CRUFRUTE[17] = CRUFRUTE[17]*CRUFRUTE[15]/100


del CRUFRUTE[13]
# elimina Mj

del CRUFRUTE[2:4]
# elimina RDP e RUP

PDIE_CRUFRUTE = CRUFRUTE[12]
LysDI_CRUFRUTE = CRUFRUTE[13]
MetDI_CRUFRUTE = CRUFRUTE[14]

LysDI_MetDI_ratio = LysDI_CRUFRUTE/MetDI_CRUFRUTE

CRUFRUTE_mod = CRUFRUTE[0:12]
CRUFRUTE_arr = np.array(CRUFRUTE_mod)

for i in range(len(CRUFRUTE_mod)):
    CRUFRUTE_mod[i] = float(CRUFRUTE_mod[i])

print("COMPOSIZIONE CHIMICA dell'alimento <CRUSCA DI FRUMENTO TENERO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % CRUFRUTE_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % CRUFRUTE_arr[1])
print("Fibra Grezza (FG) => %f g" % CRUFRUTE_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % CRUFRUTE_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % CRUFRUTE_arr[4])
print("FAT (Grasso) => %f g" % CRUFRUTE_arr[5])
print("AM (Amido) => %f g" % CRUFRUTE_arr[6])
print("ZUC (Zuccheri) => %f g" % CRUFRUTE_arr[7])
print("Ca (Calcio) => %f g" % CRUFRUTE_arr[8])
print("P (Fosforo) => %f g" % CRUFRUTE_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % CRUFRUTE_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % CRUFRUTE_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.sCRUFRUTEemat('CRUFRUTE.mat', {'vect':CRUFRUTE})
