# importa_MySQLdb_erba_loietto.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    erba_loietto = []

    for i in parametri:
        i = "SELECT %s FROM Foraggio WHERE nome = 'erba_loietto'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        erba_loietto.append(float(i[0]))
#   print(ERLO)

    ERLO = list(np.float_(erba_loietto))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <erba_loietto> dal modulo <Foraggio>') 
    from Foraggio import erba_loietto
    print('<erba_loietto> importato con successo dal modulo <Foraggio>!')

    ERLO = list(np.float_(erba_loietto))

    del ERLO[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del ERLO[10]
# elimino 'ceneri'

    del ERLO[13:15]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <ERLO> => %d' % len(ERLO))

    for i in range(len(ERLO)):
        ERLO[i] = ERLO[i]*10

    ERLO[0] = ERLO[0]/1000
    ERLO[12] = ERLO[12]/10

    ERLO_arr = np.array(ERLO)

    for i in range(len(ERLO)):
        ERLO[i] = float(ERLO[i])

print("COMPOSIZIONE CHIMICA dell'alimento <ERBA LOIETTO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % ERLO_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % ERLO_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % ERLO_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % ERLO_arr[3])
print("Fibra Grezza (FG) => %f g" % ERLO_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % ERLO_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % ERLO_arr[6])
print("FAT (Grasso) => %f g" % ERLO_arr[7])
print("AM (Amido) => %f g" % ERLO_arr[8])
print("ZUC (Zuccheri) => %f g" % ERLO_arr[9])
print("Ca (Calcio) => %f g" % ERLO_arr[10])
print("P (Fosforo) => %f g" % ERLO_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % ERLO_arr[12])
print('')

# sio.sERLOemat('ERLO.mat', {'vect':ERLO})
