# importa_MySQLdb_frumento_tenero_germe.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    frumento_tenero_germe = []

    for i in parametri:
        i = "SELECT %s FROM Sottoprodotto WHERE nome = 'frumento_tenero_germe'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        frumento_tenero_germe.append(float(i[0]))
#   print(FRUTEGE)

    FRUTEGE = list(np.float_(frumento_tenero_germe))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <frumento_tenero_germe> dal modulo <Sottoprodotto>') 
    from Sottoprodotto import frumento_tenero_germe
    print('<frumento_tenero_germe> importato con successo dal modulo <Sottoprodotto>!')

    FRUTEGE = list(np.float_(frumento_tenero_germe))

    del FRUTEGE[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del FRUTEGE[10]
# elimino 'ceneri'

    del FRUTEGE[13:17]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <FRUTEGE> => %d' % len(FRUTEGE))

    for i in range(len(FRUTEGE)):
        FRUTEGE[i] = FRUTEGE[i]*10

    FRUTEGE[0] = FRUTEGE[0]/1000
    FRUTEGE[12] = FRUTEGE[12]/10

    FRUTEGE_arr = np.array(FRUTEGE)

    for i in range(len(FRUTEGE)):
        FRUTEGE[i] = float(FRUTEGE[i])

print("COMPOSIZIONE CHIMICA dell'alimento <GERME DI FRUMENTO TENERO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % FRUTEGE_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % FRUTEGE_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % FRUTEGE_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % FRUTEGE_arr[3])
print("Fibra Grezza (FG) => %f g" % FRUTEGE_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % FRUTEGE_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % FRUTEGE_arr[6])
print("FAT (Grasso) => %f g" % FRUTEGE_arr[7])
print("AM (Amido) => %f g" % FRUTEGE_arr[8])
print("ZUC (Zuccheri) => %f g" % FRUTEGE_arr[9])
print("Ca (Calcio) => %f g" % FRUTEGE_arr[10])
print("P (Fosforo) => %f g" % FRUTEGE_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % FRUTEGE_arr[12])
print('')

# sio.sFRUTEGEemat('FRUTEGE.mat', {'vect':FRUTEGE})
