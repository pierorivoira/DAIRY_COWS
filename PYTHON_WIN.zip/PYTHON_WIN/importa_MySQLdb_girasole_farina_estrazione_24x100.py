# importa_MySQLdb_girasole_farina_estrazione_24x100.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    girasole_farina_estrazione_24x100 = []

    for i in parametri:
        i = "SELECT %s FROM Farina_di_estrazione WHERE nome = 'girasole_farina_estrazione_24x100'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        girasole_farina_estrazione_24x100.append(float(i[0]))
#   print(GIRFAESTR24)

    GIRFAESTR24 = list(np.float_(girasole_farina_estrazione_24x100))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <girasole_farina_estrazione_24x100> dal modulo <Farina_di_estrazione>') 
    from Farina_di_estrazione import girasole_farina_estrazione_24x100
    print('<girasole_farina_estrazione_24x100> importato con successo dal modulo <Farina_di_estrazione>!')

    GIRFAESTR24 = list(np.float_(girasole_farina_estrazione_24x100))

    del GIRFAESTR24[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del GIRFAESTR24[10]
# elimino 'ceneri'

    del GIRFAESTR24[13:17]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <GIRFAESTR24> => %d' % len(GIRFAESTR24))

    for i in range(len(GIRFAESTR24)):
        GIRFAESTR24[i] = GIRFAESTR24[i]*10

    GIRFAESTR24[0] = GIRFAESTR24[0]/1000
    GIRFAESTR24[12] = GIRFAESTR24[12]/10

    GIRFAESTR24_arr = np.array(GIRFAESTR24)

    for i in range(len(GIRFAESTR24)):
        GIRFAESTR24[i] = float(GIRFAESTR24[i])

print("COMPOSIZIONE CHIMICA dell'alimento <FARINA DI ESTRAZIONE DI GIRASOLE 24%>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % GIRFAESTR24_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % GIRFAESTR24_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % GIRFAESTR24_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % GIRFAESTR24_arr[3])
print("Fibra Grezza (FG) => %f g" % GIRFAESTR24_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % GIRFAESTR24_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % GIRFAESTR24_arr[6])
print("FAT (Grasso) => %f g" % GIRFAESTR24_arr[7])
print("AM (Amido) => %f g" % GIRFAESTR24_arr[8])
print("ZUC (Zuccheri) => %f g" % GIRFAESTR24_arr[9])
print("Ca (Calcio) => %f g" % GIRFAESTR24_arr[10])
print("P (Fosforo) => %f g" % GIRFAESTR24_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % GIRFAESTR24_arr[12])
print('')

# sio.sGIRFAESTR24emat('GIRFAESTR24.mat', {'vect':GIRFAESTR24})
