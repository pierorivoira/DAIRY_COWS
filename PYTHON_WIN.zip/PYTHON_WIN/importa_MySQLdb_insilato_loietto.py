# importa_MySQLdb_insilato_loietto.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    insilato_loietto = []

    for i in parametri:
        i = "SELECT %s FROM Foraggio WHERE nome = 'insilato_loietto'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        insilato_loietto.append(float(i[0]))
#   print(INSILO)

    INSILO = list(np.float_(insilato_loietto))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <insilato_loietto> dal modulo <Foraggio>') 
    from Foraggio import insilato_loietto
    print('<insilato_loietto> importato con successo dal modulo <Foraggio>!')

    INSILO = list(np.float_(insilato_loietto))

    del INSILO[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del INSILO[10]
# elimino 'ceneri'

    del INSILO[13:17]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <INSILO> => %d' % len(INSILO))

    for i in range(len(INSILO)):
        INSILO[i] = INSILO[i]*10

    INSILO[0] = INSILO[0]/1000
    INSILO[12] = INSILO[12]/10

    INSILO_arr = np.array(INSILO)

    for i in range(len(INSILO)):
        INSILO[i] = float(INSILO[i])

print("COMPOSIZIONE CHIMICA dell'alimento <INSILATO DI LOIETTO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % INSILO_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % INSILO_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % INSILO_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % INSILO_arr[3])
print("Fibra Grezza (FG) => %f g" % INSILO_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % INSILO_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % INSILO_arr[6])
print("FAT (Grasso) => %f g" % INSILO_arr[7])
print("AM (Amido) => %f g" % INSILO_arr[8])
print("ZUC (Zuccheri) => %f g" % INSILO_arr[9])
print("Ca (Calcio) => %f g" % INSILO_arr[10])
print("P (Fosforo) => %f g" % INSILO_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % INSILO_arr[12])
print('')

# sio.sINSILOemat('INSILO.mat', {'vect':INSILO})
