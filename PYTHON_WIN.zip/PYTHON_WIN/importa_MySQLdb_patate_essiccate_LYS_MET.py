# importa_MySQLdb_patate_essiccate_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
    patate_essiccate = []

    for i in parametri:
        i = "SELECT %s FROM Sottoprodotto_Lys_Met WHERE nome = 'patate_essiccate'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        patate_essiccate.append(float(i[0]))
#   print(patate_essiccate)

    PAESSI = list(np.float_(patate_essiccate))

except mysql.connector.Error as err:
  print("Server non raggiungibile: {}".format(err))
  print('Provo ad importare <orzo> dal modulo <sottoprodotto_LYS_MET>') 
  from sottoprodotto_LYS_MET import patate_essiccate
  print('<patate_essiccate> importato con successo dal modulo <sottoprodotto_LYS_MET>!')

PAESSI = list(np.float_(patate_essiccate))

del PAESSI[10]
del PAESSI[12:16]
del PAESSI[12]
del PAESSI[13]

PAESSI[0] = PAESSI[0]/100

for i in list(range(1, 12)):
	PAESSI[i] = PAESSI[i]*10

PAESSI[16] = PAESSI[16]*PAESSI[15]/100
PAESSI[17] = PAESSI[17]*PAESSI[15]/100

del PAESSI[13]
# elimina Mj

del PAESSI[2:4]
# elimina RDP e RUP

PDIE_PAESSI = PAESSI[12]
LysDI_PAESSI = PAESSI[13]
MetDI_PAESSI = PAESSI[14]

LysDI_MetDI_ratio = LysDI_PAESSI/MetDI_PAESSI

PAESSI_mod = PAESSI[0:12]
PAESSI_arr = np.array(PAESSI_mod)

for i in range(len(PAESSI_mod)):
    PAESSI_mod[i] = float(PAESSI_mod[i])

print('')
print("COMPOSIZIONE CHIMICA dell'alimento <PATATE ESSICCATE>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % PAESSI_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % PAESSI_arr[1])
print("Fibra Grezza (FG) => %f g" % PAESSI_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % PAESSI_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % PAESSI_arr[4])
print("FAT (Grasso) => %f g" % PAESSI_arr[5])
print("AM (Amido) => %f g" % PAESSI_arr[6])
print("ZUC (Zuccheri) => %f g" % PAESSI_arr[7])
print("Ca (Calcio) => %f g" % PAESSI_arr[8])
print("P (Fosforo) => %f g" % PAESSI_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % PAESSI_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % PAESSI_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.sPAESSIemat('PAESSI.mat', {'vect':PAESSI})
