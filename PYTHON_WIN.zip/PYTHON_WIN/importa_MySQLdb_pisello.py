# importa_MySQLdb_pisello.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    pisello = []

    for i in parametri:
        i = "SELECT %s FROM Leguminosa WHERE nome = 'pisello'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        pisello.append(float(i[0]))
#   print(PISELLO)

    PISELLO = list(np.float_(pisello))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <pisello> dal modulo <Leguminosa>') 
    from Leguminosa import  pisello
    print('<pisello> importato con successo dal modulo <Leguminosa>!')

    PISELLO = list(np.float_(pisello))

    del PISELLO[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del PISELLO[10]
# elimino 'ceneri'

    del PISELLO[13:17]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <PISELLO> => %d' % len(PISELLO))

    for i in range(len(PISELLO)):
        PISELLO[i] = PISELLO[i]*10

    PISELLO[0] = PISELLO[0]/1000
    PISELLO[12] = PISELLO[12]/10

    PISELLO_arr = np.array(PISELLO)

    for i in range(len(PISELLO)):
        PISELLO[i] = float(PISELLO[i])

print("COMPOSIZIONE CHIMICA dell'alimento <PISELLO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % PISELLO_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % PISELLO_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % PISELLO_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % PISELLO_arr[3])
print("Fibra Grezza (FG) => %f g" % PISELLO_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % PISELLO_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % PISELLO_arr[6])
print("FAT (Grasso) => %f g" % PISELLO_arr[7])
print("AM (Amido) => %f g" % PISELLO_arr[8])
print("ZUC (Zuccheri) => %f g" % PISELLO_arr[9])
print("Ca (Calcio) => %f g" % PISELLO_arr[10])
print("P (Fosforo) => %f g" % PISELLO_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % PISELLO_arr[12])
print('')

# sio.sPISELLOemat('PISELLO.mat', {'vect':PISELLO})
