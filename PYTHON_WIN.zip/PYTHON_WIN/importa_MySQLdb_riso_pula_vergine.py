# importa_MySQLdb_riso_pula_vergine.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    riso_pula_vergine = []

    for i in parametri:
        i = "SELECT %s FROM Sottoprodotto WHERE nome = 'riso_pula_vergine'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        riso_pula_vergine.append(float(i[0]))
#   print(RISPUVER)

    RISPUVER = list(np.float_(riso_pula_vergine))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <riso_pula_vergine> dal modulo <Sottoprodotto>') 
    from Sottoprodotto import  riso_pula_vergine
    print('<riso_pula_vergine> importato con successo dal modulo <Sottoprodotto>!')

    RISPUVER = list(np.float_(riso_pula_vergine))

    del RISPUVER[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del RISPUVER[10]
# elimino 'ceneri'

    del RISPUVER[13:17]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <RISPUVER> => %d' % len(RISPUVER))

    for i in range(len(RISPUVER)):
        RISPUVER[i] = RISPUVER[i]*10

    RISPUVER[0] = RISPUVER[0]/1000
    RISPUVER[12] = RISPUVER[12]/10

    RISPUVER_arr = np.array(RISPUVER)

    for i in range(len(RISPUVER)):
        RISPUVER[i] = float(RISPUVER[i])

print("COMPOSIZIONE CHIMICA dell'alimento <PULA VERGINE DI RISO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % RISPUVER_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % RISPUVER_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % RISPUVER_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % RISPUVER_arr[3])
print("Fibra Grezza (FG) => %f g" % RISPUVER_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % RISPUVER_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % RISPUVER_arr[6])
print("FAT (Grasso) => %f g" % RISPUVER_arr[7])
print("AM (Amido) => %f g" % RISPUVER_arr[8])
print("ZUC (Zuccheri) => %f g" % RISPUVER_arr[9])
print("Ca (Calcio) => %f g" % RISPUVER_arr[10])
print("P (Fosforo) => %f g" % RISPUVER_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % RISPUVER_arr[12])
print('')

# sio.sRISPUVERemat('RISPUVER.mat', {'vect':RISPUVER})
