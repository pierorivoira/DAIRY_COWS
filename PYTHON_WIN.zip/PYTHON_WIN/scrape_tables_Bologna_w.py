# scrape_tables_Bologna_w.py

# https://stackoverflow.com/questions/60377106/python3-module-tabula-has-no-attribute-read-pdf
# https://www.tutorialspoint.com/convert-pdf-to-csv-using-python
# https://www.codegrepper.com/code-examples/python/remove+first+instance+of+character+from+string+python
# https://towardsdatascience.com/how-to-show-all-columns-rows-of-a-pandas-dataframe-c49d4507fcf


### WINDOWS ###


import pandas as pd
import fileinput, io, numpy, os, re, subprocess, sys, tabula
from tabula.io import read_pdf
from tabula import *
from datetime import date, datetime, timedelta
from contextlib import redirect_stdout


user = os.getlogin()
os.chdir('C:/Users/%s/PYTHON' % user)

today = date.today()
offset_B = (today.weekday() - 3) % 7

import datetime

if datetime.datetime.today().weekday() == 3:
    last_Thursday = today - timedelta(days=7)
    Thursday = last_Thursday
else:
    Thursday = today - timedelta(days=offset_B)
        
data_aggiornamento_B = Thursday.strftime('%d.%m.%Y')

day = Thursday.strftime('%d')
if ((day != '10') and (day != '20') and (day != '30')): 
    day = day.replace("0","",1)
else:
    day = day

month = Thursday.strftime('%m')
if month != '10':
    month = month.replace("0","",1)
else:
    month = month

year = Thursday.strftime('%Y')

giorno_di_pubblicazione_B = '%s_%s_%s' % (day, month, year)

week = Thursday.isocalendar()[1] - 1

os.system('curl -o n.%d-%s.pdf https://www.bo.camcom.gov.it/sites/default/files/borsa-merci-e-rilevazione-prezzi/listino-dei-prezzi-settimanali/anno-%s/n.%d-%s.pdf' % (week, giorno_di_pubblicazione_B, year, week, giorno_di_pubblicazione_B))


# https://www.bo.camcom.gov.it/sites/default/files/borsa-merci-e-rilevazione-prezzi/listino-dei-prezzi-settimanali/anno-2022/n.7-24_2_2022.pdf


df0 = tabula.io.read_pdf('n.%d-%s.pdf' % (week, giorno_di_pubblicazione_B), pages='all')[0]
df1 = tabula.io.read_pdf('n.%d-%s.pdf' % (week, giorno_di_pubblicazione_B), pages='all')[1]
df2 = tabula.io.read_pdf('n.%d-%s.pdf' % (week, giorno_di_pubblicazione_B), pages='all')[2]
df3 = tabula.io.read_pdf('n.%d-%s.pdf' % (week, giorno_di_pubblicazione_B), pages='all')[3]
df4 = tabula.io.read_pdf('n.%d-%s.pdf' % (week, giorno_di_pubblicazione_B), pages='all')[4]
# df5 = tabula.io.read_pdf('n.%d-%s.pdf' % (week, giorno_di_pubblicazione_B), pages='all')[5]   AGRICOLTURA BIOLOGICA
df6 = tabula.io.read_pdf('n.%d-%s.pdf' % (week, giorno_di_pubblicazione_B), pages='all')[6]
df7 = tabula.io.read_pdf('n.%d-%s.pdf' % (week, giorno_di_pubblicazione_B), pages='all')[7]


pd.set_option('display.max_columns', None)

prezzi_0 = df0.to_numpy()
prezzi_1 = df1.to_numpy()
prezzi_2 = df2.to_numpy()
prezzi_3 = df3.to_numpy()
prezzi_4 = df4.to_numpy()
# prezzi_5 = df5.to_numpy()
prezzi_6 = df6.to_numpy()
prezzi_7 = df7.to_numpy()



SORGO = prezzi_0[11]
SOIA = prezzi_0[13]
MAIS = prezzi_1[17]
ORZO = prezzi_1[25]
FRUMENTO = prezzi_1[29]
PISELLO = prezzi_1[31]
FAVINO = prezzi_1[33]
FRUMENTO_TENERO_CRUSCA = prezzi_2[5]
FRUMENTO_TENERO_CRUSCHELLO = prezzi_2[5]
FRUMENTO_TENERO_TRITELLO = prezzi_2[6]
FRUMENTO_TENERO_FARINACCIO = prezzi_2[7]
FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO = prezzi_2[14]
FRUMENTO_DURO_FARINACCIO = prezzi_2[16]
FRUMENTO_DURO_FARINETTA = prezzi_2[17]
SOIA_FE = prezzi_2[19]
GIRASOLE_INTEGRALE_FE = prezzi_2[27]
COLZA_FE = prezzi_2[29]
ERBA_MED_DIS_17 = prezzi_2[35]
ERBA_MED_DIS_16 = prezzi_2[36]
ERBA_MED_DIS_14 = prezzi_2[37]
FIENO_1_TAGLIO = prezzi_2[39]
FIENO_1_TAGLIO_FIBRA_LUNGA = prezzi_2[45]
MAIS_FARINA = prezzi_3[3]
MAIS_SEMOLA_GLUTINATA = prezzi_3[4]
MELASSO_CANNA = prezzi_4[1]
MELASSO_BIETOLA = prezzi_4[2]
SOIA_BUCCETTE = prezzi_4[4]
BIETOLA_POLPE = prezzi_4[5]
COTONE = prezzi_4[7]
RISO_GRANA_VERDE = prezzi_6[15]
RISO_FARINACCIO = prezzi_6[16]
RISO_PULA_VERGINE = prezzi_6[17]
FIENO_MEDICA_17_1_TAGLIO_ROTBAL = prezzi_7[10]
FIENO_MEDICA_17_1_TAGLIO_BALQUA = prezzi_7[11]
FIENO_MEDICA_17_2_TAGLIO_ROTBAL = prezzi_7[12]
FIENO_MEDICA_17_2_TAGLIO_BALQUA = prezzi_7[13]
FIENO_MEDICA_17_3_TAGLIO_ROTBAL = prezzi_7[14]
FIENO_MEDICA_17_3_TAGLIO_BALQUA = prezzi_7[15]
FIENO_MEDICA_17_4_TAGLIO_ROTBAL = prezzi_7[16]
FIENO_MEDICA_17_4_TAGLIO_BALQUA = prezzi_7[17]
PAGLIA_ROTBAL = prezzi_7[50]


prezzo_SORGO_B = SORGO[5].replace(',','.')
prezzo_SOIA_B = SOIA[5].replace(',','.')
prezzo_MAIS_B = MAIS[4].replace(',','.')
prezzo_ORZO_B = ORZO[4].replace(',','.')
prezzo_FRUMENTO_B = FRUMENTO[4].replace(',','.')
prezzo_PISELLO_B = PISELLO[2].replace(',','.')
prezzo_FAVINO_B = FAVINO[2].replace(',','.')
prezzo_FRUMENTO_TENERO_CRUSCA_B = FRUMENTO_TENERO_CRUSCA[6].replace(',','.')
prezzo_FRUMENTO_TENERO_CRUSCHELLO_B = FRUMENTO_TENERO_CRUSCHELLO[6].replace(',','.')
prezzo_FRUMENTO_TENERO_TRITELLO_B = FRUMENTO_TENERO_TRITELLO[6].replace(',','.')
prezzo_FRUMENTO_TENERO_FARINACCIO_B = FRUMENTO_TENERO_FARINACCIO[6].replace(',','.')
prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B = FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO[6].replace(',','.')
prezzo_FRUMENTO_DURO_FARINACCIO_B = FRUMENTO_DURO_FARINACCIO[6].replace(',','.')
prezzo_FRUMENTO_DURO_FARINETTA_B = FRUMENTO_DURO_FARINETTA[6].replace(',','.')
prezzo_SOIA_FE_B = SOIA_FE[6].replace(',','.')
prezzo_GIRASOLE_INTEGRALE_FE_B = GIRASOLE_INTEGRALE_FE[3].replace(',','.')
prezzo_COLZA_FE_B = COLZA_FE[3].replace(',','.')
prezzo_ERBA_MED_DIS_17_B = ERBA_MED_DIS_17[6].replace(',','.')
prezzo_ERBA_MED_DIS_16_B = ERBA_MED_DIS_16[6].replace(',','.')
prezzo_ERBA_MED_DIS_14_B = ERBA_MED_DIS_14[6].replace(',','.')
prezzo_FIENO_1_TAGLIO_B = FIENO_1_TAGLIO[6].replace(',','.')
prezzo_FIENO_1_TAGLIO_FIBRA_LUNGA_B = FIENO_1_TAGLIO_FIBRA_LUNGA[6].replace(',','.')
prezzo_MAIS_FARINA_B = MAIS_FARINA[4].replace(',','.')
prezzo_MAIS_SEMOLA_GLUTINATA_B = MAIS_SEMOLA_GLUTINATA[4].replace(',','.')
prezzo_MELASSO_CANNA_B = MELASSO_CANNA[6].replace(',','.')
prezzo_MELASSO_BIETOLA_B = MELASSO_BIETOLA[6].replace(',','.')
prezzo_SOIA_BUCCETTE_B = SOIA_BUCCETTE[6].replace(',','.')
prezzo_BIETOLA_POLPE_B = BIETOLA_POLPE[6].replace(',','.')
prezzo_COTONE_B = COTONE[6].replace(',','.')
prezzo_RISO_GRANA_VERDE_B = RISO_GRANA_VERDE[5].replace(',','.')
prezzo_RISO_FARINACCIO_B = RISO_FARINACCIO[5].replace(',','.')
prezzo_RISO_PULA_VERGINE_B = RISO_PULA_VERGINE[5].replace(',','.')
prezzo_FIENO_MEDICA_17_1_TAGLIO_ROTBAL_B = FIENO_MEDICA_17_1_TAGLIO_ROTBAL[5].replace(',','.')
prezzo_FIENO_MEDICA_17_1_TAGLIO_BALQUA_B = FIENO_MEDICA_17_1_TAGLIO_BALQUA[5].replace(',','.')
prezzo_FIENO_MEDICA_17_2_TAGLIO_ROTBAL_B = FIENO_MEDICA_17_2_TAGLIO_ROTBAL[5].replace(',','.')
prezzo_FIENO_MEDICA_17_2_TAGLIO_BALQUA_B = FIENO_MEDICA_17_2_TAGLIO_BALQUA[5].replace(',','.')
prezzo_FIENO_MEDICA_17_3_TAGLIO_ROTBAL_B = FIENO_MEDICA_17_3_TAGLIO_ROTBAL[5].replace(',','.')
prezzo_FIENO_MEDICA_17_3_TAGLIO_BALQUA_B = FIENO_MEDICA_17_3_TAGLIO_BALQUA[5].replace(',','.')
prezzo_FIENO_MEDICA_17_4_TAGLIO_ROTBAL_B = FIENO_MEDICA_17_4_TAGLIO_ROTBAL[5].replace(',','.')
prezzo_FIENO_MEDICA_17_4_TAGLIO_BALQUA_B = FIENO_MEDICA_17_4_TAGLIO_BALQUA[5].replace(',','.')
prezzo_PAGLIA_ROTBAL_B = PAGLIA_ROTBAL[5].replace(',','.')


with open('listino_prezzi_Bologna.txt', 'w', encoding = "utf-8") as f:
    with redirect_stdout(f):
#       print('Prezzi della Borsa di Bologna aggiornati al %s' % data_aggiornamento_B)
        print(prezzo_SORGO_B)
        print(prezzo_SOIA_B)
        print(prezzo_MAIS_B)
        print(prezzo_ORZO_B)
        print(prezzo_FRUMENTO_B)
        print(prezzo_PISELLO_B)
        print(prezzo_FAVINO_B)
        print(prezzo_FRUMENTO_TENERO_CRUSCA_B)
        print(prezzo_FRUMENTO_TENERO_CRUSCHELLO_B)
        print(prezzo_FRUMENTO_TENERO_TRITELLO_B)
        print(prezzo_FRUMENTO_TENERO_FARINACCIO_B)
        print(prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B)
        print(prezzo_FRUMENTO_DURO_FARINACCIO_B)
        print(prezzo_FRUMENTO_DURO_FARINETTA_B)
        print(prezzo_SOIA_FE_B)
        print(prezzo_GIRASOLE_INTEGRALE_FE_B)
        print(prezzo_COLZA_FE_B)
        print(prezzo_ERBA_MED_DIS_17_B)
        print(prezzo_ERBA_MED_DIS_16_B)
        print(prezzo_ERBA_MED_DIS_14_B)
        print(prezzo_FIENO_1_TAGLIO_B)
        print(prezzo_FIENO_1_TAGLIO_FIBRA_LUNGA_B)
        print(prezzo_MAIS_FARINA_B)
        print(prezzo_MAIS_SEMOLA_GLUTINATA_B)
        print(prezzo_MELASSO_CANNA_B)
        print(prezzo_MELASSO_BIETOLA_B)
        print(prezzo_SOIA_BUCCETTE_B)
        print(prezzo_BIETOLA_POLPE_B)
        print(prezzo_COTONE_B)
        print(prezzo_RISO_GRANA_VERDE_B)
        print(prezzo_RISO_FARINACCIO_B)
        print(prezzo_RISO_PULA_VERGINE_B)
        print(prezzo_FIENO_MEDICA_17_1_TAGLIO_ROTBAL_B)
        print(prezzo_FIENO_MEDICA_17_1_TAGLIO_BALQUA_B)
        print(prezzo_FIENO_MEDICA_17_2_TAGLIO_ROTBAL_B)
        print(prezzo_FIENO_MEDICA_17_2_TAGLIO_BALQUA_B)
        print(prezzo_FIENO_MEDICA_17_3_TAGLIO_ROTBAL_B)
        print(prezzo_FIENO_MEDICA_17_3_TAGLIO_BALQUA_B)
        print(prezzo_FIENO_MEDICA_17_4_TAGLIO_ROTBAL_B)
        print(prezzo_FIENO_MEDICA_17_4_TAGLIO_BALQUA_B)
        print(prezzo_PAGLIA_ROTBAL_B)
