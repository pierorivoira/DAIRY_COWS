# scrape_tables_Milano_w.py
# https://www.geeksforgeeks.org/scrape-tables-from-any-website-using-python/

### pip install html-table-parser-python3 ###

					
### windows ### 


### pip install html-table-parser-python3 ###
### pip install --trusted-host pypi.org --trusted-host files.pythonhosted.org cryptography ###



import os, requests, ssl, urllib.request
import pandas as pd					
# from pprint import pprint					
from html.parser import HTMLParser
from html_table_parser.parser import HTMLTableParser		
from datetime import date, datetime, timedelta				
from contextlib import redirect_stdout

ssl._create_default_https_context = ssl._create_unverified_context

user = os.getlogin()
os.chdir('C:/Users/%s/PYTHON' % user)

pd.set_option('display.max_rows', 200)
pd.options.display.width=None

data = datetime.today().strftime('%d.%m.%Y')
today = date.today()

import datetime

idx = (today.weekday() + 6) % 7
Tuesday = (today - datetime.timedelta(idx)).strftime('%Y-%m-%d')
last_Tuesday = (today - datetime.timedelta(idx+7)).strftime('%Y-%m-%d')
last_last_Tuesday = (today - datetime.timedelta(idx+14)).strftime('%Y-%m-%d')

urls = ['https://www.granariamilano.it/listino-%s/' % Tuesday, 'https://www.granariamilano.it/listino-%s/' % last_Tuesday, 'https://www.granariamilano.it/listino-%s/' % last_last_Tuesday]

def check_url_exists(url):
	for i in range(len(urls)):
            return requests.head(urls[i], allow_redirects=True).status_code == 200

if check_url_exists(urls[0]) == True:
        url = urls[0]
elif check_url_exists(urls[1]) == True:
        url = urls[1]
elif check_url_exists(urls[2]) == True:
        url = urls[2]
else:
	print('Listino prezzi BORSA MERCI di Milano non disponibile')


def url_get_contents(url):					 

    req = urllib.request.Request(url)			
    f = urllib.request.urlopen(req)
    return f.read()						

xhtml = url_get_contents(url).decode('utf-8')
							
p = HTMLTableParser()						

p.feed(xhtml)							

# pprint(p.tables[1])						

# print("\n\nPANDAS DATAFRAME\n")				
granaria_milano = pd.DataFrame(p.tables[1])
print("BORSA MERCI DI Milano - %s" % url) 
print(granaria_milano)



with open('listino_prezzi_Milano.txt', 'w', encoding = "utf-8") as f:
    with redirect_stdout(f):
        print("BORSA MERCI DI Milano - %s" % url) 
        print(granaria_milano)
        
# os.system('Notepad listino_prezzi_Milano.txt')  