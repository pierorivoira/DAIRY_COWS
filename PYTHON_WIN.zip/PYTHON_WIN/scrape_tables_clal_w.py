# scrape_tables_clal_w.py

# https://www.clal.it/clal20/mini_index.php?section=razquotazioni2015&mode=mini&h=600&w=900



### WINDOWS ###



import os, ssl, urllib.request
from html.parser import HTMLParser
from html_table_parser.parser import HTMLTableParser
from datetime import date, datetime, timedelta
import pandas as pd
from contextlib import redirect_stdout


user = os.getlogin()
os.chdir('C:/Users/%s/PYTHON' % user)

ssl._create_default_https_context = ssl._create_unverified_context

pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', None)

def url_get_contents(url):
	req = urllib.request.Request(url=url)
	f = urllib.request.urlopen(req)
	return f.read()

xhtml = url_get_contents('https://www.clal.it/clal20/mini_index.php?section=razquotazioni2015&mode=mini&h=600&w=900').decode('utf-8')
p = HTMLTableParser()
p.feed(xhtml)
clal = pd.DataFrame(p.tables[0])

print('Listino prezzi clal creato con successo!')

with open('listino_prezzi_clal.txt', 'w', encoding = "utf-8") as f:
    with redirect_stdout(f):
        print(clal)
    f.close()
