# scrape_tables_teseo_w.py
# https://www.geeksforgeeks.org/scrape-tables-from-any-website-using-python/



### WINDOWS ###



import os, ssl, urllib.request
import pandas as pd
# from pprint import pprint					
from html_table_parser.parser import HTMLTableParser		
from datetime import datetime, timedelta
from contextlib import redirect_stdout

ssl._create_default_https_context = ssl._create_unverified_context					


user = os.getlogin()
os.chdir('C:/Users/%s/PYTHON' % user)


data_aggiornamento_teseo = datetime.today().strftime('%d.%m.%Y')


pd.set_option('display.max_rows', 200)
pd.options.display.width=None

def url_get_contents(url):					

    req = urllib.request.Request(url=url)			
    f = urllib.request.urlopen(req)
    return f.read()						


xhtml = url_get_contents('https://teseo.clal.it').decode('utf-8')
								

p = HTMLTableParser()						

p.feed(xhtml)							
# print(len(p.tables))
# pprint(p.tables[58])						
# print("\n\nPANDAS DATAFRAME\n")				
teseo = pd.DataFrame(p.tables[58])

# print('FONTE: https://teseo.clal.it/')
# print('Prezzi aggiornati al %s' % data_aggiornamento_teseo) 

with open('listino_prezzi_teseo.txt', 'w', encoding = "utf-8") as f:
    with redirect_stdout(f):
        print(teseo)
        
with open('listino_prezzi_teseo.txt', 'r') as file:
    filedata = file.read()

filedata = filedata.replace("In calo", "=> PREZZO: ")
filedata = filedata.replace("In aumento", "=> PREZZO: ")
filedata = filedata.replace("Prezzo", "prezzo")
filedata = filedata.replace("frumento", "Frumento")
filedata = filedata.replace(" /ton ", "EURO/ton; VARIAZIONE: ")

print(filedata)