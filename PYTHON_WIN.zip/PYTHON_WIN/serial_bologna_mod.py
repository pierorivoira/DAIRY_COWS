# serial_bologna.py

from tabula import *
# from threading import Thread
# from time import perf_counter
from tabula.io import read_pdf
from datetime import date, datetime, timedelta
import fileinput, io, math, numpy, os, re, subprocess, sys, tabula
import numpy as np
import pandas as pd
# import _thread as thread

user = os.getlogin()
os.chdir('C:/Users/%s/PYTHON' % user)

today = date.today()
offset_b = (today.weekday() - 3) % 7

import datetime

if datetime.datetime.today().weekday() == 3:
    last_Thursday_B = today - timedelta(days=7)
    Thursday_B = last_Thursday_B
else:
    Thursday_B = today - timedelta(days=offset_b)

data_aggiornamento_B = Thursday_B.strftime('%d.%m.%Y')
day_B = Thursday_B.strftime('%d')
if ((day_B != '10') and (day_B != '20') and (day_B != '30')): 
    day_B = day_B.replace("0","",1)
else:
    day_B = day_B

month_B = Thursday_B.strftime('%m')
if month_B != '10':
    month_B = month_B.replace("0","",1)
else:
    month_B = month_B

year_B = Thursday_B.strftime('%Y')
giorno_di_pubblicazione_B = '%s_%s_%s' % (day_B, month_B, year_B)
week_B = Thursday_B.isocalendar()[1] - 1
os.system('curl -o n.%d-%s.pdf https://www.bo.camcom.gov.it/sites/default/files/borsa-merci-e-rilevazione-prezzi/listino-dei-prezzi-settimanali/anno-%s/n.%d-%s.pdf' % (week_B, giorno_di_pubblicazione_B, year_B, week_B, giorno_di_pubblicazione_B))

def bologna_serial(i, count):
    global dataframe_bologna
    dataframe_bologna = []
    for i in range(count):
        dati = tabula.io.read_pdf('n.%d-%s.pdf' % (week_B, giorno_di_pubblicazione_B), pages='all')[i]
        dataframe_bologna.append(dati)
        return(dataframe_bologna)
        
dataframe_bologna = bologna_serial(7, 8)

pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', None)
print(dataframe_bologna)

SORGO = prezzi_0[11]
SOIA = prezzi_0[13]
MAIS = prezzi_1[17]
ORZO = prezzi_1[25]
FRUMENTO = prezzi_1[29]
PISELLO = prezzi_1[31]
FAVINO = prezzi_1[33]
FRUMENTO_TENERO_CRUSCA = prezzi_2[5]
FRUMENTO_TENERO_CRUSCHELLO = prezzi_2[5]
FRUMENTO_TENERO_TRITELLO = prezzi_2[6]
FRUMENTO_TENERO_FARINACCIO = prezzi_2[7]
FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO = prezzi_2[14]
FRUMENTO_DURO_FARINACCIO = prezzi_2[16]
FRUMENTO_DURO_FARINETTA = prezzi_2[17]
SOIA_FE = prezzi_2[19]
GIRASOLE_INTEGRALE_FE = prezzi_2[27]
COLZA_FE = prezzi_2[29]
ERBA_MED_DIS_17 = prezzi_2[35]
ERBA_MED_DIS_16 = prezzi_2[36]
ERBA_MED_DIS_14 = prezzi_2[37]
FIENO_1_TAGLIO = prezzi_2[39]
FIENO_1_TAGLIO_FIBRA_LUNGA = prezzi_2[45]
MAIS_FARINA = prezzi_3[3]
MAIS_SEMOLA_GLUTINATA = prezzi_3[4]
MELASSO_CANNA = prezzi_4[1]
MELASSO_BIETOLA = prezzi_4[2]
SOIA_BUCCETTE = prezzi_4[4]
BIETOLA_POLPE = prezzi_4[5]
COTONE = prezzi_4[7]
RISO_GRANA_VERDE = prezzi_6[15]
RISO_FARINACCIO = prezzi_6[16]
RISO_PULA_VERGINE = prezzi_6[17]
FIENO_MEDICA_17_1_TAGLIO_ROTBAL = prezzi_7[10]
FIENO_MEDICA_17_1_TAGLIO_BALQUA = prezzi_7[11]
FIENO_MEDICA_17_2_TAGLIO_ROTBAL = prezzi_7[12]
FIENO_MEDICA_17_2_TAGLIO_BALQUA = prezzi_7[13]
FIENO_MEDICA_17_3_TAGLIO_ROTBAL = prezzi_7[14]
FIENO_MEDICA_17_3_TAGLIO_BALQUA = prezzi_7[15]
FIENO_MEDICA_17_4_TAGLIO_ROTBAL = prezzi_7[16]
FIENO_MEDICA_17_4_TAGLIO_BALQUA = prezzi_7[17]
PAGLIA_ROTBAL = prezzi_7[50]

global prezzo_SORGO_B
global prezzo_SOIA_B
global prezzo_MAIS_B
global prezzo_ORZO_B
global prezzo_FRUMENTO_B
global prezzo_PISELLO_B
global prezzo_FAVINO_B
global prezzo_FRUMENTO_TENERO_CRUSCA_B
global prezzo_FRUMENTO_TENERO_CRUSCHELLO_B
global prezzo_FRUMENTO_TENERO_TRITELLO_B
global prezzo_FRUMENTO_TENERO_FARINACCIO_B
global prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B
global prezzo_FRUMENTO_DURO_FARINACCIO_B
global prezzo_FRUMENTO_DURO_FARINETTA_B
global prezzo_SOIA_FE_B
global prezzo_GIRASOLE_INTEGRALE_FE_B
global prezzo_COLZA_FE_B
global prezzo_ERBA_MED_DIS_17_B
global prezzo_ERBA_MED_DIS_16_B
global prezzo_ERBA_MED_DIS_14_B
global prezzo_FIENO_1_TAGLIO_B
global prezzo_FIENO_1_TAGLIO_FIBRA_LUNGA_B
global prezzo_MAIS_FARINA_B
global prezzo_MAIS_SEMOLA_GLUTINATA_B
global prezzo_MELASSO_CANNA_B
global prezzo_MELASSO_BIETOLA_B
global prezzo_SOIA_BUCCETTE_B
global prezzo_BIETOLA_POLPE_B
global prezzo_COTONE_B
global prezzo_RISO_GRANA_VERDE_B
global prezzo_RISO_FARINACCIO_B
global prezzo_RISO_PULA_VERGINE_B
global prezzo_FIENO_MEDICA_17_1_TAGLIO_ROTBAL_B
global prezzo_FIENO_MEDICA_17_1_TAGLIO_BALQUA_B
global prezzo_FIENO_MEDICA_17_2_TAGLIO_ROTBAL_B
global prezzo_FIENO_MEDICA_17_2_TAGLIO_BALQUA_B
global prezzo_FIENO_MEDICA_17_3_TAGLIO_ROTBAL_B
global prezzo_FIENO_MEDICA_17_3_TAGLIO_BALQUA_B
global prezzo_FIENO_MEDICA_17_4_TAGLIO_ROTBAL_B
global prezzo_FIENO_MEDICA_17_4_TAGLIO_BALQUA_B
global prezzo_PAGLIA_ROTBAL_B

if SORGO[5] != '-':
    prezzo_SORGO_B = float(SORGO[5].replace(',','.'))
else:
    prezzo_SORGO_B = 'ALIMENTO NON QUOTATO'

if SOIA[5] != '-':
    prezzo_SOIA_B = float(SOIA[5].replace(',','.'))
else:
    prezzo_SOIA_B = 'ALIMENTO NON QUOTATO'

if MAIS[4] != '-':
    prezzo_MAIS_B = float(MAIS[4].replace(',','.'))
else:
    prezzo_MAIS_B = 'ALIMENTO NON QUOTATO'

if ORZO[4] != '-':
    prezzo_ORZO_B = float(ORZO[4].replace(',','.'))
else:
    prezzo_ORZO_B = 'ALIMENTO NON QUOTATO'

if FRUMENTO[4] != '-':
    prezzo_FRUMENTO_B = float(FRUMENTO[4].replace(',','.'))
else:
    prezzo_FRUMENTO_B = 'ALIMENTO NON QUOTATO'

if PISELLO[2] != '-':
    prezzo_PISELLO_B = float(PISELLO[2].replace(',','.'))
else:
    prezzo_PISELLO_B = 'ALIMENTO NON QUOTATO'

if FAVINO[2] != '-':
    prezzo_FAVINO_B = float(FAVINO[2].replace(',','.'))
else:
    prezzo_FAVINO_B = 'ALIMENTO NON QUOTATO'

if FRUMENTO_TENERO_CRUSCA[6] != '-':
    prezzo_FRUMENTO_TENERO_CRUSCA_B = float(FRUMENTO_TENERO_CRUSCA[6].replace(',','.'))
else:
    prezzo_FRUMENTO_TENERO_CRUSCA_B = 'ALIMENTO NON QUOTATO'

if FRUMENTO_TENERO_CRUSCHELLO[6] != '-':
    prezzo_FRUMENTO_TENERO_CRUSCHELLO_B = float(FRUMENTO_TENERO_CRUSCHELLO[6].replace(',','.'))
else:
    prezzo_FRUMENTO_TENERO_CRUSCHELLO_B = 'ALIMENTO NON QUOTATO'

if FRUMENTO_TENERO_TRITELLO[6] != '-':
    prezzo_FRUMENTO_TENERO_TRITELLO_B = float(FRUMENTO_TENERO_TRITELLO[6].replace(',','.'))
else:
    prezzo_FRUMENTO_TENERO_TRITELLO_B = 'ALIMENTO NON QUOTATO'

if FRUMENTO_TENERO_FARINACCIO[6] != '-':
    prezzo_FRUMENTO_TENERO_FARINACCIO_B = float(FRUMENTO_TENERO_FARINACCIO[6].replace(',','.'))
else:
    prezzo_FRUMENTO_TENERO_FARINACCIO_B = 'ALIMENTO NON QUOTATO'

if FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO[6] != '-':
    prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B = float(FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO[6].replace(',','.'))
else:
    prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B = 'ALIMENTO NON QUOTATO'

if FRUMENTO_DURO_FARINACCIO[6] != '-':
    prezzo_FRUMENTO_DURO_FARINACCIO_B = float(FRUMENTO_DURO_FARINACCIO[6].replace(',','.'))
else:
    prezzo_FRUMENTO_DURO_FARINACCIO_B = 'ALIMENTO NON QUOTATO'

if FRUMENTO_DURO_FARINETTA[6] != '-':
    prezzo_FRUMENTO_DURO_FARINETTA_B = float(FRUMENTO_DURO_FARINETTA[6].replace(',','.'))
else:
    prezzo_FRUMENTO_DURO_FARINETTA_B = 'ALIMENTO NON QUOTATO'

if SOIA_FE[6] != '-':
    prezzo_SOIA_FE_B = float(SOIA_FE[6].replace(',','.'))
else:
    prezzo_SOIA_FE_B = 'ALIMENTO NON QUOTATO'

if SOIA_FE[6] != '-':
    prezzo_SOIA_FE_B = float(SOIA_FE[6].replace(',','.'))
else:
    prezzo_SOIA_FE_B = 'ALIMENTO NON QUOTATO'

if GIRASOLE_INTEGRALE_FE[3] != '-':
    prezzo_GIRASOLE_INTEGRALE_FE_B = float(GIRASOLE_INTEGRALE_FE[3].replace(',','.'))
else:
    prezzo_GIRASOLE_INTEGRALE_FE_B = 'ALIMENTO NON QUOTATO'

if COLZA_FE[3] != '-':
    prezzo_COLZA_FE_B = float(COLZA_FE[3].replace(',','.'))
else:
    prezzo_COLZA_FE_B = 'ALIMENTO NON QUOTATO'

if ERBA_MED_DIS_17[6] != '-':
    prezzo_ERBA_MED_DIS_17_B = float(ERBA_MED_DIS_17[6].replace(',','.'))
else:
    prezzo_ERBA_MED_DIS_17_B = 'ALIMENTO NON QUOTATO'

if ERBA_MED_DIS_16[6] != '-':
    prezzo_ERBA_MED_DIS_16_B = float(ERBA_MED_DIS_16[6].replace(',','.'))
else:
    prezzo_ERBA_MED_DIS_16_B = 'ALIMENTO NON QUOTATO'
   
if ERBA_MED_DIS_14[6] != '-':
    prezzo_ERBA_MED_DIS_14_B = float(ERBA_MED_DIS_14[6].replace(',','.'))
else:
    prezzo_ERBA_MED_DIS_14_B = 'ALIMENTO NON QUOTATO'

if FIENO_1_TAGLIO[6] != '-':
    prezzo_FIENO_1_TAGLIO_B = float(FIENO_1_TAGLIO[6].replace(',','.'))
else:
    prezzo_FIENO_1_TAGLIO_B = 'ALIMENTO NON QUOTATO'

if FIENO_1_TAGLIO_FIBRA_LUNGA[6] != '-':
    prezzo_FIENO_1_TAGLIO_FIBRA_LUNGA_B = float(FIENO_1_TAGLIO_FIBRA_LUNGA[6].replace(',','.'))
else:
    prezzo_FIENO_1_TAGLIO_FIBRA_LUNGA_B = 'ALIMENTO NON QUOTATO'

if MAIS_FARINA[4] != '-':
    prezzo_MAIS_FARINA_B = float(MAIS_FARINA[4].replace(',','.'))
else:
    prezzo_MAIS_FARINA_B = 'ALIMENTO NON QUOTATO'

if MAIS_SEMOLA_GLUTINATA[4] != '-':
    prezzo_MAIS_SEMOLA_GLUTINATA_B = float(MAIS_SEMOLA_GLUTINATA[4].replace(',','.'))
else:
    prezzo_MAIS_SEMOLA_GLUTINATA_B = 'ALIMENTO NON QUOTATO'

if MELASSO_CANNA[6] != '-':
    prezzo_MELASSO_CANNA_B = float(MELASSO_CANNA[6].replace(',','.'))
else:
    prezzo_MELASSO_CANNA_B = 'ALIMENTO NON QUOTATO'

if MELASSO_BIETOLA[6] != '-':
    prezzo_MELASSO_BIETOLA_B = float(MELASSO_BIETOLA[6].replace(',','.'))
else:
    prezzo_MELASSO_BIETOLA_B = 'ALIMENTO NON QUOTATO'

if SOIA_BUCCETTE[6] != '-':
    prezzo_SOIA_BUCCETTE_B = float(SOIA_BUCCETTE[6].replace(',','.'))
else:
    prezzo_SOIA_BUCCETTE_B = 'ALIMENTO NON QUOTATO'

if BIETOLA_POLPE[6] != '-':
    prezzo_BIETOLA_POLPE_B = float(BIETOLA_POLPE[6].replace(',','.'))
else:
    prezzo_BIETOLA_POLPE_B = 'ALIMENTO NON QUOTATO'

if COTONE[6] != '-':
    prezzo_COTONE_B = float(COTONE[6].replace(',','.'))
else:
    prezzo_COTONE_B = 'ALIMENTO NON QUOTATO'

if RISO_GRANA_VERDE[5] != '-':
    prezzo_RISO_GRANA_VERDE_B = float(RISO_GRANA_VERDE[5].replace(',','.'))
else:
    prezzo_RISO_GRANA_VERDE_B = 'ALIMENTO NON QUOTATO'

if RISO_FARINACCIO[5] != '-':
    prezzo_RISO_FARINACCIO_B = float(RISO_FARINACCIO[5].replace(',','.'))
else:
    prezzo_RISO_FARINACCIO_B = 'ALIMENTO NON QUOTATO'

if RISO_PULA_VERGINE[5] != '-':
    prezzo_RISO_PULA_VERGINE_B = float(RISO_PULA_VERGINE[5].replace(',','.'))
else:
    prezzo_RISO_PULA_VERGINE_B = 'ALIMENTO NON QUOTATO'

if FIENO_MEDICA_17_1_TAGLIO_ROTBAL[5] != '-':
    prezzo_FIENO_MEDICA_17_1_TAGLIO_ROTBAL_B = float(FIENO_MEDICA_17_1_TAGLIO_ROTBAL[5].replace(',','.'))
else:
    prezzo_FIENO_MEDICA_17_1_TAGLIO_ROTBAL_B = 'ALIMENTO NON QUOTATO'

if FIENO_MEDICA_17_1_TAGLIO_BALQUA[5] != '-':
    prezzo_FIENO_MEDICA_17_1_TAGLIO_BALQUA_B = float(FIENO_MEDICA_17_1_TAGLIO_BALQUA[5].replace(',','.'))
else:
    prezzo_FIENO_MEDICA_17_1_TAGLIO_BALQUA_B = 'ALIMENTO NON QUOTATO'

if FIENO_MEDICA_17_2_TAGLIO_ROTBAL[5] != '-':
    prezzo_FIENO_MEDICA_17_2_TAGLIO_ROTBAL_B = float(FIENO_MEDICA_17_2_TAGLIO_ROTBAL[5].replace(',','.'))
else:
    prezzo_FIENO_MEDICA_17_2_TAGLIO_ROTBAL_B = 'ALIMENTO NON QUOTATO'

if FIENO_MEDICA_17_2_TAGLIO_BALQUA[5] != '-':
    prezzo_FIENO_MEDICA_17_2_TAGLIO_BALQUA_B = float(FIENO_MEDICA_17_2_TAGLIO_BALQUA[5].replace(',','.'))
else:
    prezzo_FIENO_MEDICA_17_2_TAGLIO_BALQUA_B = 'ALIMENTO NON QUOTATO'

if FIENO_MEDICA_17_3_TAGLIO_ROTBAL[5] != '-':
    prezzo_FIENO_MEDICA_17_3_TAGLIO_ROTBAL_B = float(FIENO_MEDICA_17_3_TAGLIO_ROTBAL[5].replace(',','.'))
else:
    prezzo_FIENO_MEDICA_17_3_TAGLIO_ROTBAL_B = 'ALIMENTO NON QUOTATO'

if FIENO_MEDICA_17_3_TAGLIO_BALQUA[5] != '-':
    prezzo_FIENO_MEDICA_17_3_TAGLIO_BALQUA_B = float(FIENO_MEDICA_17_3_TAGLIO_BALQUA[5].replace(',','.'))
else:
    prezzo_FIENO_MEDICA_17_3_TAGLIO_BALQUA_B = 'ALIMENTO NON QUOTATO'

if FIENO_MEDICA_17_4_TAGLIO_ROTBAL[5] != '-':
    prezzo_FIENO_MEDICA_17_4_TAGLIO_ROTBAL_B = float(FIENO_MEDICA_17_4_TAGLIO_ROTBAL[5].replace(',','.'))
else:
    prezzo_FIENO_MEDICA_17_4_TAGLIO_ROTBAL_B = 'ALIMENTO NON QUOTATO'

if FIENO_MEDICA_17_4_TAGLIO_BALQUA[5] != '-':
    prezzo_FIENO_MEDICA_17_4_TAGLIO_BALQUA_B = float(FIENO_MEDICA_17_4_TAGLIO_BALQUA[5].replace(',','.'))
else:
    prezzo_FIENO_MEDICA_17_4_TAGLIO_BALQUA_B = 'ALIMENTO NON QUOTATO'

if PAGLIA_ROTBAL[5] != '-':
    prezzo_PAGLIA_ROTBAL_B = float(PAGLIA_ROTBAL[5].replace(',','.'))
else:
    prezzo_PAGLIA_ROTBAL_B = 'ALIMENTO NON QUOTATO'

print('Listino prezzi della BORSA MERCI di Bologna creato con successo!')

