Python 3.8.8 (tags/v3.8.8:024d805, Feb 19 2021, 13:18:16) [MSC v.1928 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> import os
>>> os.chdir('C:/Users/piero/PYTHON')
>>> alimenti = ['MAIS PASTONE INTEGRALE (costo di produzione)', 'FIENO MEDICA 1 TG (costo di produzione)', 'FIENO MEDICA 2 TG (costo di produzione)', 'FIENO PRATO POLIFITA (costo di produzione)', 'LOIETTO INSILATO', 'MAIS INSILATO', 'FRUMENTO TENERO FARINACCIO', 'FRUMENTO TENERO FARINACCIO (BORSA MERCI Bologna)', 'FRUMENTO TENERO TRITELLO', 'FRUMENTO TENERO TRITELLO (BORSA MERCI Bologna)', 'FRUMENTO TENERO CRUSCA', 'FRUMENTO TENERO CRUSCA (BORSA MERCI Bologna)', 'FRUMENTO TENERO CRUSCHELLO', 'FRUMENTO TENERO CRUSCHELLO (BORSA MERCI Bologna)', 'FRUMENTO TENERO GERME', 'FRUMENTO DURO CRUSCA CRUSCHELLO TRITELLO (BORSA MERCI Bologna)', 'FRUMENTO DURO FARINACCIO', 'FRUMENTO DURO FARINACCIO (BORSA MERCI Bologna)', 'FRUMENTO DURO FARINETTA (BORSA MERCI Bologna)', 'MAIS', 'MAIS (BORSA MERCI Bologna)', 'MAIS FARINA (BORSA MERCI Bologna)', 'MAIS GLUTINE', 'MAIS FARINA GLUTINATA', 'MAIS SEMOLA GLUTINATA', 'MAIS SEMOLA GLUTINATA (BORSA MERCI Bologna)', 'SEGALE', 'FRUMENTO (BORSA MERCI Bologna)', 'ORZO', 'ORZO (BORSA MERCI Bologna)', 'AVENA', 'TRITICALE', 'SORGO', 'SORGO (BORSA MERCI Bologna)', 'MANIOCA', 'PISELLO', 'PISELLO (BORSA MERCI Bologna)', 'FAVINO (BORSA MERCI Bologna)', 'FAVINO FORAGGIO (BORSA MERCI Foggia)', 'LUPINO', 'SOIA', 'SOIA (BORSA MERCI Bologna)', 'COLZA FE', 'COLZA FE (BORSA MERCI Bologna)', 'GIRASOLE DECORTICATO FE', 'GIRASOLE INTEGRALE FE (BORSA MERCI Bologna)', 'SOIA FE', 'SOIA FE (BORSA MERCI Bologna)', 'ERBA MEDICA DIS EXTRA', 'ERBA MEDICA DIS 1 QUAL', 'ERBA MED DIS 17 (BORSA MERCI Bologna)', 'ERBA MED DIS 16 (BORSA MERCI Bologna)', 'ERBA MED DIS 14 (BORSA MERCI Bologna)', 'MELASSO', 'MELASSO CANNA (BORSA MERCI Bologna)', 'MELASSO BIETOLA (BORSA MERCI Bologna)', 'BIETOLA POLPE SECCHE', 'CARRUBE FRANTUMATE', 'FIENO MAGGENGO', 'FIENO 1 TAGLIO (BORSA MERCI Bologna)', 'FIENO 1 TAGLIO FIBRA LUNGA (BORSA MERCI Bologna)', 'FIENO AGOSTANO', 'FIENO MEDICA', 'FIENO MEDICA 17 1 TAGLIO ROTBAL (BORSA MERCI Bologna)', 'FIENO MEDICA 17 1 TAGLIO BALQUA (BORSA MERCI Bologna)', 'FIENO MEDICA 17 2 TAGLIO ROTBAL (BORSA MERCI Bologna)', 'FIENO MEDICA 17 2 TAGLIO BALQUA (BORSA MERCI Bologna)', 'FIENO MEDICA 17 3 TAGLIO ROTBAL (BORSA MERCI Bologna)', 'FIENO MEDICA 17 3 TAGLIO BALQUA (BORSA MERCI Bologna)', 'FIENO MEDICA 17 4 TAGLIO ROTBAL (BORSA MERCI Bologna)', 'FIENO MEDICA 17 4 TAGLIO BALQUA (BORSA MERCI Bologna)', 'PAGLIA', 'PAGLIA ROTBAL (BORSA MERCI Bologna)', 'SOIA BUCCETTE', 'SOIA BUCCETTE (BORSA MERCI Bologna)', 'BIETOLA POLPE (BORSA MERCI Bologna)', 'RISO GRANA VERDE', 'RISO GRANA VERDE (BORSA MERCI Bologna)', 'RISO FARINACCIO', 'RISO FARINACCIO (BORSA MERCI Bologna)', 'RISO PULA VERGINE', 'RISO PULA VERGINE (BORSA MERCI Bologna)', 'COTONE (BORSA MERCI Bologna)']
>>> from crea_db_PREZZI_clal_w import prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR
>>> type(prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR)
<class 'str'>
>>> prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR = float(prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR)
>>> type(prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR)
<class 'float'>
>>> prezzi = []
>>> prezzi.append('%f' % prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR)
>>> prezzi
['124.000000']
>>> from crea_db_PREZZI_clal_w import prezzo_FIENO_MEDICA_1_TG_COSTO_PR
>>> prezzo_FIENO_MEDICA_1_TG_COSTO_PR = float(prezzo_FIENO_MEDICA_1_TG_COSTO_PR)
>>> prezzi.append('%f' % prezzo_FIENO_MEDICA_1_TG_COSTO_PR)
>>> prezzi
['124.000000', '123.000000']
>>> from crea_db_PREZZI_clal_w import prezzo_FIENO_MEDICA_2_TG_COSTO_PR
>>> prezzo_FIENO_MEDICA_2_TG_COSTO_PR = float(prezzo_FIENO_MEDICA_2_TG_COSTO_PR)
>>> prezzi.append('%f' % prezzo_FIENO_MEDICA_2_TG_COSTO_PR)
>>> prezzi
['124.000000', '123.000000', '141.000000']
>>> from crea_db_PREZZI_clal_w import prezzo_FIENO_PRATO_POLIFITA_COSTO_PR
>>> prezzo_FIENO_PRATO_POLIFITA_COSTO_PR = float(prezzo_FIENO_PRATO_POLIFITA_COSTO_PR)
>>> prezzi.append(prezzo_FIENO_PRATO_POLIFITA_COSTO_PR)
>>> prezzi
['124.000000', '123.000000', '141.000000', 129.0]
>>> from crea_db_PREZZI_Alessandria_w import prezzo_LOIETTO_INSILATO
>>> type(prezzo_LOIETTO_INSILATO)
<class 'float'>
>>> prezzi.append(prezzo_LOIETTO_INSILATO)
>>> prezzi
['124.000000', '123.000000', '141.000000', 129.0, 32.0]
>>> from crea_db_PREZZI_Alessandria_w import prezzo_MAIS_INSILATO
>>> type(prezzo_MAIS_INSILATO)
<class 'float'>
>>> prezzi.append(prezzo_MAIS_INSILATO)
>>> from crea_db_PREZZI_Milano_w import prezzo_FRUMENTO_TENERO_FARINACCIO
>>> type(prezzo_FRUMENTO_TENERO_FARINACCIO)
<class 'float'>
>>> prezzi.append(prezzo_FRUMENTO_TENERO_FARINACCIO)
>>> from crea_db_PREZZI_Bologna_w import prezzo_FRUMENTO_TENERO_FARINACCIO_B
>>> type(prezzo_FRUMENTO_TENERO_FARINACCIO_B)
<class 'float'>
>>> prezzi.append(prezzo_FRUMENTO_TENERO_FARINACCIO_B)
>>> from crea_db_PREZZI_Milano_w import prezzo_FRUMENTO_TENERO_TRITELLO
>>> type(prezzo_FRUMENTO_TENERO_TRITELLO)
<class 'float'>
>>> prezzi.append(prezzo_FRUMENTO_TENERO_TRITELLO)
>>> prezzi
['124.000000', '123.000000', '141.000000', 129.0, 32.0, 40.0, 325.0, 330.0, 273.0]
>>> prezzi[0]
'124.000000'
>>> type(prezzi[0])
<class 'str'>
>>> prezzi[0] = prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR
>>> prezzi
[124.0, '123.000000', '141.000000', 129.0, 32.0, 40.0, 325.0, 330.0, 273.0]
>>> type(prezzi[0])
<class 'float'>
>>> prezzi[1] = prezzo_FIENO_MEDICA_1_TG_COSTO_PR
>>> prezzi
[124.0, 123.0, '141.000000', 129.0, 32.0, 40.0, 325.0, 330.0, 273.0]
>>> prezzi[2] = prezzo_FIENO_MEDICA_2_TG_COSTO_PR
>>> prezzi
[124.0, 123.0, 141.0, 129.0, 32.0, 40.0, 325.0, 330.0, 273.0]
>>> len(prezzi)
9
>>> from crea_db_PREZZI_Bologna_w import prezzo_FRUMENTO_TENERO_TRITELLO_B
>>> type(prezzo_FRUMENTO_TENERO_TRITELLO_B)
<class 'float'>
>>> prezzi.append(prezzo_FRUMENTO_TENERO_TRITELLO_B)
>>> from crea_db_PREZZI_Milano_w import prezzo_FRUMENTO_TENERO_CRUSCA
>>> type(prezzo_FRUMENTO_TENERO_CRUSCA)
<class 'float'>
>>> prezzi.append(prezzo_FRUMENTO_TENERO_CRUSCA)
>>> from crea_db_PREZZI_Bologna_w import prezzo_FRUMENTO_TENERO_CRUSCA_B
>>> type(prezzo_FRUMENTO_TENERO_CRUSCA_B)
<class 'float'>
>>> prezzi.append(prezzo_FRUMENTO_TENERO_CRUSCA_B)
>>> from crea_db_PREZZI_Milano_w import prezzo_FRUMENTO_TENERO_CRUSCHELLO
>>> type(prezzo_FRUMENTO_TENERO_CRUSCHELLO)
<class 'float'>
>>> prezzi.append(prezzo_FRUMENTO_TENERO_CRUSCHELLO)
>>> from crea_db_PREZZI_Bologna_w import prezzo_FRUMENTO_TENERO_CRUSCHELLO_B
>>> type(prezzo_FRUMENTO_TENERO_CRUSCHELLO_B)
<class 'float'>
>>> prezzi.append(prezzo_FRUMENTO_TENERO_CRUSCHELLO_B)
>>> from crea_db_PREZZI_Milano_w import prezzo_FRUMENTO_TENERO_GERME
>>> type(prezzo_FRUMENTO_TENERO_GERME)
<class 'float'>
>>> prezzi.append(prezzo_FRUMENTO_TENERO_GERME)
>>> from crea_db_PREZZI_Bologna_w import prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B
>>> type(prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B)
<class 'float'>
>>> prezzi.append(prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B)
>>> from crea_db_PREZZI_Milano_w import prezzo_FRUMENTO_DURO_FARINACCIO
>>> type(prezzo_FRUMENTO_DURO_FARINACCIO)
<class 'float'>
>>> prezzi.append(prezzo_FRUMENTO_DURO_FARINACCIO)
>>> from crea_db_PREZZI_Bologna_w import prezzo_FRUMENTO_DURO_FARINACCIO_B
>>> type(prezzo_FRUMENTO_DURO_FARINACCIO_B)
<class 'float'>
>>> prezzi.append(prezzo_FRUMENTO_DURO_FARINACCIO_B)
>>> from crea_db_PREZZI_Bologna_w import prezzo_FRUMENTO_DURO_FARINETTA_B
>>> type(prezzo_FRUMENTO_DURO_FARINETTA_B)
<class 'float'>
>>> prezzi.append(prezzo_FRUMENTO_DURO_FARINETTA_B)
>>> from crea_db_PREZZI_Milano_w import prezzo_MAIS
>>> type(prezzo_MAIS)
<class 'float'>
>>> prezzi.append(prezzo_MAIS)
>>> from crea_db_PREZZI_Bologna_w import prezzo_MAIS_B
>>> type(prezzo_MAIS_B)
<class 'float'>
>>> prezzi.append(prezzo_MAIS_B)
>>> from crea_db_PREZZI_Bologna_w import prezzo_MAIS_FARINA_B
>>> type(prezzo_MAIS_FARINA_B)
<class 'float'>
>>> prezzi.append(prezzo_MAIS_FARINA_B)
>>> from crea_db_PREZZI_Milano_w import prezzo_MAIS_GLUTINE
>>> type(prezzo_MAIS_GLUTINE)
<class 'float'>
>>> prezzi.append(prezzo_MAIS_GLUTINE)
>>> from crea_db_PREZZI_Milano_w import prezzo_MAIS_FARINA_GLUTINATA
>>> type(prezzo_MAIS_FARINA_GLUTINATA)
<class 'float'>
>>> prezzi.append(prezzo_MAIS_FARINA_GLUTINATA)
>>> from crea_db_PREZZI_Milano_w import prezzo_MAIS_SEMOLA_GLUTINATA
>>> type(prezzo_MAIS_SEMOLA_GLUTINATA)
<class 'str'>
>>> prezzi.append(prezzo_MAIS_SEMOLA_GLUTINATA)
>>> prezzi
[124.0, 123.0, 141.0, 129.0, 32.0, 40.0, 325.0, 330.0, 273.0, 288.0, 268.0, 282.0, 268.0, 282.0, 710.0, 279.0, 292.0, 300.0, 400.0, 388.0, 405.0, 427.0, 1640.0, 345.0, 'ALIMENTO NON QUOTATO']
>>> from crea_db_PREZZI_Bologna_w import prezzo_MAIS_SEMOLA_GLUTINATA_B
>>> type(prezzo_MAIS_SEMOLA_GLUTINATA_B)
<class 'float'>
>>> prezzi.append(prezzo_MAIS_SEMOLA_GLUTINATA_B)
>>> prezzi
[124.0, 123.0, 141.0, 129.0, 32.0, 40.0, 325.0, 330.0, 273.0, 288.0, 268.0, 282.0, 268.0, 282.0, 710.0, 279.0, 292.0, 300.0, 400.0, 388.0, 405.0, 427.0, 1640.0, 345.0, 'ALIMENTO NON QUOTATO', 365.0]
>>> from crea_db_PREZZI_Milano_w import prezzo_SEGALE
>>> type(prezzo_SEGALE)
<class 'str'>
>>> prezzi.append(prezzo_SEGALE)
>>> from crea_db_PREZZI_Bologna_w import prezzo_FRUMENTO_B
>>> type(prezzo_FRUMENTO_B)
<class 'float'>
>>> prezzi.append(prezzo_FRUMENTO_B)
>>> from crea_db_PREZZI_Milano_w import prezzo_ORZO
>>> type(prezzo_ORZO)
<class 'str'>
>>> prezzi.append(prezzo_ORZO)
>>> prezzi
[124.0, 123.0, 141.0, 129.0, 32.0, 40.0, 325.0, 330.0, 273.0, 288.0, 268.0, 282.0, 268.0, 282.0, 710.0, 279.0, 292.0, 300.0, 400.0, 388.0, 405.0, 427.0, 1640.0, 345.0, 'ALIMENTO NON QUOTATO', 365.0, 'ALIMENTO NON QUOTATO', 427.0, 'ALIMENTO NON QUOTATO']
>>> from crea_db_PREZZI_Bologna_w import prezzo_ORZO_B
>>> type(prezzo_ORZO_B)
<class 'float'>
>>> prezzi.append(prezzo_ORZO_B)
>>> prezzi
[124.0, 123.0, 141.0, 129.0, 32.0, 40.0, 325.0, 330.0, 273.0, 288.0, 268.0, 282.0, 268.0, 282.0, 710.0, 279.0, 292.0, 300.0, 400.0, 388.0, 405.0, 427.0, 1640.0, 345.0, 'ALIMENTO NON QUOTATO', 365.0, 'ALIMENTO NON QUOTATO', 427.0, 'ALIMENTO NON QUOTATO', 384.0]
>>> from crea_db_PREZZI_Milano_w import prezzo_AVENA
>>> type(prezzo_AVENA)
<class 'str'>
>>> prezzi.append(prezzo_AVENA)
>>> prezzi
[124.0, 123.0, 141.0, 129.0, 32.0, 40.0, 325.0, 330.0, 273.0, 288.0, 268.0, 282.0, 268.0, 282.0, 710.0, 279.0, 292.0, 300.0, 400.0, 388.0, 405.0, 427.0, 1640.0, 345.0, 'ALIMENTO NON QUOTATO', 365.0, 'ALIMENTO NON QUOTATO', 427.0, 'ALIMENTO NON QUOTATO', 384.0, 'ALIMENTO NON QUOTATO']
>>> from crea_db_PREZZI_Milano_w import prezzo_TRITICALE
>>> type(prezzo_TRITICALE)
<class 'str'>
>>> prezzi.append(prezzo_TRITICALE)
>>> prezzi
[124.0, 123.0, 141.0, 129.0, 32.0, 40.0, 325.0, 330.0, 273.0, 288.0, 268.0, 282.0, 268.0, 282.0, 710.0, 279.0, 292.0, 300.0, 400.0, 388.0, 405.0, 427.0, 1640.0, 345.0, 'ALIMENTO NON QUOTATO', 365.0, 'ALIMENTO NON QUOTATO', 427.0, 'ALIMENTO NON QUOTATO', 384.0, 'ALIMENTO NON QUOTATO', 'ALIMENTO NON QUOTATO']
>>> from crea_db_PREZZI_Milano_w import prezzo_SORGO
>>> type(prezzo_SORGO)
<class 'float'>
>>> prezzi.append(prezzo_SORGO)
>>> from crea_db_PREZZI_Bologna_w import prezzo_SORGO_B
>>> type(prezzo_SORGO_B)
<class 'float'>
>>> prezzi.append(prezzo_SORGO_B)
>>> from crea_db_PREZZI_Milano_w import prezzo_MANIOCA
>>> type(prezzo_MANIOCA)
<class 'str'>
>>> prezzi.append(prezzo_MANIOCA)
>>> from crea_db_PREZZI_Milano_w import prezzo_PISELLO
>>> type(prezzo_PISELLO)
<class 'float'>
>>> prezzi.append(prezzo_PISELLO)
>>> from crea_db_PREZZI_Bologna_w import prezzo_PISELLO_B
>>> type(prezzo_PISELLO_B)
<class 'float'>
>>> prezzi.append(prezzo_PISELLO_B)
>>> from crea_db_PREZZI_Bologna_w import prezzo_FAVINO_B
>>> type(prezzo_FAVINO_B)
<class 'str'>
>>> prezzi.append(prezzo_FAVINO_B)
>>> prezzi
[124.0, 123.0, 141.0, 129.0, 32.0, 40.0, 325.0, 330.0, 273.0, 288.0, 268.0, 282.0, 268.0, 282.0, 710.0, 279.0, 292.0, 300.0, 400.0, 388.0, 405.0, 427.0, 1640.0, 345.0, 'ALIMENTO NON QUOTATO', 365.0, 'ALIMENTO NON QUOTATO', 427.0, 'ALIMENTO NON QUOTATO', 384.0, 'ALIMENTO NON QUOTATO', 'ALIMENTO NON QUOTATO', 385.0, 385.0, 'ALIMENTO NON QUOTATO', 444.0, 440.0, 'alimento non quotato']
>>> from crea_db_PREZZI_Foggia_w import prezzo_FAVINO_FORAGGIO_F
>>> type(prezzo_FAVINO_FORAGGIO_F)
<class 'float'>
>>> prezzi.append(prezzo_FAVINO_FORAGGIO_F)
>>> from crea_db_PREZZI_Alessandria_w import prezzo_LUPINO
>>> type(prezzo_LUPINO)
<class 'float'>
>>> prezzi.append(prezzo_LUPINO)
>>> from crea_db_PREZZI_Milano_w import prezzo_SOIA
>>> type(prezzo_SOIA)
<class 'float'>
>>> prezzi.append(prezzo_SOIA)
>>> from crea_db_PREZZI_Bologna_w import prezzo_SOIA_B
>>> type(prezzo_SOIA_B)
<class 'float'>
>>> prezzi.append(prezzo_SOIA_B)
>>> from crea_db_PREZZI_Milano_w import prezzo_COLZA_FE
>>> type(prezzo_COLZA_FE)
<class 'float'>
>>> prezzi.append(prezzo_COLZA_FE)
>>> from crea_db_PREZZI_Bologna_w import prezzo_COLZA_FE_B
>>> prezzi.append(prezzo_COLZA_FE_B)
>>> from crea_db_PREZZI_Milano_w import prezzo_GIRASOLE_DECORTICATO_FE
>>> prezzi.append(prezzo_GIRASOLE_DECORTICATO_FE)
>>> from crea_db_PREZZI_Bologna_w import prezzo_GIRASOLE_INTEGRALE_FE_B
>>> prezzi.append(prezzo_GIRASOLE_INTEGRALE_FE_B)
>>> from crea_db_PREZZI_Milano_w import prezzo_SOIA_FE
>>> prezzi.append(
KeyboardInterrupt
>>> prezzi.append(prezzo_SOIA_FE)
>>> from crea_db_PREZZI_Bologna_w import prezzo_SOIA_FE_B
>>> prezzi.append(prezzo_SOIA_FE_B)
>>> prezzi
[124.0, 123.0, 141.0, 129.0, 32.0, 40.0, 325.0, 330.0, 273.0, 288.0, 268.0, 282.0, 268.0, 282.0, 710.0, 279.0, 292.0, 300.0, 400.0, 388.0, 405.0, 427.0, 1640.0, 345.0, 'ALIMENTO NON QUOTATO', 365.0, 'ALIMENTO NON QUOTATO', 427.0, 'ALIMENTO NON QUOTATO', 384.0, 'ALIMENTO NON QUOTATO', 'ALIMENTO NON QUOTATO', 385.0, 385.0, 'ALIMENTO NON QUOTATO', 444.0, 440.0, 'alimento non quotato', 370.0, 200.0, 710.0, 700.0, 519.0, 498.0, 480.0, 'alimento non quotato', 601.0, 607.0]
>>> from crea_db_PREZZI_Milano_w import prezzo_ERBA_MEDICA_DIS_EXTRA
>>> prezzi.append(prezzo_ERBA_MEDICA_DIS_EXTRA)
>>> from crea_db_PREZZI_Milano_w import prezzo_ERBA_MEDICA_DIS_1_QUAL
>>> prezzi.append(prezzo_ERBA_MEDICA_DIS_1_QUAL)
>>> from crea_db_PREZZI_Bologna_w import prezzo_ERBA_MED_DIS_17_B
>>> prezzi.append(prezzo_ERBA_MED_DIS_17_B)
>>> from crea_db_PREZZI_Bologna_w import prezzo_ERBA_MED_DIS_16_B
>>> prezzi.append(prezzo_ERBA_MED_DIS_16_B)
>>> from crea_db_PREZZI_Bologna_w import prezzo_ERBA_MED_DIS_14_B
>>> prezzi.append(prezzo_ERBA_MED_DIS_14_B)
>>> from crea_db_PREZZI_Milano_w import prezzo_MELASSO
>>> prezzi.append(prezzo_MELASSO)
>>> from crea_db_PREZZI_Bologna_w import prezzo_MELASSO_CANNA_B
>>> prezzi.append(prezzo_MELASSO_CANNA_B)
>>> from crea_db_PREZZI_Bologna_w import prezzo_MELASSO_BIETOLA_B
>>> prezzi.append(prezzo_MELASSO_BIETOLA_B)
>>> from crea_db_PREZZI_Milano_w import prezzo_BIETOLA_POLPE_SECCHE
>>> prezzi.append(prezzo_BIETOLA_POLPE_SECCHE)
>>> from crea_db_PREZZI_Milano_w import prezzo_CARRUBE_FRANTUMATE
>>> prezzi.append(prezzo_CARRUBE_FRANTUMATE)
>>> from crea_db_PREZZI_Milano_w import prezzo_FIENO_MAGGENGO
>>> prezzi.append(prezzo_FIENO_MAGGENGO)
>>> from crea_db_PREZZI_Bologna_w import prezzo_FIENO_1_TAGLIO_B
>>> prezzi.append(prezzo_FIENO_1_TAGLIO_B)
>>> from crea_db_PREZZI_Bologna_w import prezzo_FIENO_1_TAGLIO_FIBRA_LUNGA_B
>>> prezzi.append(prezzo_FIENO_1_TAGLIO_FIBRA_LUNGA_B)
>>> from crea_db_PREZZI_Milano_w import prezzo_FIENO_AGOSTANO
>>> prezzi.append(prezzo_FIENO_AGOSTANO)
>>> from crea_db_PREZZI_Milano_w import prezzo_FIENO_MEDICA
>>> prezzi.append(prezzo_FIENO_MEDICA)
>>> from crea_db_PREZZI_Bologna_w import prezzo_FIENO_MEDICA_17_1_TAGLIO_ROTBAL_B
>>> prezzi.append(prezzo_FIENO_MEDICA_17_1_TAGLIO_ROTBAL_B)
>>> from crea_db_PREZZI_Bologna_w import prezzo_FIENO_MEDICA_17_1_TAGLIO_BALQUA_B
>>> prezzi.append(prezzo_FIENO_MEDICA_17_1_TAGLIO_BALQUA_B)
>>> from crea_db_PREZZI_Bologna_w import prezzo_FIENO_MEDICA_17_2_TAGLIO_ROTBAL_B
>>> prezzi.append(prezzo_FIENO_MEDICA_17_2_TAGLIO_ROTBAL_B)
>>> from crea_db_PREZZI_Bologna_w import prezzo_FIENO_MEDICA_17_2_TAGLIO_BALQUA_B
>>> prezzi.append(prezzo_FIENO_MEDICA_17_2_TAGLIO_BALQUA_B)
>>> from crea_db_PREZZI_Bologna_w import prezzo_FIENO_MEDICA_17_3_TAGLIO_ROTBAL_B
>>> prezzi.append(prezzo_FIENO_MEDICA_17_3_TAGLIO_ROTBAL_B)
>>> from crea_db_PREZZI_Bologna_w import prezzo_FIENO_MEDICA_17_3_TAGLIO_BALQUA_B
>>> prezzi.append(prezzo_FIENO_MEDICA_17_3_TAGLIO_BALQUA_B)
>>> from crea_db_PREZZI_Bologna_w import prezzo_FIENO_MEDICA_17_4_TAGLIO_ROTBAL_B
>>> prezzi.append(prezzo_FIENO_MEDICA_17_4_TAGLIO_ROTBAL_B)
>>> from crea_db_PREZZI_Bologna_w import prezzo_FIENO_MEDICA_17_4_TAGLIO_BALQUA_B
>>> prezzi.append(prezzo_FIENO_MEDICA_17_4_TAGLIO_BALQUA_B)
>>> from crea_db_PREZZI_Milano_w import prezzo_PAGLIA
>>> prezzi.append(prezzo_PAGLIA)
>>> from crea_db_PREZZI_Bologna_w import prezzo_PAGLIA_ROTBAL_B
>>> prezzi.append(prezzo_PAGLIA_ROTBAL_B)
>>> from crea_db_PREZZI_Milano_w import prezzo_SOIA_BUCCETTE
>>> prezzi.append(prezzo_SOIA_BUCCETTE)
>>> from crea_db_PREZZI_Bologna_w import prezzo_SOIA_BUCCETTE_B
>>> prezzi.append(prezzo_SOIA_BUCCETTE_B)
>>> from crea_db_PREZZI_Bologna_w import prezzo_BIETOLA_POLPE_B
>>> prezzi.append(prezzo_BIETOLA_POLPE_B)
>>> from crea_db_PREZZI_Milano_w import prezzo_RISO_GRANA_VERDE
>>> prezzi.append(prezzo_RISO_GRANA_VERDE)
>>> from crea_db_PREZZI_Bologna_w import prezzo_RISO_GRANA_VERDE_B
>>> prezzi.append(prezzo_RISO_GRANA_VERDE_B)
>>> from crea_db_PREZZI_Milano_w import prezzo_RISO_FARINACCIO
>>> prezzi.append(prezzo_RISO_FARINACCIO)
>>> from crea_db_PREZZI_Bologna_w import prezzo_RISO_FARINACCIO_B
>>> prezzi.append(prezzo_RISO_FARINACCIO_B)
>>> from crea_db_PREZZI_Milano_w import prezzo_RISO_PULA_VERGINE
>>> prezzi.append(prezzo_RISO_PULA_VERGINE)
>>> from crea_db_PREZZI_Bologna_w import prezzo_RISO_PULA_VERGINE_B
>>> prezzi.append(prezzo_RISO_PULA_VERGINE_B)
>>> from crea_db_PREZZI_Bologna_w import prezzo_COTONE_B
>>> prezzi.append(from crea_db_PREZZI_Bologna_w import prezzo_COTONE_B)
SyntaxError: invalid syntax
>>> prezzi.append(prezzo_COTONE_B)
>>> prezzi
[124.0, 123.0, 141.0, 129.0, 32.0, 40.0, 325.0, 330.0, 273.0, 288.0, 268.0, 282.0, 268.0, 282.0, 710.0, 279.0, 292.0, 300.0, 400.0, 388.0, 405.0, 427.0, 1640.0, 345.0, 'ALIMENTO NON QUOTATO', 365.0, 'ALIMENTO NON QUOTATO', 427.0, 'ALIMENTO NON QUOTATO', 384.0, 'ALIMENTO NON QUOTATO', 'ALIMENTO NON QUOTATO', 385.0, 385.0, 'ALIMENTO NON QUOTATO', 444.0, 440.0, 'alimento non quotato', 370.0, 200.0, 710.0, 700.0, 519.0, 498.0, 480.0, 'alimento non quotato', 601.0, 607.0, 308.0, 293.0, 280.0, 270.0, 250.0, 240.0, 250.0, 250.0, 370.0, 335.0, 208.0, 240.0, 230.0, 213.0, 238.0, 155.0, 163.0, 170.0, 180.0, 180.0, 195.0, 185.0, 198.0, 157.0, 70.0, 340.0, 333.0, 362.0, 385.0, 365.0, 258.0, 250.0, 207.0, 210.0, 460.0]
>>> len(prezzi)
83
>>> prezzi[82]
460.0
>>> prezzi[24]
'ALIMENTO NON QUOTATO'
>>> prezzi[25]
365.0
>>> prezzi[26]
'ALIMENTO NON QUOTATO'
>>> prezzi[27]
427.0
>>> prezzi[28]
'ALIMENTO NON QUOTATO'
>>> prezzi[29]
384.0
>>> prezzi[30]
'ALIMENTO NON QUOTATO'
>>> prezzi[31]
'ALIMENTO NON QUOTATO'
>>> prezzi[32]
385.0
>>> prezzi[33]
385.0
>>> prezzi[34]
'ALIMENTO NON QUOTATO'
>>> prezzi[35]
444.0
>>> len(alimenti)
83
>>> 