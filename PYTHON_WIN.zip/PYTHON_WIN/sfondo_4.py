# PyR-01_w_24.03.22.py


# pip install html-table-parser-python 
# pip install testresources
# pip install --upgrade --force-reinstall matplotlib
# pip install --upgrade --force-reinstall Pillow 
# sudo apt install python-tk



#####################################
########## WINDOWS VERSION ##########
#####################################

from tkinter import *
from tkinter import ttk
from PIL import Image, ImageTk                          # get widget classes
from tkinter.messagebox import *                        # get standard dialogs
from tkinter.simpledialog import askstring
from tkinter.scrolledtext import ScrolledText           # or PP4E.Gui.Tour.scrolledtext
from tkinter.filedialog   import askopenfilename        # get standard dialogs
from tkinter.filedialog   import asksaveasfilename
from tkinter.filedialog   import askdirectory
from tkinter.colorchooser import askcolor               # they live in Lib\tkinter
from tkinter.messagebox   import askquestion, showerror
from tkinter.simpledialog import askfloat
from tkinter.simpledialog import askinteger
from quitter import Quitter
import math, os, sys
import numpy as np
import tkinter as tk

global ARR, data, F, imgdir, P, PREZZI, S, user
PREZZI = []

user = os.getlogin()
os.chdir('C:/Users/%s/PYTHON' % user)
imgdir = r'C:/Users/%s/PYTHON/' % user



class GuiOutput:
    font = ('courier', 10, 'normal')                     # in class for all, root for one
    
    def __init__(root, parent=None):
        root.text = None
        if parent: root.popupnow(parent)                 # pop up now or on first write

    def popupnow(root, parent=None):                     # in parent now, Toplevel later
        if root.text: return
        root.text = ScrolledText(parent or Toplevel())
        root.text.config(font=root.font)
        root.text.pack(expand=YES, fill=BOTH)
#       hscroll = Scrollbar(root.text, orient='horizontal')
#       hscroll.pack(side=BOTTOM, fill='x')
#       hscroll.config(command=root.text.xview)
#       xscrollcommand = hscroll.set

    def write(root, text):
        root.popupnow()
        root.text.insert(END, str(text))
        root.text.see(END)
        root.text.update()                                # update gui after each line

    def writelines(root, lines):                          # lines already have '\n'
        for line in lines: root.write(line)               # or map(root.write, lines)

class GuiInput:
    def __init__(root):
        root.buff = ''

    def inputLine(root):
        line = askstring('GuiInput', 'Enter input line + <crlf> (cancel=eof)')
        if line == None:
            return ''                                     # pop-up dialog for each line
        else:                                             # cancel button means eof
            return line + '\n'                            # else add end-line marker

    def read(root, bytes=None):
        if not root.buff:
            root.buff = root.inputLine()
        if bytes:                                         # read by byte count
            text = root.buff[:bytes]                      # doesn't span lines
            root.buff = root.buff[bytes:]
        else:
            text = ''                                     # read all till eof
            line = root.buff
            while line:
                text = text + line
                line = root.inputLine()                   # until cancel=eof=''
        return text

    def readline(root):
        text = root.buff or root.inputLine()              # emulate file read methods
        root.buff = ''
        return text

    def readlines(root):
        lines = []                                        # read all lines
        while True:
            next = root.readline()
            if not next: break
            lines.append(next)
        return lines


def redirectedGuiFunc(func, *pargs, **kargs):
#   import sys
    saveStreams = sys.stdin, sys.stdout                    # map func streams to pop ups
    sys.stdin   = GuiInput()                               # pops up dialog as needed
    sys.stdout  = GuiOutput()                              # new output window per call
    sys.stderr  = sys.stdout
    result = func(*pargs, **kargs)                         # this is a blocking call
    sys.stdin, sys.stdout = saveStreams
    return result


def redirectedGuiShellCmd(command):
#   import os
    input  = os.popen(command, 'r')
    output = GuiOutput()
    def reader(input, output):                              # show a shell command's
        while True:                                         # standard output in a new
            line = input.readline()                         # pop-up text box widget;
            if not line: break                              # the readline call may block
            output.write(line)
    reader(input, output)

def info_sistema_operativo():
    import platform
    print(platform.uname())

def esegui_Notepad():
    os.system('Notepad')

IMAGE_PATH = 'logo.png'
WIDTH, HEIGHT = 650, 650

root = tk.Tk()
root.geometry('{}x{}'.format(WIDTH, HEIGHT))

canvas = tk.Canvas(root, width=WIDTH, height=HEIGHT)
canvas.pack()

img = ImageTk.PhotoImage(Image.open(IMAGE_PATH).resize((WIDTH, HEIGHT), Image.ANTIALIAS))
canvas.background = img  # Keep a reference in case this code is put in a function.
bg = canvas.create_image(0, 0, anchor=tk.NW, image=img)


toolbar = Frame(root, cursor='hand2', relief=SUNKEN, bd=2)
toolbar.pack(side=BOTTOM, fill=X)
root.toolPhotoObjs = []

from PIL import ImageTk as itk

photo1 = ImageTk.PhotoImage(Image.open('win.png').resize((40, 40), Image.ANTIALIAS))  
size = (40, 40)
btn1 = Button(toolbar, image=photo1, command=lambda: redirectedGuiFunc(info_sistema_operativo))
btn1.config(relief=RAISED, bd=2)
btn1.config(width=size[0], height=size[1])
btn1.pack(side=LEFT)


Button(toolbar, text='Quit', command=root.quit).pack(side=RIGHT, fill=Y)

root.mainloop()