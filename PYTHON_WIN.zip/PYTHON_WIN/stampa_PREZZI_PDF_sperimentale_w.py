# stampa_PREZZI_PDF_sperimentale_w.py


#####################################
########## WINDOWS VERSION ##########
#####################################

import os

user = os.getlogin()
os.chdir('C:/Users/%s/PYTHON' % user)


from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
import datetime, tabulate
import pandas as pd

last_year = (datetime.datetime.now()-relativedelta(years=1)).strftime('%Y')

today = date.today()
offset_B = (today.weekday() - 3) % 7

if datetime.datetime.today().weekday() == 3:
    last_Thursday = today - timedelta(days=7)
    Thursday = last_Thursday
else:
    Thursday = today - timedelta(days=offset_B)
        
data_aggiornamento_B = Thursday.strftime('%d.%m.%Y')

today = date.today()
offset_F = (today.weekday() - 2) % 7

import datetime

if datetime.datetime.today().weekday() == 2:
	last_Wednesday = today - timedelta(days=7)
	Wednesday = last_Wednesday
else:
	Wednesday = today - timedelta(days=offset_F)

data_aggiornamento_F = Wednesday.strftime('%d.%m.%Y')


with open('listino_prezzi_Milano.txt', 'r') as file:
	intestazione_Milano = file.readlines()[0]


from crea_db_PREZZI_clal_w import prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR
from crea_db_PREZZI_clal_w import prezzo_FIENO_MEDICA_1_TG_COSTO_PR
from crea_db_PREZZI_clal_w import prezzo_FIENO_MEDICA_2_TG_COSTO_PR
from crea_db_PREZZI_clal_w import prezzo_FIENO_PRATO_POLIFITA_COSTO_PR
from crea_db_PREZZI_Alessandria_w import prezzo_LOIETTO_INSILATO
from crea_db_PREZZI_Alessandria_w import prezzo_MAIS_INSILATO
from crea_db_PREZZI_Milano_w import prezzo_FRUMENTO_TENERO_FARINACCIO
from crea_db_PREZZI_Bologna_w import prezzo_FRUMENTO_TENERO_FARINACCIO_B
from crea_db_PREZZI_Milano_w import prezzo_FRUMENTO_TENERO_TRITELLO
from crea_db_PREZZI_Bologna_w import prezzo_FRUMENTO_TENERO_TRITELLO_B
from crea_db_PREZZI_Milano_w import prezzo_FRUMENTO_TENERO_CRUSCA
from crea_db_PREZZI_Bologna_w import prezzo_FRUMENTO_TENERO_CRUSCA_B
from crea_db_PREZZI_Milano_w import prezzo_FRUMENTO_TENERO_CRUSCHELLO
from crea_db_PREZZI_Bologna_w import prezzo_FRUMENTO_TENERO_CRUSCHELLO_B
from crea_db_PREZZI_Milano_w import prezzo_FRUMENTO_TENERO_GERME
from crea_db_PREZZI_Bologna_w import prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B
from crea_db_PREZZI_Milano_w import prezzo_FRUMENTO_DURO_FARINACCIO
from crea_db_PREZZI_Bologna_w import prezzo_FRUMENTO_DURO_FARINACCIO_B
from crea_db_PREZZI_Bologna_w import prezzo_FRUMENTO_DURO_FARINETTA_B
from crea_db_PREZZI_Milano_w import prezzo_MAIS
from crea_db_PREZZI_Bologna_w import prezzo_MAIS_B
from crea_db_PREZZI_Bologna_w import prezzo_MAIS_FARINA_B
from crea_db_PREZZI_Milano_w import prezzo_MAIS_GLUTINE
from crea_db_PREZZI_Milano_w import prezzo_MAIS_FARINA_GLUTINATA
from crea_db_PREZZI_Milano_w import prezzo_MAIS_SEMOLA_GLUTINATA
from crea_db_PREZZI_Bologna_w import prezzo_MAIS_SEMOLA_GLUTINATA_B
from crea_db_PREZZI_Milano_w import prezzo_SEGALE
from crea_db_PREZZI_Bologna_w import prezzo_FRUMENTO_B
from crea_db_PREZZI_Milano_w import prezzo_ORZO
from crea_db_PREZZI_Bologna_w import prezzo_ORZO_B
from crea_db_PREZZI_Milano_w import prezzo_AVENA
from crea_db_PREZZI_Milano_w import prezzo_TRITICALE
from crea_db_PREZZI_Milano_w import prezzo_SORGO
from crea_db_PREZZI_Bologna_w import prezzo_SORGO_B
from crea_db_PREZZI_Milano_w import prezzo_MANIOCA
from crea_db_PREZZI_Milano_w import prezzo_PISELLO
from crea_db_PREZZI_Bologna_w import prezzo_PISELLO_B
from crea_db_PREZZI_Bologna_w import prezzo_FAVINO_B
from crea_db_PREZZI_Foggia_w import prezzo_FAVINO_FORAGGIO_F
from crea_db_PREZZI_Alessandria_w import prezzo_LUPINO
from crea_db_PREZZI_Milano_w import prezzo_SOIA
from crea_db_PREZZI_Bologna_w import prezzo_SOIA_B
from crea_db_PREZZI_Milano_w import prezzo_COLZA_FE
from crea_db_PREZZI_Bologna_w import prezzo_COLZA_FE_B
from crea_db_PREZZI_Milano_w import prezzo_GIRASOLE_DECORTICATO_FE
from crea_db_PREZZI_Bologna_w import prezzo_GIRASOLE_INTEGRALE_FE_B
from crea_db_PREZZI_Milano_w import prezzo_SOIA_FE
from crea_db_PREZZI_Bologna_w import prezzo_SOIA_FE_B
from crea_db_PREZZI_Milano_w import prezzo_ERBA_MEDICA_DIS_EXTRA
from crea_db_PREZZI_Milano_w import prezzo_ERBA_MEDICA_DIS_1_QUAL
from crea_db_PREZZI_Bologna_w import prezzo_ERBA_MED_DIS_17_B
from crea_db_PREZZI_Bologna_w import prezzo_ERBA_MED_DIS_16_B
from crea_db_PREZZI_Bologna_w import prezzo_ERBA_MED_DIS_14_B
from crea_db_PREZZI_Milano_w import prezzo_MELASSO
from crea_db_PREZZI_Bologna_w import prezzo_MELASSO_CANNA_B
from crea_db_PREZZI_Bologna_w import prezzo_MELASSO_BIETOLA_B
from crea_db_PREZZI_Milano_w import prezzo_BIETOLA_POLPE_SECCHE
from crea_db_PREZZI_Milano_w import prezzo_CARRUBE_FRANTUMATE
from crea_db_PREZZI_Milano_w import prezzo_FIENO_MAGGENGO
from crea_db_PREZZI_Bologna_w import prezzo_FIENO_1_TAGLIO_B
from crea_db_PREZZI_Bologna_w import prezzo_FIENO_1_TAGLIO_FIBRA_LUNGA_B
from crea_db_PREZZI_Milano_w import prezzo_FIENO_AGOSTANO
from crea_db_PREZZI_Milano_w import prezzo_FIENO_MEDICA
from crea_db_PREZZI_Bologna_w import prezzo_FIENO_MEDICA_17_1_TAGLIO_ROTBAL_B
from crea_db_PREZZI_Bologna_w import prezzo_FIENO_MEDICA_17_1_TAGLIO_BALQUA_B
from crea_db_PREZZI_Bologna_w import prezzo_FIENO_MEDICA_17_2_TAGLIO_ROTBAL_B
from crea_db_PREZZI_Bologna_w import prezzo_FIENO_MEDICA_17_2_TAGLIO_BALQUA_B
from crea_db_PREZZI_Bologna_w import prezzo_FIENO_MEDICA_17_3_TAGLIO_ROTBAL_B
from crea_db_PREZZI_Bologna_w import prezzo_FIENO_MEDICA_17_3_TAGLIO_BALQUA_B
from crea_db_PREZZI_Bologna_w import prezzo_FIENO_MEDICA_17_4_TAGLIO_ROTBAL_B
from crea_db_PREZZI_Bologna_w import prezzo_FIENO_MEDICA_17_4_TAGLIO_BALQUA_B
from crea_db_PREZZI_Milano_w import prezzo_PAGLIA
from crea_db_PREZZI_Bologna_w import prezzo_PAGLIA_ROTBAL_B
from crea_db_PREZZI_Milano_w import prezzo_SOIA_BUCCETTE
from crea_db_PREZZI_Bologna_w import prezzo_SOIA_BUCCETTE_B
from crea_db_PREZZI_Bologna_w import prezzo_BIETOLA_POLPE_B
from crea_db_PREZZI_Milano_w import prezzo_RISO_GRANA_VERDE
from crea_db_PREZZI_Bologna_w import prezzo_RISO_GRANA_VERDE_B
from crea_db_PREZZI_Milano_w import prezzo_RISO_FARINACCIO
from crea_db_PREZZI_Bologna_w import prezzo_RISO_FARINACCIO_B
from crea_db_PREZZI_Milano_w import prezzo_RISO_PULA_VERGINE
from crea_db_PREZZI_Bologna_w import prezzo_RISO_PULA_VERGINE_B
# from scrape_tables_Verona_w import prezzo_COTONE_V
from crea_db_PREZZI_Bologna_w import prezzo_COTONE_B


alimenti = ['MAIS PASTONE INTEGRALE (costo di produzione)', 'FIENO MEDICA 1 TG (costo di produzione)', 'FIENO MEDICA 2 TG (costo di produzione)', 'FIENO PRATO POLIFITA (costo di produzione)', 'LOIETTO INSILATO', 'MAIS INSILATO', 'FRUMENTO TENERO FARINACCIO', 'FRUMENTO TENERO FARINACCIO (BORSA MERCI Bologna)', 'FRUMENTO TENERO TRITELLO', 'FRUMENTO TENERO TRITELLO (BORSA MERCI Bologna)', 'FRUMENTO TENERO CRUSCA', 'FRUMENTO TENERO CRUSCA (BORSA MERCI Bologna)', 'FRUMENTO TENERO CRUSCHELLO', 'FRUMENTO TENERO CRUSCHELLO (BORSA MERCI Bologna)', 'FRUMENTO TENERO GERME', 'FRUMENTO DURO CRUSCA CRUSCHELLO TRITELLO (BORSA MERCI Bologna)', 'FRUMENTO DURO FARINACCIO', 'FRUMENTO DURO FARINACCIO (BORSA MERCI Bologna)', 'FRUMENTO DURO FARINETTA (BORSA MERCI Bologna)', 'MAIS', 'MAIS (BORSA MERCI Bologna)', 'MAIS FARINA (BORSA MERCI Bologna)', 'MAIS GLUTINE', 'MAIS FARINA GLUTINATA', 'MAIS SEMOLA GLUTINATA', 'MAIS SEMOLA GLUTINATA (BORSA MERCI Bologna)', 'SEGALE', 'FRUMENTO (BORSA MERCI Bologna)', 'ORZO', 'ORZO (BORSA MERCI Bologna)', 'AVENA', 'TRITICALE', 'SORGO', 'SORGO (BORSA MERCI Bologna)', 'MANIOCA', 'PISELLO', 'PISELLO (BORSA MERCI Bologna)', 'FAVINO (BORSA MERCI Bologna)', 'FAVINO FORAGGIO (BORSA MERCI Foggia)', 'LUPINO', 'SOIA', 'SOIA (BORSA MERCI Bologna)', 'COLZA FE', 'COLZA FE (BORSA MERCI Bologna)', 'GIRASOLE DECORTICATO FE', 'GIRASOLE INTEGRALE FE (BORSA MERCI Bologna)', 'SOIA FE', 'SOIA FE (BORSA MERCI Bologna)', 'ERBA MEDICA DIS EXTRA', 'ERBA MEDICA DIS 1 QUAL', 'ERBA MED DIS 17 (BORSA MERCI Bologna)', 'ERBA MED DIS 16 (BORSA MERCI Bologna)', 'ERBA MED DIS 14 (BORSA MERCI Bologna)', 'MELASSO', 'MELASSO CANNA (BORSA MERCI Bologna)', 'MELASSO BIETOLA (BORSA MERCI Bologna)', 'BIETOLA POLPE SECCHE', 'CARRUBE FRANTUMATE', 'FIENO MAGGENGO', 'FIENO 1 TAGLIO (BORSA MERCI Bologna)', 'FIENO 1 TAGLIO FIBRA LUNGA (BORSA MERCI Bologna)', 'FIENO AGOSTANO', 'FIENO MEDICA', 'FIENO MEDICA 17 1 TAGLIO ROTBAL (BORSA MERCI Bologna)', 'FIENO MEDICA 17 1 TAGLIO BALQUA (BORSA MERCI Bologna)', 'FIENO MEDICA 17 2 TAGLIO ROTBAL (BORSA MERCI Bologna)', 'FIENO MEDICA 17 2 TAGLIO BALQUA (BORSA MERCI Bologna)', 'FIENO MEDICA 17 3 TAGLIO ROTBAL (BORSA MERCI Bologna)', 'FIENO MEDICA 17 3 TAGLIO BALQUA (BORSA MERCI Bologna)', 'FIENO MEDICA 17 4 TAGLIO ROTBAL (BORSA MERCI Bologna)', 'FIENO MEDICA 17 4 TAGLIO BALQUA (BORSA MERCI Bologna)', 'PAGLIA', 'PAGLIA ROTBAL (BORSA MERCI Bologna)', 'SOIA BUCCETTE', 'SOIA BUCCETTE (BORSA MERCI Bologna)', 'BIETOLA POLPE (BORSA MERCI Bologna)', 'RISO GRANA VERDE', 'RISO GRANA VERDE (BORSA MERCI Bologna)', 'RISO FARINACCIO', 'RISO FARINACCIO (BORSA MERCI Bologna)', 'RISO PULA VERGINE', 'RISO PULA VERGINE (BORSA MERCI Bologna)', 'COTONE (BORSA MERCI Bologna)']

prezzi = []
prezzi.append(prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR)
prezzi.append(prezzo_FIENO_MEDICA_1_TG_COSTO_PR)
prezzi.append(prezzo_FIENO_MEDICA_2_TG_COSTO_PR)
prezzi.append(prezzo_FIENO_PRATO_POLIFITA_COSTO_PR)
prezzi.append(prezzo_LOIETTO_INSILATO)
prezzi.append(prezzo_MAIS_INSILATO)
prezzi.append(prezzo_FRUMENTO_TENERO_FARINACCIO)
prezzi.append(prezzo_FRUMENTO_TENERO_FARINACCIO_B)
prezzi.append(prezzo_FRUMENTO_TENERO_TRITELLO)
prezzi.append(prezzo_FRUMENTO_TENERO_TRITELLO_B)
prezzi.append(prezzo_FRUMENTO_TENERO_CRUSCA)
prezzi.append(prezzo_FRUMENTO_TENERO_CRUSCA_B)
prezzi.append(prezzo_FRUMENTO_TENERO_CRUSCHELLO)
prezzi.append(prezzo_FRUMENTO_TENERO_CRUSCHELLO_B)
prezzi.append(prezzo_FRUMENTO_TENERO_GERME)
prezzi.append(prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B)
prezzi.append(prezzo_FRUMENTO_DURO_FARINACCIO)
prezzi.append(prezzo_FRUMENTO_DURO_FARINACCIO_B)
prezzi.append(prezzo_FRUMENTO_DURO_FARINETTA_B)
prezzi.append(prezzo_MAIS)
prezzi.append(prezzo_MAIS_B)
prezzi.append(prezzo_MAIS_FARINA_B)
prezzi.append(prezzo_MAIS_GLUTINE)
prezzi.append(prezzo_MAIS_FARINA_GLUTINATA)
prezzi.append(prezzo_MAIS_SEMOLA_GLUTINATA)
prezzi.append(prezzo_MAIS_SEMOLA_GLUTINATA_B)
prezzi.append(prezzo_SEGALE)
prezzi.append(prezzo_FRUMENTO_B)
prezzi.append(prezzo_ORZO)
prezzi.append(prezzo_ORZO_B)
prezzi.append(prezzo_AVENA)
prezzi.append(prezzo_TRITICALE)
prezzi.append(prezzo_SORGO)
prezzi.append(prezzo_SORGO_B)
prezzi.append(prezzo_MANIOCA)
prezzi.append(prezzo_PISELLO)
prezzi.append(prezzo_PISELLO_B)
prezzi.append(prezzo_FAVINO_B)
prezzi.append(prezzo_FAVINO_FORAGGIO_F)
prezzi.append(prezzo_LUPINO)
prezzi.append(prezzo_SOIA)
prezzi.append(prezzo_SOIA_B)
prezzi.append(prezzo_COLZA_FE)
prezzi.append(prezzo_COLZA_FE_B)
prezzi.append(prezzo_GIRASOLE_DECORTICATO_FE)
prezzi.append(prezzo_GIRASOLE_INTEGRALE_FE_B)
prezzi.append(prezzo_SOIA_FE)
prezzi.append(prezzo_SOIA_FE_B)
prezzi.append(prezzo_ERBA_MEDICA_DIS_EXTRA)
prezzi.append(prezzo_ERBA_MEDICA_DIS_1_QUAL)
prezzi.append(prezzo_ERBA_MED_DIS_17_B)
prezzi.append(prezzo_ERBA_MED_DIS_16_B)
prezzi.append(prezzo_ERBA_MED_DIS_14_B)
prezzi.append(prezzo_MELASSO)
prezzi.append(prezzo_MELASSO_CANNA_B)
prezzi.append(prezzo_MELASSO_BIETOLA_B)
prezzi.append(prezzo_BIETOLA_POLPE_SECCHE)
prezzi.append(prezzo_CARRUBE_FRANTUMATE)
prezzi.append(prezzo_FIENO_MAGGENGO)
prezzi.append(prezzo_FIENO_1_TAGLIO_B)
prezzi.append(prezzo_FIENO_1_TAGLIO_FIBRA_LUNGA_B)
prezzi.append(prezzo_FIENO_AGOSTANO)
prezzi.append(prezzo_FIENO_MEDICA)
prezzi.append(prezzo_FIENO_MEDICA_17_1_TAGLIO_ROTBAL_B)
prezzi.append(prezzo_FIENO_MEDICA_17_1_TAGLIO_BALQUA_B)
prezzi.append(prezzo_FIENO_MEDICA_17_2_TAGLIO_ROTBAL_B)
prezzi.append(prezzo_FIENO_MEDICA_17_2_TAGLIO_BALQUA_B)
prezzi.append(prezzo_FIENO_MEDICA_17_3_TAGLIO_ROTBAL_B)
prezzi.append(prezzo_FIENO_MEDICA_17_3_TAGLIO_BALQUA_B)
prezzi.append(prezzo_FIENO_MEDICA_17_4_TAGLIO_ROTBAL_B)
prezzi.append(prezzo_FIENO_MEDICA_17_4_TAGLIO_BALQUA_B)
prezzi.append(prezzo_PAGLIA)
prezzi.append(prezzo_PAGLIA_ROTBAL_B)
prezzi.append(prezzo_SOIA_BUCCETTE)
prezzi.append(prezzo_SOIA_BUCCETTE_B)
prezzi.append(prezzo_BIETOLA_POLPE_B)
prezzi.append(prezzo_RISO_GRANA_VERDE)
prezzi.append(prezzo_RISO_GRANA_VERDE_B)
prezzi.append(prezzo_RISO_FARINACCIO)
prezzi.append(prezzo_RISO_FARINACCIO_B)
prezzi.append(prezzo_RISO_PULA_VERGINE)
prezzi.append(prezzo_RISO_PULA_VERGINE_B)
prezzi.append(prezzo_COTONE_B)

d = {'ALIMENTI': alimenti, 'PREZZI': prezzi}
df = pd.DataFrame(data=d)
tabella = (df.to_markdown(tablefmt="grid"))

pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', None)

print("Prezzi della Borsa di Alessandria => valori medi annuali riferiti all'anno %s" % last_year)
print('Prezzi della Borsa di Bologna aggiornati al %s' % data_aggiornamento_B)
print('Prezzi della Borsa di Foggia aggiornati al %s' % data_aggiornamento_F)
print('%s' % intestazione_Milano)
print('Prezzi clal => valori medi riferiti agli ultimi 6 mesi')

print(tabella)

