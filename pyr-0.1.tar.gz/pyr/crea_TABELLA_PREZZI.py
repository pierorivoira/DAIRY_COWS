# crea_TABELLA_PREZZI.py

from datetime import date, datetime
import matplotlib.pyplot as plt
from pathlib import Path
from reportlab.lib.pagesizes import A4, landscape, letter
from reportlab.platypus import Frame, PageTemplate, NextPageTemplate, Image, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
from reportlab.rl_config import defaultPageSize
from reportlab.lib import colors
from reportlab.lib.colors import red
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.pdfgen import canvas
import datetime, io, os, re, reportlab.lib.colors, sys, time
import numpy as np

ALIMENTI = []
PREZZI = []

user = os.getlogin()
os.chdir('/home/%s/PYTHON/LINUX' % user)


from stampa_PREZZI_L import prezzo_LOIETTO_INSILATO, prezzo_MAIS_INSILATO, prezzo_LUPINO, prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR, prezzo_FIENO_MEDICA_1_TG_COSTO_PR, prezzo_FIENO_MEDICA_2_TG_COSTO_PR, prezzo_FIENO_PRATO_POLIFITA_COSTO_PR, prezzo_FRUMENTO_TENERO_FARINACCIO_B, prezzo_FRUMENTO_TENERO_TRITELLO_B,  prezzo_FRUMENTO_TENERO_CRUSCA_B, prezzo_FRUMENTO_TENERO_CRUSCHELLO_B, prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B, prezzo_FRUMENTO_DURO_FARINACCIO_B, prezzo_FRUMENTO_DURO_FARINETTA_B, prezzo_MAIS_B, prezzo_MAIS_FARINA_B, prezzo_MAIS_SEMOLA_GLUTINATA_B, prezzo_FRUMENTO_B, prezzo_ORZO_B, prezzo_ORZO_ESTERO_B, prezzo_SORGO_B, prezzo_PISELLO_B, prezzo_FAVINO_B, prezzo_SOIA_B, prezzo_COLZA_FE_B, prezzo_GIRASOLE_INTEGRALE_FE_B, prezzo_GIRASOLE_PROTEICO_ESTERO_FE_B, prezzo_SOIA_FE_B, prezzo_ERBA_MED_DIS_17_B, prezzo_ERBA_MED_DIS_16_B, prezzo_ERBA_MED_DIS_14_B, prezzo_MELASSO_CANNA_B, prezzo_MELASSO_BIETOLA_B, prezzo_FIENO_1_TAGLIO_B, prezzo_FIENO_1_TAGLIO_FIBRA_LUNGA_B, prezzo_FIENO_MEDICA_17_1_TAGLIO_ROTBAL_B, prezzo_FIENO_MEDICA_17_1_TAGLIO_BALQUA_B, prezzo_FIENO_MEDICA_17_2_TAGLIO_ROTBAL_B, prezzo_FIENO_MEDICA_17_2_TAGLIO_BALQUA_B, prezzo_FIENO_MEDICA_17_3_TAGLIO_ROTBAL_B, prezzo_FIENO_MEDICA_17_3_TAGLIO_BALQUA_B, prezzo_FIENO_MEDICA_17_4_TAGLIO_ROTBAL_B, prezzo_FIENO_MEDICA_17_4_TAGLIO_BALQUA_B, prezzo_PAGLIA_BAL_QUA_B, prezzo_SOIA_BUCCETTE_B, prezzo_BIETOLA_POLPE_B, prezzo_RISO_GRANA_VERDE_B, prezzo_RISO_FARINACCIO_B, prezzo_RISO_PULA_VERGINE_B, prezzo_COTONE_B, prezzo_FRUMENTO_TENERO_FARINACCIO, prezzo_FRUMENTO_TENERO_TRITELLO, prezzo_FRUMENTO_TENERO_CRUSCA, prezzo_FRUMENTO_TENERO_CRUSCHELLO, prezzo_FRUMENTO_TENERO_GERME, prezzo_FRUMENTO_DURO_FARINACCIO, prezzo_MAIS, prezzo_MAIS_GLUTINE, prezzo_MAIS_FARINA_GLUTINATA, prezzo_MAIS_SEMOLA_GLUTINATA, prezzo_SEGALE, prezzo_ORZO, prezzo_AVENA, prezzo_TRITICALE, prezzo_SORGO, prezzo_MANIOCA, prezzo_PISELLO, prezzo_SOIA, prezzo_COLZA_FE, prezzo_GIRASOLE_DECORTICATO_FE, prezzo_SOIA_FE, prezzo_ERBA_MEDICA_DIS_EXTRA, prezzo_ERBA_MEDICA_DIS_1_QUAL, prezzo_MELASSO, prezzo_BIETOLA_POLPE_SECCHE, prezzo_CARRUBE_FRANTUMATE, prezzo_FIENO_MAGGENGO, prezzo_FIENO_AGOSTANO, prezzo_FIENO_MEDICA, prezzo_PAGLIA, prezzo_SOIA_BUCCETTE, prezzo_RISO_GRANA_VERDE, prezzo_RISO_FARINACCIO, prezzo_RISO_PULA_VERGINE         


# Alessandria

ALIMENTI.append('insilato di loietto')
PREZZI.append(prezzo_LOIETTO_INSILATO)

ALIMENTI.append('insilato di mais')
PREZZI.append(prezzo_MAIS_INSILATO)

ALIMENTI.append('lupino')
PREZZI.append(prezzo_LUPINO)

# clal

ALIMENTI.append('pastone integrale di mais*')
PREZZI.append(prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR)

ALIMENTI.append('fieno di medica di I taglio*')
PREZZI.append(prezzo_FIENO_MEDICA_1_TG_COSTO_PR)

ALIMENTI.append('fieno di medica di II taglio*')
PREZZI.append(prezzo_FIENO_MEDICA_2_TG_COSTO_PR)

ALIMENTI.append('fieno di prato polifita*')
PREZZI.append(prezzo_FIENO_PRATO_POLIFITA_COSTO_PR)

# Bologna

ALIMENTI.append('farinaccio di frumento tenero')
PREZZI.append(prezzo_FRUMENTO_TENERO_FARINACCIO_B)

ALIMENTI.append('tritello di frumento tenero')
PREZZI.append(prezzo_FRUMENTO_TENERO_TRITELLO_B)

ALIMENTI.append('crusca di frumento tenero')
PREZZI.append(prezzo_FRUMENTO_TENERO_CRUSCA_B)

ALIMENTI.append('cruschello di frumento tenero')
PREZZI.append(prezzo_FRUMENTO_TENERO_CRUSCHELLO_B)

ALIMENTI.append('crusca / cruschello / tritello di frumento duro')
PREZZI.append(prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B)

ALIMENTI.append('farinaccio di frumento duro')
PREZZI.append(prezzo_FRUMENTO_DURO_FARINACCIO_B)

ALIMENTI.append('farinetta di frumento duro')
PREZZI.append(prezzo_FRUMENTO_DURO_FARINETTA_B)

ALIMENTI.append('mais')
PREZZI.append(prezzo_MAIS_B)

ALIMENTI.append('farina di mais')
PREZZI.append(prezzo_MAIS_FARINA_B)

ALIMENTI.append('semola glutinata di mais')
PREZZI.append(prezzo_MAIS_SEMOLA_GLUTINATA_B)

ALIMENTI.append('frumento')
PREZZI.append(prezzo_FRUMENTO_B)

ALIMENTI.append('orzo')
PREZZI.append(prezzo_ORZO_B)

ALIMENTI.append('orzo estero')
PREZZI.append(prezzo_ORZO_ESTERO_B)

ALIMENTI.append('sorgo')
PREZZI.append(prezzo_SORGO_B)

ALIMENTI.append('pisello')
PREZZI.append(prezzo_PISELLO_B)

ALIMENTI.append('favino')
PREZZI.append(prezzo_FAVINO_B)

ALIMENTI.append('soia')
PREZZI.append(prezzo_SOIA_B)

ALIMENTI.append('f.e. di colza')
PREZZI.append(prezzo_COLZA_FE_B)

ALIMENTI.append('f.e. di girasole integrale')
PREZZI.append(prezzo_GIRASOLE_INTEGRALE_FE_B)

ALIMENTI.append('f.e. di girasole proteico')
PREZZI.append(prezzo_GIRASOLE_PROTEICO_ESTERO_FE_B)

ALIMENTI.append('f.e. di soia')
PREZZI.append(prezzo_SOIA_FE_B)

ALIMENTI.append('erba med. dis. 17%')
PREZZI.append(prezzo_ERBA_MED_DIS_17_B)

ALIMENTI.append('erba med. dis. 16%')
PREZZI.append(prezzo_ERBA_MED_DIS_16_B)

ALIMENTI.append('erba med. dis. 14%')
PREZZI.append(prezzo_ERBA_MED_DIS_14_B)

ALIMENTI.append('melasso di canna')
PREZZI.append(prezzo_MELASSO_CANNA_B)

ALIMENTI.append('melasso di bietola')
PREZZI.append(prezzo_MELASSO_BIETOLA_B)

ALIMENTI.append('fieno I taglio')
PREZZI.append(prezzo_FIENO_1_TAGLIO_B)

ALIMENTI.append('fieno I taglio fibra lunga')
PREZZI.append(prezzo_FIENO_1_TAGLIO_FIBRA_LUNGA_B) 

ALIMENTI.append('fieno med. 17% I tg rotbal')
PREZZI.append(prezzo_FIENO_MEDICA_17_1_TAGLIO_ROTBAL_B)

ALIMENTI.append('fieno med. 17% I tg balqua')
PREZZI.append(prezzo_FIENO_MEDICA_17_1_TAGLIO_BALQUA_B)

ALIMENTI.append('fieno med. 17% II tg rotbal')
PREZZI.append(prezzo_FIENO_MEDICA_17_2_TAGLIO_ROTBAL_B)

ALIMENTI.append('fieno med. 17% II tg balqua')
PREZZI.append(prezzo_FIENO_MEDICA_17_2_TAGLIO_BALQUA_B)

ALIMENTI.append('fieno med. 17% III tg rotbal')
PREZZI.append(prezzo_FIENO_MEDICA_17_3_TAGLIO_ROTBAL_B)

ALIMENTI.append('fieno med. 17% III tg balqua')
PREZZI.append(prezzo_FIENO_MEDICA_17_3_TAGLIO_BALQUA_B)

ALIMENTI.append('fieno med. 17% IV tg rotbal')
PREZZI.append(prezzo_FIENO_MEDICA_17_4_TAGLIO_ROTBAL_B)

ALIMENTI.append('fieno med. 17% IV tg balqua')
PREZZI.append(prezzo_FIENO_MEDICA_17_4_TAGLIO_BALQUA_B)

ALIMENTI.append('paglia in balloni quad.')
PREZZI.append(prezzo_PAGLIA_BAL_QUA_B)

ALIMENTI.append('buccette di soia')
PREZZI.append(prezzo_SOIA_BUCCETTE_B)

ALIMENTI.append('polpe di bietola')
PREZZI.append(prezzo_BIETOLA_POLPE_B)

ALIMENTI.append('grana verde di riso')
PREZZI.append(prezzo_RISO_GRANA_VERDE_B)

ALIMENTI.append('farinaccio di riso')
PREZZI.append(prezzo_RISO_FARINACCIO_B)

ALIMENTI.append('pula vergine di riso')
PREZZI.append(prezzo_RISO_PULA_VERGINE_B)

ALIMENTI.append('semi di cotone')
PREZZI.append(prezzo_COTONE_B)

# Milano

ALIMENTI.append('farinaccio di frumento tenero')
PREZZI.append(prezzo_FRUMENTO_TENERO_FARINACCIO)

ALIMENTI.append('tritello di frumento tenero')
PREZZI.append(prezzo_FRUMENTO_TENERO_TRITELLO)

ALIMENTI.append('crusca di frumento tenero')
PREZZI.append(prezzo_FRUMENTO_TENERO_CRUSCA)

ALIMENTI.append('cruschello di frumento tenero')
PREZZI.append(prezzo_FRUMENTO_TENERO_CRUSCHELLO)

ALIMENTI.append('germe di frumento tenero')
PREZZI.append(prezzo_FRUMENTO_TENERO_GERME)

ALIMENTI.append('farinaccio di frumento duro')
PREZZI.append(prezzo_FRUMENTO_DURO_FARINACCIO)

ALIMENTI.append('mais')
PREZZI.append(prezzo_MAIS)

ALIMENTI.append('glutine di mais')
PREZZI.append(prezzo_MAIS_GLUTINE)

ALIMENTI.append('farina glutinata di mais')
PREZZI.append(prezzo_MAIS_FARINA_GLUTINATA)

ALIMENTI.append('semola glutinata di mais')
PREZZI.append(prezzo_MAIS_SEMOLA_GLUTINATA)

ALIMENTI.append('segale')
PREZZI.append(prezzo_SEGALE)

ALIMENTI.append('orzo')
PREZZI.append(prezzo_ORZO)

ALIMENTI.append('avena')
PREZZI.append(prezzo_AVENA)

ALIMENTI.append('triticale')
PREZZI.append(prezzo_TRITICALE)

ALIMENTI.append('sorgo')
PREZZI.append(prezzo_SORGO)

ALIMENTI.append('manioca')
PREZZI.append(prezzo_MANIOCA)

ALIMENTI.append('pisello')
PREZZI.append(prezzo_PISELLO)

ALIMENTI.append('soia')
PREZZI.append(prezzo_SOIA)

ALIMENTI.append('f.e. colza')
PREZZI.append(prezzo_COLZA_FE)

ALIMENTI.append('f.e. girasole decorticato')
PREZZI.append(prezzo_GIRASOLE_DECORTICATO_FE)

ALIMENTI.append('f.e. soia')
PREZZI.append(prezzo_SOIA_FE)

ALIMENTI.append('medica dis. extra')
PREZZI.append(prezzo_ERBA_MEDICA_DIS_EXTRA)

ALIMENTI.append('medica dis. I qual.')
PREZZI.append(prezzo_ERBA_MEDICA_DIS_1_QUAL)

ALIMENTI.append('melasso')
PREZZI.append(prezzo_MELASSO)

ALIMENTI.append('polpe secche bietola')
PREZZI.append(prezzo_BIETOLA_POLPE_SECCHE)

ALIMENTI.append('carrube frantumate')
PREZZI.append(prezzo_CARRUBE_FRANTUMATE)

ALIMENTI.append('fieno maggengo')
PREZZI.append(prezzo_FIENO_MAGGENGO)

ALIMENTI.append('fieno agostano')
PREZZI.append(prezzo_FIENO_AGOSTANO)

ALIMENTI.append('fieno medica')
PREZZI.append(prezzo_FIENO_MEDICA)

ALIMENTI.append('paglia')
PREZZI.append(prezzo_PAGLIA)

ALIMENTI.append('buccette di soia')
PREZZI.append(prezzo_SOIA_BUCCETTE)

ALIMENTI.append('grana verde di riso')
PREZZI.append(prezzo_RISO_GRANA_VERDE)

ALIMENTI.append('farinaccio di riso')
PREZZI.append(prezzo_RISO_FARINACCIO)

ALIMENTI.append('pula vergine di riso')
PREZZI.append(prezzo_RISO_PULA_VERGINE)



formatted_time = time.ctime()
today = date.today()
today = today.strftime('%d.%m.%Y')


def alternate_orientations():
    doc = SimpleDocTemplate("TABELLA_PREZZI.pdf",
    pagesize=A4,
    rightMargin=36,
    leftMargin=36,
    topMargin=36,
    bottomMargin=36)
    styles = getSampleStyleSheet()
    normal = styles["Normal"]

    margin = 0.5 * inch
    frame = Frame(margin, margin, doc.width, doc.height,
      id='frame')
    portrait_template = PageTemplate(id='portrait',
     frames=[frame],
     pagesize=A4)
    landscape_template = PageTemplate(id='landscape',
      frames=[frame],
      pagesize=landscape(A4))
    doc.addPageTemplates([portrait_template, landscape_template])

    flowables = []
      
    

# Change back to portrait
#   flowables.append(NextPageTemplate('portrait'))
#   flowables.append(PageBreak())
#   flowables.append(Paragraph("Now we're back in portrait mode again", normal))

#   doc = SimpleDocTemplate("REPORT_PyR_%s.pdf" % nome_report_pdf, pagesize=A4)
    styles = getSampleStyleSheet()       
    
       
#   styles["Normal"].spaceBefore = 10
#   styles["Normal"].spaceAfter = 10
    
    spacer = Spacer(1, 1.0*inch)    
    logo = "carro_sfondo.png"
    im = Image(logo, 3*inch, 1.5*inch)
    
    flowables.append(im)


    text = "Benvenuto nel software <i>Programma Razione Python</i> (PyR) di Piero Rivoira"
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name='Centered', alignment=TA_CENTER))
    styles["Centered"].fontSize = 12
    styles["Centered"].leading = 14
    spacer = Spacer(1, 0.5*inch)
    flowables.append(spacer)
    flowables.append(Paragraph(text, styles["Centered"]))
    flowables.append(spacer)


#   flowables.append(NextPageTemplate('landscape'))
#   flowables.append(PageBreak())


    title = '<b>TABELLA PREZZI %s</b>' % today
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name='Titolo', alignment=TA_CENTER))
    styles["Titolo"].fontSize = 20
    styles["Titolo"].leading = 14
    spacer = Spacer(1, 0.4*inch)
    flowables.append(Paragraph(title, styles["Titolo"]))
    flowables.append(spacer)

    
    styles["Normal"].fontSize = 16
    styles["Normal"].leading = 20
    
    stile_intestazione_tab = TableStyle([('FONT', (0, 0), (-1, 0), 'Helvetica', 18)])
    tblstyle = TableStyle([('FONT', (0, 1), (-1, 90), 'Helvetica', 14)])
    stile_griglia = TableStyle([('INNERGRID', (0,0), (-1,-1), 0.25, colors.black), ('BOX', (0,0), (-1,-1), 0.5, colors.black)])

    data = [['FONTE', 'ALIMENTO', 'EURO/ton'], ['Alessandria', ALIMENTI[0], PREZZI[0]], ['Alessandria', ALIMENTI[1], PREZZI[1]], ['Alessandria', ALIMENTI[2], PREZZI[2]], ['clal', ALIMENTI[3], PREZZI[3]], ['clal', ALIMENTI[4], PREZZI[4]], ['clal', ALIMENTI[5], PREZZI[5]], ['clal', ALIMENTI[6], PREZZI[6]], ['Bologna', ALIMENTI[7], PREZZI[7]], ['Bologna', ALIMENTI[8], PREZZI[8]], ['Bologna', ALIMENTI[9], PREZZI[9]], ['Bologna', ALIMENTI[10], PREZZI[10]], ['Bologna', ALIMENTI[11], PREZZI[11]], ['Bologna', ALIMENTI[12], PREZZI[12]], ['Bologna', ALIMENTI[13], PREZZI[13]], ['Bologna', ALIMENTI[14], PREZZI[14]], ['Bologna', ALIMENTI[15], PREZZI[15]], ['Bologna', ALIMENTI[16], PREZZI[16]], ['Bologna', ALIMENTI[17], PREZZI[17]], ['Bologna', ALIMENTI[18], PREZZI[18]], ['Bologna', ALIMENTI[19], PREZZI[19]], ['Bologna', ALIMENTI[20], PREZZI[20]], ['Bologna', ALIMENTI[21], PREZZI[21]], ['Bologna', ALIMENTI[22], PREZZI[22]], ['Bologna', ALIMENTI[23], PREZZI[23]], ['Bologna', ALIMENTI[24], PREZZI[24]], ['Bologna', ALIMENTI[25], PREZZI[25]], ['Bologna', ALIMENTI[26], PREZZI[26]], ['Bologna', ALIMENTI[12], PREZZI[12]], ['Bologna', ALIMENTI[12], PREZZI[12]], ['Bologna', ALIMENTI[12], PREZZI[12]], ['Bologna', ALIMENTI[27], PREZZI[27]], ['Bologna', ALIMENTI[28], PREZZI[28]], ['Bologna', ALIMENTI[29], PREZZI[29]], ['Bologna', ALIMENTI[30], PREZZI[30]], ['Bologna', ALIMENTI[31], PREZZI[31]], ['Bologna', ALIMENTI[32], PREZZI[32]], ['Bologna', ALIMENTI[33], PREZZI[33]], ['Bologna', ALIMENTI[12], PREZZI[12]], ['Bologna', ALIMENTI[12], PREZZI[12]], ['Bologna', ALIMENTI[12], PREZZI[12]], ['Bologna', ALIMENTI[34], PREZZI[34]], ['Bologna', ALIMENTI[35], PREZZI[35]], ['Bologna', ALIMENTI[36], PREZZI[36]], ['Bologna', ALIMENTI[37], PREZZI[37]], ['Bologna', ALIMENTI[38], PREZZI[38]], ['Bologna', ALIMENTI[39], PREZZI[39]], ['Bologna', ALIMENTI[40], PREZZI[40]], ['Bologna', ALIMENTI[41], PREZZI[41]], ['Bologna', ALIMENTI[42], PREZZI[42]], ['Bologna', ALIMENTI[43], PREZZI[43]], ['Milano', ALIMENTI[44], PREZZI[44]], ['Milano', ALIMENTI[45], PREZZI[45]], ['Milano', ALIMENTI[46], PREZZI[46]], ['Milano', ALIMENTI[47], PREZZI[47]], ['Milano', ALIMENTI[48], PREZZI[48]], ['Milano', ALIMENTI[49], PREZZI[49]], ['Milano', ALIMENTI[50], PREZZI[50]], ['Milano', ALIMENTI[51], PREZZI[51]], ['Milano', ALIMENTI[52], PREZZI[52]], ['Milano', ALIMENTI[53], PREZZI[53]], ['Milano', ALIMENTI[54], PREZZI[54]], ['Milano', ALIMENTI[55], PREZZI[55]], ['Milano', ALIMENTI[56], PREZZI[56]], ['Milano', ALIMENTI[57], PREZZI[57]], ['Milano', ALIMENTI[58], PREZZI[58]], ['Milano', ALIMENTI[59], PREZZI[59]], ['Milano', ALIMENTI[60], PREZZI[60]], ['Milano', ALIMENTI[61], PREZZI[61]], ['Milano', ALIMENTI[62], PREZZI[62]], ['Milano', ALIMENTI[63], PREZZI[63]], ['Milano', ALIMENTI[64], PREZZI[64]], ['Milano', ALIMENTI[65], PREZZI[65]], ['Milano', ALIMENTI[66], PREZZI[66]], ['Milano', ALIMENTI[67], PREZZI[67]], ['Milano', ALIMENTI[68], PREZZI[68]], ['Milano', ALIMENTI[69], PREZZI[69]], ['Milano', ALIMENTI[70], PREZZI[70]], ['Milano', ALIMENTI[71], PREZZI[71]], ['Milano', ALIMENTI[72], PREZZI[72]], ['Milano', ALIMENTI[73], PREZZI[73]], ['Milano', ALIMENTI[74], PREZZI[74]], ['Milano', ALIMENTI[75], PREZZI[75]], ['Milano', ALIMENTI[76], PREZZI[76]], ['Milano', ALIMENTI[77], PREZZI[77]]]   


    
    flowables.append(Spacer(inch, 0.5*inch))
    tbl = Table(data, hAlign='LEFT')
    tbl.setStyle(stile_intestazione_tab)
    tbl.setStyle(tblstyle)
    tbl.setStyle(stile_griglia)
    flowables.append(tbl)
    flowables.append(PageBreak())


    styles["Normal"].fontSize = 14
    styles["Normal"].leading = 28
    spacer = Spacer(1, 0.5*inch)

    
    testo = "* => costo di produzione"
    para = Paragraph(testo, style=styles["Normal"])
    flowables.append(para)
    flowables.append(spacer)



    doc.build(flowables)

if __name__ == '__main__':
    alternate_orientations()

os.system('evince TABELLA_PREZZI.pdf')

