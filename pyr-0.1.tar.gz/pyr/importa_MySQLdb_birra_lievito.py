# importa_MySQLdb_birra_lievito.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    birra_lievito = []

    for i in parametri:
        i = "SELECT %s FROM Sottoprodotto WHERE nome = 'birra_lievito'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        birra_lievito.append(float(i[0]))
#   print(BILIE)

    BILIE = list(np.float_(birra_lievito))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <birra_lievito> dal modulo <Sottoprodotto>') 
    from Sottoprodotto import birra_lievito
    print('<birra_lievito> importato con successo dal modulo <Sottoprodotto>!')

    BILIE = list(np.float_(birra_lievito))

    del BILIE[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del BILIE[10]
# elimino 'ceneri'

    del BILIE[13:15]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <BILIE> => %d' % len(BILIE))

    for i in range(len(BILIE)):
        BILIE[i] = BILIE[i]*10

    BILIE[0] = BILIE[0]/1000
    BILIE[12] = BILIE[12]/10

    BILIE_arr = np.array(BILIE)

    for i in range(len(BILIE)):
        BILIE[i] = float(BILIE[i])

print("COMPOSIZIONE CHIMICA dell'alimento <LIEVITO DI BIRRA>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % BILIE_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % BILIE_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % BILIE_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % BILIE_arr[3])
print("Fibra Grezza (FG) => %f g" % BILIE_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % BILIE_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % BILIE_arr[6])
print("FAT (Grasso) => %f g" % BILIE_arr[7])
print("AM (Amido) => %f g" % BILIE_arr[8])
print("ZUC (Zuccheri) => %f g" % BILIE_arr[9])
print("Ca (Calcio) => %f g" % BILIE_arr[10])
print("P (Fosforo) => %f g" % BILIE_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % BILIE_arr[12])
print('')

# sio.sBILIEemat('BILIE.mat', {'vect':BILIE})
