# importa_MySQLdb_fieno_prato_stabile_I_taglio_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
    fieno_prato_stabile_I_taglio = []

    for i in parametri:
        i = "SELECT %s FROM Foraggio_Lys_Met WHERE nome = 'fieno_prato_stabile_I_taglio'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        fieno_prato_stabile_I_taglio.append(float(i[0]))
#   print(fieno_prato_stabile_I_taglio)

    FIEPRASTA1TA = list(np.float_(fieno_prato_stabile_I_taglio))

except mysql.connector.Error as err:
  print("Server non raggiungibile: {}".format(err))
  print('Provo ad importare <fieno_prato_stabile_I_taglio> dal modulo <foraggio_LYS_MET>') 
  from foraggio_LYS_MET import fieno_prato_stabile_I_taglio
  print('<fieno_prato_stabile_I_taglio> importato con successo dal modulo <foraggio_LYS_MET>!')

FIEPRASTA1TA = list(np.float_(fieno_prato_stabile_I_taglio))

del FIEPRASTA1TA[10]
del FIEPRASTA1TA[12:16]
del FIEPRASTA1TA[12]
del FIEPRASTA1TA[13]

FIEPRASTA1TA[0] = FIEPRASTA1TA[0]/100

for i in list(range(1, 12)):
	FIEPRASTA1TA[i] = FIEPRASTA1TA[i]*10

FIEPRASTA1TA[16] = FIEPRASTA1TA[16]*FIEPRASTA1TA[15]/100
FIEPRASTA1TA[17] = FIEPRASTA1TA[17]*FIEPRASTA1TA[15]/100

del FIEPRASTA1TA[13]
# elimina Mj

del FIEPRASTA1TA[2:4]
# elimina RDP e RUP

PDIE_FIEPRASTA1TA = FIEPRASTA1TA[12]
LysDI_FIEPRASTA1TA = FIEPRASTA1TA[13]
MetDI_FIEPRASTA1TA = FIEPRASTA1TA[14]

LysDI_MetDI_ratio = LysDI_FIEPRASTA1TA/MetDI_FIEPRASTA1TA

FIEPRASTA1TA_mod = FIEPRASTA1TA[0:12]
FIEPRASTA1TA_arr = np.array(FIEPRASTA1TA_mod)

for i in range(len(FIEPRASTA1TA_mod)):
    FIEPRASTA1TA_mod[i] = float(FIEPRASTA1TA_mod[i])

print('')
print("COMPOSIZIONE CHIMICA dell'alimento <FIENO DI PRATO STABILE DI I TAGLIO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % FIEPRASTA1TA_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % FIEPRASTA1TA_arr[1])
print("Fibra Grezza (FG) => %f g" % FIEPRASTA1TA_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % FIEPRASTA1TA_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % FIEPRASTA1TA_arr[4])
print("FAT (Grasso) => %f g" % FIEPRASTA1TA_arr[5])
print("AM (Amido) => %f g" % FIEPRASTA1TA_arr[6])
print("ZUC (Zuccheri) => %f g" % FIEPRASTA1TA_arr[7])
print("Ca (Calcio) => %f g" % FIEPRASTA1TA_arr[8])
print("P (Fosforo) => %f g" % FIEPRASTA1TA_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % FIEPRASTA1TA_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % FIEPRASTA1TA_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.savemat('FIEPRASTA1TA.mat', {'vect':FIEPRASTA1TA})
