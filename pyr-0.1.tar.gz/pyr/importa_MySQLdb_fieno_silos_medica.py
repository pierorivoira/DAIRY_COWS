# importa_MySQLdb_fieno_silos_medica.py
# pip install MySQL-connector-python
# pip3 install mysql-connector-python-rf

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj']
    fieno_silos_medica = []

    for i in parametri:
        i = "SELECT %s FROM Foraggio WHERE nome = 'fieno_silos_medica'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        fieno_silos_medica.append(float(i[0]))
#   print(FIESIME)

    FIESIME = list(np.float_(fieno_silos_medica))

except mysql.connector.Error as err:
    print("Server non raggiungibile: {}".format(err))
    print('Provo ad importare <fieno_silos_medica> dal modulo <Foraggio>') 
    from Foraggio import fieno_silos_medica
    print('<fieno_silos_medica> importato con successo dal modulo <Foraggio>!')

    FIESIME = list(np.float_(fieno_silos_medica))

    del FIESIME[13:18]
# elimino 'Mg', 'K', 'S', 'Na', 'UFC'
 
    del FIESIME[10]
# elimino 'ceneri'

    del FIESIME[13:17]
# elimino 'kcal', 'Mj'

#   print('Nuova dimensione della list <FIESIME> => %d' % len(FIESIME))

    for i in range(len(FIESIME)):
        FIESIME[i] = FIESIME[i]*10

    FIESIME[0] = FIESIME[0]/1000
    FIESIME[12] = FIESIME[12]/10

    FIESIME_arr = np.array(FIESIME)

    for i in range(len(FIESIME)):
        FIESIME[i] = float(FIESIME[i])

print("COMPOSIZIONE CHIMICA dell'alimento <FIENO-SILOS DI ERBA MEDICA>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % FIESIME_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % FIESIME_arr[1])
print("Rumen Degradable Protein (RDP, Proteina Degradabile) => %f g" % FIESIME_arr[2])
print("Rumen Undegradable Protein (RUP, Proteina Indegradabile) => %f g" % FIESIME_arr[3])
print("Fibra Grezza (FG) => %f g" % FIESIME_arr[4])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % FIESIME_arr[5])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % FIESIME_arr[6])
print("FAT (Grasso) => %f g" % FIESIME_arr[7])
print("AM (Amido) => %f g" % FIESIME_arr[8])
print("ZUC (Zuccheri) => %f g" % FIESIME_arr[9])
print("Ca (Calcio) => %f g" % FIESIME_arr[10])
print("P (Fosforo) => %f g" % FIESIME_arr[11])
print("UFL (Unità Foraggere Latte) => %f" % FIESIME_arr[12])
print('')

# sio.sFIESIMEemat('FIESIME.mat', {'vect':FIESIME})
