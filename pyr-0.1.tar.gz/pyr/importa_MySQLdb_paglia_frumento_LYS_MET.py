# importa_MySQLdb_paglia_frumento_LYS_MET.py

import mysql.connector, os
import numpy as np
# import scipy.io as sio

HOST = "piero-MacBookPro"
PORT = 3306
USER = os.getlogin()
PASSWORD = "Beowulf_666"
DB = "alimenti"

try:
    DB = mysql.connector.connect(host = HOST, port=PORT, user = USER, passwd = PASSWORD, database = DB)
    cursor = DB.cursor()		   
    parametri = ['SS', 'PG', 'RDP', 'RUP', 'FG', 'NDF', 'ADF', 'FAT', 'amido', 'zuccheri', 'ceneri', 'Ca', 'P', 'Mg', 'K', 'S', 'Na', 'UFC', 'UFL', 'kcal', 'Mj', 'PDIN', 'PDIE', 'LysDI', 'MetDI']
    paglia_frumento = []

    for i in parametri:
        i = "SELECT %s FROM Foraggio_Lys_Met WHERE nome = 'paglia_frumento'" % i
        cursor.execute(i)
        i = cursor.fetchall()
        i = i[0]
        paglia_frumento.append(float(i[0]))
#   print(paglia_frumento)

    PAFRU = list(np.float_(paglia_frumento))

except mysql.connector.Error as err:
  print("Server non raggiungibile: {}".format(err))
  print('Provo ad importare <orzo> dal modulo <fonte_di_fibra_LYS_MET>') 
  from foraggio_LYS_MET import paglia_frumento
  print('<orzo> importato con successo dal modulo <fonte_di_fibra_LYS_MET>!')

PAFRU = list(np.float_(paglia_frumento))

del PAFRU[10]
del PAFRU[12:16]
del PAFRU[12]
del PAFRU[13]

PAFRU[0] = PAFRU[0]/100

for i in list(range(1, 12)):
	PAFRU[i] = PAFRU[i]*10

PAFRU[16] = PAFRU[16]*PAFRU[15]/100
PAFRU[17] = PAFRU[17]*PAFRU[15]/100

del PAFRU[13]
# elimina Mj

del PAFRU[2:4]
# elimina RDP e RUP

PDIE_PAFRU = PAFRU[12]
LysDI_PAFRU = PAFRU[13]
MetDI_PAFRU = PAFRU[14]

LysDI_MetDI_ratio = LysDI_PAFRU/MetDI_PAFRU

PAFRU_mod = PAFRU[0:12]
PAFRU_arr = np.array(PAFRU_mod)

for i in range(len(PAFRU_mod)):
    PAFRU_mod[i] = float(PAFRU_mod[i])

print('')
print("COMPOSIZIONE CHIMICA dell'alimento <PAGLIA DI FRUMENTO>")
print('')
print("Tutti i valori sono espressi per kg di tal quale")
print('')
print("Dry Matter (DM, Sostanza Secca) => %f kg" % PAFRU_arr[0])
print("Crude Protein (CP, Proteina Grezza) => %f g" % PAFRU_arr[1])
print("Fibra Grezza (FG) => %f g" % PAFRU_arr[2])
print("Neutral Detergent Fiber (NDF, Fibra resistente al Detergente Neutro) => %f g" % PAFRU_arr[3])
print("Acid Detergent Fiber (ADF, Fibra resistente al Detergente Acido) => %f g" % PAFRU_arr[4])
print("FAT (Grasso) => %f g" % PAFRU_arr[5])
print("AM (Amido) => %f g" % PAFRU_arr[6])
print("ZUC (Zuccheri) => %f g" % PAFRU_arr[7])
print("Ca (Calcio) => %f g" % PAFRU_arr[8])
print("P (Fosforo) => %f g" % PAFRU_arr[9])
print("UFL (Unità Foraggere Latte) => %f" % PAFRU_arr[10])
print("PDI (Proteina Digeribile Intestinale) => %f g" % PAFRU_arr[11])   
print('')
print("Rapporto LISINA / METIONINA => %f" % LysDI_MetDI_ratio)
print('')
# sio.savemat('PAFRU.mat', {'vect':PAFRU})
