# scrape_tables_Bologna_L.py

# https://stackoverflow.com/questions/60377106/python3-module-tabula-has-no-attribute-read-pdf
# https://www.tutorialspoint.com/convert-pdf-to-csv-using-python
# https://www.codegrepper.com/code-examples/python/remove+first+instance+of+character+from+string+python
# https://towardsdatascience.com/how-to-show-all-columns-rows-of-a-pandas-dataframe-c49d4507fcf
# https://stackoverflow.com/questions/11768070/transform-url-string-into-normal-string-in-python-20-to-space-etc

### LINUX ###


import pandas as pd
import fileinput, io, numpy, os, re, subprocess, sys, tabula, urllib.parse
from tabula.io import read_pdf
from tabula import *
from datetime import date, datetime, timedelta
from contextlib import redirect_stdout
from urllib.parse import unquote



user = os.getlogin()
os.chdir('/home/%s/PYTHON/LINUX' % user)

today = date.today()
offset_B = (today.weekday() - 3) % 7

import datetime

if datetime.datetime.today().weekday() == 3:
    last_Thursday = today - timedelta(days=7)
    Thursday = last_Thursday
else:
    Thursday = today - timedelta(days=offset_B)
        
data_aggiornamento_B = Thursday.strftime('%d.%m.%Y')

day = Thursday.strftime('%d')
if ((day != '10') and (day != '20') and (day != '30')): 
    day = day.replace("0","",1)
else:
    day = day

month = Thursday.strftime('%m')
if month != '10':
    month = month.replace("0","",1)
else:
    month = month

year = Thursday.strftime('%Y')

giorno_di_pubblicazione_B = '%s_%s_%s' % (day, month, year)

week = Thursday.isocalendar()[1] - 1

link = unquote("https://www.bo.camcom.gov.it/sites/default/files/borsa-merci-e-rilevazione-prezzi/listino-dei-prezzi-settimanali/anno-%s/n.%d%%20-%%20%s.pdf" % (year, week, giorno_di_pubblicazione_B))

# %20 is the symbol for whitespace in url encoding

# link = link.replace(" ", "")

print("Provo a scaricare i prezzi dal link <%s>!" % link)

# os.system('wget https://www.bo.camcom.gov.it/sites/default/files/borsa-merci-e-rilevazione-prezzi/listino-dei-prezzi-settimanali/anno-%s/n.%d-%s.pdf' % (year, week, giorno_di_pubblicazione_B))

os.system('wget "%s"' % link) 


# https://www.bo.camcom.gov.it/sites/default/files/borsa-merci-e-rilevazione-prezzi/listino-dei-prezzi-settimanali/anno-2022/n.22%20-%209_6_2022.pdf


df0 = tabula.io.read_pdf('n.%d - %s.pdf' % (week, giorno_di_pubblicazione_B), pages='all')[0]
df1 = tabula.io.read_pdf('n.%d - %s.pdf' % (week, giorno_di_pubblicazione_B), pages='all')[1]
df2 = tabula.io.read_pdf('n.%d - %s.pdf' % (week, giorno_di_pubblicazione_B), pages='all')[2]
df3 = tabula.io.read_pdf('n.%d - %s.pdf' % (week, giorno_di_pubblicazione_B), pages='all')[3]
df4 = tabula.io.read_pdf('n.%d - %s.pdf' % (week, giorno_di_pubblicazione_B), pages='all')[4]
# df5 = tabula.io.read_pdf('n.%d - %s.pdf' % (week, giorno_di_pubblicazione_B), pages='all')[5]   AGRICOLTURA BIOLOGICA
df6 = tabula.io.read_pdf('n.%d - %s.pdf' % (week, giorno_di_pubblicazione_B), pages='all')[6]
df7 = tabula.io.read_pdf('n.%d - %s.pdf' % (week, giorno_di_pubblicazione_B), pages='all')[7]


pd.set_option('display.max_columns', None)

prezzi_0 = df0.to_numpy()
prezzi_1 = df1.to_numpy()
prezzi_2 = df2.to_numpy()
prezzi_3 = df3.to_numpy()
prezzi_4 = df4.to_numpy()
# prezzi_5 = df5.to_numpy()
prezzi_6 = df6.to_numpy()
prezzi_7 = df7.to_numpy()



SORGO = prezzi_0[11]
SOIA = prezzi_0[13]
MAIS = prezzi_1[17]
ORZO = prezzi_1[25]
ORZO_ESTERO = prezzi_1[27]
FRUMENTO = prezzi_1[29]
PISELLO = prezzi_1[31]
FAVINO = prezzi_1[33]
FRUMENTO_TENERO_CRUSCA = prezzi_2[5]
FRUMENTO_TENERO_CRUSCHELLO = prezzi_2[5]
FRUMENTO_TENERO_TRITELLO = prezzi_2[6]
FRUMENTO_TENERO_FARINACCIO = prezzi_2[7]
FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO = prezzi_2[14]
FRUMENTO_DURO_FARINACCIO = prezzi_2[16]
FRUMENTO_DURO_FARINETTA = prezzi_2[17]
SOIA_FE = prezzi_2[19]
GIRASOLE_INTEGRALE_FE = prezzi_2[27]
GIRASOLE_PROTEICO_ESTERO_FE = prezzi_2[28]
COLZA_FE = prezzi_2[29]
ERBA_MED_DIS_17 = prezzi_2[35]
ERBA_MED_DIS_16 = prezzi_2[36]
ERBA_MED_DIS_14 = prezzi_2[37]
FIENO_1_TAGLIO = prezzi_2[39]
FIENO_1_TAGLIO_FIBRA_LUNGA = prezzi_2[45]
MAIS_FARINA = prezzi_3[3]
MAIS_SEMOLA_GLUTINATA = prezzi_3[4]
MELASSO_CANNA = prezzi_4[1]
MELASSO_BIETOLA = prezzi_4[2]
SOIA_BUCCETTE = prezzi_4[4]
BIETOLA_POLPE = prezzi_4[5]
COTONE = prezzi_4[7]
RISO_GRANA_VERDE = prezzi_6[15]
RISO_FARINACCIO = prezzi_6[16]
RISO_PULA_VERGINE = prezzi_6[18]
FIENO_MEDICA_17_1_TAGLIO_ROTBAL = prezzi_7[10]
FIENO_MEDICA_17_1_TAGLIO_BALQUA = prezzi_7[11]
FIENO_MEDICA_17_2_TAGLIO_ROTBAL = prezzi_7[12]
FIENO_MEDICA_17_2_TAGLIO_BALQUA = prezzi_7[13]
FIENO_MEDICA_17_3_TAGLIO_ROTBAL = prezzi_7[14]
FIENO_MEDICA_17_3_TAGLIO_BALQUA = prezzi_7[15]
FIENO_MEDICA_17_4_TAGLIO_ROTBAL = prezzi_7[16]
FIENO_MEDICA_17_4_TAGLIO_BALQUA = prezzi_7[17]
PAGLIA_ROTBAL = prezzi_7[66]



try:
    prezzo_SORGO_B = float(str(SORGO[4]).replace(',','.'))
    print("Prezzo del SORGO => %f" % prezzo_SORGO_B) 
except ValueError:
    prezzo_SORGO_B = str(SORGO[4]).replace(',','.')
    print("Prezzo del SORGO => %s" % prezzo_SORGO_B) 

try:
    prezzo_SOIA_B = float(str(SOIA[4]).replace(',','.'))
    print("Prezzo della SOIA => %f" % prezzo_SOIA_B) 
except ValueError:
    prezzo_SOIA_B = str(SOIA[4]).replace(',','.')
    print("Prezzo della SOIA => %s" % prezzo_SOIA_B) 

try:
    prezzo_MAIS_B = float(str(MAIS[4]).replace(',','.'))
    print("Prezzo del MAIS => %f" % prezzo_MAIS_B)
except ValueError:
    prezzo_MAIS_B = str(MAIS[4]).replace(',','.')
    print("Prezzo del MAIS => %s" % prezzo_MAIS_B)

try:
    prezzo_ORZO_B = float(str(ORZO[4]).replace(',','.'))
    print("Prezzo dell'ORZO => %f" % prezzo_ORZO_B)
except ValueError:
    prezzo_ORZO_B = str(ORZO[4]).replace(',','.')
    print("Prezzo dell'ORZO => %s" % prezzo_ORZO_B)

try:
    prezzo_ORZO_ESTERO_B = float(str(ORZO_ESTERO[4]).replace(',','.'))
    print("Prezzo dell'ORZO_ESTERO => %f" % prezzo_ORZO_ESTERO_B)
except ValueError:
    prezzo_ORZO_ESTERO_B = str(ORZO_ESTERO[4]).replace(',','.')
    print("Prezzo dell'ORZO_ESTERO => %s" % prezzo_ORZO_ESTERO_B)

try:
    prezzo_FRUMENTO_B = float(str(FRUMENTO[4]).replace(',','.'))
    print("Prezzo del FRUMENTO => %f" % prezzo_FRUMENTO_B)
except ValueError:
    prezzo_FRUMENTO_B = str(FRUMENTO[4]).replace(',','.')
    print("Prezzo del FRUMENTO => %s" % prezzo_FRUMENTO_B)

try:
    prezzo_PISELLO_B = float(str(PISELLO[2]).replace(',','.'))
    print("Prezzo del PISELLO => %f" % prezzo_PISELLO_B)
except ValueError:
    prezzo_PISELLO_B = str(PISELLO[2]).replace(',','.')
    print("Prezzo del PISELLO => %s" % prezzo_PISELLO_B)

try:
    prezzo_FAVINO_B = float(str(FAVINO[2]).replace(',','.'))
    print("Prezzo del FAVINO => %f" % prezzo_FAVINO_B)
except ValueError:
    prezzo_FAVINO_B = str(FAVINO[2]).replace(',','.')
    print("Prezzo del FAVINO => %s" % prezzo_FAVINO_B)

try:
    prezzo_FRUMENTO_TENERO_CRUSCA_B = float(str(FRUMENTO_TENERO_CRUSCA[6]).replace(',','.'))
    print("Prezzo della CRUSCA DI FRUMENTO TENERO => %f" % prezzo_FRUMENTO_TENERO_CRUSCA_B)
except ValueError:
    prezzo_FRUMENTO_TENERO_CRUSCA_B = str(FRUMENTO_TENERO_CRUSCA[6]).replace(',','.')
    print("Prezzo della CRUSCA DI FRUMENTO TENERO => %s" % prezzo_FRUMENTO_TENERO_CRUSCA_B)

try:
    prezzo_FRUMENTO_TENERO_CRUSCHELLO_B = float(str(FRUMENTO_TENERO_CRUSCHELLO[6]).replace(',','.'))
    print("Prezzo del CRUSCHELLO DI FRUMENTO TENERO => %f" % prezzo_FRUMENTO_TENERO_CRUSCHELLO_B)
except ValueError:
    prezzo_FRUMENTO_TENERO_CRUSCHELLO_B = str(FRUMENTO_TENERO_CRUSCHELLO[6]).replace(',','.')
    print("Prezzo del CRUSCHELLO DI FRUMENTO TENERO => %s" % prezzo_FRUMENTO_TENERO_CRUSCHELLO_B)

try:
    prezzo_FRUMENTO_TENERO_TRITELLO_B = float(str(FRUMENTO_TENERO_TRITELLO[6]).replace(',','.'))
    print("Prezzo del TRITELLO DI FRUMENTO TENERO => %f" % prezzo_FRUMENTO_TENERO_TRITELLO_B)
except ValueError:
    prezzo_FRUMENTO_TENERO_TRITELLO_B = str(FRUMENTO_TENERO_TRITELLO[6]).replace(',','.')
    print("Prezzo del TRITELLO DI FRUMENTO TENERO => %s" % prezzo_FRUMENTO_TENERO_TRITELLO_B)

try:
    prezzo_FRUMENTO_TENERO_FARINACCIO_B = float(str(FRUMENTO_TENERO_FARINACCIO[6]).replace(',','.'))
    print("Prezzo del FARINACCIO DI FRUMENTO TENERO => %f" % prezzo_FRUMENTO_TENERO_FARINACCIO_B)
except ValueError:
    prezzo_FRUMENTO_TENERO_FARINACCIO_B = str(FRUMENTO_TENERO_FARINACCIO[6]).replace(',','.')
    print("Prezzo del FARINACCIO DI FRUMENTO TENERO => %s" % prezzo_FRUMENTO_TENERO_FARINACCIO_B)

try:
    prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B = float(str(FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO[6]).replace(',','.'))
    print("Prezzo della CRUSCA / CRUSCHELLO / TRITELLO DI FRUMENTO DURO => %f" % prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B)
except ValueError:
    prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B = str(FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO[6]).replace(',','.')
    print("Prezzo della CRUSCA / CRUSCHELLO / TRITELLO DI FRUMENTO DURO => %s" % prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B)

try:
    prezzo_FRUMENTO_DURO_FARINACCIO_B = float(str(FRUMENTO_DURO_FARINACCIO[6]).replace(',','.'))
    print("Prezzo del FARINACCIO DI FRUMENTO DURO => %f" % prezzo_FRUMENTO_DURO_FARINACCIO_B)
except ValueError:
    prezzo_FRUMENTO_DURO_FARINACCIO_B = str(FRUMENTO_DURO_FARINACCIO[6]).replace(',','.')
    print("Prezzo del FARINACCIO DI FRUMENTO DURO => %s" % prezzo_FRUMENTO_DURO_FARINACCIO_B)

try:
    prezzo_FRUMENTO_DURO_FARINETTA_B = float(str(FRUMENTO_DURO_FARINETTA[6]).replace(',','.'))
    print("Prezzo della FARINETTA DI FRUMENTO DURO => %f" % prezzo_FRUMENTO_DURO_FARINETTA_B)
except ValueError:
    prezzo_FRUMENTO_DURO_FARINETTA_B = str(FRUMENTO_DURO_FARINETTA[6]).replace(',','.')
    print("Prezzo della FARINETTA DI FRUMENTO DURO => %s" % prezzo_FRUMENTO_DURO_FARINETTA_B)

try:
    prezzo_SOIA_FE_B = float(str(SOIA_FE[6]).replace(',','.'))
    print("Prezzo della FARINA DI ESTRAZIONE DI SOIA => %f" % prezzo_SOIA_FE_B) 
except ValueError:
    prezzo_SOIA_FE_B = str(SOIA_FE[6]).replace(',','.')
    print("Prezzo della FARINA DI ESTRAZIONE DI SOIA => %s" % prezzo_SOIA_FE_B) 

try:
    prezzo_GIRASOLE_INTEGRALE_FE_B = float(str(GIRASOLE_INTEGRALE_FE[3]).replace(',','.'))
    print("Prezzo della FARINA DI ESTRAZIONE DI GIRASOLE INTEGRALE => %f" % prezzo_GIRASOLE_INTEGRALE_FE_B)
except ValueError:
    prezzo_GIRASOLE_INTEGRALE_FE_B = str(GIRASOLE_INTEGRALE_FE[3]).replace(',','.')
    print("Prezzo della FARINA DI ESTRAZIONE DI GIRASOLE INTEGRALE => %s" % prezzo_GIRASOLE_INTEGRALE_FE_B)

try:
    prezzo_GIRASOLE_PROTEICO_ESTERO_FE_B = float(str(GIRASOLE_PROTEICO_ESTERO_FE[6]).replace(',','.'))
    print("Prezzo della FARINA DI ESTRAZIONE DI GIRASOLE PROTEICO_ESTERO => %f" % prezzo_GIRASOLE_PROTEICO_ESTERO_FE_B)
except ValueError:
    prezzo_GIRASOLE_PROTEICO_ESTERO_FE_B = str(GIRASOLE_PROTEICO_ESTERO_FE[6]).replace(',','.')
    print("Prezzo della FARINA DI ESTRAZIONE DI GIRASOLE PROTEICO_ESTERO => %s" % prezzo_GIRASOLE_PROTEICO_ESTERO_FE_B)

try:
    prezzo_COLZA_FE_B = float(str(COLZA_FE[3]).replace(',','.'))
    print("Prezzo della FARINA DI ESTRAZIONE DI COLZA => %f" % prezzo_COLZA_FE_B) 
except ValueError:
    prezzo_COLZA_FE_B = str(COLZA_FE[3]).replace(',','.')
    print("Prezzo della FARINA DI ESTRAZIONE DI COLZA => %s" % prezzo_COLZA_FE_B) 

try:
    prezzo_ERBA_MED_DIS_17_B = float(str(ERBA_MED_DIS_17[6]).replace(',','.'))
    print("Prezzo dell'ERBA MEDICA DISIDRATATA 17x100 => %f" % prezzo_ERBA_MED_DIS_17_B) 
except ValueError:
    prezzo_ERBA_MED_DIS_17_B = str(ERBA_MED_DIS_17[6]).replace(',','.')
    print("Prezzo dell'ERBA MEDICA DISIDRATATA 17x100 => %s" % prezzo_ERBA_MED_DIS_17_B) 

try:
    prezzo_ERBA_MED_DIS_16_B = float(str(ERBA_MED_DIS_16[6]).replace(',','.'))
    print("Prezzo dell'ERBA MEDICA DISIDRATATA 16x100 => %f" % prezzo_ERBA_MED_DIS_16_B) 
except ValueError:
    prezzo_ERBA_MED_DIS_16_B = str(ERBA_MED_DIS_16[6]).replace(',','.')
    print("Prezzo dell'ERBA MEDICA DISIDRATATA 16x100 => %s" % prezzo_ERBA_MED_DIS_16_B) 

try:
    prezzo_ERBA_MED_DIS_14_B = float(str(ERBA_MED_DIS_14[6]).replace(',','.'))
    print("Prezzo dell'ERBA MEDICA DISIDRATATA 14x100 => %f" % prezzo_ERBA_MED_DIS_14_B) 
except ValueError:
    prezzo_ERBA_MED_DIS_14_B = str(ERBA_MED_DIS_14[6]).replace(',','.')
    print("Prezzo dell'ERBA MEDICA DISIDRATATA 14x100 => %s" % prezzo_ERBA_MED_DIS_14_B) 

try:
    prezzo_FIENO_1_TAGLIO_B = float(str(FIENO_1_TAGLIO[6]).replace(',','.'))
    print("Prezzo del FIENO DI I TAGLIO => %f" % prezzo_FIENO_1_TAGLIO_B)
except ValueError:
    prezzo_FIENO_1_TAGLIO_B = str(FIENO_1_TAGLIO[6]).replace(',','.')
    print("Prezzo del FIENO DI I TAGLIO => %s" % prezzo_FIENO_1_TAGLIO_B)

try:
    prezzo_FIENO_1_TAGLIO_FIBRA_LUNGA_B = float(str(FIENO_1_TAGLIO_FIBRA_LUNGA[6]).replace(',','.'))
    print("Prezzo del FIENO DI I TAGLIO A FIBRA LUNGA => %f" % prezzo_FIENO_1_TAGLIO_FIBRA_LUNGA_B)
except ValueError:
    prezzo_FIENO_1_TAGLIO_FIBRA_LUNGA_B = float(str(FIENO_1_TAGLIO_FIBRA_LUNGA[6]).replace(',','.'))
    print("Prezzo del FIENO DI I TAGLIO A FIBRA LUNGA => %s" % prezzo_FIENO_1_TAGLIO_FIBRA_LUNGA_B)

try:
    prezzo_MAIS_FARINA_B = float(str(MAIS_FARINA[4]).replace(',','.'))
    print("Prezzo della FARINA DI MAIS => %f" % prezzo_MAIS_FARINA_B)
except ValueError:
    prezzo_MAIS_FARINA_B = str(MAIS_FARINA[4]).replace(',','.')
    print("Prezzo della FARINA DI MAIS => %s" % prezzo_MAIS_FARINA_B)

try:
    prezzo_MAIS_SEMOLA_GLUTINATA_B = float(str(MAIS_SEMOLA_GLUTINATA[4]).replace(',','.'))
    print("Prezzo della SEMOLA GLUTINATA DI MAIS => %s" % prezzo_MAIS_SEMOLA_GLUTINATA_B)
except ValueError:
    prezzo_MAIS_SEMOLA_GLUTINATA_B = float(str(MAIS_SEMOLA_GLUTINATA[4]).replace(',','.'))
    print("Prezzo della SEMOLA GLUTINATA DI MAIS => %s" % prezzo_MAIS_SEMOLA_GLUTINATA_B)

try:
    prezzo_MELASSO_CANNA_B = float(str(MELASSO_CANNA[6]).replace(',','.'))
    print("Prezzo del MELASSO DI CANNA => %f" % prezzo_MELASSO_CANNA_B)
except ValueError:
    prezzo_MELASSO_CANNA_B = str(MELASSO_CANNA[6]).replace(',','.')
    print("Prezzo del MELASSO DI CANNA => %s" % prezzo_MELASSO_CANNA_B)

try:
    prezzo_MELASSO_BIETOLA_B = float(str(MELASSO_BIETOLA[6]).replace(',','.'))
    print("Prezzo del MELASSO DI BIETOLA => %f" % prezzo_MELASSO_BIETOLA_B)
except ValueError:
    prezzo_MELASSO_BIETOLA_B = float(str(MELASSO_BIETOLA[6]).replace(',','.'))
    print("Prezzo del MELASSO DI BIETOLA => %s" % prezzo_MELASSO_BIETOLA_B)

try:
    prezzo_SOIA_BUCCETTE_B = float(str(SOIA_BUCCETTE[6]).replace(',','.'))
    print("Prezzo delle BUCCETTE DI SOIA => %f" % prezzo_SOIA_BUCCETTE_B)
except ValueError:
    prezzo_SOIA_BUCCETTE_B = str(SOIA_BUCCETTE[6]).replace(',','.')
    print("Prezzo delle BUCCETTE DI SOIA => %s" % prezzo_SOIA_BUCCETTE_B)

try:
    prezzo_BIETOLA_POLPE_B = float(str(BIETOLA_POLPE[6]).replace(',','.'))
    print("Prezzo delle POLPE DI BIETOLA => %f" % prezzo_BIETOLA_POLPE_B)
except ValueError:
    prezzo_BIETOLA_POLPE_B = str(BIETOLA_POLPE[6]).replace(',','.')
    print("Prezzo delle POLPE DI BIETOLA => %s" % prezzo_BIETOLA_POLPE_B)

try:
    prezzo_COTONE_B = float(str(COTONE[6]).replace(',','.'))
    print("Prezzo del COTONE => %f" % prezzo_COTONE_B)
except ValueError:
    prezzo_COTONE_B = str(COTONE[6]).replace(',','.')
    print("Prezzo del COTONE => %s" % prezzo_COTONE_B)

try:
    prezzo_RISO_GRANA_VERDE_B = float(str(RISO_GRANA_VERDE[4]).replace(',','.'))
    print("Prezzo della GRANA VERDE DI RISO => %f" % prezzo_RISO_GRANA_VERDE_B)
except ValueError:
    prezzo_RISO_GRANA_VERDE_B = str(RISO_GRANA_VERDE[4]).replace(',','.')
    print("Prezzo della GRANA VERDE DI RISO => %s" % prezzo_RISO_GRANA_VERDE_B)

try:
    prezzo_RISO_FARINACCIO_B = float(str(RISO_FARINACCIO[4]).replace(',','.'))
    print("Prezzo del FARINACCIO DI RISO => %f" % prezzo_RISO_FARINACCIO_B)
except ValueError:
    prezzo_RISO_FARINACCIO_B = str(RISO_FARINACCIO[4]).replace(',','.')
    print("Prezzo del FARINACCIO DI RISO => %s" % prezzo_RISO_FARINACCIO_B)
    
try:    
    prezzo_RISO_PULA_VERGINE_B = float(str(RISO_PULA_VERGINE[4]).replace(',','.'))
    print("Prezzo della PULA VERGINE DI RISO => %f" % prezzo_RISO_PULA_VERGINE_B)
except ValueError:
    prezzo_RISO_PULA_VERGINE_B = str(RISO_PULA_VERGINE[4]).replace(',','.')
    print("Prezzo della PULA VERGINE DI RISO => %s" % prezzo_RISO_PULA_VERGINE_B)

try:
    prezzo_FIENO_MEDICA_17_1_TAGLIO_ROTBAL_B = float(str(FIENO_MEDICA_17_1_TAGLIO_ROTBAL[2]).replace(',','.'))
    print("Prezzo del FIENO DI MEDICA DI I TAGLIO 17x100 (in rotoballe) => %f" % prezzo_FIENO_MEDICA_17_1_TAGLIO_ROTBAL_B)
except ValueError:
    prezzo_FIENO_MEDICA_17_1_TAGLIO_ROTBAL_B = str(FIENO_MEDICA_17_1_TAGLIO_ROTBAL[2]).replace(',','.')
    print("Prezzo del FIENO DI MEDICA DI I TAGLIO 17x100 (in rotoballe) => %s" % prezzo_FIENO_MEDICA_17_1_TAGLIO_ROTBAL_B)

try:
    prezzo_FIENO_MEDICA_17_1_TAGLIO_BALQUA_B = float(str(FIENO_MEDICA_17_1_TAGLIO_BALQUA[2]).replace(',','.'))
    print("Prezzo del FIENO DI MEDICA DI I TAGLIO 17x100 (in balle quadre) => %f" % prezzo_FIENO_MEDICA_17_1_TAGLIO_BALQUA_B)
except ValueError:
    prezzo_FIENO_MEDICA_17_1_TAGLIO_BALQUA_B = str(FIENO_MEDICA_17_1_TAGLIO_BALQUA[2]).replace(',','.')
    print("Prezzo del FIENO DI MEDICA DI I TAGLIO 17x100 (in balle quadre) => %s" % prezzo_FIENO_MEDICA_17_1_TAGLIO_BALQUA_B)

try:
    prezzo_FIENO_MEDICA_17_2_TAGLIO_ROTBAL_B = float(str(FIENO_MEDICA_17_2_TAGLIO_ROTBAL[2]).replace(',','.'))
    print("Prezzo del FIENO DI MEDICA DI II TAGLIO 17x100 (in rotoballe) => %f" % prezzo_FIENO_MEDICA_17_2_TAGLIO_ROTBAL_B)
except ValueError:
    prezzo_FIENO_MEDICA_17_2_TAGLIO_ROTBAL_B = str(FIENO_MEDICA_17_2_TAGLIO_ROTBAL[2]).replace(',','.')
    print("Prezzo del FIENO DI MEDICA DI II TAGLIO 17x100 (in rotoballe) => %s" % prezzo_FIENO_MEDICA_17_2_TAGLIO_ROTBAL_B)

try:
    prezzo_FIENO_MEDICA_17_2_TAGLIO_BALQUA_B = float(str(FIENO_MEDICA_17_2_TAGLIO_BALQUA[2]).replace(',','.'))
    print("Prezzo del FIENO DI MEDICA DI II TAGLIO 17x100 (in balle quadre) => %f" % prezzo_FIENO_MEDICA_17_2_TAGLIO_BALQUA_B)
except ValueError:
    prezzo_FIENO_MEDICA_17_2_TAGLIO_BALQUA_B = str(FIENO_MEDICA_17_2_TAGLIO_BALQUA[2]).replace(',','.')
    print("Prezzo del FIENO DI MEDICA DI II TAGLIO 17x100 (in balle quadre) => %s" % prezzo_FIENO_MEDICA_17_2_TAGLIO_BALQUA_B)

try:
    prezzo_FIENO_MEDICA_17_3_TAGLIO_ROTBAL_B = float(str(FIENO_MEDICA_17_3_TAGLIO_ROTBAL[2]).replace(',','.'))
    print("Prezzo del FIENO DI MEDICA DI III TAGLIO 17x100 (in rotoballe) => %f" % prezzo_FIENO_MEDICA_17_3_TAGLIO_ROTBAL_B)
except ValueError:
    prezzo_FIENO_MEDICA_17_3_TAGLIO_ROTBAL_B = str(FIENO_MEDICA_17_3_TAGLIO_ROTBAL[2]).replace(',','.')
    print("Prezzo del FIENO DI MEDICA DI III TAGLIO 17x100 (in rotoballe) => %s" % prezzo_FIENO_MEDICA_17_3_TAGLIO_ROTBAL_B)

try:
    prezzo_FIENO_MEDICA_17_3_TAGLIO_BALQUA_B = float(str(FIENO_MEDICA_17_3_TAGLIO_BALQUA[2]).replace(',','.'))
    print("Prezzo del FIENO DI MEDICA DI III TAGLIO 17x100 (in balle quadre) => %f" % prezzo_FIENO_MEDICA_17_3_TAGLIO_BALQUA_B)
except ValueError:
    prezzo_FIENO_MEDICA_17_3_TAGLIO_BALQUA_B = str(FIENO_MEDICA_17_3_TAGLIO_BALQUA[2]).replace(',','.')
    print("Prezzo del FIENO DI MEDICA DI III TAGLIO 17x100 (in balle quadre) => %s" % prezzo_FIENO_MEDICA_17_3_TAGLIO_BALQUA_B)

try:
    prezzo_FIENO_MEDICA_17_4_TAGLIO_ROTBAL_B = float(str(FIENO_MEDICA_17_4_TAGLIO_ROTBAL[2]).replace(',','.'))
    print("Prezzo del FIENO DI MEDICA DI IV TAGLIO 17x100 (in rotoballe) => %f" % prezzo_FIENO_MEDICA_17_4_TAGLIO_ROTBAL_B)
except ValueError:
    prezzo_FIENO_MEDICA_17_4_TAGLIO_ROTBAL_B = str(FIENO_MEDICA_17_4_TAGLIO_ROTBAL[2]).replace(',','.')
    print("Prezzo del FIENO DI MEDICA DI IV TAGLIO 17x100 (in rotoballe) => %s" % prezzo_FIENO_MEDICA_17_4_TAGLIO_ROTBAL_B)

try:
    prezzo_FIENO_MEDICA_17_4_TAGLIO_BALQUA_B = float(str(FIENO_MEDICA_17_4_TAGLIO_BALQUA[2]).replace(',','.'))
    print("Prezzo del FIENO DI MEDICA DI IV TAGLIO 17x100 (in balle quadre) => %f" % prezzo_FIENO_MEDICA_17_4_TAGLIO_BALQUA_B)
except ValueError:
    prezzo_FIENO_MEDICA_17_4_TAGLIO_BALQUA_B = str(FIENO_MEDICA_17_4_TAGLIO_BALQUA[2]).replace(',','.')
    print("Prezzo del FIENO DI MEDICA DI IV TAGLIO 17x100 (in balle quadre) => %s" % prezzo_FIENO_MEDICA_17_4_TAGLIO_BALQUA_B)

try:
    prezzo_PAGLIA_BAL_QUA_B = float(str(PAGLIA_ROTBAL[6]).replace(',','.'))
    print("Prezzo della PAGLIA (in rotoballe) => %f" % prezzo_PAGLIA_BAL_QUA_B)
except ValueError:
    prezzo_PAGLIA_BAL_QUA_B = str(PAGLIA_ROTBAL[6]).replace(',','.')
    print("Prezzo della PAGLIA (in rotoballe) => %s" % prezzo_PAGLIA_BAL_QUA_B)


with open('listino_prezzi_Bologna.txt', 'w', encoding = "utf-8") as f:
    with redirect_stdout(f):
#       print('Prezzi della Borsa di Bologna aggiornati al %s' % data_aggiornamento_B)
        print(prezzo_SORGO_B)
        print(prezzo_SOIA_B)
        print(prezzo_MAIS_B)
        print(prezzo_ORZO_B)
        print(prezzo_ORZO_ESTERO_B)
        print(prezzo_FRUMENTO_B)
        print(prezzo_PISELLO_B)
        print(prezzo_FAVINO_B)
        print(prezzo_FRUMENTO_TENERO_CRUSCA_B)
        print(prezzo_FRUMENTO_TENERO_CRUSCHELLO_B)
        print(prezzo_FRUMENTO_TENERO_TRITELLO_B)
        print(prezzo_FRUMENTO_TENERO_FARINACCIO_B)
        print(prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B)
        print(prezzo_FRUMENTO_DURO_FARINACCIO_B)
        print(prezzo_FRUMENTO_DURO_FARINETTA_B)
        print(prezzo_SOIA_FE_B)
        print(prezzo_GIRASOLE_INTEGRALE_FE_B)
        print(prezzo_GIRASOLE_PROTEICO_ESTERO_FE_B)
        print(prezzo_COLZA_FE_B)
        print(prezzo_ERBA_MED_DIS_17_B)
        print(prezzo_ERBA_MED_DIS_16_B)
        print(prezzo_ERBA_MED_DIS_14_B)
        print(prezzo_FIENO_1_TAGLIO_B)
        print(prezzo_FIENO_1_TAGLIO_FIBRA_LUNGA_B)
        print(prezzo_MAIS_FARINA_B)
        print(prezzo_MAIS_SEMOLA_GLUTINATA_B)
        print(prezzo_MELASSO_CANNA_B)
        print(prezzo_MELASSO_BIETOLA_B)
        print(prezzo_SOIA_BUCCETTE_B)
        print(prezzo_BIETOLA_POLPE_B)
        print(prezzo_COTONE_B)
        print(prezzo_RISO_GRANA_VERDE_B)
        print(prezzo_RISO_FARINACCIO_B)
        print(prezzo_RISO_PULA_VERGINE_B)
        print(prezzo_FIENO_MEDICA_17_1_TAGLIO_ROTBAL_B)
        print(prezzo_FIENO_MEDICA_17_1_TAGLIO_BALQUA_B)
        print(prezzo_FIENO_MEDICA_17_2_TAGLIO_ROTBAL_B)
        print(prezzo_FIENO_MEDICA_17_2_TAGLIO_BALQUA_B)
        print(prezzo_FIENO_MEDICA_17_3_TAGLIO_ROTBAL_B)
        print(prezzo_FIENO_MEDICA_17_3_TAGLIO_BALQUA_B)
        print(prezzo_FIENO_MEDICA_17_4_TAGLIO_ROTBAL_B)
        print(prezzo_FIENO_MEDICA_17_4_TAGLIO_BALQUA_B)
        print(prezzo_PAGLIA_BAL_QUA_B)
