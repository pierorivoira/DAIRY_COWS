# stampa_PREZZI_L.py


#####################################
########### LINUX VERSION ###########
#####################################

import os
from pathlib import Path

user = os.getlogin()
os.chdir('/home/%s/PYTHON/LINUX' % user)
cartella = os.getcwd()

from datetime import date, datetime, timedelta
from dateutil.relativedelta import relativedelta
import datetime

last_year = (datetime.datetime.now()-relativedelta(years=1)).strftime('%Y')

today = date.today()
offset_B = (today.weekday() - 3) % 7

if datetime.datetime.today().weekday() == 3:
    last_Thursday = today - timedelta(days=7)
    Thursday = last_Thursday
else:
    Thursday = today - timedelta(days=offset_B)
        
data_aggiornamento_B = Thursday.strftime('%d.%m.%Y')

today = date.today()
offset_F = (today.weekday() - 2) % 7

import datetime

if datetime.datetime.today().weekday() == 2:
	last_Wednesday = today - timedelta(days=7)
	Wednesday = last_Wednesday
else:
	Wednesday = today - timedelta(days=offset_F)

data_aggiornamento_F = Wednesday.strftime('%d.%m.%Y')

if Path("listino_prezzi_Milano.txt").exists():
    with open('listino_prezzi_Milano.txt', 'r') as file:
        intestazione_Milano = file.readlines()[0]
else:
    print('Impossibile trovare la data di aggiornamento del LISTINO PREZZI <BORSA MERCI di Milano>!')
    print('')

try:
    from crea_db_PREZZI_Alessandria_L import prezzo_LOIETTO_INSILATO
    from crea_db_PREZZI_Alessandria_L import prezzo_MAIS_INSILATO
    from crea_db_PREZZI_Alessandria_L import prezzo_LUPINO

    print('')
    print('______________________________________________________________________________________________')
    print('|                                            |                        |                       |')
    print('|                                            |         PREZZO         |                       |')
    print('|                 ALIMENTO                   |       (EURO/ton)       |         FONTE         |')
    print('|                                            |                        |                       |')
    print('|____________________________________________|________________________|_______________________|')
    print('')
    print("Prezzi della Borsa di Alessandria => valori medi annuali riferiti all'anno %s" % last_year)
    print('|       INSILATO DI LOIETTO                  |      %s              | Borsa Merci di Alessandria |' % prezzo_LOIETTO_INSILATO)
    print('|       INSILATO DI MAIS                     |      %s              | Borsa Merci di Alessandria |' % prezzo_MAIS_INSILATO)
    print('|       LUPINO (prezzo medio)                |      %s              | Borsa Merci di Alessandria  |' % prezzo_LUPINO)
    
except ImportError:
    print('Impossibile trovare la data di aggiornamento del LISTINO PREZZI <BORSA MERCI di Alessandria>!')
    print('')

try:
    from crea_db_PREZZI_clal_L import prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR
    from crea_db_PREZZI_clal_L import prezzo_FIENO_MEDICA_1_TG_COSTO_PR
    from crea_db_PREZZI_clal_L import prezzo_FIENO_MEDICA_2_TG_COSTO_PR
    from crea_db_PREZZI_clal_L import prezzo_FIENO_PRATO_POLIFITA_COSTO_PR
    print('')
    print('')
    print('Prezzi clal => valori medi riferiti agli ultimi 6 mesi')
    print('')
    print('|       PASTONE INTEGR. DI MAIS (costo pr.)  |      %s              | https://www.clal.it |' % prezzo_MAIS_PASTONE_INTEGRALE_COSTO_PR)
    print('|       FIENO DI MEDICA DI 1 TG (costo pr.)  |      %s              | https://www.clal.it |' % prezzo_FIENO_MEDICA_1_TG_COSTO_PR)
    print('|       FIENO DI MEDICA DI 2 TG (costo pr.)  |      %s              | https://www.clal.it |' % prezzo_FIENO_MEDICA_2_TG_COSTO_PR)
    print('|       FIENO DI PRATO POLIFITA (costo pr.)  |      %s              | https://www.clal.it |' % prezzo_FIENO_PRATO_POLIFITA_COSTO_PR)
except ImportError:
    print('Impossibile trovare la data di aggiornamento del LISTINO PREZZI <CLAL>!')
    print('')

try:
    from crea_db_PREZZI_Bologna_L import prezzo_FRUMENTO_TENERO_FARINACCIO_B
    from crea_db_PREZZI_Bologna_L import prezzo_FRUMENTO_TENERO_TRITELLO_B
    from crea_db_PREZZI_Bologna_L import prezzo_FRUMENTO_TENERO_CRUSCA_B
    from crea_db_PREZZI_Bologna_L import prezzo_FRUMENTO_TENERO_CRUSCHELLO_B
    from crea_db_PREZZI_Bologna_L import prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B
    from crea_db_PREZZI_Bologna_L import prezzo_FRUMENTO_DURO_FARINACCIO_B
    from crea_db_PREZZI_Bologna_L import prezzo_FRUMENTO_DURO_FARINETTA_B
    from crea_db_PREZZI_Bologna_L import prezzo_MAIS_B
    from crea_db_PREZZI_Bologna_L import prezzo_MAIS_FARINA_B
    from crea_db_PREZZI_Bologna_L import prezzo_MAIS_SEMOLA_GLUTINATA_B
    from crea_db_PREZZI_Bologna_L import prezzo_FRUMENTO_B
    from crea_db_PREZZI_Bologna_L import prezzo_ORZO_B
    from crea_db_PREZZI_Bologna_L import prezzo_ORZO_ESTERO_B
    from crea_db_PREZZI_Bologna_L import prezzo_SORGO_B
    from crea_db_PREZZI_Bologna_L import prezzo_PISELLO_B
    from crea_db_PREZZI_Bologna_L import prezzo_FAVINO_B
    from crea_db_PREZZI_Bologna_L import prezzo_SOIA_B
    from crea_db_PREZZI_Bologna_L import prezzo_COLZA_FE_B
    from crea_db_PREZZI_Bologna_L import prezzo_GIRASOLE_INTEGRALE_FE_B
    from crea_db_PREZZI_Bologna_L import prezzo_GIRASOLE_PROTEICO_ESTERO_FE_B
    from crea_db_PREZZI_Bologna_L import prezzo_SOIA_FE_B
    from crea_db_PREZZI_Bologna_L import prezzo_ERBA_MED_DIS_17_B
    from crea_db_PREZZI_Bologna_L import prezzo_ERBA_MED_DIS_16_B
    from crea_db_PREZZI_Bologna_L import prezzo_ERBA_MED_DIS_14_B
    from crea_db_PREZZI_Bologna_L import prezzo_MELASSO_CANNA_B
    from crea_db_PREZZI_Bologna_L import prezzo_MELASSO_BIETOLA_B
    from crea_db_PREZZI_Bologna_L import prezzo_FIENO_1_TAGLIO_B
    from crea_db_PREZZI_Bologna_L import prezzo_FIENO_1_TAGLIO_FIBRA_LUNGA_B
    from crea_db_PREZZI_Bologna_L import prezzo_FIENO_MEDICA_17_1_TAGLIO_ROTBAL_B
    from crea_db_PREZZI_Bologna_L import prezzo_FIENO_MEDICA_17_1_TAGLIO_BALQUA_B
    from crea_db_PREZZI_Bologna_L import prezzo_FIENO_MEDICA_17_2_TAGLIO_ROTBAL_B
    from crea_db_PREZZI_Bologna_L import prezzo_FIENO_MEDICA_17_2_TAGLIO_BALQUA_B
    from crea_db_PREZZI_Bologna_L import prezzo_FIENO_MEDICA_17_3_TAGLIO_ROTBAL_B
    from crea_db_PREZZI_Bologna_L import prezzo_FIENO_MEDICA_17_3_TAGLIO_BALQUA_B
    from crea_db_PREZZI_Bologna_L import prezzo_FIENO_MEDICA_17_4_TAGLIO_ROTBAL_B
    from crea_db_PREZZI_Bologna_L import prezzo_FIENO_MEDICA_17_4_TAGLIO_BALQUA_B
    from crea_db_PREZZI_Bologna_L import prezzo_PAGLIA_BAL_QUA_B
    from crea_db_PREZZI_Bologna_L import prezzo_SOIA_BUCCETTE_B
    from crea_db_PREZZI_Bologna_L import prezzo_BIETOLA_POLPE_B
    from crea_db_PREZZI_Bologna_L import prezzo_RISO_GRANA_VERDE_B
    from crea_db_PREZZI_Bologna_L import prezzo_RISO_FARINACCIO_B
    from crea_db_PREZZI_Bologna_L import prezzo_RISO_PULA_VERGINE_B
    from crea_db_PREZZI_Bologna_L import prezzo_COTONE_B
    print('')
    print('')
    print('Prezzi della Borsa di Bologna aggiornati al %s' % data_aggiornamento_B)
    print('')
    print('|       FARINACCIO DI FRUMENTO TENERO        |      %s              | Borsa Merci di Bologna |' % prezzo_FRUMENTO_TENERO_FARINACCIO_B)
    print('|       TRITELLO DI FRUMENTO TENERO          |      %s              | Borsa Merci di Bologna |' % prezzo_FRUMENTO_TENERO_TRITELLO_B)
    print('|       CRUSCA DI FRUMENTO TENERO            |      %s              | Borsa Merci di Bologna |' % prezzo_FRUMENTO_TENERO_CRUSCA_B)
    print('|       CRUSCHELLO DI FRUMENTO TENERO        |      %s              | Borsa Merci di Bologna |' % prezzo_FRUMENTO_TENERO_CRUSCHELLO_B)
    print('|       CRUSCA, CRUSCHELLO E TRITELLO F. D.  |      %s              | Borsa Merci di Bologna |' % prezzo_FRUMENTO_DURO_CRUSCA_CRUSCHELLO_TRITELLO_B)
    print('|       FARINACCIO DI FRUMENTO DURO          |      %s              | Borsa Merci di Bologna |' % prezzo_FRUMENTO_DURO_FARINACCIO_B)
    print('|       FARINETTA DI FRUMENTO DURO           |      %s              | Borsa Merci di Bologna |' % prezzo_FRUMENTO_DURO_FARINETTA_B)
    print('|       MAIS                                 |      %s              | Borsa Merci di Bologna |' % prezzo_MAIS_B)
    print('|       FARINA DI MAIS                       |      %s              | Borsa Merci di Bologna |' % prezzo_MAIS_FARINA_B)
    print('|       SEMOLA GLUTINATA DI MAIS             |      %s              | Borsa Merci di Bologna |' % prezzo_MAIS_SEMOLA_GLUTINATA_B)
    print('|       FRUMENTO                             |      %s              | Borsa Merci di Bologna |' % prezzo_FRUMENTO_B)
    print('|       ORZO                                 |      %s              | Borsa Merci di Bologna |' % prezzo_ORZO_B)
    print('|       SORGO                                |      %s              | Borsa Merci di Bologna |' % prezzo_SORGO_B)
    print('|       PISELLO                              |      %s              | Borsa Merci di Bologna |' % prezzo_PISELLO_B)
    print('|       FAVINO DA GRANELLA                   |      %s              | Borsa Merci di Bologna |' % prezzo_FAVINO_B)
    print('|       SOIA                                 |      %s              | Borsa Merci di Bologna |' % prezzo_SOIA_B)
    print('|       FARINA DI ESTRAZIONE DI COLZA        |      %s              | Borsa Merci di Bologna |' % prezzo_COLZA_FE_B)
    print('|       FARINA DI ESTRAZIONE DI GIRASOLE INT.|      %s              | Borsa Merci di Bologna |' % prezzo_GIRASOLE_INTEGRALE_FE_B)
    print('|       FARINA DI ESTRAZIONE DI SOIA         |      %s              | Borsa Merci di Bologna |' % prezzo_SOIA_FE_B)
    print('|       ERBA MEDICA DISIDRATATA 17x100       |      %s              | Borsa Merci di Bologna |' % prezzo_ERBA_MED_DIS_17_B)
    print('|       ERBA MEDICA DISIDRATATA 16x100       |      %s              | Borsa Merci di Bologna |' % prezzo_ERBA_MED_DIS_16_B)
    print('|       ERBA MEDICA DISIDRATATA 14x100       |      %s              | Borsa Merci di Bologna |' % prezzo_ERBA_MED_DIS_14_B)
    print('|       POLPE DI BIETOLA                     |      %s              | Borsa Merci di Bologna |' % prezzo_BIETOLA_POLPE_B)
    print('|       FIENO DI 1 TAGLIO                    |      %s              | Borsa Merci di Bologna |' % prezzo_FIENO_1_TAGLIO_B)
    print('|       FIENO DI 1 TAGLIO FIBRA LUNGA        |      %s              | Borsa Merci di Bologna |' % prezzo_FIENO_1_TAGLIO_FIBRA_LUNGA_B)
    print('|       FIENO MEDICA 17x100 1 TAG. IN ROTOB. |      %s              | Borsa Merci di Bologna |' % prezzo_FIENO_MEDICA_17_1_TAGLIO_ROTBAL_B)
    print('|       FIENO MEDICA 17x100 1 TAG. IN BALL.Q.|      %s              | Borsa Merci di Bologna |' % prezzo_FIENO_MEDICA_17_1_TAGLIO_BALQUA_B)
    print('|       FIENO MEDICA 17x100 2 TAG. IN ROTOB. |      %s              | Borsa Merci di Bologna |' % prezzo_FIENO_MEDICA_17_2_TAGLIO_ROTBAL_B)
    print('|       FIENO MEDICA 17x100 2 TAG. IN BALL.Q.|      %s              | Borsa Merci di Bologna |' % prezzo_FIENO_MEDICA_17_2_TAGLIO_BALQUA_B)
    print('|       FIENO MEDICA 17x100 3 TAG. IN ROTOB. |      %s              | Borsa Merci di Bologna |' % prezzo_FIENO_MEDICA_17_3_TAGLIO_ROTBAL_B)
    print('|       FIENO MEDICA 17x100 3 TAG. IN BALL.Q.|      %s              | Borsa Merci di Bologna |' % prezzo_FIENO_MEDICA_17_3_TAGLIO_BALQUA_B)
    print('|       FIENO MEDICA 17x100 4 TAG. IN ROTOB. |      %s              | Borsa Merci di Bologna |' % prezzo_FIENO_MEDICA_17_4_TAGLIO_ROTBAL_B)
    print('|       FIENO MEDICA 17x100 4 TAG. IN BALL.Q.|      %s              | Borsa Merci di Bologna |' % prezzo_FIENO_MEDICA_17_4_TAGLIO_BALQUA_B)
    print('|       PAGLIA                               |      %s              | Borsa Merci di Bologna |' % prezzo_PAGLIA_BAL_QUA_B)
    print('|       MELASSO DI CANNA                     |      %s              | Borsa Merci di Bologna |' % prezzo_MELASSO_CANNA_B)
    print('|       MELASSO DI BIETOLA                   |      %s              | Borsa Merci di Bologna |' % prezzo_MELASSO_BIETOLA_B)
    print('|       BUCCETTE DI SOIA                     |      %s              | Borsa Merci di Bologna |' % prezzo_SOIA_BUCCETTE_B)
    print('|       GRANA VERDE DI RISO                  |      %s              | Borsa Merci di Bologna |' % prezzo_RISO_GRANA_VERDE_B)
    print('|       FARINACCIO  DI RISO                  |      %s              | Borsa Merci di Bologna |' % prezzo_RISO_FARINACCIO_B)
    print('|       PULA VERGINE DI RISO                 |      %s              | Borsa Merci di Bologna |' % prezzo_RISO_PULA_VERGINE_B)
    print('|       SEMI DI COTONE                       |      %s              | Borsa Merci di Bologna |' % prezzo_COTONE_B)
    
except ImportError:
    print('Impossibile trovare la data di aggiornamento del LISTINO PREZZI <BORSA MERCI di Bologna>!')
    print('')


try:
    from crea_db_PREZZI_Milano_L import prezzo_FRUMENTO_TENERO_FARINACCIO
    prezzo_FRUMENTO_TENERO_FARINACCIO = str(prezzo_FRUMENTO_TENERO_FARINACCIO)
    from crea_db_PREZZI_Milano_L import prezzo_FRUMENTO_TENERO_TRITELLO
    prezzo_FRUMENTO_TENERO_TRITELLO = str(prezzo_FRUMENTO_TENERO_TRITELLO)
    from crea_db_PREZZI_Milano_L import prezzo_FRUMENTO_TENERO_CRUSCA
    prezzo_FRUMENTO_TENERO_CRUSCA = str(prezzo_FRUMENTO_TENERO_CRUSCA)
    from crea_db_PREZZI_Milano_L import prezzo_FRUMENTO_TENERO_CRUSCHELLO
    prezzo_FRUMENTO_TENERO_CRUSCHELLO = str(prezzo_FRUMENTO_TENERO_CRUSCHELLO)
    from crea_db_PREZZI_Milano_L import prezzo_FRUMENTO_TENERO_GERME
    prezzo_FRUMENTO_TENERO_GERME = str(prezzo_FRUMENTO_TENERO_GERME)
    from crea_db_PREZZI_Milano_L import prezzo_FRUMENTO_DURO_FARINACCIO
    prezzo_FRUMENTO_DURO_FARINACCIO = str(prezzo_FRUMENTO_DURO_FARINACCIO)
    from crea_db_PREZZI_Milano_L import prezzo_MAIS
    prezzo_MAIS = str(prezzo_MAIS)
    from crea_db_PREZZI_Milano_L import prezzo_MAIS_GLUTINE
    prezzo_MAIS_GLUTINE = str(prezzo_MAIS_GLUTINE) 
    from crea_db_PREZZI_Milano_L import prezzo_MAIS_FARINA_GLUTINATA
    prezzo_MAIS_FARINA_GLUTINATA = str(prezzo_MAIS_FARINA_GLUTINATA)
    from crea_db_PREZZI_Milano_L import prezzo_MAIS_SEMOLA_GLUTINATA
    prezzo_MAIS_SEMOLA_GLUTINATA = str(prezzo_MAIS_SEMOLA_GLUTINATA)
    from crea_db_PREZZI_Milano_L import prezzo_SEGALE
    prezzo_SEGALE = str(prezzo_SEGALE)
    from crea_db_PREZZI_Milano_L import prezzo_ORZO
    prezzo_ORZO = str(prezzo_ORZO)
    from crea_db_PREZZI_Milano_L import prezzo_AVENA
    prezzo_AVENA = str(prezzo_AVENA)
    from crea_db_PREZZI_Milano_L import prezzo_TRITICALE
    prezzo_TRITICALE = str(prezzo_TRITICALE)
    from crea_db_PREZZI_Milano_L import prezzo_SORGO
    prezzo_SORGO = str(prezzo_SORGO)
    from crea_db_PREZZI_Milano_L import prezzo_MANIOCA
    prezzo_MANIOCA = str(prezzo_MANIOCA)
    from crea_db_PREZZI_Milano_L import prezzo_PISELLO
    prezzo_PISELLO = str(prezzo_PISELLO)
    from crea_db_PREZZI_Milano_L import prezzo_SOIA
    prezzo_SOIA = str(prezzo_SOIA)
    from crea_db_PREZZI_Milano_L import prezzo_COLZA_FE
    prezzo_COLZA_FE = str(prezzo_COLZA_FE)
    from crea_db_PREZZI_Milano_L import prezzo_GIRASOLE_DECORTICATO_FE
    prezzo_GIRASOLE_DECORTICATO_FE_B = str(prezzo_GIRASOLE_DECORTICATO_FE)
    from crea_db_PREZZI_Milano_L import prezzo_SOIA_FE
    prezzo_SOIA_FE = str(prezzo_SOIA_FE)
    from crea_db_PREZZI_Milano_L import prezzo_ERBA_MEDICA_DIS_EXTRA
    prezzo_ERBA_MEDICA_DIS_EXTRA = str(prezzo_ERBA_MEDICA_DIS_EXTRA)
    from crea_db_PREZZI_Milano_L import prezzo_ERBA_MEDICA_DIS_1_QUAL
    prezzo_ERBA_MEDICA_DIS_1_QUAL = str(prezzo_ERBA_MEDICA_DIS_1_QUAL)
    from crea_db_PREZZI_Milano_L import prezzo_MELASSO
    prezzo_MELASSO = str(prezzo_MELASSO)
    from crea_db_PREZZI_Milano_L import prezzo_BIETOLA_POLPE_SECCHE
    prezzo_BIETOLA_POLPE_SECCHE = str(prezzo_BIETOLA_POLPE_SECCHE)
    from crea_db_PREZZI_Milano_L import prezzo_CARRUBE_FRANTUMATE
    prezzo_CARRUBE_FRANTUMATE = str(prezzo_CARRUBE_FRANTUMATE)
    from crea_db_PREZZI_Milano_L import prezzo_FIENO_MAGGENGO
    prezzo_FIENO_MAGGENGO = str(prezzo_FIENO_MAGGENGO)
    from crea_db_PREZZI_Milano_L import prezzo_FIENO_AGOSTANO
    prezzo_FIENO_AGOSTANO = str(prezzo_FIENO_AGOSTANO)
    from crea_db_PREZZI_Milano_L import prezzo_FIENO_MEDICA
    prezzo_FIENO_MEDICA = str(prezzo_FIENO_MEDICA)
    from crea_db_PREZZI_Milano_L import prezzo_PAGLIA
    prezzo_PAGLIA = str(prezzo_PAGLIA)
    from crea_db_PREZZI_Milano_L import prezzo_SOIA_BUCCETTE
    prezzo_SOIA_BUCCETTE = str(prezzo_SOIA_BUCCETTE)
    from crea_db_PREZZI_Milano_L import prezzo_RISO_GRANA_VERDE
    prezzo_RISO_GRANA_VERDE = str(prezzo_RISO_GRANA_VERDE)
    from crea_db_PREZZI_Milano_L import prezzo_RISO_FARINACCIO
    prezzo_RISO_FARINACCIO = str(prezzo_RISO_FARINACCIO)
    from crea_db_PREZZI_Milano_L import prezzo_RISO_PULA_VERGINE
    prezzo_RISO_PULA_VERGINE = str(prezzo_RISO_PULA_VERGINE)
    print('')
    print('')
    print('%s' % intestazione_Milano)
    print('|       FARINACCIO DI FRUMENTO TENERO        |      %s              | Borsa Merci di Milano |' % prezzo_FRUMENTO_TENERO_FARINACCIO)
    print('|       TRITELLO DI FRUMENTO TENERO          |      %s              | Borsa Merci di Milano |' % prezzo_FRUMENTO_TENERO_TRITELLO)
    print('|       CRUSCA DI FRUMENTO TENERO            |      %s              | Borsa Merci di Milano |' % prezzo_FRUMENTO_TENERO_CRUSCA)
    print('|       CRUSCHELLO DI FRUMENTO TENERO        |      %s              | Borsa Merci di Milano |' % prezzo_FRUMENTO_TENERO_CRUSCHELLO)
    print('|       GERME DI FRUMENTO TENERO             |      %s              | Borsa Merci di Milano |' % prezzo_FRUMENTO_TENERO_GERME)
    print('|       FARINACCIO DI FRUMENTO DURO          |      %s              | Borsa Merci di Milano |' % prezzo_FRUMENTO_DURO_FARINACCIO)
    print('|       MAIS                                 |      %s              | Borsa Merci di Milano |' % prezzo_MAIS)
    print('|       GLUTINE DI MAIS                      |      %s              | Borsa Merci di Milano |' % prezzo_MAIS_GLUTINE)
    print('|       FARINA GLUTINATA DI MAIS             |      %s              | Borsa Merci di Milano |' % prezzo_MAIS_FARINA_GLUTINATA)
    print('|       SEMOLA GLUTINATA DI MAIS             |      %s              | Borsa Merci di Milano |' % prezzo_MAIS_SEMOLA_GLUTINATA)
    print('|       SEGALE             		        |      %s              | Borsa Merci di Milano |' % prezzo_SEGALE)
    print('|       ORZO                                 |      %s              | Borsa Merci di Milano |' % prezzo_ORZO)
    print('|       AVENA                                |      %s              | Borsa Merci di Milano |' % prezzo_AVENA)
    print('|       TRITICALE                            |      %s              | Borsa Merci di Milano |' % prezzo_TRITICALE)
    print('|       SORGO                                |      %s              | Borsa Merci di Milano |' % prezzo_SORGO)
    print('|       MANIOCA                              |      %s              | Borsa Merci di Milano |' % prezzo_MANIOCA)
    print('|       PISELLO                              |      %s              | Borsa Merci di Milano |' % prezzo_PISELLO)
    print('|       SOIA                                 |      %s              | Borsa Merci di Milano |' % prezzo_SOIA)
    print('|       FARINA DI ESTRAZIONE DI COLZA        |      %s              | Borsa Merci di Milano |' % prezzo_COLZA_FE)
    print('|       FARINA DI ESTRAZIONE DI GIRASOLE DEC.|      %s              | Borsa Merci di Milano |' % prezzo_GIRASOLE_DECORTICATO_FE)
    print('|       FARINA DI ESTRAZIONE DI SOIA         |      %s              | Borsa Merci di Milano |' % prezzo_SOIA_FE)
    print('|       ERBA MEDICA DISIDRATATA EXTRA        |      %s              | Borsa Merci di Milano |' % prezzo_ERBA_MEDICA_DIS_EXTRA)
    print('|       ERBA MEDICA DISIDRATATA DI 1 QUALITÀ |      %s              | Borsa Merci di Milano |' % prezzo_ERBA_MEDICA_DIS_1_QUAL)
    print('|       POLPE SECCHE DI BIETOLA              |      %s              | Borsa Merci di Milano |' % prezzo_BIETOLA_POLPE_SECCHE)
    print('|       CARRUBE FRANTUMATE                   |      %s              | Borsa Merci di Milano |' % prezzo_CARRUBE_FRANTUMATE)
    print('|       FIENO MAGGENGO                       |      %s              | Borsa Merci di Milano |' % prezzo_FIENO_MAGGENGO)
    print('|       FIENO AGOSTANO                       |      %s              | Borsa Merci di Milano |' % prezzo_FIENO_AGOSTANO)
    print('|       FIENO MEDICA                         |      %s              | Borsa Merci di Milano |' % prezzo_FIENO_MEDICA)
    print('|       PAGLIA                               |      %s              | Borsa Merci di Milano |' % prezzo_PAGLIA)
    print('|       MELASSO                              |      %s              | Borsa Merci di Milano |' % prezzo_MELASSO)
    print('|       BUCCETTE DI SOIA                     |      %s              | Borsa Merci di Milano |' % prezzo_SOIA_BUCCETTE)
    print('|       GRANA VERDE DI RISO                  |      %s              | Borsa Merci di Milano |' % prezzo_RISO_GRANA_VERDE)
    print('|       FARINACCIO  DI RISO                  |      %s              | Borsa Merci di Milano |' % prezzo_RISO_FARINACCIO)
    print('|       PULA VERGINE DI RISO                 |      %s              | Borsa Merci di Milano |' % prezzo_RISO_PULA_VERGINE)
    print('______________________________________________________________________________________________')
    
except ImportError:
    print('Impossibile trovare la data di aggiornamento del LISTINO PREZZI <BORSA MERCI di Milano>!')
    print('')



